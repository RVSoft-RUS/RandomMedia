#!/bin/bash

set -xe

export GRADLE_USER_HOME="/home/${USER}/.gradle/"
export GRADLE_OPTS='-Dorg.gradle.daemon=false -Dorg.gradle.logging.level=info'

echo "Running Docker containers"
docker run --rm \
--name "${GROUP_ID}-${REPO_NAME}-${BUILD_NUMBER}-${STAGE_NAME// /_}-${JENKINS_NODE_COOKIE}" \
-e LANG -e LOCAL_USER="${USER}" -e LOCAL_USER_ID="$(id -u)" \
-e GRADLE_OPTS -e GRADLE_USER_HOME \
-e NEXUS_BASE_URL -e GROUP_ID \
--mount type=volume,source="${GROUP_ID}-${REPO_NAME}-buildcache",target="/home" \
--mount type=bind,src="$(pwd)",target="/src" \
--net=host \
-w /src \
"${JDK_IMAGE}" \
-c "/bin/sh ./gradlew ${GRADLE_ARGS} $*"
