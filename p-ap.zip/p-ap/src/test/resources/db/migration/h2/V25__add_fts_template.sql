INSERT INTO template_new
(dbo_pro_id, name, date_created, last_modified_date, status, doc_type,
 purpose, pay_priority, payment_basis, basis_document_number, basis_document_created, tax_period,
 uin, kbk, oktmo, payee_name, payee_account,
 payee_inn,payee_kpp, payee_bank_name, payee_bank_bic, payee_bank_correspondent_account)
VALUES('FTS', 'Общий шаблон ФТС', '2023-12-31 23:59:59.927', '2023-12-31 23:59:59.927', 'ACTIVE', 'DE',
       'Авансовый платеж для единого лицевого счета, открытого в ФТС России. Без НДС', '5', '0', '0', '0', '10000010',
       '0', '0', '45328000', 'Межрегиональное операционное УФК (ФТС России)', '03100643000000019502',
       '7730176610', '773001001', 'Межрегиональное операционное УФК', '024501901', '40102810045370000002');