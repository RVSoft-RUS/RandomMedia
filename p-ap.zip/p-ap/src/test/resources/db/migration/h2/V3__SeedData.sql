INSERT INTO document
           (number
           ,date
           ,status
           ,doctype
           ,purpose
           ,amount
           ,paypriority
           ,urgent
           ,payer_status
           ,payer_name
           ,payer_account
           ,payer_inn
           ,payer_bank_name
           ,payer_bank_bic
           ,payer_bank_correspondent_account
           ,payee_name
           ,payee_account
           ,payee_inn
           ,payee_kpp
           ,payee_bank_name
           ,payee_bank_bic
           ,payee_bank_correspondent_account
           ,rem_ip
           ,show_error
           ,client_id
           ,type_tax_payment
           ,organization_bis_id
           ,organization_bis_branch
           ,organization_crm_id
           ,organization_short_name)
     VALUES
           ('777'
           ,'2021-01-23 00:00:00.000'
           ,'CREATED'
           ,'DG'
           ,'гос пошлинаБез НДС test'
           ,15.00
           ,'5'
           ,'0'
           ,'01'
           ,'ИП Донварь Кристина Валерьевна'
           ,'40802810597880000207'
           ,'450146852396'
           ,'Московский филиал ПАО "РОСБАНК"'
           ,'044525256'
           ,'30101810000000000256'
           ,'20/110'
           ,'40802810397880000326'
           ,'450146852396'
           ,'0'
           ,'ПАО РОСБАНК'
           ,'044525256'
           ,'30101810000000000256'
           ,'10.35.5.45'
           ,1
           ,704
           ,0
           ,'2F5954'
           ,'R19'
           ,'1-QZA-320'
           ,'ИП Донварь Кристина Валерьевна');

INSERT INTO document
           (number
           ,date
           ,status
           ,doctype
           ,purpose
           ,amount
           ,paypriority
           ,urgent
           ,payer_name
           ,payer_account
           ,payer_inn
           ,payer_bank_name
           ,payer_bank_bic
           ,payer_bank_correspondent_account
           ,payee_name
           ,payee_account
           ,payee_inn
           ,payee_kpp
           ,payee_bank_name
           ,payee_bank_bic
           ,payee_bank_correspondent_account
           ,rem_ip
           ,dbo_pro_id
           ,show_error
           ,client_id
           ,type_tax_payment
           ,execution_date
           ,sign_date
           ,organization_bis_id
           ,organization_bis_branch
           ,organization_crm_id
           ,organization_short_name)
     VALUES
           ('778'
           ,'2021-01-17 00:00:00.000'
           ,'SIGNED'
           ,'DG'
           ,' Без НДС'
           ,200.00
           ,'5'
           ,'0'
           ,'ИП Донварь Кристина Валерьевна'
           ,'40702810393790000591'
           ,'450146852396'
           ,'Московский филиал ПАО "РОСБАНК"'
           ,'044525256'
           ,'30101810000000000256'
           ,'20/110'
           ,'40802810397880000326'
           ,'450146852396'
           ,'0'
           ,'ПАО РОСБАНК'
           ,'044525256'
           ,'30101810000000000256'
           ,'10.35.5.45'
           ,null
           ,1
           ,704
           ,null
           ,now()
           ,'2021-01-17 00:00:00.000'
           ,'2F5954'
           ,'R19'
           ,'1-QZA-320'
           ,null);

INSERT INTO document
           (number
           ,date
           ,status
           ,doctype
           ,purpose
           ,amount
           ,paypriority
           ,urgent
           ,payer_name
           ,payer_account
           ,payer_inn
           ,payer_bank_name
           ,payer_bank_bic
           ,payer_bank_correspondent_account
           ,payee_name
           ,payee_account
           ,payee_inn
           ,payee_kpp
           ,payee_bank_name
           ,payee_bank_bic
           ,payee_bank_correspondent_account
           ,rem_ip
           ,dbo_pro_id
           ,show_error
           ,client_id
           ,type_tax_payment
           ,execution_date
           ,sign_date
           ,organization_bis_id
           ,organization_bis_branch
           ,organization_crm_id
           ,organization_short_name)
     VALUES
           ('779'
           ,'2021-01-17 00:00:00.000'
           ,'PLANNED'
           ,'DG'
           ,' Без НДС'
           ,300.00
           ,'5'
           ,'0'
           ,'ИП Донварь Кристина Валерьевна'
           ,'40802810597880000207'
           ,'450146852396'
           ,'Московский филиал ПАО "РОСБАНК"'
           ,'044525256'
           ,'30101810000000000256'
           ,'20/110'
           ,'40802810397880000326'
           ,'450146852396'
           ,'0'
           ,'ПАО РОСБАНК'
           ,'044525256'
           ,'30101810000000000256'
           ,'10.35.5.45'
           ,null
           ,1
           ,704
           ,0
           ,now()
           ,null
           ,'2F5954'
           ,'R19'
           ,'1-QZA-320'
           ,'ИП Донварь Кристина Валерьевна');

INSERT INTO imported_document
    (id
    ,batch
    ,created
    ,client_id
    ,status
    ,doc_type
    ,purpose
    ,amount
    ,pay_priority
    ,urgent
    ,payer_status
    ,payment_basis
    ,basis_document_number
    ,basis_document_created
    ,tax_period
    ,uin
    ,kbk
    ,oktmo
    ,payer_name
    ,payer_account
    ,payer_inn
    ,payer_kpp
    ,payer_bank_name
    ,payer_bank_bic
    ,payer_bank_correspondent_account
    ,payee_name
    ,payee_account
    ,payee_inn
    ,payee_kpp
    ,payee_bank_name
    ,payee_bank_bic
    ,payee_bank_correspondent_account
    ,document_id
    ,code_type_income
    ,type_tax_payment)
VALUES (1
        ,'1'
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,0
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null
        ,null);



INSERT INTO property
           (property_key
           ,value)
     VALUES
           ('document.creation.date'
           ,'2020-08-24');




UPDATE imported_document
SET client_id = 704
   ,document_id = 1;
