CREATE TABLE document_recall (
	id bigint identity (1,1) not null,
    created datetime not null,
	document_id bigint,
	status varchar(20),
	info varchar(255),
    primary key (id),
    foreign key (document_id) references document(id)
);

insert into document_recall (created, document_id, status) values ('2021-01-23 00:00:00.000', 3L, 'CREATED');

