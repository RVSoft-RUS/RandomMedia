CREATE TABLE IF NOT EXISTS status_translation
(
    status_comment VARCHAR2(255),
    translation    VARCHAR2(255),
    primary key (status_comment)
);

INSERT INTO status_translation (status_comment, translation)
VALUES ('Не указан адрес в наименовании плательщика для платежа ФЛ или ИП в бюджет.. Не указан адрес в наименовании плательщика для платежа ФЛ или ИП в бюджет.',
        'Не указан адрес в наименовании плательщика для платежа ФЛ или ИП в бюджет');