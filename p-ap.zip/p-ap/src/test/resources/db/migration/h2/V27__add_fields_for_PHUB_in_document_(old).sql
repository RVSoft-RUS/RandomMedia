ALTER TABLE document ADD uuid uuid;
ALTER TABLE document ADD status_date_time timestamp;
ALTER TABLE document ADD status_comment VARCHAR2(255);
ALTER TABLE document ADD status_code VARCHAR2(100);
ALTER TABLE document ADD status_sys_name VARCHAR2(100);

ALTER TABLE document_old ADD uuid uuid;
ALTER TABLE document_old ADD status_date_time timestamp;
ALTER TABLE document_old ADD status_comment VARCHAR2(255);
ALTER TABLE document_old ADD status_code VARCHAR2(100);
ALTER TABLE document_old ADD status_sys_name VARCHAR2(100);
