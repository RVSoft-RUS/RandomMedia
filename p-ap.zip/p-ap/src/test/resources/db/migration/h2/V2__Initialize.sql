CREATE TABLE shedlock(name VARCHAR(64) NOT NULL, lock_until datetime2 NOT NULL,
    locked_at datetime2 NOT NULL, locked_by VARCHAR(255) NOT NULL, PRIMARY KEY (name));

CREATE TABLE document(
	id bigint IDENTITY(1,1) NOT NULL,
	bis_document_id varchar(50) NULL,
	number varchar(255) NULL,
	date datetime NULL,
	status varchar(20) NULL,
	status_message varchar(1020) NULL,
	doctype varchar(2) NULL,
	purpose nvarchar(210) NULL,
	amount numeric(19, 2) NULL,
	paypriority varchar(2) NULL,
	urgent boolean NULL,
	payer_status varchar(255) NULL,
	payment_basis varchar(255) NULL,
	basis_document_number varchar(255) NULL,
	basis_document_created varchar(255) NULL,
	tax_period varchar(255) NULL,
	uin varchar(255) NULL,
	kbk varchar(255) NULL,
	oktmo varchar(255) NULL,
	payer_name varchar(160) NULL,
	payer_account varchar(255) NULL,
	payer_inn varchar(255) NULL,
	payer_kpp varchar(255) NULL,
	payer_bank_name varchar(255) NULL,
	payer_bank_bic varchar(255) NULL,
	payer_bank_correspondent_account varchar(255) NULL,
	payee_name varchar(160) NULL,
	payee_account varchar(255) NULL,
	payee_inn varchar(255) NULL,
	payee_kpp varchar(255) NULL,
	payee_bank_name varchar(255) NULL,
	payee_bank_bic varchar(255) NULL,
	payee_bank_correspondent_account varchar(255) NULL,
	rem_ip varchar(50) NULL,
	rem_mac varchar(25) NULL,
	dbo_pro_id varchar(255) NULL,
	show_error int NOT NULL,
	client_id bigint NULL,
	code_type_income varchar(1) NULL,
	type_tax_payment smallint NULL,
	execution_date datetime NULL,
	sign_date datetime NULL,
	organization_bis_id varchar(15) NULL,
	organization_bis_branch varchar(15) NULL,
	organization_crm_id varchar(15) NULL,
	organization_short_name varchar(100) NULL,
PRIMARY KEY (id));

CREATE TABLE DFM_Payment(
	id bigint IDENTITY(1,1) NOT NULL,
	DOC_DATE datetime NULL,
	REASON nvarchar(210) NULL,
	DOC_SUM decimal(19, 2) NULL,
	NAME varchar(160) NULL,
	PAYERACCCODE varchar(255) NULL,
	PAYERINN varchar(255) NULL,
	PAYERBANK varchar(255) NULL,
	PAYERBIK varchar(255) NULL,
	BENEFNAME varchar(160) NULL,
	BENEFACCCODE varchar(255) NULL,
	BENEFINN varchar(255) NULL,
	BENEFBANK varchar(255) NULL,
	BENEFBIK varchar(255) NULL,
	BENEFBANKACC varchar(255) NULL,
	I_DATE datetime NULL,
	CLI_CODE varchar(20) NULL,
	FLAG int NULL,
	INF varchar(255) NULL,
	STATUS varchar(20) NULL,
	DOC_NUMBER varchar(255) NULL,
	DOC_SERIAL bigint NULL,
    DOC_TYPE varchar(2) NULL,
PRIMARY KEY (id));

CREATE TABLE antifraud_resolution(
	id bigint IDENTITY(1,1) NOT NULL,
	request_id varchar(36) NOT NULL,
	client_id bigint NOT NULL,
	document_id bigint NOT NULL,
	status varchar(30) NULL,
	created datetime NOT NULL,
PRIMARY KEY (id));


CREATE TABLE antifraud_client(
	id bigint IDENTITY(1,1) NOT NULL,
	client_id bigint NOT NULL,
	resolution_id varchar(36) NULL,
	status varchar(100) NOT NULL,
	crm_id_natural varchar(30) NULL,
	crm_id_legal varchar(30) NULL,
	created datetime NOT NULL,
PRIMARY KEY (id));

CREATE TABLE antifraud_block(
	id bigint IDENTITY(1,1) NOT NULL,
	client_id bigint NOT NULL,
	created datetime NOT NULL,
	released datetime NULL,
PRIMARY KEY (id));

CREATE TABLE  CB_BIC
   (	BIC VARCHAR(9),
      NAMEP VARCHAR(1000),
      ENGLNAME VARCHAR(1000),
      REGN VARCHAR(1000),
      CNTRCD VARCHAR(1000),
      RGN VARCHAR(1000),
      IND VARCHAR(1000),
      TNP VARCHAR(1000),
      NNP VARCHAR(1000),
      ADR VARCHAR(1000),
      PRNTBIC VARCHAR(1000),
      DATEIN Date,
      DATEOUT Date,
      PTTYPE VARCHAR(1000),
      SRVCS VARCHAR(1000),
      XCHTYPE VARCHAR(1000),
      C1 VARCHAR(1000),
      NPSPARTICIPANT VARCHAR(1000),
      TONPSDATE Date,
      PARTICIPANTSTATUS VARCHAR(1000),
      DIRECTBIC VARCHAR(1000),
      DIRECTACCOUNT VARCHAR(1000) );

CREATE TABLE   CB_BIC_ACCOUNT
   (	BIC 			VARCHAR(9),
      ACCOUNT		 VARCHAR(20),
      REGULATIONACCOUNTTYPE VARCHAR(1000),
      CK 			VARCHAR(1000),
      ACCOUNTCBRBIC	VARCHAR(1000),
      DATEIN 		Date,
      DATEOUT 		Date,
      ACCOUNTSTATUS	 VARCHAR(1000) );

create table property
(
    id           bigint  IDENTITY(1,1) not null,
    property_key varchar(50) not null,
    value        varchar(255),
    description  varchar(255),
    constraint property_pk primary key (id),
    constraint c_property_key_unique unique(property_key)
);


create table imported_document (
        id bigint NOT NULL,
        batch varchar(255) NULL,
        created datetime NULL,
        client_id bigint NULL,
        status varchar(20) NULL,

        doc_type varchar(2) NULL,
        purpose varchar(210) NULL,
        amount numeric(19, 2) NULL,
        pay_priority varchar(2) NULL,
        urgent varchar(1) NULL,
        payer_status varchar(255) NULL,
        payment_basis varchar(255) NULL,
        basis_document_number varchar(255) NULL,
        basis_document_created varchar(255) NULL,
        tax_period varchar(255) NULL,
        uin varchar(255) NULL,
        kbk varchar(255) NULL,
        oktmo varchar(255) NULL,
        payer_name varchar(160) NULL,
        payer_account varchar(255) NULL,
        payer_inn varchar(255) NULL,
        payer_kpp varchar(255) NULL,
        payer_bank_name varchar(255) NULL,
        payer_bank_bic varchar(255) NULL,
        payer_bank_correspondent_account varchar(255) NULL,
        payee_name varchar(160) NULL,
        payee_account varchar(255) NULL,
        payee_inn varchar(255) NULL,
        payee_kpp varchar(255) NULL,
        payee_bank_name varchar(255) NULL,
        payee_bank_bic varchar(255) NULL,
        payee_bank_correspondent_account varchar(255) NULL,
        primary key (id)
);

alter table imported_document add code_type_income varchar(1);
alter table imported_document add type_tax_payment smallint;
alter table imported_document add number varchar(255);
alter table imported_document alter column payee_name varchar(400);
alter table imported_document add document_id bigint;
alter table imported_document
    add constraint imported_document_fk foreign key (document_id) references document;

--ALTER TABLE dbo.DFM_Payment_p  WITH CHECK ADD  CONSTRAINT FK_DFM_DOCUMENT_P_ID FOREIGN KEY(DOC_SERIAL)
--REFERENCES dbo.payment (id)

--ALTER TABLE dbo.DFM_Payment_p CHECK CONSTRAINT FK_DFM_DOCUMENT_P_ID

create table delivering_resource (id bigint not null, created date, attempts int, phone varchar(255), email varchar(255), reference varchar(255), resource_id varchar(255), resource_name varchar(255), resource_content image, resource_content_type varchar(255), primary key (id));
CREATE INDEX delivering_resource_idx1 ON delivering_resource (resource_id);

create sequence hibernate_sequence start with 1 increment by 1;

