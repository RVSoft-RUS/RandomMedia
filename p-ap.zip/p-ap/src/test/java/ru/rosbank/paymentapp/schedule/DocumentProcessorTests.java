package ru.rosbank.paymentapp.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.when;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import ru.rosbank.paymentapp.BaseTestEsb;
import ru.rosbank.paymentapp.entity.AntifraudBlockEntity;
import ru.rosbank.paymentapp.entity.AntifraudClientEntity;
import ru.rosbank.paymentapp.entity.AntifraudResolutionEntity;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.esb.service.PaymentOrderService;
import ru.rosbank.paymentapp.esb.support.BankProcessingException;
import ru.rosbank.paymentapp.repository.AntifraudBlockEntityRepository;
import ru.rosbank.paymentapp.repository.AntifraudClientEntityRepository;
import ru.rosbank.paymentapp.repository.AntifraudResolutionEntityRepository;
import ru.rosbank.paymentapp.repository.DFMPaymentRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.PaymentOrderLogService;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.bs.BsService;
import ru.rosbank.paymentapp.service.cryptopro.CryptoproService;
import ru.rosbank.paymentapp.service.dfm.DfmEmailService;
import ru.rosbank.paymentapp.service.exceptions.SendToBisPaymentException;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService;
import ru.rosbank.paymentapp.service.fraud.PaymentStatusEvents;
import ru.rosbank.paymentapp.service.sms.SendSmsService;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.esb.exception.EsbTimeoutException;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderRequestTypeEsb;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderResponseTypeEsb;
import ru.rosbank.platform.esb.model.getcustomeraccountlist.GetCustomerAccountListResponseTypeEsb;
import ru.rosbank.platform.esb.model.senddbomatrix.SendDBOMatrixRequestTypeEsb;
import ru.rosbank.platform.esb.model.senddbomatrix.SendDBOMatrixResponseTypeEsb;
import ru.rosbank.platform.esb.support.EsbRequestTypeEnum;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;


public class DocumentProcessorTests extends BaseTestEsb {

    @Autowired
    AntifraudResolutionEntityRepository antifraudResolutionEntityRepository;
    @Autowired
    DFMPaymentRepository dfmPaymentRepository;
    @Autowired
    AntifraudClientEntityRepository antifraudClientEntityRepository;
    @Autowired
    AntifraudBlockEntityRepository antifraudBlockEntityRepository;

    @Autowired
    PaymentEntityRepository documentRepository;
    @Autowired
    DocumentProcessor processor;
    @Autowired
    PaymentOrderService paymentOrderService;

    @MockBean
    PaymentEventService paymentEventService;
    @MockBean
    PaymentStatusEventService paymentStatusEventService;
    @MockBean
    CryptoproService cryptoproService;
    @MockBean
    BsService bsService;
    @MockBean
    ReferenceAppApiClient referenceAppApiClient;
    @MockBean
    DfmEmailService dfmEmailService;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    ScheduledConfiguration scheduledConfiguration;
    @MockBean
    SendSmsService sendSmsService;
    @MockBean
    PaymentOrderLogService paymentOrderLogService;
    @MockBean
    UserService userService;

    @Value("${anti-fraud.resolution.timeout}")
    int antifraudTimeout;
    @Value("${anti-fraud.review.timeout}")
    int antifraudReviewTimeout;

    private PaymentEntity payment;
    private static final Long docId = 2L;

    @BeforeEach
    public void init() throws Exception {
        ClientDTO clientDTO = new ClientDTO();
        when(paymentOrderLogService.savePaymentOrderLog(anyLong())).thenReturn(true);
        when(userService.getClientById(anyLong())).thenReturn(Optional.of(clientDTO));
        payment = documentRepository.findById(docId).get();
        ClientDTO client = initClient();

        GetCustomerAccountListResponseTypeEsb accList =
                (GetCustomerAccountListResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/GetCustomerAccountListResponse.xml"),
                        EsbRequestTypeEnum.GET_CUSTOMER_ACCOUNT_LIST);
        when(esbService.getCustomerAccountList(any())).thenReturn(accList);
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);

        CreatePaymentOrderResponseTypeEsb createOrder =
                (CreatePaymentOrderResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/CreatePaymentOrderResponse.xml"),
                        EsbRequestTypeEnum.CREATE_PAYMENT_ORDER);

        SendDBOMatrixResponseTypeEsb sendDboMatrix =
                (SendDBOMatrixResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/SendDboMatrixResponse.xml"),
                        EsbRequestTypeEnum.SEND_DBO_MATRIX);

        SignatureDTO signatureDTO = buildSignResponse(payment);
        List<SignatureDTO> signatures = Collections.singletonList(signatureDTO);
        when(cryptoproService.getDocumentSignatures(any())).thenReturn(signatures);

        when(esbService.createPaymentOrder(any(CreatePaymentOrderRequestTypeEsb.class))).thenReturn(createOrder);
        when(esbService.sendDBOMatrix(any(SendDBOMatrixRequestTypeEsb.class))).thenReturn(sendDboMatrix);
        when(bsService.getClient(any(Long.class))).thenReturn(client);
        doNothing().when(dfmEmailService).sendMailToDfm(any(DFMPaymentEntity.class), any(PaymentEntity.class), any(Boolean.class),
                any(Boolean.class));
    }

    @AfterEach
    public void clear() {
        documentRepository.findById(docId)
                .map(p -> {
                    p.setStatus(DocumentStatus.SIGNED.toString());
                    p.setBisDocumentId(null);
                    return p;
                }).ifPresent(documentRepository::save);
        antifraudResolutionEntityRepository.deleteAll();
        dfmPaymentRepository.deleteAll();
    }

    @Test
    public void processDfmFailTest() throws ExecutionException, InterruptedException {

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();
        Assertions.assertEquals(DocumentStatus.DFM_PROCESSING.toString(), processed.getStatus());

        DFMPaymentEntity dfm = dfmPaymentRepository.findByDocSerial(processed.getId()).orElse(null);
        Assertions.assertNotNull(dfm);

    }

    @Test
    public void processAntifraudFailTest() throws ExecutionException, InterruptedException {

        initDfm();
        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();
        Assertions.assertEquals(DocumentStatus.SIGNED.toString(), processed.getStatus());

    }

    @Test
    public void processAntifraudReviewWaitingSuccessfulTest() throws ExecutionException, InterruptedException {

        initDfm();
        initAntifraudReview();

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Assertions.assertEquals(DocumentStatus.REVIEW.toString(), processed.getStatus());
        Assertions.assertEquals(DocumentStatus.PROCESSING.toString(), processed.getStatusMessage());
        Mockito.verify(esbService, times(0)).createPaymentOrder(any());

    }

    @Test
    public void processAntifraudAllowSuccessfulTest() throws ExecutionException, InterruptedException {

        initDfm();
        initAntifraudAllow();

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Assertions.assertEquals(DocumentStatus.SENT_TO_BIS.toString(), processed.getStatus());
        Mockito.verify(esbService, times(1)).createPaymentOrder(any());
        Mockito.verify(paymentStatusEventService, times(1))
                .sendPaymentEvent(any(), eq(PaymentStatusEvents.ANTI_FRAUD_ALLOW));

    }

    @Test
    public void processAntifraudAllowFailedTest() throws ExecutionException, InterruptedException {
        when(paymentOrderLogService.savePaymentOrderLog(anyLong())).thenReturn(false);
        initDfm();
        initAntifraudAllow();

        processor.process(payment.getId()).get();
        Mockito.verify(esbService, never()).createPaymentOrder(any());
    }

    @Test
    public void processAntifraudReviewTimeoutSuccessfulTest() throws ExecutionException, InterruptedException {

        initDfm();
        initAntifraudReviewTimeout();

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Mockito.verify(paymentStatusEventService, times(1))
                .sendPaymentEvent(any(), eq(PaymentStatusEvents.ANTI_FRAUD_REVIEW_TIMEOUT));
        Mockito.verify(esbService, times(1)).createPaymentOrder(any());
        Assertions.assertNotNull(processed.getBisDocumentId());
        Assertions.assertEquals(DocumentStatus.SENT_TO_BIS.toString(), processed.getStatus());

    }


    @Test
    public void processPaymentOrderEsbTimeoutExTest() throws Exception {
        when(esbService.createPaymentOrder(any())).thenThrow(EsbTimeoutException.class);

        initDfm();
        initAntifraud();

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Assertions.assertNull(processed.getBisDocumentId());
        Mockito.verify(sendSmsService, times(0)).sendSmsTechnicalProblemsForPayment(any());
        Assertions.assertEquals(DocumentStatus.ERROR.toString(), processed.getStatus());
    }

    @Test
    public void processPaymentOrderBankProcessingExceptionTest() throws Exception {
        when(esbService.createPaymentOrder(any())).thenThrow(BankProcessingException.class);

        initDfm();
        initAntifraud();

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Assertions.assertNull(processed.getBisDocumentId());
        Mockito.verify(sendSmsService, times(1)).sendSmsTechnicalProblemsForPayment(any());
        Assertions.assertEquals(DocumentStatus.REJECTED.toString(), processed.getStatus());
    }

    @Test
    public void processPaymentOrderExceptionTest() throws Exception {
        when(paymentOrderLogService.savePaymentOrderLog(any())).thenThrow(UnsupportedOperationException.class);

        initDfm();
        initAntifraud();

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Assertions.assertNull(processed.getBisDocumentId());
        Mockito.verify(sendSmsService, times(1)).sendSmsTechnicalProblemsForPayment(any());
        Assertions.assertEquals(DocumentStatus.REJECTED.toString(), processed.getStatus());
    }

    @Test
    public void processPaymentOrderExceptionDisablePropertyTest() throws Exception {
        when(paymentOrderLogService.savePaymentOrderLog(any())).thenThrow(UnsupportedOperationException.class);

        initDfm();
        initAntifraud();

        paymentOrderService.setSystemsActive(false);
        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Assertions.assertNull(processed.getBisDocumentId());
        Mockito.verify(sendSmsService, times(0)).sendSmsTechnicalProblemsForPayment(any());
        Assertions.assertEquals(DocumentStatus.SIGNED.toString(), processed.getStatus());
    }

    @Test
    public void processCreatePaymentBisFailTest() throws ExecutionException, InterruptedException {

        initDfm();
        initAntifraud();
        when(esbService.createPaymentOrder(any()))
                .thenThrow(new SendToBisPaymentException("333", new Exception()));

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Mockito.verify(esbService, times(1)).createPaymentOrder(any());
        Assertions.assertNull(processed.getBisDocumentId());
        Assertions.assertEquals(DocumentStatus.ERROR.toString(), processed.getStatus());

    }

    @Test
    public void processException() throws ExecutionException, InterruptedException {

        initDfm();
        initAntifraud();
        when(cryptoproService.getDocumentSignatures(any())).thenThrow(new RuntimeException());
        processor.process(payment.getId()).get();
    }

    @Test
    public void processSuccessfulTest() throws ExecutionException, InterruptedException {

        initDfm();
        initAntifraud();

        Long id = processor.process(payment.getId()).get();
        PaymentEntity processed = documentRepository.findById(id).get();

        Mockito.verify(esbService, times(1)).createPaymentOrder(any());
        Assertions.assertNotNull(processed.getBisDocumentId());
        Assertions.assertEquals(DocumentStatus.SENT_TO_BIS.toString(), processed.getStatus());

    }

    private void initDfm() {
        DFMPaymentEntity dfm = new DFMPaymentEntity();
        dfm.setDocDate(LocalDateTime.now());
        dfm.setReason("Без НДС");
        dfm.setDocSum(new BigDecimal("100.00"));
        dfm.setName("ИП Донварь Кристина Валерьевна");
        dfm.setPayeracccode("40802810597880000207");
        dfm.setPayerinn("450146852396");
        dfm.setPayerbank("РОСБАНК");
        dfm.setPayerbik("044525256");
        dfm.setBenefname("20/110");
        dfm.setIdate(LocalDateTime.now());
        dfm.setFlag(1);
        dfm.setStatus("PROCESSING");
        dfm.setDocNumber("777");
        dfm.setDocSerial(docId);
        dfmPaymentRepository.save(dfm);
    }

    private void initAntifraudAllow() {
        AntifraudResolutionEntity resolution = initAntifraud();
        resolution.setStatus(AntifraudResolutionEntity.ALLOW);
        antifraudResolutionEntityRepository.save(resolution);
    }

    private void initAntifraudReview() {
        AntifraudResolutionEntity resolution = initAntifraud();
        resolution.setStatus(AntifraudResolutionEntity.REVIEW);
        antifraudResolutionEntityRepository.save(resolution);
    }

    private void initAntifraudReviewTimeout() {
        AntifraudResolutionEntity resolution = initAntifraud();
        resolution.setStatus(AntifraudResolutionEntity.REVIEW);
        resolution.setCreated(LocalDateTime.of(2020, 11, 16, 10, 10));
        antifraudResolutionEntityRepository.save(resolution);

        AntifraudClientEntity client = new AntifraudClientEntity();
        client.setClientId(704L);
        client.setCreated(LocalDateTime.now());
        client.setStatus("block_active_operations");
        antifraudClientEntityRepository.save(client);

        AntifraudBlockEntity block = new AntifraudBlockEntity();
        block.setClientId(704L);
        block.setCreated(LocalDateTime.now());
        block.setReleased(LocalDateTime.now());
        antifraudBlockEntityRepository.save(block);
    }

    private AntifraudResolutionEntity initAntifraud() {
        AntifraudResolutionEntity resolution = new AntifraudResolutionEntity();
        resolution.setRequestId("ae711ea7-2643-41ea-887f-d67240b0fc49");
        resolution.setClientId(704L);
        resolution.setDocumentId(docId);
        resolution.setStatus("antifraud_processing");
        resolution.setCreated(LocalDateTime.now().minusSeconds(antifraudTimeout));
        return antifraudResolutionEntityRepository.save(resolution);
    }

    private ClientDTO initClient() {
        ClientDTO client = new ClientDTO();
        client.setFio("ФИО");
        client.setId("48c06071-ed20-4844-905d-b2eed4fdca32");
        client.setPassword("$2a$10$85kCutzFB99tCGvBIS0OGu81ZAfPOf3LWvShYpufz9i1uXtwHapdC");
        client.setPhone("79111234566");
        client.setEmail("dprosquad@yandex.ru");
        return client;
    }

}
