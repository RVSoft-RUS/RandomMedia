package ru.rosbank.paymentapp.schedule;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.CurrencyControlEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.CurrencyControlRepository;
import ru.rosbank.paymentapp.service.validators.ProPortalService;


public class SendCurrencyControlToProPortalJobTest extends BaseTest {
    @Autowired
    private SendCurrencyControlToProPortalJob sendCurrencyControlToProPortalJob;
    @MockBean
    private CurrencyControlRepository currencyControlRepository;
    @MockBean
    private ProPortalService proPortalService;


    @Test
    public void test() {
        Mockito.when(currencyControlRepository
                        .findAllByIsSentToProPortalIsFalseAndAttemptsSentProPortalIsBetween(Mockito.anyInt(), Mockito.anyInt()))
                        .thenReturn(getCurrencyControlEntityList());
        sendCurrencyControlToProPortalJob.run();
        Mockito.verify(proPortalService, Mockito.times(2))
                .sendCurrencyControlInfoToProPortal(Mockito.any());
    }

    @Test
    public void testNegative() {
        Mockito.when(currencyControlRepository
                        .findAllByIsSentToProPortalIsFalseAndAttemptsSentProPortalIsBetween(Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(getCurrencyControlEntityList());
        Mockito.doThrow(new NullPointerException()).when(proPortalService).sendCurrencyControlInfoToProPortal(Mockito.any());
        sendCurrencyControlToProPortalJob.run();
    }

    private List<CurrencyControlEntity> getCurrencyControlEntityList() {
        CurrencyControlEntity currencyControlEntity1 = new CurrencyControlEntity();
        currencyControlEntity1.setPaymentEntity(new PaymentEntity());
        CurrencyControlEntity currencyControlEntity2 = new CurrencyControlEntity();
        currencyControlEntity2.setPaymentEntity(new PaymentEntity());
        return List.of(currencyControlEntity1, currencyControlEntity2);
    }
}
