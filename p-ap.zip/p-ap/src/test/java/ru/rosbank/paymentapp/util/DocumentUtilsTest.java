package ru.rosbank.paymentapp.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class DocumentUtilsTest {

    @Test
    void toStatementBisId() {
        String bisId = DocumentUtils.toStatementBisId("PP200121-409813901");
        Assertions.assertEquals(bisId, "Y01200121409813901");

        Assertions.assertEquals(DocumentUtils.toStatementBisId("DD200121-409813901"), "DD200121-409813901");
    }

    @Test
    void toPaymentBisId() {
        String bisId = DocumentUtils.toPaymentBisId("Y01200122410882501");
        Assertions.assertEquals(bisId, "PP200122-410882501");

        Assertions.assertEquals(DocumentUtils.toPaymentBisId("DD200121-409813901"), "DD200121-409813901");
    }

    @Test
    void replaceBisId() {
        String bisId = DocumentUtils.replaceBisId("Y01200122410882501");
        Assertions.assertEquals(bisId, "PP200122-410882501");
        Assertions.assertEquals(DocumentUtils.replaceBisId(bisId), "Y01200122410882501");

        bisId = DocumentUtils.replaceBisId("PP200121-409813901");
        Assertions.assertEquals(bisId, "Y01200121409813901");
        Assertions.assertEquals(DocumentUtils.replaceBisId(bisId), "PP200121-409813901");

        Assertions.assertEquals(DocumentUtils.replaceBisId("DD200121-409813901"), "DD200121-409813901");
    }
}