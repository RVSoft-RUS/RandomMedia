package ru.rosbank.paymentapp.util;

import java.time.LocalDate;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

class UtilsTest {

    @Test
    void workingDaysElapsedFromTwentyOneOfFebruary() {
        LocalDate twentyOneOfFebruary = LocalDate.of(2024, 2, 21);
        LocalDate now = LocalDate.of(2024, 2, 27);
        try (MockedStatic<LocalDate> utilities = Mockito.mockStatic(LocalDate.class, Mockito.CALLS_REAL_METHODS)) {
            utilities.when(LocalDate::now).thenReturn(now);
            Assertions.assertThat(Utils.workingDaysElapsedFrom(twentyOneOfFebruary)).isEqualTo(3L);
        }
    }

    @Test
    void workingDaysElapsedFromTwentySixOfApril() {
        LocalDate twentySixOfApril = LocalDate.of(2024, 4, 26);
        LocalDate now = LocalDate.of(2024, 5, 3);
        try (MockedStatic<LocalDate> utilities = Mockito.mockStatic(LocalDate.class, Mockito.CALLS_REAL_METHODS)) {
            utilities.when(LocalDate::now).thenReturn(now);
            Assertions.assertThat(Utils.workingDaysElapsedFrom(twentySixOfApril)).isEqualTo(3L);
        }
    }

    @Test
    void workingDaysElapsedFromElevenOfJune() {
        LocalDate elevenOfJune = LocalDate.of(2024, 6, 11);
        LocalDate now = LocalDate.of(2024, 6, 17);
        try (MockedStatic<LocalDate> utilities = Mockito.mockStatic(LocalDate.class, Mockito.CALLS_REAL_METHODS)) {
            utilities.when(LocalDate::now).thenReturn(now);
            Assertions.assertThat(Utils.workingDaysElapsedFrom(elevenOfJune)).isEqualTo(3L);
        }
    }
}