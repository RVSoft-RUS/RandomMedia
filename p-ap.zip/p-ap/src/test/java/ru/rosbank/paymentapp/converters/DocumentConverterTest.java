package ru.rosbank.paymentapp.converters;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.server.paymentapp.model.Document;

class DocumentConverterTest extends BaseTest {
    @Autowired
    DocumentConverter documentConverter;

    @Test
    void toDTO() {
        PaymentEntity entity = generateEntity();
        Document document = documentConverter.toDTO(entity);

        Assertions.assertNotNull(document.getEnrollmentDate());

        entity.setEnrollmentDate(null);
        document = documentConverter.toDTO(entity);

        Assertions.assertNull(document.getEnrollmentDate());
    }

    @Test
    void fromDTO() {
        DocumentDTO document = generateDocument();
        PaymentEntity entity = documentConverter.fromDTO(document);

        Assertions.assertNotNull(entity.getEnrollmentDate());

        document.setEnrollmentDate(null);
        entity = documentConverter.fromDTO(document);

        Assertions.assertNull(entity.getEnrollmentDate());
    }

    private DocumentDTO generateDocument() {
        DocumentDTO document = new DocumentDTO();
        document.setId(1);
        document.setSignDate(OffsetDateTime.now());
        document.setDate(OffsetDateTime.now());
        document.setEnrollmentDate(OffsetDateTime.now());
        document.setStatus(DocumentStatusDTO.ARCHIVE);
        return document;
    }

    private PaymentEntity generateEntity() {
        PaymentEntity entity = new PaymentEntity();
        entity.setId(1L);
        entity.setSignDate(LocalDateTime.now());
        entity.setDate(LocalDateTime.now());
        entity.setEnrollmentDate(LocalDateTime.now());
        return entity;
    }
}