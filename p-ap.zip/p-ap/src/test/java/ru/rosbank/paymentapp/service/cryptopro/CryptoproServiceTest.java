package ru.rosbank.paymentapp.service.cryptopro;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.MyFeignException;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;

public class CryptoproServiceTest extends BaseTest {

    @MockBean
    private CryptoproAppApi cryptoproAppApi;
    @Autowired
    private CryptoproService service;

    @Test
    public void getDocumentSignaturesTest() {
        PaymentEntity entity = new PaymentEntity();
        entity.setId(1L);
        List<SignatureDTO> appSuccessResponse = List.of(new SignatureDTO().confirmed(true));
        when(cryptoproAppApi.signatureGet(anyString(), eq("DOCUMENT"))).thenReturn(ResponseEntity.ok(appSuccessResponse));
        Assertions.assertEquals(1, service.getDocumentSignatures(entity).size());
        entity.setReferenceId("refid");
        when(cryptoproAppApi.signatureGet(anyString(), eq("DOCUMENT"))).thenReturn(ResponseEntity.ok(appSuccessResponse));
        Assertions.assertEquals(1, service.getDocumentSignatures(entity).size());
        entity.setReferenceType("SUBSCRIPTION");
        when(cryptoproAppApi.signatureGet(anyString(), eq("SUBSCRIPTION"))).thenReturn(ResponseEntity.ok(appSuccessResponse));
        Assertions.assertEquals(1, service.getDocumentSignatures(entity).size());

        when(cryptoproAppApi.signatureGet(anyString(), anyString())).thenThrow(new MyFeignException(500, "test"));
        Assertions.assertThrows(BackendException.class, () -> service.getDocumentSignatures(entity));
    }
}
