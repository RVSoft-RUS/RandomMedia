package ru.rosbank.paymentapp.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import ru.rosbank.paymentapp.BaseTestEsb;
import ru.rosbank.paymentapp.client.pricing.PricingRbspFeignClient;
import ru.rosbank.paymentapp.dto.pricing.CommissionResponseDTO;
import ru.rosbank.paymentapp.dto.pricing.Response;
import ru.rosbank.paymentapp.dto.pricing.ResponseMetaData;
import ru.rosbank.paymentapp.entity.PricingCommissionEntity;
import ru.rosbank.paymentapp.repository.PricingCommissionRepository;
import ru.rosbank.platform.client.paymentapp.model.AmountDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.CurrencyControlDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.FileInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderRequestTypeEsb;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderResponseTypeEsb;
import ru.rosbank.platform.esb.support.EsbRequestTypeEnum;

class CommissionServiceTest extends BaseTestEsb {
    @Autowired
    CommissionService commissionService;
    @MockBean
    PricingCommissionRepository pricingCommissionRepository;
    @MockBean
    PricingRbspFeignClient feignClient;

    @Test
    void calculateCommissionWhenCodeIsNotRbspAndBothResponsesOk() throws Exception {
        CreatePaymentOrderResponseTypeEsb createOrder =
                (CreatePaymentOrderResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/CreatePaymentOrderResponse.xml"),
                        EsbRequestTypeEnum.CREATE_PAYMENT_ORDER);
        when(esbService.createPaymentOrder(any(CreatePaymentOrderRequestTypeEsb.class))).thenReturn(createOrder);
        CommissionResponseDTO responseDTO = new CommissionResponseDTO();
        responseDTO.setCommissionAmount(BigDecimal.TEN);
        when(feignClient.getCommission(any()))
                .thenReturn(new Response<>(new ResponseMetaData(), responseDTO));

        AmountDTO commission = commissionService.calculateCommission(createDocument());

        Assertions.assertEquals(new BigDecimal("89323174.50"), commission.getSum());
        ArgumentCaptor<PricingCommissionEntity> argumentCaptor = ArgumentCaptor.forClass(PricingCommissionEntity.class);
        verify(pricingCommissionRepository, times(1)).save(argumentCaptor.capture());
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getStatus()).isEqualTo("SUCCESS");
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getPricingCommission()).isEqualTo(BigDecimal.TEN);

    }

    @Test
    void calculateCommissionWhenCodeIsRbspAndBothResponsesOk() throws Exception {
        CreatePaymentOrderResponseTypeEsb createOrder =
                (CreatePaymentOrderResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/CreatePaymentOrderResponse.xml"),
                        EsbRequestTypeEnum.CREATE_PAYMENT_ORDER);
        when(esbService.createPaymentOrder(any(CreatePaymentOrderRequestTypeEsb.class))).thenReturn(createOrder);
        CommissionResponseDTO responseDTO = new CommissionResponseDTO();
        responseDTO.setCommissionAmount(BigDecimal.TEN);
        when(feignClient.getCommission(any()))
                .thenReturn(new Response<>(new ResponseMetaData(), responseDTO));

        DocumentDTO document = createDocument();
        document.setTariffCode("HV1");
        AmountDTO commission = commissionService.calculateCommission(document);

        Assertions.assertEquals(BigDecimal.TEN, commission.getSum());
        ArgumentCaptor<PricingCommissionEntity> argumentCaptor = ArgumentCaptor.forClass(PricingCommissionEntity.class);
        verify(pricingCommissionRepository, times(1)).save(argumentCaptor.capture());
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getStatus()).isEqualTo("SUCCESS");

    }

    @Test
    void calculateCommissionWhenCodeIsRbspAndRbspResponseErrorAndBisResponseOk() throws Exception {
        CreatePaymentOrderResponseTypeEsb createOrder =
                (CreatePaymentOrderResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/CreatePaymentOrderResponse.xml"),
                        EsbRequestTypeEnum.CREATE_PAYMENT_ORDER);
        when(esbService.createPaymentOrder(any(CreatePaymentOrderRequestTypeEsb.class))).thenReturn(createOrder);
        when(feignClient.getCommission(any()))
                .thenThrow(new RuntimeException("rbspError"));

        DocumentDTO document = createDocument();
        document.setTariffCode("HV1");
        AmountDTO commission = commissionService.calculateCommission(document);

        Assertions.assertEquals(new BigDecimal("89323174.50"), commission.getSum());
        ArgumentCaptor<PricingCommissionEntity> argumentCaptor = ArgumentCaptor.forClass(PricingCommissionEntity.class);
        verify(pricingCommissionRepository, times(1)).save(argumentCaptor.capture());
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getStatus()).isEqualTo("ERROR");
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getErrorMsg()).isEqualTo("rbspError");

    }

    @Test
    void calculateCommissionWhenCodeIsRbspAndBothResponsesError() throws Exception {
        when(esbService.createPaymentOrder(any(CreatePaymentOrderRequestTypeEsb.class)))
                .thenThrow(new RuntimeException("bisError"));
        when(feignClient.getCommission(any()))
                .thenThrow(new RuntimeException("rbspError"));

        DocumentDTO document = createDocument();
        document.setTariffCode("HV1");

        org.assertj.core.api.Assertions.assertThatThrownBy(() -> commissionService.calculateCommission(document))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("Error while getting commission from bis after rbsp error");
        ArgumentCaptor<PricingCommissionEntity> argumentCaptor = ArgumentCaptor.forClass(PricingCommissionEntity.class);
        verify(pricingCommissionRepository, times(1)).save(argumentCaptor.capture());
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getStatus()).isEqualTo("ERROR");
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getErrorMsg()).isEqualTo("rbspError");
    }

    @Test
    void calculateCommissionWhenCodeIsNotRbspAndRbspResponseIsOkAndBisResponseError() throws Exception {
        when(esbService.createPaymentOrder(any(CreatePaymentOrderRequestTypeEsb.class)))
                .thenThrow(new RuntimeException("bisError"));
        CommissionResponseDTO responseDTO = new CommissionResponseDTO();
        responseDTO.setCommissionAmount(BigDecimal.TEN);
        when(feignClient.getCommission(any()))
                .thenReturn(new Response<>(new ResponseMetaData(), responseDTO));

        org.assertj.core.api.Assertions.assertThatThrownBy(() -> commissionService.calculateCommission(createDocument()))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("Error while getting commission from bis");
        ArgumentCaptor<PricingCommissionEntity> argumentCaptor = ArgumentCaptor.forClass(PricingCommissionEntity.class);
        verify(pricingCommissionRepository, times(1)).save(argumentCaptor.capture());
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getStatus()).isEqualTo("SUCCESS");
        org.assertj.core.api.Assertions.assertThat(argumentCaptor.getValue().getPricingCommission()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    void calculateCommission_commonError() throws Exception {
        CreatePaymentOrderResponseTypeEsb createOrder =
                (CreatePaymentOrderResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/CreatePaymentOrderErrorResponse.xml"),
                        EsbRequestTypeEnum.CREATE_PAYMENT_ORDER);
        when(esbService.createPaymentOrder(any(CreatePaymentOrderRequestTypeEsb.class))).thenReturn(createOrder);
        assertThrows(RuntimeException.class, () -> commissionService.calculateCommission(createDocument()));
    }

    private DocumentDTO createDocument() {
        DocumentDTO doc = new DocumentDTO();
        doc.setClientId(704L);
        doc.setAmount("100");
        doc.setDate(OffsetDateTime.now());
        doc.setNumber("123");
        doc.setStatus(DocumentStatusDTO.CREATED);
        doc.setType(DocumentDTO.TypeEnum.DB);
        doc.setShowError(true);

        RequisiteDTO payee = new RequisiteDTO();
        BankInfoDTO bankInfo = new BankInfoDTO();
        bankInfo.setBic("044525256");
        payee.setBank(bankInfo);
        doc.setPayee(payee);

        RequisiteDTO payer = new RequisiteDTO();
        payer.setAccount("40702810393790000591");
        payer.setInn("7810709158");
        payer.setKpp("781001001");
        payer.setName("Name");
        payer.setBank(new BankInfoDTO().bic("payerBankBic"));
        doc.setPayer(payer);
        doc.setCurrencyControl(new CurrencyControlDTO().fullName("fullname")
                .addFileInfoItem(new FileInfoDTO().id("1")));
        doc.setBisId(new BisIdDTO().id("bisId").branch("bisBranch"));
        return doc;
    }
}