package ru.rosbank.paymentapp.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.converters.ImportedDocumentDtoToEntityConverter;
import ru.rosbank.paymentapp.entity.ImportedDocumentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.ImportedDocumentRepository;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedBatchResultDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.NextDocumentInfo;



class DocumentImportServiceTest extends BaseTest {
    @Autowired
    DocumentImportService documentImportService;
    @Autowired
    ImportedDocumentRepository importedDocumentRepository;

    @Autowired
    ImportedDocumentDtoToEntityConverter entityConverter;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    PaymentService paymentService;
    @MockBean
    AccountService accountService;
    @MockBean
    UserService userService;
    @MockBean
    OrganizationService organizationService;


    @BeforeEach
    public void init()  {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(1L);
        when(userService.getClientById(1L)).thenReturn(Optional.of(clientDTO));
        when(userService.getClientByDboProId("2")).thenReturn(Optional.of(clientDTO));
        when(userService.getClientById(1L)).thenReturn(Optional.of(clientDTO));
    }


    @Test
    void createBatch() {
        List<ImportedDocumentDTO> importedDocumentDTOS = Arrays.asList(entityConverter.convertBack(getImportedDocumentEntity()));
        String batch = documentImportService.createBatch("2", importedDocumentDTOS);
        Assertions.assertNotNull(batch);
        assertThrows(RuntimeException.class, () -> documentImportService.createBatch("35563c07",
                importedDocumentDTOS));
    }

    @Test
    void deleteImportedDocument() {
        ImportedDocumentEntity entity = importedDocumentRepository.save(getImportedDocumentEntity());
        documentImportService.deleteImportedDocument(entity.getId().toString(),
                "2");
        assertThrows(RuntimeException.class, () -> documentImportService.deleteImportedDocument(entity.getId().toString(),
                "35563c07-82b2-43a8-a3b2-c9a11c696b40"));
    }

    @Test
    void getImportedDocuments() {
        ImportedDocumentEntity entity = getImportedDocumentEntity();
        entity.setBatch("getImportedDocuments");
        entity = importedDocumentRepository.save(entity);
        List<ImportedDocumentDTO> dtos = documentImportService.getImportedDocuments("getImportedDocuments",
                "2", entity.getStatus());
        dtos.stream().forEach(i -> Assertions.assertEquals("INVALID", i.getStatus().toString()));
        dtos = documentImportService.getImportedDocuments("getImportedDocuments",
                "2", "ALL");
        dtos.stream().forEach(i -> Assertions.assertEquals("INVALID", i.getStatus().toString()));
        assertThrows(RuntimeException.class, () -> documentImportService.getImportedDocuments("getImportedDocuments",
                "35563c07-82b2-43a8-a3b2-c9a11c696b40", "ALL"));
    }

    @Test
    void processBatch() {
        when(organizationService.rootGet(anyString())).thenReturn(
                List.of(new OrganizationDTO().crmId("crm").bisIds(List.of(
                        new ru.rosbank.platform.client.organizationapp.model.BisIdDTO().id("BisId")))));
        when(accountService.getAccountList(anyString(), any())).thenReturn(List.of(
                new AccountDTO().number("01234567890123456789").bisId(new BisIdDTO().id("BisId").branch("branch"))));
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        when(accountService.getBisId(anyString())).thenReturn(new BisIdDTO()
                                .id("BisId").branch("branch"));
        when(paymentService.getNextInfo(any())).thenReturn(new NextDocumentInfo().created(OffsetDateTime.now()).number("1"));
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setId(1L);
        when(paymentService.createDocument(any(PaymentEntity.class))).thenReturn(paymentEntity);
        ImportedDocumentEntity entity = getImportedDocumentEntity();
        entity.setPayerAccount("01234567890123456789");
        entity.setBatch("processBatch");
        entity.setStatus("VALID");
        importedDocumentRepository.save(entity);
        ImportedBatchResultDTO result = documentImportService.processBatch(entity.getBatch(),
                "2");
        Assertions.assertEquals(1, result.getPaymentsCount());
        Assertions.assertEquals(entity.getBatch(), result.getId());
        Assertions.assertEquals("01234567890123456789", result.getAccount());
        when(userService.getClientByDboProId("35563c07-82b2-43a8-a3b2-c9a11c696b4e")).thenThrow(new RuntimeException());
        assertThrows(RuntimeException.class, () -> documentImportService.processBatch(entity.getBatch(),
                "35563c07-82b2-43a8-a3b2-c9a11c696b40"));
    }

    @Test
    void saveNewDocument() {
    }

    @Test
    void updateImportedDocument() {
        ImportedDocumentEntity entity = importedDocumentRepository.save(getImportedDocumentEntity());
        ImportedDocumentDTO importedDocument = entityConverter.convertBack(entity);
        importedDocument.setNumber("123456");
        ImportedDocumentDTO result = documentImportService.updateImportedDocument(importedDocument,
                "2");
        Assertions.assertEquals(importedDocument.getNumber(), result.getNumber());
        assertThrows(RuntimeException.class, () -> documentImportService.updateImportedDocument(importedDocument,
                "35563c07-82b2-43a8-a3b2-c9a11c696b40"));

    }

    ImportedDocumentEntity getImportedDocumentEntity() {
        ImportedDocumentEntity entity = new ImportedDocumentEntity();
        entity.setBatch("1");
        ClientDTO client = new ClientDTO();
        client.setId("2");
        client.setLegacyId(1L);
        entity.setClientId(client.getLegacyId());
        entity.setAmount(BigDecimal.ONE);
        entity.setNumber("1");
        entity.setDocumentDate(LocalDateTime.now());
        entity.setCreated(LocalDateTime.now());
        entity.setPayeeAccount("01234567890123456789");
        entity.setStatus(ImportedDocumentDTO.StatusEnum.VALID.getValue());
        entity.setDocType("DA");
        entity.setPayerAccount("01234567890123456789");
        entity.setStatus("INVALID");
        return entity;
    }

}