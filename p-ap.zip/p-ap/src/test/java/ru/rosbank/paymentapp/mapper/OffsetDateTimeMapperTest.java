package ru.rosbank.paymentapp.mapper;

import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;

class OffsetDateTimeMapperTest extends BaseTest {
    @Autowired
    OffsetDateTimeMapper offsetDateTimeMapper;

    @Test
    void toDate() {
        OffsetDateTime offsetDateTime = OffsetDateTime.now();
        Assertions.assertEquals(offsetDateTime.getMinute(), offsetDateTimeMapper.toDate(offsetDateTime).getMinute());
        Assertions.assertNull(offsetDateTimeMapper.toDate(null));
    }
}