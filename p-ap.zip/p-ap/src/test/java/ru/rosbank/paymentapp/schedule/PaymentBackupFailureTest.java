package ru.rosbank.paymentapp.schedule;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntityOld;
import ru.rosbank.paymentapp.repository.PaymentEntityOldRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.BackupService;
import ru.rosbank.platform.redis.SharedLock;

public class PaymentBackupFailureTest extends BaseTest {
    @Autowired
    PaymentBackupJob paymentBackupJob;
    @Autowired
    PaymentEntityRepository paymentEntityRepository;
    @Autowired
    PaymentEntityOldRepository paymentEntityOldRepository;
    @MockBean
    SharedLock sharedLock;

    @MockBean
    BackupService backupService;


    @Test
    void backupFail() throws InvocationTargetException, IllegalAccessException {
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        when(backupService.getBatchPayments(any())).thenReturn(List.of(new PaymentEntity()));
        save();
        doThrow(IllegalAccessException.class).when(backupService).saveAndDeletePayment(any());
        Iterable<PaymentEntity> all = paymentEntityRepository.findAll();
        long sizeBefore = all.spliterator().getExactSizeIfKnown();
        paymentBackupJob.backup();
        Iterable<PaymentEntityOld> entityOldRepositoryAll = paymentEntityOldRepository.findAll();
        long sizeEntityOld = entityOldRepositoryAll.spliterator().getExactSizeIfKnown();
        assertEquals(0, sizeEntityOld);
        Iterable<PaymentEntity>  entityAll = paymentEntityRepository.findAll();
        long sizeEntity = entityAll.spliterator().getExactSizeIfKnown();
        assertEquals(sizeBefore, sizeEntity);
        paymentEntityRepository.deleteByBisDocumentId("123456789");
    }

    @Transactional
    public void save() {
        PaymentEntity doc = new PaymentEntity();
        doc.setStatus("COMPLETED");
        doc.setDate(LocalDateTime.now().minusDays(23));
        doc.setBisDocumentId("123456789");
        paymentEntityRepository.save(doc);
    }


}
