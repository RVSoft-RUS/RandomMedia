package ru.rosbank.paymentapp;


import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import ru.rosbank.paymentapp.service.fraud.model.AbstractEvent;


@SpringBootTest
@ActiveProfiles("unit_test")
public abstract class BaseTest {
    @MockBean(name = "antifraudKafkaTemplate")
    KafkaTemplate<String, AbstractEvent> antifraudKafkaTemplate;
}
