package ru.rosbank.paymentapp.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static ru.rosbank.paymentapp.service.RejectedPaymentStatusProcessor.BIS_PAYMENT_ORDER_PRO_INPUT_SYSTEM;
import static ru.rosbank.paymentapp.service.RejectedPaymentStatusProcessor.BIS_PAYMENT_ORDER_REJECTED_STATUS;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.AccountService;
import ru.rosbank.paymentapp.service.EsbService;
import ru.rosbank.paymentapp.service.OrganizationService;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.MoneyAmountTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.DocumentIndicatorTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;


class RejectedVtbPaymentStatusJobTest extends BaseTest {

    @Value("${rejected.VTBPaymentStatus.bicsVtb}")
    private List<String> bicsVtb;

    @Autowired
    RejectedVtbPaymentStatusJob rejectedVtbPaymentStatusJob;
    @Autowired
    PaymentEntityRepository paymentEntityRepository;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    AccountService accountAppApi;
    @MockBean
    OrganizationService organizationAppApi;
    @MockBean
    public EsbService esbService;
    @MockBean
    UserService userService;
    @MockBean
    PaymentEventService paymentEventService;

    @BeforeEach
    public void init() {
        when(organizationAppApi.rootGet(anyString())).thenReturn(List.of(new OrganizationDTO()
                .bisIds(List.of(new BisIdDTO().id("id").branch("branch")))));

        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(1L);
        clientDTO.setId("2");
        when(userService.getClientById(anyLong())).thenReturn(Optional.of(clientDTO));
        when(userService.getClientByDboProId(anyString())).thenReturn(Optional.of(clientDTO));

    }

    @Test
    void test() {
        doNothing().when(paymentEventService).sendDocumentStatus(any());
        var paymentSentToBis = paymentEntityRepository.findAllByStatusIn(
                List.of(DocumentStatus.SIGNED.getValue(), DocumentStatus.DFM_PROCESSING.getValue(),
                        DocumentStatus.COMPLETED.getValue())).stream().findFirst().get();
        paymentSentToBis.setId(null);
        paymentSentToBis.setExecutionDate(LocalDateTime.now());
        paymentSentToBis.setStatus(DocumentStatus.SENT_TO_BIS.getValue());
        paymentSentToBis.setPayeeBankBic("40349758");
        paymentSentToBis.setNumber("112");
        var paymentError = paymentEntityRepository.findAllByStatusIn(List.of(DocumentStatus.SIGNED.getValue(),
                DocumentStatus.DFM_PROCESSING.getValue(), DocumentStatus.COMPLETED.getValue())).stream().findFirst().get();
        paymentError.setId(null);
        paymentError.setPayeeBankBic("40349758");
        paymentError.setNumber("112");
        paymentError.setStatus(DocumentStatus.ERROR.getValue());
        paymentEntityRepository.saveAll(List.of(paymentSentToBis, paymentError));
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        List<PaymentOrderTypeEsb> paymentOrderTypeEsbs = new ArrayList<>();
        paymentOrderTypeEsbs.add(new PaymentOrderTypeEsb()
                .withOrderNumber(paymentSentToBis.getNumber())
                .withStatus(BIS_PAYMENT_ORDER_REJECTED_STATUS)
                .withDocumentDate(Date.from(paymentSentToBis.getDate().atZone(ZoneId.systemDefault()).toInstant()))
                .withPayee(
                        new RequisiteTypeEsb()
                                .withNumber(new AccountNumberTypeEsb()
                                        .withAccountNumber20Digit(paymentSentToBis.getPayeeAccount())))
                .withDocumentIndicator(
                        new DocumentIndicatorTypeEsb().withInputSystem(BIS_PAYMENT_ORDER_PRO_INPUT_SYSTEM))
                .withAmount(new MoneyAmountTypeEsb().withAmount(paymentSentToBis.getAmount())));
        when(esbService.getPaymentList(anyString(), anyString(), any(), any())).thenReturn(paymentOrderTypeEsbs);
        List<AccountDTO> accountDTOS = new ArrayList<>();
        accountDTOS.add(new AccountDTO().bisId(
                new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                        .id("id").branch("branch"))
                .number(paymentSentToBis.getPayerAccount())
                .number13(""));
        when(accountAppApi.getAccountList(any(), any())).thenReturn(accountDTOS);

        rejectedVtbPaymentStatusJob.run();
        Assertions.assertEquals(1, StreamSupport
                        .stream(paymentEntityRepository.findAll().spliterator(), false)
                        .filter(p -> DocumentStatus.REJECTED.name().equals(p.getStatus()))
                        .filter(p -> "112".equals(p.getNumber())).collect(Collectors.toList()).size());
        paymentEntityRepository.deleteAll(List.of(paymentSentToBis, paymentError));
    }
}
