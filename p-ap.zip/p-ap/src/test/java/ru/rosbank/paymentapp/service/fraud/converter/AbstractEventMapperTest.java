package ru.rosbank.paymentapp.service.fraud.converter;

import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.REJECTED_AT_ONCE_PAYMENT_STATUS;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.service.fraud.model.AntifraudPaymentStatusEvent;
import ru.rosbank.platform.client.auditapp.model.AntifraudPaymentStatusDTO;
import ru.rosbank.platform.client.auditapp.model.PaymentStatusDTO;


class AbstractEventMapperTest extends BaseTest {

    private final AbstractEventMapper eventMapper = Mappers.getMapper(AbstractEventMapper.class);

    @Test
    void toPaymentStatusEventDto() {
        AntifraudPaymentStatusEvent event =
                new AntifraudPaymentStatusEvent();
        event.setId("eventId");
        event.setStatus(REJECTED_AT_ONCE_PAYMENT_STATUS);
        event.setStatusCodeT1(0);

        AntifraudPaymentStatusDTO dto = eventMapper.toPaymentStatusEventDto(event);
        Assertions.assertEquals("eventId", dto.getPaymentStatus().getId());
        Assertions.assertEquals(PaymentStatusDTO.StatusCodeT1Enum.ZERO, dto.getPaymentStatus().getStatusCodeT1());
        Assertions.assertEquals(PaymentStatusDTO.StatusEnum.REJECTED_AT_ONCE, dto.getPaymentStatus().getStatus());

    }

}