package ru.rosbank.paymentapp.service.dfm;

import static org.mockito.ArgumentMatchers.any;

import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;
import ru.rosbank.paymentapp.entity.DocumentType;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.DFMPaymentRepository;

class DfmPaymentServiceTest extends BaseTest {
    @MockBean
    DFMPaymentRepository dfmPaymentRepository;
    @Autowired
    DfmPaymentService dfmPaymentService;

    @Test
    void finalizeStatusOnError() {
        DFMPaymentEntity dfm = new DFMPaymentEntity();
        dfm.setFlag(5);
        Mockito.when(dfmPaymentRepository.findByDocSerial(any())).thenReturn(Optional.of(dfm));
        Mockito.when(dfmPaymentRepository.save(any())).thenReturn(dfm);
        PaymentEntity document = new PaymentEntity();
        document.setDoctype(DocumentType.DA.value());
        document.setPayerAccount("40500000001234567890");
        dfmPaymentService.finalizeStatusOnError(document);
    }

    @Test
    void getInputUser() {
        DFMPaymentEntity dfm = new DFMPaymentEntity();
        dfm.setFlag(3);
        Mockito.when(dfmPaymentRepository.findByDocSerial(any())).thenReturn(Optional.of(dfm));
        PaymentEntity document = new PaymentEntity();
        document.setDoctype("DA");
        document.setPayerAccount("40501234567890123456");
        Assertions.assertEquals(dfmPaymentService.getInputUser(document), "DBO");

    }
}