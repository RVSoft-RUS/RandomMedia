package ru.rosbank.paymentapp.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.mapper.TemplateMapper;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;
import ru.rosbank.platform.server.paymentapp.model.Template;


class TemplateServiceTest extends BaseTest {

    @Autowired
    TemplateService templateService;

    @MockBean
    ScheduledConfiguration scheduledConfiguration;


    private static final List<String> ACCS = Arrays.asList("40802810597880000207", "40702810393790000591");

    @Test
    void getTemplateList() {

        List<Template> templates = templateService.getTemplateList("123456789", "10", "0", ACCS);
        Assert.assertEquals(5, templates.size());
        Assert.assertEquals("VZX-77", templates.get(0).getName());
        Assert.assertEquals("Абв", templates.get(1).getName());
        Assert.assertEquals("ц777", templates.get(2).getName());
        Assert.assertEquals("Ц777", templates.get(3).getName());
        Assert.assertEquals("я 2", templates.get(4).getName());
    }

    @Test
    void getPageTest() {
        List<Template> templates = templateService.getTemplateList("123456789", "2", "2", ACCS);
        Assert.assertEquals(2, templates.size());

        templates = templateService.getTemplateList("123456789", "2", "20", ACCS);
        Assert.assertEquals(0, templates.size());

        templates = templateService.getTemplateList("123456789", "", "", ACCS);
        Assert.assertEquals(5, templates.size());
    }

    @Test
    void incrementTest() {
        Assertions.assertDoesNotThrow(() -> templateService.increment(2L));
    }

    @Test
    void searchName() {

        List<Template> templates = templateService.search("123456789", "77", ACCS);
        Assert.assertEquals(3, templates.size());
        Assert.assertEquals("VZX-77", templates.get(0).getName());
        Assert.assertEquals("ц777", templates.get(1).getName());
        Assert.assertEquals("Ц777", templates.get(2).getName());
    }

    @Test
    void searchPayeeName() {
        List<Template> templates = templateService.search("123456789", "/110", ACCS);
        Assert.assertEquals(3, templates.size());
    }

    @Test
    void searchPayeeInn() {
        List<Template> templates = templateService.search("123456789", "4501", ACCS);
        Assert.assertEquals(5, templates.size());
    }

    @Test
    void searchPayerName() {
        List<Template> templates = templateService.search("123456789", "Донварь", ACCS);
        Assert.assertEquals(5, templates.size());
    }

    @Test
    void search0() {
        List<Template> templates = templateService.search("123456789", "Донварь Test", ACCS);
        Assert.assertEquals(0, templates.size());
    }

    @Test
    void search() {
        List<Template> templates = templateService.search("123456789", "1", ACCS);
        Assert.assertEquals(5, templates.size());
    }

    @Test
    void getTemplate() throws Exception {
        Template template = templateService.getTemplate(1L, "123456789");
        Assert.assertEquals("123456789", template.getDboProId());
    }

    @Test
    void saveTemplate() throws Exception {
        List<Template> templates = templateService.getTemplateList("123456789", "10", "0", ACCS);
        Template template = templates.get(0);
        template.setLastModifiedDate(LocalDate.now());
        template.setKbk("New kbk");
        templateService.saveTemplate(TemplateMapper.INSTANCE.toDTO(template));

        templates = templateService.search("123456789", "VZX-77", ACCS);
        Assert.assertEquals(1, templates.size());
        Assert.assertEquals("New kbk", templates.get(0).getKbk());
    }

    @Test
    void createAndDeleteTemplate() {
        List<Template> templates = templateService.getTemplateList("123456789", "10", "0", ACCS);
        Template template = templateService.createTemplateFromDocument(TemplateMapper.INSTANCE.toDTO(templates.get(0)),
                "TestTest", "123456789");
        templates = templateService.getTemplateList("123456789", "10", "0", ACCS);
        Assert.assertEquals(6, templates.size());

        templateService.deleteTemplate(Long.valueOf(template.getId()), template.getDboProId());
        templates = templateService.getTemplateList("123456789", "10", "0", ACCS);
        Assert.assertEquals(5, templates.size());
    }

    @Test
    void searchPayerNameAccNull() {
        List<Template> templates = templateService.search("123456789", "Донварь", null);
        org.assertj.core.api.Assertions.assertThat(templates.size()).isEqualTo(5);
    }

    @Test
    void search0AccNull() {
        List<Template> templates = templateService.search("123456789", "Донварь Test", null);
        org.assertj.core.api.Assertions.assertThat(templates.size()).isEqualTo(0);
    }

    @Test
    void searchQueryNullAccNull() {
        List<Template> templates = templateService.search("123456789", null, null);
        org.assertj.core.api.Assertions.assertThat(templates.size()).isEqualTo(5);
    }
}
