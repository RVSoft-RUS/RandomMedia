package ru.rosbank.paymentapp.service.validators;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.CurrencyControlEntity;
import ru.rosbank.paymentapp.entity.FileInfoEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.CurrencyControlRepository;
import ru.rosbank.platform.client.fileapp.api.FileAppApiClient;
import ru.rosbank.platform.client.fileapp.model.FileInfoDTO;
import ru.rosbank.platform.client.portalpro.api.PortalProApiApiClient;
import ru.rosbank.platform.redis.SharedLock;


class ProPortalServiceTest extends BaseTest {
    @Autowired
    private ProPortalService proPortalService;
    @MockBean
    private PortalProApiApiClient portalProApiApiClient;
    @MockBean
    private FileAppApiClient fileAppApiClient;
    @MockBean
    private CurrencyControlRepository currencyControlRepository;
    @MockBean
    private SharedLock sharedLock;

    @Test
    void sendCurrencyControlInfoWithFilesToProPortal() {
        PaymentEntity paymentEntity = getPaymentEntity();
        paymentEntity.getCurrencyControlEntity().setFileInfoEntityList(new ArrayList<>());
        paymentEntity.getCurrencyControlEntity().setPaymentEntity(paymentEntity);
        Mockito.when(fileAppApiClient.fileIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(new FileInfoDTO(), HttpStatus.OK));

        Mockito.when(fileAppApiClient.fileIdElibPost(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new FileInfoDTO(), HttpStatus.OK));

        Mockito.when(fileAppApiClient.fileIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(new FileInfoDTO().elibId("elibId"), HttpStatus.OK));

        Mockito.when(sharedLock.lock(Mockito.anyString(), Mockito.anyInt()))
                .thenReturn(true);
        Mockito.when(currencyControlRepository.findById(Mockito.any()))
                .thenReturn(Optional.of(paymentEntity.getCurrencyControlEntity()));
        proPortalService.sendCurrencyControlInfoToProPortal(getPaymentEntity());
        Mockito.verify(currencyControlRepository, Mockito.times(2)).save(Mockito.any());
    }

    @Test
    void sendCurrencyControlInfoWithoutFilesToProPortal() {
        PaymentEntity paymentEntity = getPaymentEntity();
        paymentEntity.getCurrencyControlEntity().setFileInfoEntityList(null);
        paymentEntity.getCurrencyControlEntity().setPaymentEntity(paymentEntity);
        Mockito.when(sharedLock.lock(Mockito.anyString(), Mockito.anyInt()))
                .thenReturn(true);
        Mockito.when(currencyControlRepository.findById(Mockito.any()))
                .thenReturn(Optional.of(paymentEntity.getCurrencyControlEntity()));
        proPortalService.sendCurrencyControlInfoToProPortal(paymentEntity);
        Mockito.verify(currencyControlRepository, Mockito.times(2)).save(Mockito.any());

    }

    @Test
    void sendCurrencyControlInfoWithEmptyFileListToProPortal() {
        PaymentEntity paymentEntity = getPaymentEntity();
        paymentEntity.getCurrencyControlEntity().setFileInfoEntityList(new ArrayList<>());
        paymentEntity.getCurrencyControlEntity().setPaymentEntity(paymentEntity);
        Mockito.when(sharedLock.lock(Mockito.anyString(), Mockito.anyInt()))
                .thenReturn(true);
        Mockito.when(currencyControlRepository.findById(Mockito.any()))
                .thenReturn(Optional.of(paymentEntity.getCurrencyControlEntity()));
        proPortalService.sendCurrencyControlInfoToProPortal(paymentEntity);
        Mockito.verify(currencyControlRepository, Mockito.times(2)).save(Mockito.any());

    }

    @Test
    void sendCurrencyControlNegative() {
        PaymentEntity paymentEntity = getPaymentEntity();
        paymentEntity.getCurrencyControlEntity().setFileInfoEntityList(new ArrayList<>());
        paymentEntity.getCurrencyControlEntity().setPaymentEntity(paymentEntity);
        Mockito.when(sharedLock.lock(Mockito.anyString(), Mockito.anyInt()))
                .thenReturn(true);
        Mockito.when(currencyControlRepository.findById(Mockito.any()))
                .thenReturn(Optional.of(paymentEntity.getCurrencyControlEntity()));
        proPortalService.sendCurrencyControlInfoToProPortal(getPaymentEntity());
        Mockito.verify(sharedLock, Mockito.atLeastOnce()).release(Mockito.anyString());
    }

    private List<FileInfoEntity> getFileInfoEntityList() {
        FileInfoEntity fileInfoEntity1 = new FileInfoEntity();
        fileInfoEntity1.setFileId("1");
        FileInfoEntity fileInfoEntity2 = new FileInfoEntity();
        fileInfoEntity2.setFileId("2");
        return Arrays.asList(fileInfoEntity1, fileInfoEntity2);
    }

    private CurrencyControlEntity getCurrencyControl() {
        CurrencyControlEntity currencyControlEntity = new CurrencyControlEntity();
        currencyControlEntity.setId(Long.parseLong("123"));
        currencyControlEntity.setFileInfoEntityList(getFileInfoEntityList());
        currencyControlEntity.setIsSumContractLess200(true);
        currencyControlEntity.setComment("comment");
        currencyControlEntity.setFullName("fullName");
        currencyControlEntity.setPhone("phone");
        return currencyControlEntity;
    }

    private PaymentEntity getPaymentEntity() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setCurrencyControlEntity(getCurrencyControl());
        paymentEntity.setOrganizationCrmId("orgCrmId");
        paymentEntity.setOrganizationBisBranch("branch");
        paymentEntity.setOrganizationBisId("bisId");
        paymentEntity.setOrganizationShortName("shortName");
        paymentEntity.setNumber("number");
        paymentEntity.setDate(LocalDateTime.now());
        return paymentEntity;
    }

}