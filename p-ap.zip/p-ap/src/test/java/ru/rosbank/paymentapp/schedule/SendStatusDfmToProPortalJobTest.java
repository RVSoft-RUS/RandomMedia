package ru.rosbank.paymentapp.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.DFMPaymentRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.platform.client.portalpro.api.PortalProApiApi;
import ru.rosbank.platform.redis.SharedLock;

class SendStatusDfmToProPortalJobTest extends BaseTest {
    @MockBean
    PaymentEntityRepository paymentEntityRepository;
    @MockBean
    DFMPaymentRepository dfmPaymentRepository;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    PortalProApiApi portalProApiApi;
    @Autowired
    SendStatusDfmToProPortalJob sendStatusDfmToProPortalJob;


    @Test
    void run() {
        Mockito.when(dfmPaymentRepository.findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(any(), any()))
                .thenReturn(List.of(getDfm()));
        Mockito.when(paymentEntityRepository.findAllByStatusAndIdIn(any(), any())).thenReturn(List.of(getPaymentEntity()));
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        sendStatusDfmToProPortalJob.run();
        Mockito.verify(portalProApiApi, times(1)).appDfmAlertsPut(any());
    }

    @Test
    void run2() {
        Mockito.when(dfmPaymentRepository.findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(any(), any()))
                .thenReturn(List.of(getDfm()));
        Mockito.when(paymentEntityRepository.findAllByStatusAndIdIn(any(), any())).thenReturn(List.of(getPaymentEntity()));
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(false);
        sendStatusDfmToProPortalJob.run();
        Mockito.verify(portalProApiApi, times(0)).appDfmAlertsPut(any());
    }

    public DFMPaymentEntity getDfm() {
        DFMPaymentEntity dfm = new DFMPaymentEntity();
        dfm.setId(1L);
        dfm.setDocDate(LocalDateTime.now());
        dfm.setReason("Без НДС");
        dfm.setDocSum(new BigDecimal("100.00"));
        dfm.setName("ИП Донварь Кристина Валерьевна");
        dfm.setPayeracccode("40802810597880000207");
        dfm.setPayerinn("450146852396");
        dfm.setPayerbank("РОСБАНК");
        dfm.setPayerbik("044525256");
        dfm.setBenefname("20/110");
        dfm.setIdate(LocalDateTime.now());
        dfm.setFlag(5);
        dfm.setStatus("PROCESSING");
        dfm.setDocNumber("777");
        dfm.setDocSerial(2L);
        return dfm;
    }

    private PaymentEntity getPaymentEntity() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setId(2L);
        paymentEntity.setOrganizationCrmId("orgCrmId");
        paymentEntity.setOrganizationBisBranch("branch");
        paymentEntity.setOrganizationBisId("bisId");
        paymentEntity.setOrganizationShortName("shortName");
        paymentEntity.setNumber("number");
        paymentEntity.setDate(LocalDateTime.now());
        paymentEntity.setSignDate(LocalDateTime.now());
        return paymentEntity;
    }
}