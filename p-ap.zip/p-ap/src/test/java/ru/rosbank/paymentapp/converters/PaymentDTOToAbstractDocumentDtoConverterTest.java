package ru.rosbank.paymentapp.converters;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.BankInfoDTO;
import ru.rosbank.platform.client.statementapp.model.CommissionDTO;
import ru.rosbank.platform.client.statementapp.model.ContactPersonDTO;
import ru.rosbank.platform.client.statementapp.model.MemberDTO;
import ru.rosbank.platform.client.statementapp.model.MemorialOrderDTO;
import ru.rosbank.platform.client.statementapp.model.OrderStampDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.client.statementapp.model.RequisiteDTO;
import ru.rosbank.platform.client.statementapp.model.SignerDTO;

class PaymentDTOToAbstractDocumentDtoConverterTest extends BaseTest {
    @Autowired
    PaymentDTOToAbstractDocumentDtoConverter converter;

    @Test
    void test() {
        var response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.PAYMENT_BILL, PaymentDTO.TypeEnum.DA));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.PAYMENT_BILL, PaymentDTO.TypeEnum.DP));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.PAYMENT_ORDER, PaymentDTO.TypeEnum.DK));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.BANK_ORDER, PaymentDTO.TypeEnum.DJ));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.MEMORIAL_ORDER, PaymentDTO.TypeEnum.DF));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.CASH_RECEIPT_ORDER, PaymentDTO.TypeEnum.CJ));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.ACCOUNT_CASH_WARRANT, PaymentDTO.TypeEnum.CK));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.COLLECTION_ASSIGNMENT, PaymentDTO.TypeEnum.CF));
        Assertions.assertNotNull(response);
        response = converter.convert(createPaymentDTO(PaymentDTO.SubtypeEnum.CURRENCY_TRANSACTION, PaymentDTO.TypeEnum.DA));
        Assertions.assertNotNull(response);
    }

    private PaymentDTO createPaymentDTO(PaymentDTO.SubtypeEnum subtype, PaymentDTO.TypeEnum type) {
        return new PaymentDTO().subtype(subtype)
                .id("id")
                .number("number")
                .created(OffsetDateTime.now())
                .completed(OffsetDateTime.now())
                .amount(new AmountDTO().sum(BigDecimal.TEN).currency("RUR"))
                .amountString("10")
                .amountStringCurrency("RUR")
                .type(type)
                .payer(new RequisiteDTO().account("payer").bank(new BankInfoDTO().bic("payerbic")))
                .payee(new RequisiteDTO().account("payee").bank(new BankInfoDTO().bic("payeebic")))
                .purpose("purpose")
                .payerStatus("payerStatus")
                .basisDocumentNumber("basisDocumentNumber")
                .incomingDate(OffsetDateTime.now())
                .basisDocumentCreated("basisDocumentCreated")
                .taxPeriod("taxPeriod")
                .taxPaymentType("taxPaymentType")
                .codeTypeIncome("810")
                .uin("uin")
                .kbk("kbk")
                .oktmo("oktmo")
                .paymentBasis("paymentBasis")
                .paymentPriority("paymentPriority")
                .processedBy(new BankInfoDTO().bic("processedbybik"))
                .paymentOutputMode(PaymentDTO.PaymentOutputModeEnum.TELEGRAPH)
                .merchantName("merchantName")
                .cardPan("cardPan")
                .cardHolder("cardHolder")
                .approveCode("approveCode")
                .mcc("mcc")
                .valueDate(OffsetDateTime.now())
                .expirationAcceptanceDate(OffsetDateTime.now())
                .orderStampSinger("orderStampSinger")
                .content("content")
                .itmTransId("itmTransId")
                .paymentPartialNumber("paymentPartialNumber")
                .typeCodeOrder("typeCodeOrder")
                .paymentOrderNumber("paymentOrderNumber")
                .paymentOrderDate(OffsetDateTime.now())
                .paymentBalanceAmount("paymentBalanceAmount")
                .placeInFileDate(OffsetDateTime.now())
                .paymentCondition("paymentCondition")
                .expirationAcceptance("expirationAcceptance")
                .endExpirationAcceptance("endExpirationAcceptance")
                .orderDate(OffsetDateTime.now())
                .cardAcceptorAddress("cardAcceptorAddress")
                .terminalId("terminalId")
                .transDateTime(OffsetDateTime.now())
                .accountNumber13("accountNumber13")
                .status("status")
                .signerFirst(new SignerDTO().fio("first"))
                .signerSecond(new SignerDTO().fio("second"))
                .conversionCourse("conversionCourse")
                .member(new MemberDTO().account("memberacc"))
                .commission(new CommissionDTO().amount("1"))
                .contactPerson(new ContactPersonDTO().name("contactPerson"))
                .memorialOrder(new MemorialOrderDTO().number("memorialOrder"))
                .additionalInformation("additionalInformation")
                .paymentKind("paymentKind")
                .orderStamp(new OrderStampDTO().bik("order stamp bik"))
                .exchangeRate("exchangeRate")
                .exchangeAmountPayer("exchangeAmountPayer")
                .exchangeAmountPayee("exchangeAmountPayee")
                .field23("field23");
    }
}
