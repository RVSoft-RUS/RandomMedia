package ru.rosbank.paymentapp.service.fraud.converter;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;


class ApiLevelToVersionConverterTest extends BaseTest {

    @Autowired
    ApiLevelToVersionConverter apiLevelToVersionConverter;

    @Test
    void getVersion() {
        String version = apiLevelToVersionConverter.getVersion("1");
        assertEquals(version, "1.0");
        version = apiLevelToVersionConverter.getVersion("34");
        assertEquals(version, "14");
    }

    @Test
    void getVersionNull() {
        String version = apiLevelToVersionConverter.getVersion("35");
        assertNull(version);
        version = apiLevelToVersionConverter.getVersion(null);
        assertNull(version);
    }
}