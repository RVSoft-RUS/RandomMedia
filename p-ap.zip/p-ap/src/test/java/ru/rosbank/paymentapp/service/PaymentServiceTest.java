package ru.rosbank.paymentapp.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static ru.rosbank.platform.client.statementapp.model.PaymentDTO.SubtypeEnum.BANK_ORDER;

import freemarker.template.TemplateException;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.dto.phub.DocumentStatusMessageDto;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.entity.StatusTranslationEntity;
import ru.rosbank.paymentapp.esb.support.BankProcessingException;
import ru.rosbank.paymentapp.repository.DocumentRecallRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.repository.StatusTranslationRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;
import ru.rosbank.paymentapp.service.email.LocalEmailSender;
import ru.rosbank.paymentapp.service.exceptions.DocumentNotSignedException;
import ru.rosbank.paymentapp.service.exceptions.DocumentRecallException;
import ru.rosbank.paymentapp.service.exceptions.DocumentRecallRetryException;
import ru.rosbank.paymentapp.service.exceptions.PaymentNotRevertibleException;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.paymentapp.service.sms.SendSmsService;
import ru.rosbank.paymentapp.service.validators.PaymentSignedValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.MetaDataDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.esb.exception.EsbTimeoutException;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.reversepaymentorder.ReversePaymentOrderResponseTypeEsb;
import ru.rosbank.platform.redis.SharedLock;

@Slf4j
class PaymentServiceTest extends BaseTest {

    @Autowired
    PaymentService paymentService;
    @Autowired
    PaymentSignedValidator paymentSafeSignedService;
    @Autowired
    PaymentEntityRepository documentRepository;
    @Autowired
    DocumentRecallRepository documentRecallRepository;
    @Autowired
    PaymentEntityRepository paymentEntityRepository;
    @Autowired
    StatusTranslationRepository statusTranslationRepository;
    @Autowired
    SendSmsService sendSmsService;

    @MockBean
    ScheduledConfiguration scheduledConfiguration;
    @MockBean
    ReferenceAppApiClient referenceAppApiClient;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    EsbService esbService;
    @MockBean
    PaymentEventService paymentEventService;
    @MockBean
    StatementService statementService;
    @MockBean
    DeliveringResourceService deliveringResourceService;
    @MockBean
    PrintFormGenerator printFormGenerator;
    @MockBean
    LocalEmailSender localEmailSender;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    AccountService accountService;

    @Value("${payment.recall.timeout}")
    private int recallTimeout;
    private static final String STATUS_PHUB_DOCUMENT_ACCEPTED = "DocumentAccepted";
    private static final String STATUS_PHUB_DOCUMENT_REJECTED = "DocumentRejected";

    @Test
    void getDocumentCreationDate() {
        Date creationDate = paymentService.getDocumentCreationDate();
        Assertions.assertNotNull(creationDate);
    }

    @Test
    void isRevertible() {

        PaymentEntity document = documentRepository.findById(2L).get();
        document.setSignDate(LocalDateTime.now().minusSeconds(recallTimeout));
        document.setPayerInn("0123456789");
        boolean isRevertible = paymentService.isRevertible(document);
        Assertions.assertTrue(isRevertible);
    }

    @Test
    void isRevertibleToYourself() {
        Mockito.when(referenceAppApiClient.branchGet(any()))
                .thenReturn(new ResponseEntity<>(getBranches(), HttpStatus.OK));

        PaymentEntity document = documentRepository.findById(2L).get();
        document.setSignDate(LocalDateTime.now().minusSeconds(recallTimeout));

        document.setPayerInn("0123456789");
        document.setPayeeInn("0123456789");
        document.setPayerBankBic("044525256");
        document.setPayeeBankBic("044525256");
        document.setPayeeAccount("40802567890123456789");
        boolean isRevertible = paymentService.isRevertible(document);
        Assertions.assertFalse(isRevertible);
    }

    @Test
    void sign() {
        var document = documentRepository.save(createDocument());
        paymentService.setSigned(document.getId(), new MetaDataDTO().dateSignature(OffsetDateTime.now())
                .bisId(new ru.rosbank.platform.client.paymentapp.model.BisIdDTO().branch("R19").id("BisId")).crmId("crmId")
                .dboProId("dboProId").shortNameOrg("shortNameOrg"));
        var documentSigned = documentRepository.findById(document.getId());
        assertThat(documentSigned.get().getOrganizationCrmId()).isEqualTo("crmId");
        assertThat(documentSigned.get().getOrganizationBisId()).isEqualTo("BisId");
        assertThat(documentSigned.get().getOrganizationBisBranch()).isEqualTo("R19");
        assertThat(documentSigned.get().getOrganizationShortName()).isEqualTo("shortNameOrg");
        assertThat(documentSigned.get().getStatus()).isEqualTo("SIGNED");
        documentRepository.delete(document);
    }

    @Test
    void signThrow() {
        var document = documentRepository.save(createDocument());

        org.assertj.core.api.Assertions.assertThatThrownBy(() -> paymentService.setSigned(document.getId(),
                new MetaDataDTO().dateSignature(OffsetDateTime.now()))).isInstanceOf(RuntimeException.class);

        documentRepository.delete(document);
    }

    @Test
    void recallSignedCompletedThrowsException() {
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        var document = createDocument();
        document.setStatus("COMPLETED");
        documentRepository.save(document);
        Assertions.assertThrows(PaymentNotRevertibleException.class, () -> paymentService.recall(document.getId(), false));
        var result = documentRecallRepository.findByPaymentEntityId(document.getId()).get();
        Assertions.assertEquals("COMPLETED", result.getStatus());
        documentRepository.delete(document);
    }

    @Test
    void recallSignedRetryLockFailed() {
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(false);
        var document = createDocument();
        documentRepository.save(document);
        Assertions.assertThrows(DocumentRecallRetryException.class, () -> paymentService.recall(document.getId(), false));
        var result = documentRecallRepository.findByPaymentEntityId(document.getId()).get();
        Assertions.assertEquals("RETRY", result.getStatus());
        documentRepository.delete(document);
    }

    @Test
    void recallSignedSentToBisSuccessful() {
        doNothing().when(paymentEventService).sendDocumentStatus(any());
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        when(esbService.reversePaymentOrder(any())).thenReturn(
                new ReversePaymentOrderResponseTypeEsb(List.of(
                        new ReversePaymentOrderResponseTypeEsb.ReversePaymentOrderResponse()
                                .withPaymentOrder(new PaymentOrderTypeEsb().withDocumentID("id")))));
        var document = createDocument();
        document.setStatus("SENT_TO_BIS");
        document.setBisDocumentId("PP220224-421818101");
        documentRepository.save(document);
        paymentService.recall(document.getId(), true);
        var recall = documentRecallRepository.findByPaymentEntityId(document.getId()).get();
        Assertions.assertEquals("RECALLED", recall.getStatus());
        var result = paymentEntityRepository.findById(document.getId()).get();
        Assertions.assertEquals("RECALLED", result.getStatus());
        documentRepository.delete(document);
    }

    @Test
    void recallSignedSuccessful() {
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        var document = createDocument();
        document.setStatus("DFM_PROCESSING");
        documentRepository.save(document);
        paymentService.recall(document.getId(), true);
        var recall = documentRecallRepository.findByPaymentEntityId(document.getId()).get();
        Assertions.assertEquals("RECALLED", recall.getStatus());
        var result = paymentEntityRepository.findById(document.getId()).get();
        Assertions.assertEquals("RECALLED", result.getStatus());
        documentRepository.delete(document);
    }

    @Test
    void recallSignedBisProcessingException() {
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        when(esbService.reversePaymentOrder(any())).thenThrow(new BankProcessingException("333", "Some 333 BIS error"));
        var document = createDocument();
        document.setStatus("SENT_TO_BIS");
        document.setBisDocumentId("PP220224-421818101");
        documentRepository.save(document);
        Assertions.assertThrows(DocumentRecallException.class, () -> paymentService.recall(document.getId(), true));
        var result = documentRecallRepository.findByPaymentEntityId(document.getId()).get();
        Assertions.assertEquals("ERROR", result.getStatus());
        documentRepository.delete(document);
    }

    @Test
    void recallSignedBisTimeoutException() {
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        when(esbService.reversePaymentOrder(any())).thenThrow(new EsbTimeoutException("timeout"));
        var document = createDocument();
        document.setStatus("SENT_TO_BIS");
        document.setBisDocumentId("PP220224-421818101");
        documentRepository.save(document);
        Assertions.assertThrows(DocumentRecallException.class, () -> paymentService.recall(document.getId(), true));
        var result = documentRecallRepository.findByPaymentEntityId(document.getId()).get();
        Assertions.assertEquals("TIMEOUT", result.getStatus());
        documentRepository.delete(document);
    }

    @Test
    void recallSignedBisProcessingSuccessful() {
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        var document = createDocument();
        document.setStatus("SENT_TO_BIS");
        document.setBisDocumentId("PP220224-421818101");
        documentRepository.save(document);
        when(esbService.reversePaymentOrder(any()))
                .thenReturn(new ReversePaymentOrderResponseTypeEsb()
                        .withReversePaymentOrderResponse(List
                                .of(new ReversePaymentOrderResponseTypeEsb.ReversePaymentOrderResponse()
                                        .withPaymentOrder(new PaymentOrderTypeEsb()
                                                .withDocumentID(document.getBisDocumentId())))));
        Assertions.assertThrows(DocumentNotSignedException.class, () -> paymentService.recall(document.getId(), false));
        paymentService.recall(document.getId(), true);
        var result = documentRecallRepository.findByPaymentEntityId(document.getId()).get();
        Assertions.assertEquals("RECALLED", result.getStatus());
        documentRepository.delete(document);
    }

    @Test
    void getSignedDocumentCountTest() {
        var payment1 = new PaymentEntity();
        payment1.setStatus("CREATED");
        payment1.setAmount(BigDecimal.TEN);
        payment1 = paymentEntityRepository.save(payment1);
        var payment2 = new PaymentEntity();
        payment2.setStatus("SIGNED");
        payment2.setAmount(BigDecimal.TEN);
        payment2 = paymentEntityRepository.save(payment2);
        Assertions.assertEquals(1, paymentService.getSignedDocumentCount(List.of(payment1.getId(), payment2.getId())));
    }

    @Test
    void sendDocumentStatementEmailTest() throws TemplateException, IOException {
        var paymentFromStatement = new PaymentDTO()
                .subtype(BANK_ORDER)
                .processedBy(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO())
                .amount(new AmountDTO().currency("RUR"))
                .completed(OffsetDateTime.now())
                .created(OffsetDateTime.now())
                .type(PaymentDTO.TypeEnum.DP)
                .payee(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO()
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()))
                .payer(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO()
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()));

        when(statementService.getPayment(anyString(), anyString())).thenReturn(Optional.of(paymentFromStatement));
        when(deliveringResourceService.buildReference(anyString())).thenReturn("reference");
        when(deliveringResourceService.save(any())).thenAnswer(answer -> answer.getArgument(0));
        when(printFormGenerator.generatePaymentHtml(any())).thenReturn("content");
        when(printFormGenerator.buildEmailMessage(any(), anyString())).thenReturn("buildEmailMessage");
        when(printFormGenerator.buildEmailPlainTextMessage(any(), anyString())).thenReturn("buildEmailPlainTextMessage");
        when(printFormGenerator.getTitle(any())).thenReturn("getTitle");
        when(printFormGenerator.createEmailInlineResources()).thenReturn(null);
        doNothing().when(localEmailSender).sendMimeEmailAudited(anyString(), anyString(), anyString(), anyString(), any(), any());
        Assertions.assertAll(() -> paymentService.sendDocument("id", "99999999", "a@a.mil", "dboproid"));
    }

    @Test
    void sendDocumentRepositoryPhoneTest() throws TemplateException, IOException {
        var payment = new PaymentEntity();
        payment.setStatus("CREATED");
        payment.setBisDocumentId("BisDocumentId");
        payment.setPayerAccount("PayerAccount");
        payment.setAmount(BigDecimal.TEN);
        payment.setDate(LocalDateTime.now());
        payment.setExecutionDate(LocalDateTime.now());
        payment.setDoctype("DA");
        paymentEntityRepository.save(payment);
        when(statementService.getPayment(anyString(), anyString())).thenReturn(Optional.empty());
        when(organizationService.rootGet(anyString())).thenReturn(
                List.of(new OrganizationDTO().crmId("crm").bisIds(List.of(new BisIdDTO()))));
        when(accountService.getAccountList(anyString(), any())).thenReturn(List.of(new AccountDTO().number("PayerAccount")));
        when(deliveringResourceService.buildReference(anyString())).thenReturn("reference");
        when(deliveringResourceService.save(any())).thenAnswer(answer -> answer.getArgument(0));
        when(printFormGenerator.generatePaymentHtml(any())).thenReturn("content");

        doNothing().when(deliveringResourceService).deliverReferenceBySms(anyString(), anyString());
        Assertions.assertAll(() -> paymentService.sendDocument("BisDocumentId", "9999999", "a@a.ru", "dboproid"));
    }

    @Test
    void processDocumentStatusMessageTest() {
        StatusTranslationEntity statusTranslationEntity1 = new StatusTranslationEntity();
        statusTranslationEntity1.setStatusComment("status_comment");
        statusTranslationEntity1.setTranslation("translation");
        statusTranslationRepository.save(statusTranslationEntity1);

        var payment1 = new PaymentEntity();
        payment1.setStatus("CREATED");
        payment1.setAmount(BigDecimal.TEN);
        payment1.setBisDocumentId("PP240116-200270901");
        paymentEntityRepository.save(payment1);

        DocumentStatusMessageDto dto = new DocumentStatusMessageDto();
        dto.setBisId("PP240116-200270901");
        dto.setStatusCode(1);
        dto.setStatusComment("comment");
        dto.setStatusSysName("sys");

        paymentService.processDocumentStatusMessage(dto);

        var documentoOpt = paymentEntityRepository.findByBisDocumentId(dto.getBisId());
        Assertions.assertNotNull(documentoOpt);
        Assertions.assertEquals("comment", documentoOpt.get().getStatusComment());
        Assertions.assertEquals("CREATED", documentoOpt.get().getStatus());

        dto.setStatusSysName(STATUS_PHUB_DOCUMENT_ACCEPTED);
        paymentService.processDocumentStatusMessage(dto);

        documentoOpt = paymentEntityRepository.findByBisDocumentId(dto.getBisId());
        Assertions.assertNotNull(documentoOpt);
        Assertions.assertEquals("COMPLETED", documentoOpt.get().getStatus());

        dto.setStatusSysName(STATUS_PHUB_DOCUMENT_REJECTED);
        paymentService.processDocumentStatusMessage(dto);

        documentoOpt = paymentEntityRepository.findByBisDocumentId(dto.getBisId());
        Assertions.assertNotNull(documentoOpt);
        Assertions.assertEquals("REJECTED", documentoOpt.get().getStatus());
        Assertions.assertEquals("Платёж отклонён Банком", documentoOpt.get().getStatusMessage());

        dto.setStatusComment("status_comment");
        paymentService.processDocumentStatusMessage(dto);

        documentoOpt = paymentEntityRepository.findByBisDocumentId(dto.getBisId());
        Assertions.assertNotNull(documentoOpt);
        Assertions.assertEquals("REJECTED", documentoOpt.get().getStatus());
        Assertions.assertEquals("translation", documentoOpt.get().getStatusMessage());

        payment1.setStatus("RECALLED");
        paymentEntityRepository.save(payment1);
        dto.setStatusSysName(STATUS_PHUB_DOCUMENT_REJECTED);
        paymentService.processDocumentStatusMessage(dto);

        documentoOpt = paymentEntityRepository.findByBisDocumentId(dto.getBisId());
        Assertions.assertNotNull(documentoOpt);
        Assertions.assertEquals("RECALLED", documentoOpt.get().getStatus());
    }

    List<BranchDTO> getBranches() {
        return Arrays.asList(new BranchDTO().bik("044525256"), new BranchDTO().bik("042202747"),
                new BranchDTO().bik("046015239"), new BranchDTO().bik("046577903"), new BranchDTO().bik("040407388"));
    }

    private PaymentEntity createDocument() {
        PaymentEntity doc = new PaymentEntity();
        doc.setClientId(704L);
        doc.setAmount(BigDecimal.ONE);
        doc.setDate(LocalDateTime.now());
        doc.setNumber("12345");
        doc.setStatus(DocumentStatusDTO.CREATED.getValue());
        doc.setShowError(true);

        RequisiteDTO payee = new RequisiteDTO();
        BankInfoDTO bankInfo = new BankInfoDTO();
        bankInfo.setBic("044525256");
        payee.setBank(bankInfo);

        RequisiteDTO payer = new RequisiteDTO();
        payer.setAccount("40702810393790000591");
        payer.setInn("7810709158");
        payer.setKpp("781001001");
        payer.setName("Name");
        return doc;
    }
}