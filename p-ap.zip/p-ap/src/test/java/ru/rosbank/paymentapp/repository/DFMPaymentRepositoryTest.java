package ru.rosbank.paymentapp.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;
import ru.rosbank.paymentapp.schedule.SendStatusDfmToProPortalConfig;

class DFMPaymentRepositoryTest extends BaseTest {

    @Autowired
    private DFMPaymentRepository dfmPaymentRepository;
    @Autowired
    private SendStatusDfmToProPortalConfig config;
    private static final Long docId = 2L;

    @Test
    void findAllDocSerialByDocSerialInAndFlagIsNot() {
        dfmPaymentRepository.save(getDfm());
        List<DFMPaymentEntity> dfmPayments =
                dfmPaymentRepository.findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(1,
                        LocalDateTime.now().minusMinutes(config.getHourAgo()));
        Assertions.assertTrue(dfmPayments.size() == 1);
        dfmPaymentRepository.deleteAll();
        DFMPaymentEntity dfm = getDfm();
        dfm.setFlag(1);
        dfmPaymentRepository.save(dfm);
        dfmPayments = dfmPaymentRepository.findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(1,
                LocalDateTime.now().minusMinutes(config.getHourAgo()));
        Assertions.assertTrue(dfmPayments.size() == 0);
        dfmPaymentRepository.deleteAll();
        dfm.setFlag(null);
        dfmPaymentRepository.save(dfm);
        dfmPayments = dfmPaymentRepository.findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(1,
                LocalDateTime.now().minusMinutes(config.getHourAgo()));
        Assertions.assertTrue(dfmPayments.size() == 0);
        dfmPaymentRepository.deleteAll();

    }

    @Test
    void findAllDocSerialByDocSerialInAndFlagIsNot2() {
        DFMPaymentEntity dfm = getDfm();
        dfm.setIdate(LocalDateTime.now().minusMinutes(config.getHourAgo() + 5));
        dfm = dfmPaymentRepository.save(dfm);

        List<DFMPaymentEntity> dfmPayments =
                dfmPaymentRepository.findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(1,
                        LocalDateTime.now().minusMinutes(config.getHourAgo()));
        Assertions.assertTrue(dfmPayments.size() == 0);
        dfmPaymentRepository.deleteAll();

    }

    public DFMPaymentEntity getDfm() {
        DFMPaymentEntity dfm = new DFMPaymentEntity();
        dfm.setDocDate(LocalDateTime.now());
        dfm.setReason("Без НДС");
        dfm.setDocSum(new BigDecimal("100.00"));
        dfm.setName("ИП Донварь Кристина Валерьевна");
        dfm.setPayeracccode("40802810597880000207");
        dfm.setPayerinn("450146852396");
        dfm.setPayerbank("РОСБАНК");
        dfm.setPayerbik("044525256");
        dfm.setBenefname("20/110");
        dfm.setIdate(LocalDateTime.now());
        dfm.setFlag(5);
        dfm.setStatus("PROCESSING");
        dfm.setDocNumber("777");
        dfm.setDocSerial(docId);
        return dfm;
    }



}