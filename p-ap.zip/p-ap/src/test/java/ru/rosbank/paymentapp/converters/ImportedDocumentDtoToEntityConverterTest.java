package ru.rosbank.paymentapp.converters;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.ImportedDocumentEntity;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

class ImportedDocumentDtoToEntityConverterTest extends BaseTest {

    ClientDTO client;

    @Autowired
    ImportedDocumentDtoToEntityConverter converter;

    @MockBean
    UserService userService;

    @BeforeEach
    public void init()  {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(1L);
        clientDTO.setId("0");
        when(userService.getClientById(anyLong())).thenReturn(Optional.of(clientDTO));
        when(userService.getClientByDboProId(anyString())).thenReturn(Optional.of(clientDTO));
    }

    @Test
    void convert() {
        ImportedDocumentEntity entity1 = getImportedDocumentEntity();
        ImportedDocumentDTO dto = converter.convertBack(entity1);
        ImportedDocumentEntity entity2 = converter.convert(dto, client, entity1.getBatch());
        Assertions.assertEquals(entity1.getBatch(), entity2.getBatch());
        Assertions.assertEquals(entity1.getPayeeAccount(), entity2.getPayeeAccount());
        Assertions.assertEquals(entity1.getDocType(), entity2.getDocType());
    }

    ImportedDocumentEntity getImportedDocumentEntity() {
        ImportedDocumentEntity entity = new ImportedDocumentEntity();
        entity.setBatch("1");
        client = new ClientDTO();
        client.setId("1");
        client.setLegacyId(1L);
        entity.setClientId(client.getLegacyId());
        entity.setAmount(BigDecimal.ONE);
        entity.setNumber("1");
        entity.setCreated(LocalDateTime.now());
        entity.setPayeeAccount("01234567890123456789");
        entity.setStatus(ImportedDocumentDTO.StatusEnum.VALID.getValue());
        entity.setDocType("DA");
        entity.setPayerAccount("01234567890123456789");
        entity.setBatch("R19");
        entity.setPayPriority("5");
        entity.setDocumentDate(LocalDateTime.now());
        return entity;
    }
}