package ru.rosbank.paymentapp.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;
import ru.rosbank.paymentapp.service.audit.AuditService;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.DatePeriodTypeEsb;
import ru.rosbank.platform.esb.model.common.MessageInfoTypeEsb;
import ru.rosbank.platform.esb.model.getpaymentlist.GetPaymentListRequestTypeEsb;
import ru.rosbank.platform.esb.model.message.MessageTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

public class PaymentListSiebelHandlerTest extends BaseTest {

    @Autowired
    private PaymentListSiebelHandler paymentListSiebelHandler;
    @Autowired
    private PaymentEntityRepository paymentEntityRepository;
    @MockBean
    private ScheduledConfiguration scheduledConfiguration;
    @MockBean
    private AuditService auditService;

    @Test
    @Disabled
    public void testSigned() {
        var response = paymentListSiebelHandler.handleWithResult(new MessageTypeEsb()
                .withMessageBody(new MessageTypeEsb.MessageBody()
                        .withGetPaymentListRequest(new GetPaymentListRequestTypeEsb()
                                .withPaymentOrder(new PaymentOrderTypeEsb()
                                        .withPayer(new RequisiteTypeEsb()
                                                .withNumber(
                                                        new AccountNumberTypeEsb()
                                                                .withAccountNumber20Digit("40702810393790000591"))))
                                .withReportPeriod(new DatePeriodTypeEsb()
                                        .withStartDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime())
                                        .withEndDate(new Date())
                                ))
                )
                .withMessageInfo(new MessageInfoTypeEsb()));
        Assertions.assertNotNull(response.getMessageBody().getGetPaymentListResponse());
        Assertions.assertNull(response.getMessageBody()
                .getGetPaymentListResponse()
                .getPaymentOrderList().getPaymentOrder().stream().findFirst().get().getCancellationsReason());
        Mockito.verify(auditService, times(1)).sendEventAsync(any());
    }

    @Test
    public void testNotExistAccount() {
        var response = paymentListSiebelHandler.handleWithResult(new MessageTypeEsb()
                .withMessageBody(new MessageTypeEsb.MessageBody()
                        .withGetPaymentListRequest(new GetPaymentListRequestTypeEsb()
                                .withPaymentOrder(new PaymentOrderTypeEsb()
                                        .withPayer(new RequisiteTypeEsb()
                                                .withNumber(new AccountNumberTypeEsb().withAccountNumber20Digit(""))))
                                .withReportPeriod(new DatePeriodTypeEsb()
                                        .withStartDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime())
                                        .withEndDate(new Date())
                                ))
                )
                .withMessageInfo(new MessageInfoTypeEsb()));
        Assertions.assertNull(response.getMessageBody().getGetPaymentListResponse().getPaymentOrderList());
        Mockito.verify(auditService, times(0)).sendEvent(any());
    }

    @Disabled
    @Test
    public void testWithCancellationsReason() {
        var statusMessage = "status_message";
        var withSignedStatus = paymentEntityRepository.findAllByStatusIn(
                List.of(DocumentStatus.SIGNED.getValue())).stream().findFirst().get();
        withSignedStatus.setId(null);
        withSignedStatus.setStatus(DocumentStatus.REJECTED.getValue());
        withSignedStatus.setStatusMessage(statusMessage);

        var persist = paymentEntityRepository.save(withSignedStatus);
        var response = paymentListSiebelHandler.handleWithResult(new MessageTypeEsb()
                .withMessageBody(new MessageTypeEsb.MessageBody()
                        .withGetPaymentListRequest(new GetPaymentListRequestTypeEsb()
                                .withPaymentOrder(new PaymentOrderTypeEsb()
                                        .withPayer(new RequisiteTypeEsb()
                                                .withNumber(
                                                        new AccountNumberTypeEsb()
                                                                .withAccountNumber20Digit("40702810393790000591"))))
                                .withReportPeriod(new DatePeriodTypeEsb()
                                        .withStartDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime())
                                        .withEndDate(new Date())
                                ))
                )
                .withMessageInfo(new MessageInfoTypeEsb()));
        Assertions.assertEquals(statusMessage, response.getMessageBody()
                .getGetPaymentListResponse().getPaymentOrderList().getPaymentOrder()
                .stream().filter(it -> DocumentStatus.REJECTED.getValue().equals(it.getStatus()))
                .findFirst().get().getCancellationsReason());
        Mockito.verify(auditService, times(1)).sendEventAsync(any());
        paymentEntityRepository.delete(persist);
    }
}
