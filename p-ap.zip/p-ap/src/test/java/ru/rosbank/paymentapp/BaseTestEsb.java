package ru.rosbank.paymentapp;

import com.google.gson.GsonBuilder;
import java.io.InputStream;
import java.util.Base64;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.helpers.DefaultValidationEventHandler;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.Resource;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import ru.rosbank.paymentapp.converters.DocumentConverter;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.EsbService;
import ru.rosbank.paymentapp.service.fraud.model.AbstractEvent;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateDTO;
import ru.rosbank.platform.client.cryptoproapp.model.MetaDataDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.esb.model.message.MessageTypeEsb;
import ru.rosbank.platform.esb.support.EsbRequestTypeEnum;


@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("unit_test")
public abstract class BaseTestEsb {

    @Autowired
    DocumentConverter documentConverter;

    @MockBean(name = "antifraudKafkaTemplate")
    public KafkaTemplate<String, AbstractEvent> kafkaTemplate;
    @MockBean
    public EsbService esbService;

    protected Object xmlToObj(Resource xml, EsbRequestTypeEnum requestType) throws Exception {
        JAXBContext jaxbContext = JAXBContext.newInstance("ru.rosbank.platform.esb.model.message");
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        unmarshaller.setEventHandler(new DefaultValidationEventHandler());
        InputStream inputStream = xml.getInputStream();
        JAXBElement jaxbElement = (JAXBElement) unmarshaller.unmarshal(inputStream);

        MessageTypeEsb response = (MessageTypeEsb) jaxbElement.getValue();
        return requestType.extractResponseFromMessage(response);

    }

    protected SignatureDTO buildSignResponse(PaymentEntity payment) {

        SignatureDTO signatureDTO = new SignatureDTO();
        signatureDTO.setConfirmed(true);
        signatureDTO.setCertificateId("1");
        signatureDTO.setMetaData(new MetaDataDTO());
        String result = new GsonBuilder().create().toJson(documentConverter.toDTO(payment));
        signatureDTO.setResult(Base64.getEncoder().encodeToString(result.getBytes()));

        return signatureDTO;
    }

    protected CertificateDTO buildCertResponse() {

        CertificateDTO certificateDTO = new CertificateDTO();
        certificateDTO.setCrmId("1-QZA-320");

        return certificateDTO;
    }

}
