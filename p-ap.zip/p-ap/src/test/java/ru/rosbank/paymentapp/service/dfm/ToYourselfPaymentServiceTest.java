package ru.rosbank.paymentapp.service.dfm;

import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;


class ToYourselfPaymentServiceTest extends BaseTest {
    @Autowired
    ToYourselfPaymentService toYourselfPaymentService;
    @MockBean
    ReferenceAppApiClient referenceAppApiClient;

    @BeforeEach
    public void init() {
        Mockito.when(referenceAppApiClient.branchGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getBranches(), HttpStatus.OK));
    }

    @Test
    void isToYourselfInn10() {

        Assertions.assertTrue(toYourselfPaymentService.isToYourself(getPaymentToYourself("0123456789")));
    }

    @Test
    void isNotToYourselfInn10() {

        Assertions.assertFalse(toYourselfPaymentService.isToYourself(getPayment("0123456789")));
    }

    @Test
    void isToYourselfInn12() {

        Assertions.assertTrue(toYourselfPaymentService.isToYourself(getPaymentToYourself("012345678912")));
    }

    @Test
    void isNotToYourselfInn12() {

        Assertions.assertFalse(toYourselfPaymentService.isToYourself(getPayment("012345678912")));
        Assertions.assertFalse(toYourselfPaymentService.isToYourself(getPaymentAcc("012345678912")));
    }

    @Test
    void isBicRosbank() {

        Assertions.assertTrue(toYourselfPaymentService.isBicRosbank("044525256"));
        Assertions.assertFalse(toYourselfPaymentService.isBicRosbank("044525255"));
    }

    @Test
    void isNotRevertible() {

        Assertions.assertTrue(toYourselfPaymentService.isNotRevertible(getPaymentToYourself("0123456789")));
        Assertions.assertTrue(toYourselfPaymentService.isNotRevertible(getPaymentToYourself("012345678912")));
        Assertions.assertTrue(toYourselfPaymentService.isNotRevertible(getPaymentNotRevertible()));
        Assertions.assertFalse(toYourselfPaymentService.isNotRevertible(getPayment("0123456789")));
    }

    private PaymentEntity getPaymentToYourself(String inn) {
        PaymentEntity doc = new PaymentEntity();
        doc.setPayerInn(inn);
        doc.setPayeeInn(inn);
        doc.setPayerBankBic("044525256");
        doc.setPayeeBankBic("044525256");
        doc.setPayeeAccount("40802567890123456789");
        return doc;
    }

    private PaymentEntity getPayment(String inn) {
        PaymentEntity doc = new PaymentEntity();
        doc.setPayerInn(inn);
        doc.setPayeeInn(inn);
        doc.setPayerBankBic("044525255");
        doc.setPayeeBankBic("044525258");
        return doc;
    }

    private PaymentEntity getPaymentAcc(String inn) {
        PaymentEntity doc = new PaymentEntity();
        doc.setPayerInn(inn);
        doc.setPayeeInn(inn);
        doc.setPayerBankBic("044525255");
        doc.setPayeeBankBic("044525258");
        doc.setPayeeAccount("01234567890123456789");
        return doc;
    }

    private PaymentEntity getPaymentNotRevertible() {
        PaymentEntity doc = new PaymentEntity();
        doc.setPayerInn("012345678912");
        doc.setPayeeInn("012345678912");
        doc.setPayerBankBic("044525256");
        doc.setPayeeBankBic("044525256");
        doc.setPayeeAccount("40817567890123456789");
        return doc;
    }

    List<BranchDTO> getBranches() {
        return Arrays.asList(new BranchDTO().bik("044525256"), new BranchDTO().bik("042202747"),
                new BranchDTO().bik("046015239"), new BranchDTO().bik("046577903"), new BranchDTO().bik("040407388"));
    }
}