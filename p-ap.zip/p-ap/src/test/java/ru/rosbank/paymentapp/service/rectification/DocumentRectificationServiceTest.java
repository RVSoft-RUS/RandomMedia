package ru.rosbank.paymentapp.service.rectification;

import static ru.rosbank.paymentapp.entity.DocumentRectification.DocumentRectificationStatus.ACTIVE;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.DocumentRectification;
import ru.rosbank.paymentapp.repository.DocumentRectificationRepository;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.paymentapp.service.exceptions.ValidationException;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;

class DocumentRectificationServiceTest extends BaseTest {

    @Autowired
    DocumentRectificationService rectificationService;

    @Autowired
    DocumentRectificationRepository documentRectificationRepository;

    @Test
    void test() {
        RectificationDTO documentRectificationDto = new RectificationDTO();
        documentRectificationDto.setDocumentId("PP200122-410882501");
        RectificationDTO result = rectificationService.register(documentRectificationDto);
        Assertions.assertEquals(documentRectificationDto.getDocumentId(), result.getDocumentId());
        DocumentRectification entity = rectificationService.findById(result.getId());
        Assertions.assertEquals(entity.getDocumentId(), result.getDocumentId());
        RectificationDTO result2 = rectificationService.getActiveDocumentRectificationByBisId("PP200122-410882501");
        Assertions.assertNull(result2);
        rectificationService.processDocument(result.getId());
        result2 = rectificationService.getActiveDocumentRectificationByBisId("Y01200122410882501");
        Assertions.assertNotNull(result2);
    }

    @Test
    void testFindAllById() {
        DocumentRectification documentRectification = new DocumentRectification();
        documentRectification.setDocumentId("PP200122-410882503");
        documentRectification.setStatus(String.valueOf(ACTIVE));
        DocumentRectification documentRectificationSave = documentRectificationRepository.save(documentRectification);
        List<String> ids = new ArrayList<>();
        ids.add(documentRectificationSave.getDocumentId());
        List<RectificationDTO> allById = rectificationService.findAllByDocumentIdAndStatus(ids);
        Assertions.assertEquals(allById.get(0).getDocumentId(), documentRectification.getDocumentId());
        Assertions.assertEquals(allById.get(0).getId(), documentRectification.getId());
    }

    @Test
    void testFindAllIfIdNull() {
        Assertions.assertThrows(BackendException.class, () -> rectificationService.findAllByDocumentIdAndStatus(null));
    }

    @Test
    void testFindAllByIdValidationException() {
        RectificationDTO documentRectificationDto = new RectificationDTO();
        documentRectificationDto.setDocumentId("PP200122-410882502");
        RectificationDTO result = rectificationService.register(documentRectificationDto);
        Assertions.assertNotNull(result);
        List<String> ids = new ArrayList<>();
        Assertions.assertNotNull(rectificationService.findAllByDocumentIdAndStatus(ids));
    }

}