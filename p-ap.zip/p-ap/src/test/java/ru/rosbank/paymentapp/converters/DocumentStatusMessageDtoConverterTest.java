package ru.rosbank.paymentapp.converters;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusFinal;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusMiddle;
import ru.rosbank.paymentapp.BaseTest;

class DocumentStatusMessageDtoConverterTest extends BaseTest {
    @Autowired
    DocumentStatusMessageDtoConverter converter;
    private final Instant instant = Instant.parse("2024-02-28T13:10:10.301Z");

    @Test
    void convertDocumentStatusMiddleTest() {
        var document = generateDocumentStatusMiddle();
        var response = converter.convert(document);

        Assertions.assertNotNull(response);
        Assertions.assertEquals("PP240116-200270901", response.getBisId());
        Assertions.assertEquals("StatusComment-1", response.getStatusComment());
        Assertions.assertEquals("StatusSysName-1", response.getStatusSysName());
        Assertions.assertEquals(LocalDateTime.ofInstant(instant, ZoneId.of("UTC")), response.getStatusDateTime());
        Assertions.assertEquals("ed3db846-fde8-4035-a0f7-3e499f570c38", response.getUuid().toString());

        document.setStatusDateTime(null);
        document.setDocumentID("incorrect string");
        response = converter.convert(document);

        Assertions.assertNotNull(response);
        Assertions.assertNull(response.getStatusDateTime());
        Assertions.assertNull(response.getUuid());
    }

    @Test
    void convertDocumentStatusFinalTest() {
        var document = generateDocumentStatusFinal();
        var response = converter.convert(document);

        Assertions.assertNotNull(response);
        Assertions.assertEquals("PP240116-200270901", response.getBisId());
        Assertions.assertEquals("StatusComment-1", response.getStatusComment());
        Assertions.assertEquals("StatusSysName-1", response.getStatusSysName());
        Assertions.assertEquals(1, response.getStatusCode());
        Assertions.assertEquals(LocalDateTime.ofInstant(instant, ZoneId.of("UTC")), response.getStatusDateTime());
        Assertions.assertEquals("ed3db846-fde8-4035-a0f7-3e499f570c38", response.getUuid().toString());

        document.setStatusDateTime(null);
        document.setDocumentID("incorrect string");
        response = converter.convert(document);

        Assertions.assertNotNull(response);
        Assertions.assertNull(response.getStatusDateTime());
        Assertions.assertNull(response.getUuid());
    }

    private DocumentStatusMiddle generateDocumentStatusMiddle() {
        DocumentStatusMiddle document = new DocumentStatusMiddle();
        document.setBISID("R26-1240116-2002709");
        document.setStatusComment("StatusComment-1");
        document.setStatusSysName("StatusSysName-1");
        document.setStatusDateTime(instant);
        document.setDocumentID("ed3db846-fde8-4035-a0f7-3e499f570c38");
        return document;
    }

    private DocumentStatusFinal generateDocumentStatusFinal() {
        DocumentStatusFinal document = new DocumentStatusFinal();
        document.setBISID("R26-1240116-2002709");
        document.setStatusComment("StatusComment-1");
        document.setStatusSysName("StatusSysName-1");
        document.setStatusCode(1);
        document.setStatusDateTime(instant);
        document.setDocumentID("ed3db846-fde8-4035-a0f7-3e499f570c38");
        return document;
    }
}
