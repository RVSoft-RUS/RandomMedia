package ru.rosbank.paymentapp.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentOrderLog;
import ru.rosbank.paymentapp.repository.PaymentOrderLogRepository;

class PaymentOrderLogServiceTest extends BaseTest {

    @Autowired
    PaymentOrderLogService paymentOrderLogService;
    @Autowired
    PaymentOrderLogRepository paymentOrderLogRepository;

    @BeforeEach
    public void init() {
        paymentOrderLogRepository.deleteAll();
    }

    @Test
    public void successChecking() {
        Assertions.assertTrue(paymentOrderLogService.savePaymentOrderLog(1L));
    }

    @Test
    public void failedChecking() {
        var log = new PaymentOrderLog();
        log.setDocumentId(1L);
        paymentOrderLogRepository.save(log);
        Assertions.assertFalse(paymentOrderLogService.savePaymentOrderLog(1L));
    }
}