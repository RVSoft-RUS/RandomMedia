package ru.rosbank.paymentapp.service;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.platform.server.paymentapp.model.Document;


class DuplicatesServiceTest extends BaseTest {

    @Autowired
    PaymentEntityRepository documentRepository;
    @Autowired
    DuplicatesService duplicatesService;

    private static final Long docId = 1L;

    @Test
    void getDuplicatesList() {
        List<String> docIds = new ArrayList();
        PaymentEntity paymentEntity = documentRepository.findById(docId).get();
        docIds.add(paymentEntity.getId().toString());
        paymentEntity.setId(null);
        PaymentEntity paymentEntity2 = documentRepository.save(paymentEntity);
        docIds.add(paymentEntity2.getId().toString());
        paymentEntity.setId(null);
        PaymentEntity paymentEntity3 = documentRepository.save(paymentEntity);
        docIds.add(paymentEntity3.getId().toString());
        List<Document> documentList = duplicatesService.getDuplicatesList(docIds);
        Assertions.assertEquals(3, documentList.size());
    }

    @Test
    void equalsTrue() {
        PaymentEntity paymentEntity = documentRepository.findById(docId).get();
        boolean result = DuplicatesService.equals(paymentEntity, paymentEntity);
        Assertions.assertTrue(result);
    }

    @Test
    void equalsFalse() {
        PaymentEntity paymentEntity1 = documentRepository.findById(docId).get();
        PaymentEntity paymentEntity2 = documentRepository.findById(docId).get();
        paymentEntity2.setPayeeKpp("123456789");
        boolean result = DuplicatesService.equals(paymentEntity1, paymentEntity2);
        Assertions.assertFalse(result);
    }

    @Test
    void hashCodeEquals() {
        PaymentEntity paymentEntity = documentRepository.findById(docId).get();

        Integer result1 = DuplicatesService.hashCode(paymentEntity);
        Integer result2 = DuplicatesService.hashCode(paymentEntity);
        Assertions.assertEquals(result1, result2);
    }

    @Test
    void hashCodeEqualsFalse() {
        PaymentEntity paymentEntity1 = documentRepository.findById(docId).get();
        PaymentEntity paymentEntity2 = documentRepository.findById(docId).get();
        paymentEntity2.setPayeeKpp("123456789");
        Integer result1 = DuplicatesService.hashCode(paymentEntity1);
        Integer result2 = DuplicatesService.hashCode(paymentEntity2);
        Assertions.assertNotEquals(result1, result2);
    }
}