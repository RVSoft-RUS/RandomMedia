package ru.rosbank.paymentapp.converters;

import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.platform.server.paymentapp.model.BankInfo;
import ru.rosbank.platform.server.paymentapp.model.BisId;
import ru.rosbank.platform.server.paymentapp.model.CurrencyControl;
import ru.rosbank.platform.server.paymentapp.model.Document;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;
import ru.rosbank.platform.server.paymentapp.model.Requisite;

class DocumentDtoConverterTest extends BaseTest {
    @Autowired
    DocumentDtoConverter converter;

    @Test
    void convertTest() {
        var document = generateDocument();
        var response = converter.convert(document);
        Assertions.assertNotNull(response);
        response = converter.convert(document.type(Document.TypeEnum.DE));
        Assertions.assertNotNull(response);
        response = converter.convert(document.id(null));
        Assertions.assertNotNull(response);
        document.getPayer().inn("inn");
        response = converter.convert(document);
        Assertions.assertNotNull(response);
        document.getPayee().inn("inn");
        response = converter.convert(document);
        Assertions.assertNotNull(response);
        response = converter.convert(document.showError(Boolean.FALSE));
        Assertions.assertNotNull(response);
        response = converter.convert(document.statusMessage(""));
        Assertions.assertNotNull(response);
        response = converter.convert(document.codeTypeIncome(null));
        Assertions.assertNotNull(response);
        response = converter.convert(document.typeTaxPayment("1"));
        Assertions.assertNotNull(response);
        response = converter.convert(document.typeTaxPayment("0"));
        Assertions.assertNotNull(response);
    }

    private Document generateDocument() {
        return new Document().id(1)
                .bisRefference("bisRefference")
                .clientId(1L)
                .number("number")
                .date(OffsetDateTime.now())
                .signDate(OffsetDateTime.now())
                .executionDate(OffsetDateTime.now())
                .status(DocumentStatus.CREATED)
                .showError(Boolean.TRUE)
                .statusMessage("statusMessage")
                .type(Document.TypeEnum.DA)
                .purpose("purpose")
                .amount("100")
                .paymentPriority("5")
                .payerStatus("payerStatus")
                .basisDocumentNumber("basisDocumentNumber")
                .basisDocumentCreated("basisDocumentCreated")
                .paymentBasis("paymentBasis")
                .taxPeriod("taxPeriod")
                .uin("uin")
                .kbk("kbk")
                .oktmo("oktmo")
                .payer(new Requisite().account("payer").bank(new BankInfo()))
                .payee(new Requisite().account("payee").bank(new BankInfo()))
                .codeTypeIncome("1")
                .typeTaxPayment("typeTaxPayment")
                .bisId(new BisId().id("bisId"))
                .currencyControl(new CurrencyControl().id("currencyControl"))
                .crmId("crmId")
                .orgShortName("orgShortName")
                .referenceId("referenceId")
                .referenceType("referenceType");
    }
}
