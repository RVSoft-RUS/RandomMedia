package ru.rosbank.paymentapp.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static ru.rosbank.paymentapp.service.RejectedPaymentStatusProcessor.BIS_PAYMENT_ORDER_PRO_INPUT_SYSTEM;
import static ru.rosbank.paymentapp.service.RejectedPaymentStatusProcessor.BIS_PAYMENT_ORDER_REJECTED_STATUS;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.AccountService;
import ru.rosbank.paymentapp.service.EsbService;
import ru.rosbank.paymentapp.service.OrganizationService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.MoneyAmountTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.DocumentIndicatorTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

class RejectedPaymentStatusJobTest extends BaseTest {

    @Autowired
    RejectedPaymentStatusJob rejectedPaymentStatusJob;
    @Autowired
    PaymentEntityRepository paymentEntityRepository;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    AccountService accountAppApi;
    @MockBean
    OrganizationService organizationAppApi;
    @MockBean
    public EsbService esbService;

    @BeforeEach
    public void init() {
        when(organizationAppApi.rootGet(anyString())).thenReturn(List.of(new OrganizationDTO()
                .bisIds(List.of(new BisIdDTO().id("id").branch("branch")))));
    }

    @Test
    @Transactional
    void test() {
        var paymentSentToBis = new PaymentEntity();
        paymentSentToBis.setDate(LocalDateTime.now());
        paymentSentToBis.setStatus(DocumentStatus.SENT_TO_BIS.getValue());
        paymentSentToBis.setNumber("113");
        paymentSentToBis.setClientId(704L);
        paymentSentToBis.setPayerAccount("40702810393790000591");
        paymentSentToBis.setDate(LocalDateTime.now().minusDays(2));
        var paymentError = new PaymentEntity();
        paymentError.setStatus(DocumentStatus.ERROR.getValue());
        paymentError.setNumber("113");
        paymentError.setClientId(704L);
        paymentError.setPayerAccount("40702810393790000591");
        paymentError.setDate(LocalDateTime.now().minusDays(1));
        paymentEntityRepository.saveAll(List.of(paymentSentToBis, paymentError));
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        when(esbService.getPaymentList(anyString(), anyString(), any(), any())).thenReturn(List.of(
                new PaymentOrderTypeEsb()
                        .withOrderNumber(paymentSentToBis.getNumber())
                        .withStatus(BIS_PAYMENT_ORDER_REJECTED_STATUS)
                        .withDocumentDate(Date.from(paymentSentToBis.getDate().atZone(ZoneId.systemDefault()).toInstant()))
                        .withPayee(
                                new RequisiteTypeEsb()
                                        .withNumber(new AccountNumberTypeEsb()
                                                .withAccountNumber20Digit(paymentSentToBis.getPayeeAccount())))
                        .withDocumentIndicator(
                                new DocumentIndicatorTypeEsb().withInputSystem(BIS_PAYMENT_ORDER_PRO_INPUT_SYSTEM))
                        .withAmount(new MoneyAmountTypeEsb().withAmount(paymentSentToBis.getAmount()))
        ));
        when(accountAppApi.getAccountList(anyString(), anyList())).thenReturn(List.of(
                new AccountDTO().bisId(
                        new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("id").branch("branch"))
                        .number(paymentSentToBis.getPayerAccount())
                        .number13("")));

        rejectedPaymentStatusJob.run();
    }
}
