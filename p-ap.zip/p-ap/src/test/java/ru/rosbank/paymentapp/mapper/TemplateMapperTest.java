package ru.rosbank.paymentapp.mapper;

import java.time.LocalDate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.paymentapp.model.Template;




class TemplateMapperTest {

    @Test
    void fromDTO() {
        TemplateDTO templateDTO = new TemplateDTO();
        templateDTO.setId("1");
        templateDTO.amount("123456");
        templateDTO.setDocType(TemplateDTO.DocTypeEnum.DA);
        templateDTO.dateCreated(LocalDate.now());
        templateDTO.dboProId("dboProId");
        templateDTO.setName(" Test");

        BankInfoDTO bank = new BankInfoDTO();
        bank.bic("044525256").correspondentAccount("30101810000000000256").name("Московский филиал ПАО \"РОСБАНК\"");
        RequisiteDTO payee = new RequisiteDTO();
        payee.account("40702810097370000155").inn("7716859727").kpp("0").name("ООО ТРАНС-ТК").bank(bank);
        templateDTO.setPayee(payee);
        templateDTO.setPayer(payee);

        Template template = TemplateMapper.INSTANCE.fromDTO(templateDTO);
        templateDTO = TemplateMapper.INSTANCE.toDTO(template);
        Assertions.assertEquals(templateDTO.getAmount(), template.getAmount());
        Assertions.assertEquals(templateDTO.getDateCreated(), template.getDateCreated());
        Assertions.assertEquals(templateDTO.getDocType().getValue(), template.getDocType().getValue());
    }
}