package ru.rosbank.paymentapp.entity;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.paymentapp.BaseTest;

class DeliveringResourceTest extends BaseTest {

    @Test
    void isPhoneTest() {
        var resource = new DeliveringResource();
        Assertions.assertFalse(resource.isPhoneDelivering());
        resource.setPhone("");
        Assertions.assertFalse(resource.isPhoneDelivering());
        resource.setPhone("1");
        Assertions.assertTrue(resource.isPhoneDelivering());
    }


    @Test
    void isEmailTest() {
        var resource = new DeliveringResource();
        Assertions.assertFalse(resource.isEmailDelivering());
        resource.setEmail("");
        Assertions.assertFalse(resource.isEmailDelivering());
        resource.setEmail("1");
        Assertions.assertTrue(resource.isEmailDelivering());
    }
}
