package ru.rosbank.paymentapp.service.phub;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusFinal;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusMiddle;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.converters.DocumentStatusMessageDtoConverter;
import ru.rosbank.paymentapp.service.PaymentService;


class PaymentHubConsumerTest extends BaseTest {
    @MockBean
    private PaymentService paymentService;
    @Autowired
    private DocumentStatusMessageDtoConverter converter;
    private PaymentHubConsumer consumer;

    public void init() {
        consumer = new PaymentHubConsumer(paymentService, converter);
    }

    @Test
    void consumeStatusesTest() {
        init();

        DocumentStatusMiddle message = new DocumentStatusMiddle();
        message.setBISID("R26-1240116-2002709");
        message.setStatusComment("StatusComment-1");
        message.setStatusSysName("StatusSysName-1");
        message.setDocumentID("ed3db846-fde8-4035-a0f7-3e499f570c38");
        message.setInputSystem("T");

        when(paymentService.isValidInputSystem(message)).thenReturn(false);
        consumer.consumeProcStatus(message);
        Mockito.verify(paymentService, times(0)).processDocumentStatusMessage(any());

        when(paymentService.isValidInputSystem(message)).thenReturn(true);
        message.setInputSystem("C");

        consumer.consumeProcStatus(message);
        Mockito.verify(paymentService, times(1)).processDocumentStatusMessage(any());


        DocumentStatusFinal message2 = new DocumentStatusFinal();
        message2.setBISID("R26-1240116-2002709");
        message2.setStatusComment("StatusComment-1");
        message2.setStatusSysName("StatusSysName-1");
        message2.setDocumentID("ed3db846-fde8-4035-a0f7-3e499f570c38");
        message2.setInputSystem("T");

        when(paymentService.isValidInputSystem(message2)).thenReturn(false);
        consumer.consumeFinishStatus(message2);
        Mockito.verify(paymentService, times(1)).processDocumentStatusMessage(any());

        message2.setInputSystem("C");

        when(paymentService.isValidInputSystem(message2)).thenReturn(true);
        consumer.consumeFinishStatus(message2);
        Mockito.verify(paymentService, times(2)).processDocumentStatusMessage(any());
    }
}