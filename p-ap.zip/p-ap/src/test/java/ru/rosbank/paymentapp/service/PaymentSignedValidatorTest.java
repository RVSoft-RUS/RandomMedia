package ru.rosbank.paymentapp.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.exceptions.UnprocessablePaymentException;
import ru.rosbank.paymentapp.service.sms.SendSmsService;
import ru.rosbank.paymentapp.service.validators.PaymentSignedValidator;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;


class PaymentSignedValidatorTest extends BaseTest {

    @Autowired
    PaymentSignedValidator paymentSignedValidator;
    @MockBean
    PaymentService paymentService;
    @Autowired
    SendSmsService sendSmsService;


    @Test
    void testIsSignedOk() {
        var doc = new PaymentEntity();
        doc.setStatus(DocumentStatus.CREATED.name());
        Assertions.assertDoesNotThrow(() -> {
            paymentSignedValidator.validate(doc);
        });
    }

    @Test
    void testIsSigned422() {
        var doc = new PaymentEntity();
        doc.setStatus(DocumentStatus.SIGNED.name());
        Assertions.assertThrows(UnprocessablePaymentException.class, () -> {
            paymentSignedValidator.validate(doc);
        });
    }

}