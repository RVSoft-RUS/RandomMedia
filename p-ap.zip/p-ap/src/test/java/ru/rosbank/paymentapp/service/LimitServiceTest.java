package ru.rosbank.paymentapp.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.OrganizationLimit;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.OrganizationLimitRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.exceptions.ValidationException;
import ru.rosbank.platform.client.paymentapp.model.LimitRequestDTO;
import ru.rosbank.platform.client.paymentapp.model.LimitResponseDTO;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

class LimitServiceTest extends BaseTest {
    @Autowired
    private LimitService limitService;
    @MockBean
    private OrganizationLimitRepository organizationLimitRepository;
    @MockBean
    private PaymentEntityRepository paymentEntityRepository;
    @MockBean
    ReferenceAppApiClient referenceAppApiClient;

    @BeforeEach
    public void init() {
        Mockito.when(referenceAppApiClient.branchGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getBranches(), HttpStatus.OK));
    }

    @Test
    void process() {
        when(paymentEntityRepository.findAllBySignDateBetweenAndOrganizationCrmIdAndStatusInAndNumberIsNotNull(any(),
                any(), any(), any())).thenReturn(Collections.singletonList(
                getPaymentEntitySigned()));
        when(paymentEntityRepository.findByIdInOrderByIdDesc(any())).thenReturn(Collections.singletonList(
                getPaymentEntityCreated()));
        when(organizationLimitRepository.findByOrganizationIdAndStatus(any(), any())).thenReturn(Arrays.asList(
                getOrganizationLimitOneOp(), getOrganizationLimitPeriod()));
        LimitRequestDTO limitRequestDTO = new LimitRequestDTO();
        limitRequestDTO.setDocumentIds(Collections.singletonList("1"));
        LimitResponseDTO responseDTO = limitService.process("1-QZA-320", limitRequestDTO);
        Assertions.assertEquals(responseDTO.getResult(),
                LimitResponseDTO.ResultEnum.LIMIT_NOT_EXCEEDED);

    }

    @Test
    void processException() {
        when(paymentEntityRepository.findAllBySignDateBetweenAndOrganizationCrmIdAndStatusInAndNumberIsNotNull(any(),
                any(), any(), any())).thenReturn(Collections.singletonList(
                getPaymentEntitySigned()));
        when(paymentEntityRepository.findByIdInOrderByIdDesc(any())).thenReturn(Collections.singletonList(
                getPaymentEntityCreated()));
        when(organizationLimitRepository.findByOrganizationIdAndStatus(any(), any())).thenReturn(Arrays.asList(
                getOrganizationLimitOneOp(), getOrganizationLimitPeriodException()));
        LimitRequestDTO limitRequestDTO = new LimitRequestDTO();
        limitRequestDTO.setDocumentIds(Collections.singletonList("1"));
        Assertions.assertThrows(ValidationException.class, () ->
                limitService.process("1-QZA-320", limitRequestDTO));


    }

    OrganizationLimit getOrganizationLimitOneOp() {
        OrganizationLimit ol = new OrganizationLimit();
        ol.setType(OrganizationLimit.Type.ONE_OPERATION_LIMIT.name());
        ol.setLimitPeriod(0);
        ol.setCurrency("RUB");
        ol.setLimitSum(BigDecimal.valueOf(300));
        ol.setOrganizationId("1-QZA-320");
        ol.setStatus(OrganizationLimit.Status.ACTIVE.name());
        ol.setPaymentType(OrganizationLimit.PaymentType.ALL.name());
        return ol;
    }

    OrganizationLimit getOrganizationLimitPeriod() {
        OrganizationLimit ol = getOrganizationLimitOneOp();
        ol.setLimitPeriod(1000);
        ol.setType(OrganizationLimit.Type.LIMIT_FOR_PERIOD.name());
        return ol;
    }

    OrganizationLimit getOrganizationLimitPeriodException() {
        OrganizationLimit ol = getOrganizationLimitOneOp();
        ol.setType(OrganizationLimit.Type.LIMIT_FOR_PERIOD.name());
        ol.setLimitPeriod(1000);
        ol.setLimitSum(BigDecimal.valueOf(200));
        return ol;
    }

    @Test
    void getSumFromPeriod() {
        when(paymentEntityRepository.findAllBySignDateBetweenAndOrganizationCrmIdAndStatusInAndNumberIsNotNull(any(),
                any(), any(), any())).thenReturn(Collections.singletonList(
                getPaymentEntitySigned()));
        OrganizationLimit limit = new OrganizationLimit();
        limit.setPaymentType(OrganizationLimit.PaymentType.ALL.name());
        limit.setCurrency("RUB");
        limit.setLimitPeriod(2);
        BigDecimal sum = limitService.getSumFromPeriod(limit, "1-QZA-320");
        Assertions.assertTrue(sum.equals(BigDecimal.valueOf(200)));
    }

    @Test
    void isPaymentTypeInnerOwnAccount() {
        PaymentEntity payment = new PaymentEntity();
        payment.setPayerInn("0123456789");
        payment.setPayeeInn("0123456789");
        payment.setPayeeBankBic("044525256");
        OrganizationLimit limit = new OrganizationLimit();
        limit.setPaymentType(OrganizationLimit.PaymentType.INNER_OWN_ACCOUNT.name());
        Assertions.assertTrue(limitService.isPaymentType(limit, payment));
        payment.setPayeeBankBic("044525257");
        Assertions.assertFalse(limitService.isPaymentType(limit, payment));
        payment.setPayeeInn("0123456788");
        payment.setPayeeBankBic("044525256");
        Assertions.assertFalse(limitService.isPaymentType(limit, payment));
    }

    @Test
    void isPaymentTypeFavorOfBank() {
        PaymentEntity payment = new PaymentEntity();
        payment.setPayerInn("0123456789");
        payment.setPayeeInn("7730060164");
        payment.setPayeeBankBic("044525256");
        OrganizationLimit limit = new OrganizationLimit();
        limit.setPaymentType(OrganizationLimit.PaymentType.FAVOR_OF_BANK.name());
        Assertions.assertTrue(limitService.isPaymentType(limit, payment));
        payment.setPayeeBankBic("044525257");
        Assertions.assertFalse(limitService.isPaymentType(limit, payment));
        payment.setPayeeInn("0123456788");
        payment.setPayeeBankBic("044525256");
        Assertions.assertFalse(limitService.isPaymentType(limit, payment));
    }

    @Test
    void isPaymentTypeAll() {
        PaymentEntity payment = new PaymentEntity();
        OrganizationLimit limit = new OrganizationLimit();
        limit.setPaymentType(OrganizationLimit.PaymentType.ALL.name());
        Assertions.assertTrue(limitService.isPaymentType(limit, payment));
    }

    @Test
    void isPaymentTypeOther() {
        PaymentEntity payment = new PaymentEntity();
        payment.setPayerInn("0123456789");
        payment.setPayeeInn("7730060164");
        payment.setPayeeBankBic("044525256");
        OrganizationLimit limit = new OrganizationLimit();
        limit.setPaymentType(OrganizationLimit.PaymentType.OTHER.name());
        Assertions.assertFalse(limitService.isPaymentType(limit, payment));
        payment.setPayerInn("0123456789");
        payment.setPayeeInn("7730060164");
        payment.setPayeeBankBic("044525256");
        Assertions.assertFalse(limitService.isPaymentType(limit, payment));
        payment.setPayeeBankBic("044525257");
        Assertions.assertTrue(limitService.isPaymentType(limit, payment));
        payment.setPayeeInn("0123456788");
        payment.setPayeeBankBic("044525256");
        Assertions.assertTrue(limitService.isPaymentType(limit, payment));
    }

    @Test
    void isInnerOwnAccount() {
        PaymentEntity payment = new PaymentEntity();
        payment.setPayerInn("0123456789");
        payment.setPayeeInn("0123456789");
        payment.setPayeeBankBic("044525256");
        Assertions.assertTrue(limitService.isInnerOwnAccount(payment));
        payment.setPayeeBankBic("044525257");
        Assertions.assertFalse(limitService.isInnerOwnAccount(payment));
        payment.setPayeeInn("0123456788");
        payment.setPayeeBankBic("044525256");
        Assertions.assertFalse(limitService.isInnerOwnAccount(payment));
    }

    @Test
    void isFavorOfBank() {
        PaymentEntity payment = new PaymentEntity();
        payment.setPayerInn("0123456789");
        payment.setPayeeInn("7730060164");
        payment.setPayeeBankBic("044525256");
        Assertions.assertTrue(limitService.isFavorOfBank(payment));
        payment.setPayeeBankBic("044525257");
        Assertions.assertFalse(limitService.isFavorOfBank(payment));
        payment.setPayeeInn("0123456788");
        payment.setPayeeBankBic("044525256");
        Assertions.assertFalse(limitService.isFavorOfBank(payment));
    }

    @Test
    void getFullSum() {
        when(paymentEntityRepository.findAllBySignDateBetweenAndOrganizationCrmIdAndStatusInAndNumberIsNotNull(any(),
                any(), any(), any())).thenReturn(Collections.singletonList(
                getPaymentEntitySigned()));
        OrganizationLimit limit = new OrganizationLimit();
        limit.setPaymentType(OrganizationLimit.PaymentType.ALL.name());
        limit.setCurrency("RUB");
        limit.setLimitPeriod(1000);
        limit.setLimitSum(BigDecimal.valueOf(1000));

        BigDecimal sum = limitService.getFullSum(limit, "1-QZA-320", Collections.singletonList(
                getPaymentEntityCreated()));
        Assertions.assertTrue(sum.equals(BigDecimal.valueOf(215)));
    }

    private PaymentEntity getPaymentEntitySigned() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setId(0L);
        paymentEntity.setOrganizationCrmId("1-QZA-320");
        paymentEntity.setOrganizationBisBranch("branch");
        paymentEntity.setOrganizationBisId("bisId");
        paymentEntity.setOrganizationShortName("shortName");
        paymentEntity.setNumber("number");
        paymentEntity.setSignDate(LocalDateTime.now().minusDays(1));
        paymentEntity.setStatus(DocumentStatus.SIGNED.getValue());
        paymentEntity.setAmount(BigDecimal.valueOf(200));
        return paymentEntity;
    }

    private PaymentEntity getPaymentEntityCreated() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setId(1L);
        paymentEntity.setOrganizationCrmId("1-QZA-320");
        paymentEntity.setOrganizationBisBranch("branch");
        paymentEntity.setOrganizationBisId("bisId");
        paymentEntity.setOrganizationShortName("shortName");
        paymentEntity.setNumber("number");
        paymentEntity.setSignDate(LocalDateTime.now().minusDays(1));
        paymentEntity.setStatus(DocumentStatus.CREATED.getValue());
        paymentEntity.setAmount(BigDecimal.valueOf(15));
        return paymentEntity;
    }

    List<BranchDTO> getBranches() {
        return Arrays.asList(new BranchDTO().bik("044525256"), new BranchDTO().bik("042202747"),
                new BranchDTO().bik("046015239"), new BranchDTO().bik("046577903"), new BranchDTO().bik("040407388"));
    }
}