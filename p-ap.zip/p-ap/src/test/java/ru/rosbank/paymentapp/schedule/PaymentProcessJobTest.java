package ru.rosbank.paymentapp.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.PropertyService;
import ru.rosbank.paymentapp.service.dfm.DfmPaymentService;
import ru.rosbank.platform.redis.SharedLock;

public class PaymentProcessJobTest extends BaseTest {

    @Autowired
    PaymentProcessCheckJob paymentProcessCheckJob;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    PropertyService propertyService;
    @MockBean
    DocumentProcessor documentProcessor;
    @MockBean
    PaymentEntityRepository paymentEntityRepository;
    @MockBean
    DfmPaymentService dfmPaymentService;

    @Test
    public void processDisableJob() {
        when(propertyService.getBoolean(anyString())).thenReturn(Optional.of(true));
        paymentProcessCheckJob.run();
        Mockito.verify(sharedLock, times(0)).lock(anyString(), anyInt());
    }

    @Test
    public void processEnableJob() {
        when(propertyService.getBoolean(anyString())).thenReturn(Optional.empty());
        paymentProcessCheckJob.run();
        when(paymentEntityRepository.findAllIdsByStatusIn(any())).thenReturn(List.of(1L));
        Mockito.verify(paymentEntityRepository, atLeastOnce()).findAllIdsByStatusIn(any());
    }
}
