package ru.rosbank.paymentapp.service;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.converters.DocumentConverter;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.platform.server.paymentapp.model.Document;

class PaymentServiceTest2 extends BaseTest {
    @Autowired
    PaymentService paymentService;
    @MockBean
    PaymentEntityRepository paymentEntityRepository;
    @MockBean
    DocumentConverter documentConverter;

    @Test
    void getDocumentByReference() {
        when(paymentEntityRepository.findByBisDocumentId(ArgumentMatchers.any())).thenReturn(Optional.of(new PaymentEntity()));
        when(documentConverter.toDTO(ArgumentMatchers.any())).thenReturn(new Document());
        paymentService.getDocumentByReference("Y01200121409813901");
        verify(paymentEntityRepository).findByBisDocumentId(ArgumentMatchers.eq("PP200121-409813901"));
    }
}