package ru.rosbank.paymentapp.service.validators;

import java.time.LocalDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;


class DocumentDateOnSendToEsbValidatorTest extends BaseTest {
    private static final long DAYS_BEFORE_FOR_EXCEPTION = 12;
    private static final long DAYS_AFTER_FOR_EXCEPTION = 32;
    @Autowired
    DocumentDateOnSendToEsbValidator documentDateOnSendToEsbValidator;

    @Test
    void validate() {
        PaymentEntity payment = new PaymentEntity();
        payment.setDate(LocalDateTime.now());
        Assertions.assertDoesNotThrow(() -> documentDateOnSendToEsbValidator.validate(payment));

        payment.setExecutionDate(LocalDateTime.now());
        Assertions.assertDoesNotThrow(() -> documentDateOnSendToEsbValidator.validate(payment));

        payment.setExecutionDate(LocalDateTime.now().minusDays(DAYS_BEFORE_FOR_EXCEPTION));
        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentDateOnSendToEsbValidator.validate(payment));

        payment.setExecutionDate(LocalDateTime.now().plusDays(DAYS_AFTER_FOR_EXCEPTION));
        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentDateOnSendToEsbValidator.validate(payment));
    }
}