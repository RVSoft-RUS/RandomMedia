package ru.rosbank.paymentapp.mapper;


import java.time.LocalDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;

class DfmSaveAlertsRequestMapperTest extends BaseTest {

    @Autowired
    DfmSaveAlertsRequestMapper mapper;

    @Test
    void toDate() {
        LocalDateTime localDateTime = LocalDateTime.now();
        String date = mapper.toDate(localDateTime);
        Assertions.assertNotNull(date);
    }
}