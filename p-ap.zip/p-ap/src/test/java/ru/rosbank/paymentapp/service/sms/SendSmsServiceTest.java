package ru.rosbank.paymentapp.service.sms;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTestEsb;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

class SendSmsServiceTest extends BaseTestEsb {
    @Autowired
    SendSmsService sendSmsService;
    @MockBean
    UserService userService;

    @Test
    void sendSmsTechnicalProblemsForPayment() {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(704L);
        clientDTO.setId("0");
        clientDTO.setPhone("0123456789");
        when(userService.getClientById(anyLong())).thenReturn(Optional.of(clientDTO));

        sendSmsService.sendSmsTechnicalProblemsForPayment(getPaymentEntity());
        Mockito.verify(esbService, times(1)).sendSms(any());
    }

    @Test
    void sendSmsTechnicalProblemsForPaymentException() {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(704L);
        clientDTO.setId("0");
        clientDTO.setPhone("0123456789");
        when(userService.getClientById(anyLong())).thenThrow(new BackendException("333"));

        sendSmsService.sendSmsTechnicalProblemsForPayment(getPaymentEntity());
        Mockito.verify(esbService, times(0)).sendSms(any());
    }

    private PaymentEntity getPaymentEntity() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setOrganizationCrmId("orgCrmId");
        paymentEntity.setOrganizationBisBranch("branch");
        paymentEntity.setOrganizationBisId("bisId");
        paymentEntity.setOrganizationShortName("shortName");
        paymentEntity.setNumber("number");
        paymentEntity.setDate(LocalDateTime.now());
        paymentEntity.setSignDate(LocalDateTime.now());
        paymentEntity.setClientId(1L);
        return paymentEntity;
    }
}