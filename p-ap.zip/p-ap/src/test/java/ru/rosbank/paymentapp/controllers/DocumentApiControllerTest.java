package ru.rosbank.paymentapp.controllers;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static ru.rosbank.paymentapp.entity.DocumentRectification.DocumentRectificationStatus.ACTIVE;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.converters.PaymentDTOToAbstractDocumentDtoConverter;
import ru.rosbank.paymentapp.dto.PaymentAssignmentDocumentDto;
import ru.rosbank.paymentapp.entity.DocumentRectification;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.DocumentRectificationRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;
import ru.rosbank.paymentapp.service.DeliveringResourceService;
import ru.rosbank.paymentapp.service.PrintFormGenerator;
import ru.rosbank.paymentapp.service.RejectedPaymentStatusProcessor;
import ru.rosbank.paymentapp.service.StatementService;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.fraud.DboEventRegisterPaymentService;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.CurrencyControlDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.FileInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.server.paymentapp.model.DocumentSendRequestApp;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class DocumentApiControllerTest extends BaseTest {

    @Autowired
    private MockMvc mvc;
    @Autowired
    PaymentEntityRepository paymentEntityRepository;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private DocumentRectificationRepository documentRectificationRepository;

    @MockBean
    ScheduledConfiguration scheduledConfiguration;
    @MockBean
    PaymentEventService paymentEventService;
    @MockBean
    DboEventRegisterPaymentService dboEventRegisterPaymentService;

    @MockBean
    UserService userService;
    @MockBean
    RejectedPaymentStatusProcessor rejectedPaymentStatusProcessor;
    @MockBean
    StatementService statementService;
    @MockBean
    PaymentDTOToAbstractDocumentDtoConverter converter;
    @MockBean
    DeliveringResourceService deliveringResourceService;
    @MockBean
    PrintFormGenerator printFormGenerator;

    @BeforeEach
    public void init() {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(704L);
        clientDTO.setId("0");
        when(userService.getClientById(ArgumentMatchers.anyLong())).thenReturn(Optional.of(clientDTO));
        when(userService.getClientByDboProId(ArgumentMatchers.anyString())).thenReturn(Optional.of(clientDTO));
        when(rejectedPaymentStatusProcessor.updateRejectedPaymentStatus(ArgumentMatchers.any(),
                ArgumentMatchers.any())).thenReturn(null);
    }

    @Test
    void documentGet() throws Exception {

        mvc.perform(get("/document/")
                .queryParam("payer_accounts", "40802810597880000207", "40702810393790000591")
                .queryParam("from", "2021-01-01T00:00:00")
                .queryParam("to", "2021-02-01T00:00:00")
                .queryParam("statuses", "PROCESSING")
                .queryParam("limit", "2")
                .queryParam("offset", "0"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$[0].id").exists());
    }

    @Test
    void documentsGet() throws Exception {

        mvc.perform(get("/document/list/")
                .queryParam("payer_accounts", "40802810597880000207", "40702810393790000591")
                .queryParam("from", "2021-01-01T00:00:00")
                .queryParam("to", "2021-02-01T00:00:00")
                .queryParam("statuses", "PROCESSING", "CREATED")
                .queryParam("limit", "2")
                .queryParam("offset", "0"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$[0].id").exists());
        Mockito.verify(rejectedPaymentStatusProcessor, times(1)).updateRejectedPaymentStatus(
                ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void documentsGetCreated() throws Exception {

        mvc.perform(get("/document/list/")
                .queryParam("payer_accounts", "40802810597880000207", "40702810393790000591")
                .queryParam("from", "2021-01-01T00:00:00")
                .queryParam("to", "2021-02-01T00:00:00")
                .queryParam("statuses", "CREATED")
                .queryParam("limit", "2")
                .queryParam("offset", "0"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$[0].id").exists());
        Mockito.verify(rejectedPaymentStatusProcessor, times(0)).updateRejectedPaymentStatus(
                ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void documentsGetStatusesNull() throws Exception {

        mvc.perform(get("/document/list/")
                .queryParam("payer_accounts", "40802810597880000207", "40702810393790000591")
                .queryParam("from", "2021-01-01T00:00:00")
                .queryParam("to", "2021-02-01T00:00:00")
                .queryParam("limit", "2")
                .queryParam("offset", "0"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$[0].id").exists());
        Mockito.verify(rejectedPaymentStatusProcessor, times(1)).updateRejectedPaymentStatus(
                ArgumentMatchers.any(), ArgumentMatchers.any());
    }

    @Test
    void importedDocumentGet() throws Exception {

        mvc.perform(get("/imported/document/list/")
                .queryParam("batch_id", "1")
                .queryParam("client_id", "704"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$[0].id").exists())
                .andExpect(jsonPath("$[0].number").value("777"));
    }

    @Test
    void documentNextInfoGet() throws Exception {

        mvc.perform(get("/document/next/info/")
                .queryParam("payer_accounts", "40802810597880000207", "40702810393790000591"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"));

    }

    @Test
    void documentIdContentGet() throws Exception {

        mvc.perform(get("/document/1/content/")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    void documentPost() throws Exception {
        doNothing().when(dboEventRegisterPaymentService).sendRegisterPaymentEvent(any(),any());
        mvc.perform(MyRequestFactory.myFactoryRequestPost("/document/")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(createDocument())))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.amount").value("100"));

        var doc = createDocument();
        doc.setStatus(DocumentStatusDTO.SIGNED);
        mvc.perform(post("/document/4/")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(doc)))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.amount").value("100"));

    }

    @Test
    void documentIdSign404() throws Exception {
        mvc.perform(post("/document/999999/sign")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    void documentIdGet() throws Exception {

        mvc.perform(get("/document/1/"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.id").value(1));

    }

    @Test
    void documentIdDelete() throws Exception {
        doNothing().when(paymentEventService).sendDocumentStatus(any());

        mvc.perform(delete("/document/1/"))
                .andExpect(status().isOk());

        assertEquals(DocumentStatus.ARCHIVE.name(),
                paymentEntityRepository.findById(1L).map(PaymentEntity::getStatus).get());

    }

    @Test
    void documentRectificationBatchGetIdNull() throws Exception {
        mvc.perform(get("/document/rectification/batch"))
                .andExpect(status().is4xxClientError());
    }

    @Test
    void documentRectificationBatchGet() throws Exception {
        DocumentRectification documentRectification = new DocumentRectification();
        documentRectification.setDocumentId("PP200122-410882502");
        documentRectification.setStatus(String.valueOf(ACTIVE));
        DocumentRectification save = documentRectificationRepository.save(documentRectification);
        mvc.perform(get("/document/rectification/batch?documentsIds=PP200122-410882502"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$[0].id").value(save.getId()));
    }

    @Test
    void documentSendPostTest() throws Exception {
        when(statementService.getPayment(anyString(), anyString())).thenReturn(Optional.of(new PaymentDTO()));
        when(converter.convert(any())).thenReturn(new PaymentAssignmentDocumentDto());
        when(deliveringResourceService.buildReference(anyString())).thenReturn("reference");
        when(printFormGenerator.generatePaymentHtml(any())).thenReturn("print form");
        when(deliveringResourceService.save(any())).thenAnswer(i -> i.getArguments()[0]);
        mvc.perform(post("/document/send")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new DocumentSendRequestApp()
                                .documentId("id")
                                .phone("99999")
                                .dboProId("dboproid"))))
                .andExpect(status().isOk());
    }

    private DocumentDTO createDocument() {
        DocumentDTO doc = new DocumentDTO();
        doc.setClientId(704L);
        doc.setAmount("100");
        doc.setDate(OffsetDateTime.now());
        doc.setNumber("123");
        doc.setStatus(DocumentStatusDTO.CREATED);
        doc.setType(DocumentDTO.TypeEnum.DB);
        doc.setShowError(true);

        RequisiteDTO payee = new RequisiteDTO();
        BankInfoDTO bankInfo = new BankInfoDTO();
        bankInfo.setBic("044525256");
        payee.setBank(bankInfo);
        doc.setPayee(payee);

        RequisiteDTO payer = new RequisiteDTO();
        payer.setAccount("40702810393790000591");
        payer.setInn("7810709158");
        payer.setKpp("781001001");
        payer.setName("Name");
        doc.setPayer(payer);
        doc.setCurrencyControl(new CurrencyControlDTO().fullName("fullname")
                .addFileInfoItem(new FileInfoDTO()));
        doc.setEnrollmentDate(OffsetDateTime.now());
        return doc;
    }

}
