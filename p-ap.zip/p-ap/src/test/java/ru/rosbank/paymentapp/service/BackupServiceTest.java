package ru.rosbank.paymentapp.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.esb.support.BankProcessingException;
import ru.rosbank.paymentapp.repository.PaymentEntityOldRepository;

class BackupServiceTest extends BaseTest {

    @MockBean
    PaymentEntityOldRepository paymentEntityOldRepository;
    @Autowired
    BackupService backupService;



    @Test
    void saveAndDeletePayment() {
        when(paymentEntityOldRepository.save(any())).thenThrow(BankProcessingException.class);
        Assertions.assertThrows(BankProcessingException.class, () -> backupService.saveAndDeletePayment(new PaymentEntity()));
    }
}