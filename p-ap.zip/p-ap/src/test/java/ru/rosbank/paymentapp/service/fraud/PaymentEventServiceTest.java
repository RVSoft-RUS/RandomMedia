package ru.rosbank.paymentapp.service.fraud;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import ru.rosbank.paymentapp.BaseTestEsb;
import ru.rosbank.paymentapp.entity.AntifraudResolutionEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.AntifraudResolutionEntityRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.cryptopro.CryptoproService;
import ru.rosbank.paymentapp.service.fraud.model.AbstractEvent;
import ru.rosbank.paymentapp.service.fraud.model.DocumentStatusEvent;
import ru.rosbank.paymentapp.service.fraud.model.PaymentEvent;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateDTO;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateRequestDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.esb.model.getcustomeraccountlist.GetCustomerAccountListResponseTypeEsb;
import ru.rosbank.platform.esb.support.EsbRequestTypeEnum;

class PaymentEventServiceTest extends BaseTestEsb {

    @Autowired
    PaymentEventService paymentEventService;
    @Autowired
    PaymentEntityRepository documentRepository;
    @Autowired
    AntifraudResolutionEntityRepository antifraudResolutionEntityRepository;

    @MockBean
    FraudSenderService fraudSenderService;
    @MockBean
    CryptoproService cryptoproService;
    @MockBean
    ScheduledConfiguration scheduledConfiguration;
    @MockBean
    UserService userService;


    private PaymentEntity payment;
    private static final Long docId = 2L;

    @BeforeEach
    public void init() throws Exception {
        payment = documentRepository.findById(docId).get();
        doNothing().when(fraudSenderService).sendPaymentEventMessage(any(AbstractEvent.class));

        GetCustomerAccountListResponseTypeEsb accList =
                (GetCustomerAccountListResponseTypeEsb) xmlToObj(
                        new ClassPathResource("/responses/jms/GetCustomerAccountListResponse.xml"),
                        EsbRequestTypeEnum.GET_CUSTOMER_ACCOUNT_LIST);
        when(esbService.getCustomerAccountList(any())).thenReturn(accList);

        SignatureDTO signatureDTO = buildSignResponse(payment);
        List<SignatureDTO> signatures = Collections.singletonList(signatureDTO);
        when(cryptoproService.getDocumentSignatures(any())).thenReturn(signatures);

        CertificateDTO certificateDTO = buildCertResponse();
        CertificateRequestDTO certificateRequestDTO = new CertificateRequestDTO();
        certificateRequestDTO.setNameShort(payment.getPayerName());
        when(cryptoproService.getCertificate(anyString())).thenReturn(certificateDTO);
        when(cryptoproService.getCertificateRequest(anyString())).thenReturn(Optional.of(certificateRequestDTO));

        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(704L);
        clientDTO.setRegistrationCompleted(OffsetDateTime.now());
        clientDTO.setPermPassPrimeSet(OffsetDateTime.now());
        clientDTO.setLogin("79411234566");

        when(userService.getClientById(anyLong())).thenReturn(Optional.of(clientDTO));
        when(userService.getClientByDboProId(anyString())).thenReturn(Optional.of(clientDTO));

    }

    @AfterEach
    public void clear() {
        antifraudResolutionEntityRepository.deleteAll();
    }

    @Test
    public void sendPaymentEventTestSuccessful() {
        paymentEventService.sendPaymentEvent(payment);

        ArgumentCaptor<PaymentEvent> argumentCaptor = ArgumentCaptor.forClass(PaymentEvent.class);
        verify(fraudSenderService).sendPaymentEventMessage(argumentCaptor.capture());
        PaymentEvent capturedArgument = argumentCaptor.getValue();

        Assertions.assertEquals(778, capturedArgument.getDocumentNumber());

        Assertions.assertEquals("ИП Донварь Кристина Валерьевна", capturedArgument.getEntity().getOrganizationName());

        AntifraudResolutionEntity resolution =
                antifraudResolutionEntityRepository.findByDocumentId(payment.getId()).orElse(null);
        Assertions.assertNotNull(resolution);
    }

    @Test
    public void sendDocStatusTest() {
        ClientDTO clientDTO = new ClientDTO();
        clientDTO.setLegacyId(704L);
        clientDTO.setRegistrationCompleted(OffsetDateTime.now());
        clientDTO.setPermPassPrimeSet(OffsetDateTime.now());
        clientDTO.setLogin("79411234566");
        clientDTO.setId("id");
        clientDTO.setFio("FIO");
        clientDTO.setCrmId("crmId");
        clientDTO.setRegistrationCompleted(OffsetDateTime.now());
        clientDTO.setPermPassPrimeSet(OffsetDateTime.now());
        when(userService.getClientById(anyLong())).thenReturn(Optional.of(clientDTO));
        SignatureDTO signatureDTO = buildSignResponse(payment);
        signatureDTO.getMetaData().setPlatform("ANDROID");
        signatureDTO.getMetaData().setDeviceId("DeviceId");
        signatureDTO.getMetaData().setAppVersion("AppVersion");
        signatureDTO.getMetaData().setSessionId("SessionId");
        List<SignatureDTO> signatures = Collections.singletonList(signatureDTO);
        when(cryptoproService.getDocumentSignatures(any())).thenReturn(signatures);
        paymentEventService.sendDocumentStatus(payment);

        ArgumentCaptor<DocumentStatusEvent> argumentCaptor = ArgumentCaptor.forClass(DocumentStatusEvent.class);
        verify(fraudSenderService).sendDocumentStatusEventMessage(argumentCaptor.capture());
        DocumentStatusEvent capturedArgument = argumentCaptor.getValue();
        Assertions.assertEquals("ИП Донварь Кристина Валерьевна", capturedArgument.getEntity().getOrganizationName());
        Assertions.assertEquals("79411234566", capturedArgument.getCustomer().getUserLogin());
        Assertions.assertEquals("crmId", capturedArgument.getCustomer().getSiebelId());
        Assertions.assertEquals("SessionId", capturedArgument.getRequest().getSessionId());
    }

    @Test
    public void sendDocStatusTestNull() {
        when(userService.getClientById(anyLong())).thenReturn(null);
        when(cryptoproService.getDocumentSignatures(any())).thenReturn(null);
        paymentEventService.sendDocumentStatus(payment);

        ArgumentCaptor<DocumentStatusEvent> argumentCaptor = ArgumentCaptor.forClass(DocumentStatusEvent.class);
        verify(fraudSenderService).sendDocumentStatusEventMessage(argumentCaptor.capture());
        DocumentStatusEvent capturedArgument = argumentCaptor.getValue();
        Assertions.assertEquals("", capturedArgument.getEntity().getOrganizationName());
        Assertions.assertEquals(null, capturedArgument.getCustomer().getUserLogin());
    }
}