package ru.rosbank.paymentapp;

import feign.FeignException;

public class MyFeignException extends FeignException {
    public MyFeignException(int status, String message) {
        super(status, message);
    }
}
