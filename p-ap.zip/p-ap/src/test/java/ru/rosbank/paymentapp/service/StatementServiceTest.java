package ru.rosbank.paymentapp.service;

import static org.mockito.ArgumentMatchers.anyString;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.MyFeignException;
import ru.rosbank.platform.client.statementapp.api.StatementAppApiClient;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;

class StatementServiceTest extends BaseTest {
    @Autowired
    StatementService statementService;
    @MockBean
    StatementAppApiClient statementAppApiClient;

    @Test
    void getPaymentTest() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(anyString(), anyString()))
                .thenReturn(ResponseEntity.ok(new PaymentDTO().accountNumber13("13")));
        var response = statementService.getPayment("dboproid", "docId");
        Assertions.assertTrue(response.isPresent());
        Assertions.assertEquals("13", response.get().getAccountNumber13());
    }

    @Test
    void getPayment404ExceptionTest() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(anyString(), anyString()))
                .thenThrow(new MyFeignException(404, "test"));
        Assertions.assertFalse(statementService.getPayment("dboproid", "docId").isPresent());
    }

    @Test
    void getPayment500ExceptionTest() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(anyString(), anyString()))
                .thenThrow(new MyFeignException(500, "test"));
        Assertions.assertFalse(statementService.getPayment("dboproid", "docId").isPresent());
    }

    @Test
    void getPaymentRuntimeExceptionTest() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(anyString(), anyString()))
                .thenThrow(new RuntimeException("test"));
        Assertions.assertFalse(statementService.getPayment("dboproid", "docId").isPresent());
    }
}
