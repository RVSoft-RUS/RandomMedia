package ru.rosbank.paymentapp.esb.service;

import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderRequestTypeEsb;

@Slf4j
class PaymentOrderServiceTest extends BaseTest {

    @Autowired
    PaymentEntityRepository paymentEntityRepository;
    @Autowired
    PaymentOrderService paymentOrderService;

    @Test
    void buildRequest() {
        Iterable<PaymentEntity> docs = paymentEntityRepository.findAll();
        Integer i = 1;

        for (PaymentEntity doc: docs) {
            log.debug("buildRequestTest! {}, {}, {}", doc.getAmount(), doc.getId(), doc);
            doc.setPaypriority("0" + i.toString());
            if (i > 5) {
                i = 5;
            }
            CreatePaymentOrderRequestTypeEsb request = paymentOrderService.buildRequest(doc, "inputUser");

            Assert.assertEquals(i.toString(), request.getCreatePaymentOrderRequest().getPaymentOrder().getSubtypeOperation());
        }
    }
}