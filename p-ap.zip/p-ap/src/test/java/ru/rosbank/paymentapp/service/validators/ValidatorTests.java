package ru.rosbank.paymentapp.service.validators;

import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;

public class ValidatorTests extends BaseTest {

    @Autowired
    UniqDocumentNumberValidator validator;
    @Autowired
    PaymentEntityRepository documentRepository;

    @MockBean
    ScheduledConfiguration scheduledConfiguration;

    @Test
    void uniqDocumentNumberValidatorTest() {

        PaymentEntity doc = new PaymentEntity();
        doc.setNumber("7083");
        doc.setClientId(22L);
        doc.setId(3L);
        doc.setDate(LocalDateTime.now());
        doc.setPayerInn("450146852396");

        validator.validate(doc);

    }

    @Test
    void uniqDocumentNumberPerDeyValidatorTest() {

        PaymentEntity doc = new PaymentEntity();
        doc.setNumber("777");
        doc.setClientId(22L);
        doc.setExecutionDate(LocalDateTime.now());

        doc.setPayerInn("450146852396");
        LocalDateTime yesterday = LocalDateTime.of(2021, 01, 23, 00,00, 00, 000);
        LocalDateTime today = yesterday.plusDays(1);
        validator.validatePerDey(doc, today);

        //assertThrows(DocumentNumberException.class, () -> validator.validatePerDey(doc, yesterday));

        doc.setId(1L);
        validator.validatePerDey(doc, yesterday);
    }
}
