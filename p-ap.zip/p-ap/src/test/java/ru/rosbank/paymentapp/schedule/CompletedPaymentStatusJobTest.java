package ru.rosbank.paymentapp.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.StatementService;
import ru.rosbank.platform.client.statementapp.model.AccountStatementDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

public class CompletedPaymentStatusJobTest extends BaseTest {

    @Autowired
    CompletedPaymentStatusJob completedPaymentStatusJob;
    @Autowired
    PaymentEntityRepository paymentEntityRepository;
    @MockBean
    SharedLock sharedLock;
    @MockBean
    StatementService statementService;

    @Test
    public void test() {
        var paymentSentToBis = paymentEntityRepository.findAllByStatusIn(
                List.of(DocumentStatus.SIGNED.getValue())).stream().findFirst().get();
        paymentSentToBis.setId(null);
        paymentSentToBis.setDate(LocalDateTime.now());
        paymentSentToBis.setBisDocumentId("PP111");
        paymentSentToBis.setStatus(DocumentStatus.SENT_TO_BIS.getValue());
        paymentSentToBis = paymentEntityRepository.save(paymentSentToBis);
        when(sharedLock.lock(anyString(), anyInt())).thenReturn(true);
        when(statementService.getStatement(anyString(), anyString(), any(), any())).thenReturn(Optional.of(
                new AccountStatementDTO().operations(List.of(new PaymentDTO().id("PP111")))));

        completedPaymentStatusJob.run();
        Assertions.assertEquals(1, StreamSupport.stream(paymentEntityRepository
                .findAll().spliterator(), false)
                        .filter(p -> DocumentStatus.COMPLETED.name().equals(p.getStatus()))
                .count());
        paymentEntityRepository.delete(paymentSentToBis);
    }
}
