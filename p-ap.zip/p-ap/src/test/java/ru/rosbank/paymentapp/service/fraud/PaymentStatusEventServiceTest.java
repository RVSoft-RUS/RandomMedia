package ru.rosbank.paymentapp.service.fraud;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.BaseTestEsb;
import ru.rosbank.paymentapp.entity.AntifraudResolutionEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.AntifraudResolutionEntityRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;
import ru.rosbank.paymentapp.service.audit.AuditService;
import ru.rosbank.platform.client.auditapp.model.AntifraudPaymentStatusDTO;
import ru.rosbank.platform.client.auditapp.model.AntifraudRequestDTO;
import ru.rosbank.platform.client.auditapp.model.PaymentStatusDTO;


class PaymentStatusEventServiceTest extends BaseTestEsb {

    @Autowired
    PaymentStatusEventService paymentStatusEventService;
    @Autowired
    PaymentEntityRepository documentRepository;
    @Autowired
    AntifraudResolutionEntityRepository antifraudResolutionEntityRepository;

    @MockBean
    AuditService auditService;
    @MockBean
    ScheduledConfiguration scheduledConfiguration;

    private PaymentEntity payment;
    private static final Long docId = 2L;

    @BeforeEach
    public void init() throws Exception {
        payment = documentRepository.findById(docId).get();
        doNothing().when(auditService).sendAntifraudEvent(any());
    }

    @AfterEach
    public void clear() {
        antifraudResolutionEntityRepository.deleteAll();
    }

    @Test
    void sendPaymentFirstTimeoutEventGotRequestId() {

        AntifraudResolutionEntity resolutionEntity = new AntifraudResolutionEntity();
        resolutionEntity.setId(1L);
        resolutionEntity.setStatus("allow_timeout");
        resolutionEntity.setRequestId("600f28e6-125b-4c32-9548-41ffb5d490f6");
        resolutionEntity.setDocumentId(2L);
        resolutionEntity.setClientId(704L);
        resolutionEntity.setCreated(LocalDateTime.now());
        antifraudResolutionEntityRepository.save(resolutionEntity);

        paymentStatusEventService.sendPaymentEvent(payment, PaymentStatusEvents.ANTI_FRAUD_ALLOW_TIMEOUT);
        Mockito.verify(auditService, times(1)).sendAntifraudEvent(any());

        ArgumentCaptor<AntifraudRequestDTO> argumentCaptor = ArgumentCaptor.forClass(AntifraudRequestDTO.class);
        verify(auditService).sendAntifraudEvent(argumentCaptor.capture());
        AntifraudRequestDTO capturedArgument = argumentCaptor.getValue();

        Assertions.assertEquals("600f28e6-125b-4c32-9548-41ffb5d490f6", capturedArgument.getRequest().getRequestId());
    }

    @Test
    void sendPaymentSecondTimeoutEventSuccessful() {

        paymentStatusEventService.sendPaymentEvent(payment, PaymentStatusEvents.ANTI_FRAUD_REVIEW_TIMEOUT);
        Mockito.verify(auditService, times(1)).sendAntifraudEvent(any());

    }

    @Test
    void sendRejectedAtOnceEventSuccessful() {

        paymentStatusEventService.sendPaymentEvent(payment, PaymentStatusEvents.ANTI_FRAUD_DENY);
        Mockito.verify(auditService, times(1)).sendAntifraudEvent(any());

        ArgumentCaptor<AntifraudPaymentStatusDTO> argumentCaptor = ArgumentCaptor.forClass(AntifraudPaymentStatusDTO.class);
        verify(auditService).sendAntifraudEvent(argumentCaptor.capture());
        AntifraudPaymentStatusDTO capturedArgument = argumentCaptor.getValue();

        Assertions.assertEquals(PaymentStatusDTO.StatusCodeT1Enum.ZERO, capturedArgument.getPaymentStatus().getStatusCodeT1());

    }

    @Test
    void sendRecalledInReviewEventSuccessful() {

        paymentStatusEventService.sendPaymentEvent(payment, PaymentStatusEvents.ANTI_FRAUD_RECALLED_IN_REVIEW);
        Mockito.verify(auditService, times(1)).sendAntifraudEvent(any());

    }
}