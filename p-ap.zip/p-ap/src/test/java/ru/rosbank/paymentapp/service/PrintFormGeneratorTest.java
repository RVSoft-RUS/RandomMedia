package ru.rosbank.paymentapp.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.dto.AccountCashWarrantDocumentDto;
import ru.rosbank.paymentapp.dto.BankOrderDocumentDto;
import ru.rosbank.paymentapp.dto.CashReceiptOrderDocumentDto;
import ru.rosbank.paymentapp.dto.CollectionAssignmentDocumentDto;
import ru.rosbank.paymentapp.dto.DocumentStatusDto;
import ru.rosbank.paymentapp.dto.DocumentTypeDto;
import ru.rosbank.paymentapp.dto.MemorialOrderDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentAssignmentDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentBillDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentOrderDocumentDto;
import ru.rosbank.paymentapp.service.exceptions.BackendException;

class PrintFormGeneratorTest extends BaseTest {
    @Autowired
    PrintFormGenerator printFormGenerator;

    @Test
    void getTemplateByDocumentTest() {
        Assertions.assertEquals("paymentOrder.html.ftl",
                printFormGenerator.getTemplateByDocument(new PaymentOrderDocumentDto()));
        Assertions.assertEquals("cardOperation.html.ftl",
                printFormGenerator.getTemplateByDocument(new PaymentAssignmentDocumentDto().withCardPan("1")));
        Assertions.assertEquals("paymentAssignmentWithComment.html.ftl",
                printFormGenerator.getTemplateByDocument(new PaymentAssignmentDocumentDto()
                        .withStatus(DocumentStatusDto.REJECTED)));
        Assertions.assertEquals("paymentAssignment.html.ftl",
                printFormGenerator.getTemplateByDocument(new PaymentAssignmentDocumentDto()
                        .withStatus(DocumentStatusDto.COMPLETED)));
        Assertions.assertEquals("bankingOrder.html.ftl",
                printFormGenerator.getTemplateByDocument(new BankOrderDocumentDto()));
        Assertions.assertEquals("memorialOrder.html.ftl",
                printFormGenerator.getTemplateByDocument(new MemorialOrderDocumentDto()));
        Assertions.assertEquals("paymentRequestCredit.html.ftl",
                printFormGenerator.getTemplateByDocument(new PaymentBillDocumentDto().withType(DocumentTypeDto.CA)));
        Assertions.assertEquals("paymentRequestDebit.html.ftl",
                printFormGenerator.getTemplateByDocument(new PaymentBillDocumentDto()));
        Assertions.assertEquals("collectionOrderCredit.html.ftl",
                printFormGenerator.getTemplateByDocument(new CollectionAssignmentDocumentDto().withType(DocumentTypeDto.CA)));
        Assertions.assertEquals("collectionOrderDebit.html.ftl",
                printFormGenerator.getTemplateByDocument(new CollectionAssignmentDocumentDto()));
        Assertions.assertThrows(BackendException.class,
            () -> printFormGenerator.getTemplateByDocument(new AccountCashWarrantDocumentDto()));
    }

    @Test
    void getTitleTest() {
        Assertions.assertEquals("Платёжный ордер № ",
                printFormGenerator.getTitle(new PaymentOrderDocumentDto()));
        Assertions.assertEquals("Операция по карте",
                printFormGenerator.getTitle(new PaymentAssignmentDocumentDto().withCardPan("1")));
        Assertions.assertEquals("Платёжное поручение № ",
                printFormGenerator.getTitle(new PaymentAssignmentDocumentDto()));
        Assertions.assertEquals("Банковский ордер № ",
                printFormGenerator.getTitle(new BankOrderDocumentDto()));
        Assertions.assertEquals("МЕМОРИАЛЬНЫЙ ОРДЕР № ",
                printFormGenerator.getTitle(new MemorialOrderDocumentDto()));
        Assertions.assertEquals("ПЛАТЕЖНОЕ ТРЕБОВАНИЕ № ",
                printFormGenerator.getTitle(new PaymentBillDocumentDto()));
        Assertions.assertEquals("ИНКАССОВОЕ ПОРУЧЕНИЕ № ",
                printFormGenerator.getTitle(new CollectionAssignmentDocumentDto()));
        Assertions.assertEquals("РАСХОДНЫЙ КАССОВЫЙ ОРДЕР № ",
                printFormGenerator.getTitle(new AccountCashWarrantDocumentDto()));
        Assertions.assertEquals("ПРИХОДНЫЙ КАССОВЫЙ ОРДЕР № ",
                printFormGenerator.getTitle(new CashReceiptOrderDocumentDto()));
    }
}
