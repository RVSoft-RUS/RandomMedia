package ru.rosbank.paymentapp.template.converters;

import java.util.List;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.TemplateEntity;
import ru.rosbank.paymentapp.repository.TemplateRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;


class TemplateDtoToTemplateConverterTest extends BaseTest {

    @Autowired
    TemplateRepository templateRepository;

    @Autowired
    TemplateDtoToTemplateConverter templateDtoToTemplateConverter;

    @Autowired
    TemplateToTemplateDtoConverter templateToTemplateDtoConverter;

    @MockBean
    ScheduledConfiguration scheduledConfiguration;

    @Test
    void convert() {
        List<TemplateEntity> templateEntities = templateRepository.findByDboProIdAndStatus("123456789",
                TemplateEntity.Status.ACTIVE.value());

        Boolean result = templateEntities.stream().map(templateToTemplateDtoConverter::convert)
                .map(templateDtoToTemplateConverter::convert)
                .allMatch(t -> templateEntities.stream().anyMatch(sours -> t.equals(sours)));
        Assert.assertTrue(result);
    }
}