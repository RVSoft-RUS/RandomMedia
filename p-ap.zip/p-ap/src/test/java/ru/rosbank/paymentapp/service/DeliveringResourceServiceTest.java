package ru.rosbank.paymentapp.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.DeliveringResource;
import ru.rosbank.paymentapp.repository.DeliveringResourceRepository;
import ru.rosbank.paymentapp.service.sms.SendSmsService;

class DeliveringResourceServiceTest extends BaseTest {
    @MockBean
    SendSmsService sendSmsService;

    @Autowired
    DeliveringResourceService deliveringResourceService;
    @Autowired
    DeliveringResourceRepository deliveringResourceRepository;

    @Test
    void getDeliveringResourceExistsTest() {
        deliveringResourceRepository.deleteAll();
        var resource = new DeliveringResource();
        resource.setAttempts(0);
        resource.setResourceId("res id");
        resource.setReference("reference");
        resource.setResourceName("resname");
        resource.setResourceContent("content".getBytes(StandardCharsets.UTF_8));
        resource.setResourceContentType("HTML");
        resource = deliveringResourceRepository.save(resource);
        var result = deliveringResourceService.getDeliveringResource(resource.getReference());
        Assertions.assertNotNull(result);
        Assertions.assertEquals(resource.getResourceId(), result.getId());
        Assertions.assertEquals(1, deliveringResourceRepository.findById(resource.getId()).get().getAttempts());
    }

    @Test
    void getDeliveringResourceNotExistsTest() {
        deliveringResourceRepository.deleteAll();
        var result = deliveringResourceService.getDeliveringResource("test");
        Assertions.assertNotNull(result);
        Assertions.assertNull(result.getContent());
    }

    @Test
    void deliverReferenceBySmsTest() {
        Mockito.doNothing().when(sendSmsService).sendSMS(anyString(), any(), anyString());
        deliveringResourceService.deliverReferenceBySms("test", "test");
        Mockito.verify(sendSmsService, Mockito.times(1)).sendSMS(anyString(), any(), anyString());
    }
}
