package ru.rosbank.paymentapp.service.validators;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.ScheduledConfiguration;
import ru.rosbank.paymentapp.service.cryptopro.CryptoproService;
import ru.rosbank.paymentapp.service.exceptions.DocumentContentDifferentException;
import ru.rosbank.platform.client.cryptoproapp.model.MetaDataDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;

class DocumentContentValidatorTest extends BaseTest {

    @Autowired
    DocumentContentValidator documentContentValidator;
    @Autowired
    PaymentEntityRepository documentRepository;

    @MockBean
    CryptoproService cryptoproService;
    @MockBean
    ScheduledConfiguration scheduledConfiguration;

    private PaymentEntity payment;
    private static final Long docId = 2L;

    @BeforeEach
    public void init() {
        payment = documentRepository.findById(docId).get();
        SignatureDTO signatureDTO = buildSignResponse();
        List<SignatureDTO> signatures = Collections.singletonList(signatureDTO);
        when(cryptoproService.getDocumentSignatures(any())).thenReturn(signatures);
    }

    @Test
    void validate() throws DocumentContentDifferentException {
        documentContentValidator.validate(payment);
    }

    private SignatureDTO buildSignResponse() {

        SignatureDTO signatureDTO = new SignatureDTO();
        signatureDTO.setConfirmed(true);
        signatureDTO.setMetaData(new MetaDataDTO());
        signatureDTO.setResult("MIIIwQYJKoZIhvcNAQcCoIIIsjCCCK4CAQExDjAMBggqhQMHAQECAgUAMEYGCSqGSIb3DQEHAaA5BDc8P3htbC"
                + "B2ZXJzaW9uPSIxLjAiIGVuY29kaW5nPSJVVEYtOCIgc3RhbmRhbG9uZT0ieWVzIj8+oIIFNjCCBTIwggTfoAMCAQICEQGtlvkAf"
                + "6yFpkdiDhoy51bMMAoGCCqFAwcBAQMCMIHeMRgwFgYFKoUDZAESDTEwMjc3Mzk0NjA3MzcxGjAYBggqhQMDgQMBARIMMDA3NzMw"
                + "MDYwMTY0MQswCQYDVQQGEwJSVTEVMBMGA1UEBwwM0JzQvtGB0LrQstCwMTMwMQYDVQQJDCrRg9C7LtCc0LDRiNC4INCf0L7RgNGL"
                + "0LLQsNC10LLQvtC5LCDQtC4gMzQxHjAcBgNVBAoMFdCf0JDQniDQoNCe0KHQkdCQ0J3QmjEtMCsGA1UEAwwk0KbQoSDQoNC+0YHQ"
                + "sdCw0L3QuiDQotC10YHRgtC+0LLRi9C5MB4XDTIwMTEyNjE0NTg0NFoXDTIyMDIyNjE1MDg0NFowWzEcMBoGA1UECgwT0JjQnyDQ"
                + "lNGA0L7QstC90LXQsjE7MDkGA1UEAwwy0JTQoNCe0JLQndCV0JIg0JDQm9CV0JrQodCV0Jkg0JvQldCe0J3QmNCU0J7QktCY0Kcw"
                + "ZjAfBggqhQMHAQEBATATBgcqhQMCAiQABggqhQMHAQECAgNDAARArvf7TKIdR4wKnAKsrhcTKykI7G86iHwzmu62IJuOF0aBtY5Z"
                + "8J1gcb39IRnMLLKDicni+jqE14qiyLn7biJZTqOCAvEwggLtMA4GA1UdDwEB/wQEAwID6DAdBgNVHQ4EFgQUboSQqsvJWDkEvOl/c"
                + "32wQtrzDegwHwYJKwYBBAGCNxUHBBIwEAYIKoUDAgIuAAgCAQECAQAwHQYDVR0lBBYwFAYIKwYBBQUHAwIGCCsGAQUFBwMEMIG/B"
                + "ggrBgEFBQcBAQSBsjCBrzBEBggrBgEFBQcwAYY4aHR0cDovL3JzYnQtYXN0Y3J0MDEudHJvc2JhbmsudHJ1cy50c29jZ2VuL29jc3"
                + "Avb2NzcC5zcmYwZwYIKwYBBQUHMAKGW2h0dHA6Ly9yc2J0LWFzdGNydDAxLnRyb3NiYW5rLnRydXMudHNvY2dlbi9haWEvY2Y1OT"
                + "c0MzJmOGU5NDA3ZmI5ZDg0YTIwMDQ4OTg2NDdkYTQ3NGM5Yy5jcnQwbAYDVR0fBGUwYzBhoF+gXYZbaHR0cDovL3JzYnQtYXN0Y3"
                + "J0MDEudHJvc2JhbmsudHJ1cy50c29jZ2VuL2NkcC9jZjU5NzQzMmY4ZTk0MDdmYjlkODRhMjAwNDg5ODY0N2RhNDc0YzljLmNybD"
                + "CCAR0GA1UdIwSCARQwggEQgBTPWXQy+OlAf7nYSiAEiYZH2kdMnKGB5KSB4TCB3jEYMBYGBSqFA2QBEg0xMDI3NzM5NDYwNzM3MRo"
                + "wGAYIKoUDA4EDAQESDDAwNzczMDA2MDE2NDELMAkGA1UEBhMCUlUxFTATBgNVBAcMDNCc0L7RgdC60LLQsDEzMDEGA1UECQwq0YPQuy"
                + "7QnNCw0YjQuCDQn9C+0YDRi9Cy0LDQtdCy0L7QuSwg0LQuIDM0MR4wHAYDVQQKDBXQn9CQ0J4g0KDQntCh0JHQkNCd0JoxLTArBgNVB"
                + "AMMJNCm0KEg0KDQvtGB0LHQsNC90Log0KLQtdGB0YLQvtCy0YvQuYIRAc8B3AD7q8GEQX+4t4RG7QswKwYDVR0QBCQwIoAPMjAyMDE"
                + "xMjYxNDU4NDNagQ8yMDIyMDIyNjE0NTg0M1owCgYIKoUDBwEBAwIDQQCykOr7cv7UY+2AVFM0PRPEx15UX3TJZdR11YxCJWrXYCluCk"
                + "t/G7jFuvqdJD8LHVnxF3AdtREBoDJwNjUB9wx5MYIDFTCCAxECAQEwgfQwgd4xGDAWBgUqhQNkARINMTAyNzczOTQ2MDczNzEaMBgGC"
                + "CqFAwOBAwEBEgwwMDc3MzAwNjAxNjQxCzAJBgNVBAYTAlJVMRUwEwYDVQQHDAzQnNC+0YHQutCy0LAxMzAxBgNVBAkMKtGD0Lsu0JzQs"
                + "NGI0Lgg0J/QvtGA0YvQstCw0LXQstC+0LksINC0LiAzNDEeMBwGA1UECgwV0J/QkNCeINCg0J7QodCR0JDQndCaMS0wKwYDVQQDDCTQ"
                + "ptChINCg0L7RgdCx0LDQvdC6INCi0LXRgdGC0L7QstGL0LkCEQGtlvkAf6yFpkdiDhoy51bMMAwGCCqFAwcBAQICBQCgggG1MBgGCSq"
                + "GSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTIxMDExNDA3MjMwNVowLwYJKoZIhvcNAQkEMSIEIJ0xweI68E2bu7"
                + "6pMqEiYUhAKsr7ANVyllc325Hj76LPMIIBSAYLKoZIhvcNAQkQAi8xggE3MIIBMzCCAS8wggErMAoGCCqFAwcBAQICBCA4m08zQ59ouC3"
                + "iSEl5zGT0UF2sg0aYh4gPBbkTB0aTdTCB+jCB5KSB4TCB3jEYMBYGBSqFA2QBEg0xMDI3NzM5NDYwNzM3MRowGAYIKoUDA4EDAQESDDA"
                + "wNzczMDA2MDE2NDELMAkGA1UEBhMCUlUxFTATBgNVBAcMDNCc0L7RgdC60LLQsDEzMDEGA1UECQwq0YPQuy7QnNCw0YjQuCDQn9C+0YD"
                + "Ri9Cy0LDQtdCy0L7QuSwg0LQuIDM0MR4wHAYDVQQKDBXQn9CQ0J4g0KDQntCh0JHQkNCd0JoxLTArBgNVBAMMJNCm0KEg0KDQvtGB0LH"
                + "QsNC90Log0KLQtdGB0YLQvtCy0YvQuQIRAa2W+QB/rIWmR2IOGjLnVswwDAYIKoUDBwEBAQEFAARAaSekOsvf/SKFT0lL8pyxBAgqzma"
                + "pDf16UQsD+2vlTIy0lmxpXcnfVQaOgmIzefx81bIJRmCui4+ooVBVuaQTbQ==");

        return signatureDTO;
    }

}