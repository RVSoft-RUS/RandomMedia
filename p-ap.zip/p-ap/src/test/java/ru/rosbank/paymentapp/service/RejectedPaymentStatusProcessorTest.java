package ru.rosbank.paymentapp.service;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.paymentapp.BaseTest;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.MoneyAmountTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;


class RejectedPaymentStatusProcessorTest extends BaseTest {

    @Autowired
    private RejectedPaymentStatusProcessor rejectedPaymentStatusProcessor;
    private LocalDateTime dateStart = LocalDateTime.of(2021, 11, 10, 0, 0);

    @MockBean
    OrganizationService organizationService;

    @Test
    void isSameDocumentAndPayment() {
        boolean result = rejectedPaymentStatusProcessor.isSameDocumentAndPayment(
                getDocument(), getPayment(dateStart));
        Assertions.assertTrue(result);
    }

    @Test
    void isSameDocumentAndPayment1() {
        boolean result = rejectedPaymentStatusProcessor.isSameDocumentAndPayment(
                getDocument(), getPayment(dateStart.plusDays(1)));
        Assertions.assertTrue(result);
    }

    @Test
    void isSameDocumentAndPayment6() {
        boolean result = rejectedPaymentStatusProcessor.isSameDocumentAndPayment(
                getDocument(), getPayment(dateStart.plusDays(6)));
        Assertions.assertFalse(result);
    }

    @Test
    void isSameDocumentAndPayment5() {
        boolean result = rejectedPaymentStatusProcessor.isSameDocumentAndPayment(
                getDocument(), getPayment(dateStart.plusDays(5)));
        Assertions.assertTrue(result);
    }

    @Test
    void isSameDocumentAndPaymentAmount() {
        PaymentOrderTypeEsb payment = getPayment(dateStart);
        payment.setAmount(new MoneyAmountTypeEsb().withAmount(BigDecimal.TEN));
        boolean result = rejectedPaymentStatusProcessor.isSameDocumentAndPayment(
                getDocument(), payment);
        Assertions.assertFalse(result);
    }

    @Test
    void isSameDocumentAndPaymentRecalled() {
        PaymentEntity doc = getDocument();
        doc.setStatus(DocumentStatus.RECALLED.name());
        boolean result = rejectedPaymentStatusProcessor.isSameDocumentAndPayment(
                doc, getPayment(dateStart));
        org.assertj.core.api.Assertions.assertThat(result).isFalse();
    }

    @Test
    void isSameDocumentAndPaymentRejected() {
        PaymentEntity doc = getDocument();
        doc.setStatus(DocumentStatus.REJECTED.name());
        boolean result = rejectedPaymentStatusProcessor.isSameDocumentAndPayment(
                doc, getPayment(dateStart));
        org.assertj.core.api.Assertions.assertThat(result).isFalse();
    }

    @Test
    void process() {
        var client = new ClientDTO();
        var docs = List.of(getDocument());
        rejectedPaymentStatusProcessor.process(docs, client);
    }

    PaymentEntity getDocument() {
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setStatus(DocumentStatus.CREATED.name());
        paymentEntity.setAmount(BigDecimal.ONE);
        paymentEntity.setNumber("1");
        paymentEntity.setDate(dateStart);
        paymentEntity.setPayeeAccount("01234567890123456789");

        return paymentEntity;
    }

    PaymentOrderTypeEsb getPayment(LocalDateTime date) {
        PaymentOrderTypeEsb payment = new PaymentOrderTypeEsb();
        payment.setAmount(new MoneyAmountTypeEsb().withAmount(BigDecimal.ONE));
        payment.setOrderNumber("1");
        payment.setDocumentDate(Date.from(date.atZone(ZoneId.systemDefault()).toInstant()));
        payment.setPayee(
                new RequisiteTypeEsb()
                        .withNumber(new AccountNumberTypeEsb()
                                .withAccountNumber20Digit("01234567890123456789")));
        return payment;
    }
}