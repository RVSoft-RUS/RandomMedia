package ru.rosbank.paymentapp.mapper;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;
import ru.rosbank.paymentapp.entity.DocumentRectification;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;


@org.mapstruct.Mapper
public interface RectificationMapper {
    RectificationMapper INSTANCE = Mappers.getMapper(RectificationMapper.class);

    @Mapping(source = "created", target = "created", qualifiedByName = "from_offset")
    DocumentRectification fromDTO(RectificationDTO dto);

    @Mapping(source = "created", target = "created", qualifiedByName = "to_offset")
    RectificationDTO toDTO(DocumentRectification doc);

    @Named("to_offset")
    default OffsetDateTime toOffset(Date date) {
        if (date != null) {
            return date.toInstant().atOffset(ZoneOffset.UTC);
        } else {
            return null;
        }
    }

    @Named("from_offset")
    default Date fromOffset(OffsetDateTime date) {
        if (date != null) {
            return java.sql.Date.from(date.toInstant());
        } else {
            return null;
        }
    }
}
