package ru.rosbank.paymentapp.service.exceptions;


public class DocumentRecallException extends RuntimeException {

    public DocumentRecallException(String msg) {
        super(msg);
    }

}
