package ru.rosbank.paymentapp.service;

import feign.FeignException;
import java.time.OffsetDateTime;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.statementapp.api.StatementAppApiClient;
import ru.rosbank.platform.client.statementapp.model.AccountStatementDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;

@Service
@Slf4j
@RequiredArgsConstructor
public class StatementService {

    private final StatementAppApiClient statementAppApiClient;


    public Optional<AccountStatementDTO> getStatement(String account,
                                                      String organizationBisBranch, OffsetDateTime from, OffsetDateTime to) {
        try {
            return Optional.ofNullable(statementAppApiClient.accountStatementOnlineGet(
                    account, organizationBisBranch, from, to, null, null)).map(HttpEntity::getBody);
        } catch (Exception e) {
            log.error("Unexpected exception get statement by account {}", account, e);
            return Optional.empty();
        }
    }

    public Optional<PaymentDTO> getPayment(String dboProId, String documentId) {
        try {
            return Optional.ofNullable(statementAppApiClient.documentDboProIdIdGet(dboProId, documentId))
                    .map(HttpEntity::getBody);
        } catch (FeignException e) {
            if (HttpStatus.NOT_FOUND.value() == e.status()) {
                log.warn("Payment id {} not found for dboProId {} in statement app.", documentId, dboProId);
            } else {
                log.error("Feign exception get payment by id {} and dboProId {}. HttpCode: {}",
                        documentId, dboProId, e.status(), e);
            }
            return Optional.empty();
        } catch (Exception e) {
            log.error("Unexpected exception get payment by id {}", documentId, e);
            return Optional.empty();
        }
    }
}
