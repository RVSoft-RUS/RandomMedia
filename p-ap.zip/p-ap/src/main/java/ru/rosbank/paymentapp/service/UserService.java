package ru.rosbank.paymentapp.service;

import feign.FeignException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.platform.client.userapp.api.UserAppApi;
import ru.rosbank.platform.client.userapp.model.ClientDTO;


@Service
@Slf4j
public class UserService {
    @Autowired
    private UserAppApi userAppApi;

    public Optional<ClientDTO> getClientById(Long id) {

        ClientDTO clientDTO;
        try {
            clientDTO = userAppApi.userGetById(id).getBody();

        } catch (FeignException ex) {
            log.error("Ошибка получения клиента {} ", id, ex);
            throw new BackendException(ex.getMessage(), String.valueOf(ex.status()), true);
        }
        return Optional.ofNullable(clientDTO);

    }

    public Optional<ClientDTO> getClientByDboProId(String id) {
        ClientDTO clientDTO;
        try {
            clientDTO = userAppApi.userGetByDboProId(id).getBody();
        } catch (FeignException ex) {
            log.error("Ошибка получения клиента {} ", id, ex);
            throw new BackendException(ex.getMessage(), String.valueOf(ex.status()), true);
        }
        return Optional.ofNullable(clientDTO);

    }

}
