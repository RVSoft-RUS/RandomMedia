package ru.rosbank.paymentapp.service.exceptions;


public class CrmNotFoundException extends Exception {

    public CrmNotFoundException(String message) {
        super(message);
    }

}
