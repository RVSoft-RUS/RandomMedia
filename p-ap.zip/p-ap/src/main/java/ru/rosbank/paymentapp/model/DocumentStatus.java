package ru.rosbank.paymentapp.model;

import ru.rosbank.paymentapp.dto.DocumentStatusDto;

//Imported from bs-app
public enum DocumentStatus {

    CREATED,
    SIGNING,

    SIGNED,         // PROCESSING
    DFM_PROCESSING, // PROCESSING
    SENT_TO_BIS,    // PROCESSING

    PROCESSING,
    COMPLETED,
    REJECTED,
    RECALLED,
    REVIEW,         // PROCESSING
    PLANNED,
    ERROR;

    public String value() {
        return name();
    }

    public static DocumentStatus fromValue(String v) {
        return valueOf(v);
    }

    public DocumentStatusDto getDto() {
        return getDto(this);
    }

    public static DocumentStatusDto getDto(DocumentStatus status) {
        if (isProcessingForDto(status)) {
            return DocumentStatusDto.PROCESSING;
        }
        return DocumentStatusDto.fromValue(status.name());
    }

    public static boolean isProcessingForDto(DocumentStatus status) {
        return DFM_PROCESSING.equals(status) || SENT_TO_BIS.equals(status) || ERROR.equals(status)
            || PROCESSING.equals(status) || REVIEW.equals(status);
    }
}
