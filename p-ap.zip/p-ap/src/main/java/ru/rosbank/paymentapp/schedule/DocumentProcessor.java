package ru.rosbank.paymentapp.schedule;

import static ru.rosbank.paymentapp.entity.PaymentEntity.PROCESSING_STATUS;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.esb.service.PaymentOrderService;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.PaymentService;
import ru.rosbank.paymentapp.service.cryptopro.CryptoproService;
import ru.rosbank.paymentapp.service.dfm.DfmPaymentService;
import ru.rosbank.paymentapp.service.fraud.AntifraudPaymentService;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Slf4j
@RequiredArgsConstructor
@Component
public class DocumentProcessor {

    private final SharedLock sharedLock;
    private final PaymentEntityRepository paymentEntityRepository;
    private final PaymentService paymentService;
    private final DfmPaymentService dfmPaymentService;
    private final AntifraudPaymentService antifraudPaymentService;
    private final PaymentOrderService paymentOrderService;
    private final CryptoproService cryptoproService;

    @Value("${dfm.payment.lock.task.period}")
    int period;

    @Async("document_executor")
    public CompletableFuture<Long> process(Long id) {
        boolean lock = false;
        String lockKey = "DFMPayment_" + id;
        try {
            lock = sharedLock.lock(lockKey, period);
            if (lock) {
                Optional<PaymentEntity> optDocument = paymentEntityRepository.findById(id);
                if (optDocument.isPresent()) {
                    PaymentEntity document = optDocument.get();
                    if (documentHasSignature(document)) {
                        if (PROCESSING_STATUS.contains(document.getStatus()) && readyToProcess(document)) {
                            processDocument(document);
                        } else {
                            log.info("У документа не подходящий статус {}", id);
                        }
                    } else {
                        log.info("У документа не достаточно подписей {}", id);
                    }
                } else {
                    log.info("Ну удалось найти документ {}", id);
                }
                sharedLock.release(lockKey);
            } else {
                log.info("Не удалось захватить управление документом {}", id);
            }
        } catch (Throwable t) {
            log.error("Обработка документа [{}] прекращена с ошибкой: {}", id, t);
        } finally {
            if (lock) {
                sharedLock.release(lockKey);
                log.info("lock " + lockKey + " is released");
            }
        }
        return CompletableFuture.completedFuture(id);
    }

    private void processDocument(PaymentEntity document) {
        log.info("Обработка документа {}", document.getId());
        if (!StringUtils.isBlank(document.getBisDocumentId())) {
            log.info("Бис id заполнен {}", document.getId());
            return;
        }
        if (paymentService.isRevertible(document)) {
            log.info("Документ ещё можно отозвать {}", document.getId());
            return;
        }
        if (!dfmPaymentService.isProcessed(document)) {
            log.info("Нет резолюции ДФМ для документа {}", document.getId());
            return;
        }
        if (!antifraudPaymentService.isProcessed(document)) {
            log.info("Нет резолюции антифрод для документа {}", document.getId());
            return;
        }
        String user = dfmPaymentService.getInputUser(document);
        if (user == null) {
            return;
        }

        if (paymentOrderService.createPaymentOrderInBis(document)) {
            dfmPaymentService.finalizeStatusOnSuccess(document);
            antifraudPaymentService.sendPaymentStatusEvent(document);

        } else {
            dfmPaymentService.finalizeStatusOnError(document);
        }
    }

    private boolean documentHasSignature(PaymentEntity paymentEntity) {
        return !cryptoproService.getDocumentSignatures(paymentEntity).isEmpty();
    }

    private boolean readyToProcess(PaymentEntity document) {
        return (!DocumentStatus.PLANNED.name().equals(document.getStatus())
                || !(document.getExecutionDate() != null && LocalDateTime.now().isBefore(document.getExecutionDate())));
    }

}
