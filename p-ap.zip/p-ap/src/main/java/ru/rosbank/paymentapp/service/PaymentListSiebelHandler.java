package ru.rosbank.paymentapp.service;

import static ru.rosbank.paymentapp.service.audit.AuditService.SENT_PAYMENT_LIST_SIEBEL_STAGE;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.converters.DocumentConverter;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.audit.AuditService;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.DatePeriodTypeEsb;
import ru.rosbank.platform.esb.model.common.ResultInfoTypeEsb;
import ru.rosbank.platform.esb.model.getpaymentlist.GetPaymentListRequestTypeEsb;
import ru.rosbank.platform.esb.model.getpaymentlist.GetPaymentListResponseTypeEsb;
import ru.rosbank.platform.esb.model.message.MessageTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderListTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Service
public class PaymentListSiebelHandler {

    private static final String NOT_FOUND_MESSAGE = "Не найдено операций за период";
    private static final String PAYER_ACCOUNT_IS_EMPTY_MESSAGE = "PayerAccount is empty";
    private static final String ERROR_RESULT_CODE = "0099";
    private static final String SUCCESS_RESULT_CODE = "0";
    private static final String NOT_FOUND_RESULT_CODE = "0010";
    private final List<Predicate<PaymentEntity>> filters = new ArrayList<>();
    private static final List<String> APPROPRIATE_STATUSES = List.of(
            DocumentStatus.DFM_PROCESSING.getValue(),
            DocumentStatus.REJECTED.getValue(),
            DocumentStatus.REVIEW.getValue(),
            DocumentStatus.RECALLED.getValue(),
            DocumentStatus.WAIT.getValue(), DocumentStatus.SIGNED.getValue());

    private final Predicate<PaymentEntity> rejectedIfBisDocumentIdIsEmpty = (it ->
            !(DocumentStatus.REJECTED.toString().equals(it.getStatus()))
                    || DocumentStatus.REJECTED.toString().equals(it.getStatus())
                    && (it.getBisDocumentId() == null
                                    || it.getBisDocumentId().isEmpty()));

    @PostConstruct
    public void init() {
        filters.add(rejectedIfBisDocumentIdIsEmpty);
    }

    @Autowired
    private PaymentEntityRepository paymentEntityRepository;
    @Autowired
    private AuditService auditService;
    @Autowired
    private DocumentConverter documentConverter;

    public MessageTypeEsb handleWithResult(MessageTypeEsb messageTypeEsb) {
        var response = new MessageTypeEsb()
                .withMessageBody(new MessageTypeEsb.MessageBody()
                        .withGetPaymentListResponse(new GetPaymentListResponseTypeEsb()));
        var account = StringUtils.EMPTY;
        Date start = null;
        Date end = null;

        try {
            var paymentListRequestTypeEsb = messageTypeEsb.getMessageBody().getGetPaymentListRequest();
            var messageInfo = messageTypeEsb.getMessageInfo();

            account = Optional.ofNullable(paymentListRequestTypeEsb)
                    .map(GetPaymentListRequestTypeEsb::getPaymentOrder)
                    .map(PaymentOrderTypeEsb::getPayer)
                    .map(RequisiteTypeEsb::getNumber)
                    .map(AccountNumberTypeEsb::getAccountNumber20Digit)
                    .orElse(null);

            start = Optional.ofNullable(paymentListRequestTypeEsb)
                    .map(GetPaymentListRequestTypeEsb::getReportPeriod)
                    .map(DatePeriodTypeEsb::getStartDate).orElse(new Date());
            end = Optional.ofNullable(paymentListRequestTypeEsb)
                    .map(GetPaymentListRequestTypeEsb::getReportPeriod)
                    .map(DatePeriodTypeEsb::getEndDate).orElse(new Date());


            if (account == null) {
                auditService.sendEventAsync(new EventDTO()
                        .stage(SENT_PAYMENT_LIST_SIEBEL_STAGE)
                        .message(PAYER_ACCOUNT_IS_EMPTY_MESSAGE));
                return response.withMessageInfo(messageInfo.withResultInfo(
                        new ResultInfoTypeEsb()
                                .withCode(ERROR_RESULT_CODE)
                                .withMessage(PAYER_ACCOUNT_IS_EMPTY_MESSAGE)));
            }

            Set<PaymentEntity> paymentEntitySet = paymentEntityRepository
                    .findAllBySignDateBetweenAndPayerAccountAndStatusInAndNumberIsNotNull(
                            start.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime(),
                            end.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().plusDays(1),
                            account, APPROPRIATE_STATUSES)
                    .stream()
                    .filter(filters.stream().reduce(x -> true, Predicate::and))
                    .collect(Collectors.toSet());

            var eventMessage = String.format("по счету %s за период %s - %s", account, start.toString(), end.toString());
            if (paymentEntitySet.isEmpty()) {
                auditService.sendEventAsync(new EventDTO()
                        .stage(SENT_PAYMENT_LIST_SIEBEL_STAGE)
                        .message(eventMessage));
                return response.withMessageInfo(messageInfo.withResultInfo(
                        new ResultInfoTypeEsb()
                                .withCode(NOT_FOUND_RESULT_CODE)
                                .withMessage(NOT_FOUND_MESSAGE)));
            }

            auditService.sendEventAsync(new EventDTO()
                    .stage(SENT_PAYMENT_LIST_SIEBEL_STAGE)
                    .message(eventMessage));

            return response.withMessageInfo(messageInfo.withResultInfo(new ResultInfoTypeEsb()
                    .withCode(SUCCESS_RESULT_CODE)))
                    .withMessageBody(new MessageTypeEsb.MessageBody().withGetPaymentListResponse(
                            new GetPaymentListResponseTypeEsb()
                                    .withPaymentOrderList(
                                            new PaymentOrderListTypeEsb()
                                                    .withPaymentOrder(paymentEntitySet.stream()
                                                            .map(documentConverter::toEsbPayment).collect(Collectors.toList())))
                    ));
        } catch (Exception e) {
            auditService.sendEvent(new EventDTO().stage(SENT_PAYMENT_LIST_SIEBEL_STAGE)
                    .errorMessage(String.format("по счету %s за период %s - %s", account,
                            start != null ? start.toString() : StringUtils.EMPTY,
                            end != null ? end.toString() : StringUtils.EMPTY)));
            throw e;
        }
    }
}
