package ru.rosbank.paymentapp.service.exceptions;


public class DocumentExecutionDateException extends ValidationException {

    public DocumentExecutionDateException(String msg) {
        super(msg);
    }

    public DocumentExecutionDateException(String msg, Throwable t) {
        super(msg, t);
    }
}
