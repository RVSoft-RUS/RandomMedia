package ru.rosbank.paymentapp.service.dfm;

public enum DfmBisStatus {
    PROCESSING,
    COMPLETED,
    ERROR;

    public String value() {
        return name();
    }

    public static DfmBisStatus fromValue(String v) {
        return valueOf(v);
    }
}
