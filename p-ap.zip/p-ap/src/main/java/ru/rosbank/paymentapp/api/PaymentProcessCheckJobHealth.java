package ru.rosbank.paymentapp.api;

import java.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;
import ru.rosbank.paymentapp.schedule.PaymentProcessCheckJob;
import ru.rosbank.paymentapp.util.MXHelper;

@Slf4j
@Component
public class PaymentProcessCheckJobHealth implements HealthIndicator {
    @Value("${scheduler.max-life.minutes:10}")
    private int maxLifeMinutes;

    @Override
    public Health health() {
        if (PaymentProcessCheckJob.startDateTime != null
                && LocalDateTime.now().isAfter(PaymentProcessCheckJob.startDateTime.plusMinutes(maxLifeMinutes))) {
            String dump = MXHelper.getFormattedThreadDump(true, true);
            log.error("Завис процессинг документов. Рестарт. Дамп потоков: \n{}", dump);
            return Health.down().build();
        }
        return Health.up().build();
    }

}