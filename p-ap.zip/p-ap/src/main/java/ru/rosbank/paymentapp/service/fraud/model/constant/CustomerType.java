package ru.rosbank.paymentapp.service.fraud.model.constant;

public enum CustomerType {

    PHYSICAL("physical"),
    LEGAL("legal");
    private String text;

    CustomerType(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
