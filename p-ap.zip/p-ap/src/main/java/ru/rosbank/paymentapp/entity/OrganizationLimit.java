package ru.rosbank.paymentapp.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Summary.
 * @author rb068869
 */
@Entity(name = "organization_limit")
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class OrganizationLimit implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;
    private String status;
    private String type;
    private String organizationId;
    private BigDecimal limitSum;
    private int limitPeriod;
    private String paymentType;
    private String currency;

    public enum Status {
        ACTIVE,
        INACTIVE
    }

    public enum Type {
        ONE_OPERATION_LIMIT,
        LIMIT_FOR_PERIOD
    }

    public enum PaymentType {
        ALL,
        INNER_OWN_ACCOUNT,
        FAVOR_OF_BANK,
        OTHER
    }
}
