package ru.rosbank.paymentapp.dto;

import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 *                 Расходный кассовый ордер.
 *
 *              <p>valueDate - Дата валютирования;
 *                 orderStampSinger - Составитель;
 *                 content - Содержание операции, наименование, номер и дата документа,
 *                 на основании которого составлен мемориальный ордер;
 *                 ITMTransId - Референс;
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class AccountCashWarrantDocumentDto extends AbstractDocumentDto {

    protected Date valueDate;
    protected String orderStampSinger;
    protected String content;
    protected String itmTransId;
    protected BankInfoDto processedBy;

}
