package ru.rosbank.paymentapp.service.fraud;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.fraud.model.resolution.Message;

@Slf4j
@Service
@Profile("!unit_test")
@RequiredArgsConstructor
public class Receiver {

    private final AntifraudPaymentService antifraudPaymentService;

    @KafkaListener(topics = "${anti-fraud.resolution.payment-topic-name}",
            autoStartup = "${anti-fraud.resolution.respect}",
            containerFactory = "antifraudKafkaListenerContainerFactory")
    public void listenPaymentTopic(Message message) {
        log.info("Резолюция антифрода по платежу: {}", message);
        antifraudPaymentService.consumeResolution(message);
    }

}
