package ru.rosbank.paymentapp.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.mapper.BisIdMapper;
import ru.rosbank.paymentapp.service.exceptions.GetAccountBalanceException;
import ru.rosbank.platform.client.accountapp.api.AccountAppApi;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.esb.model.account.AccountAmountTypeEsb;
import ru.rosbank.platform.esb.model.account.AccountTypeEsb;
import ru.rosbank.platform.esb.model.common.MoneyAmountTypeEsb;
import ru.rosbank.platform.esb.model.getcustomeraccountlist.GetCustomerAccountListResponseTypeEsb;

@Slf4j
@RequiredArgsConstructor
@Service
public class AccountService {

    private final EsbService esbService;
    private final AccountAppApi accountAppApi;
    private final BisIdMapper bisIdMapper;

    public BigDecimal getAccountBalance(PaymentEntity document) throws Exception {

        List<GetCustomerAccountListResponseTypeEsb.GetCustomerAccountListResponse> accListResp =
                esbService.getCustomerAccountList(document).getGetCustomerAccountListResponse();

        return accListResp.stream()
                .map(GetCustomerAccountListResponseTypeEsb.GetCustomerAccountListResponse::getAccount)
                .flatMap(Collection::stream)
                .filter(a -> document.getPayerAccount().equals(a.getAccountNumber().getAccountNumber20Digit()))
                .map(AccountTypeEsb::getAccountAmount)
                .map(AccountAmountTypeEsb::getCurrentlyAmount)
                .map(MoneyAmountTypeEsb::getAmount).findFirst()
                .orElseThrow(() -> new GetAccountBalanceException(
                        "Не удалось получить баланс по счёту " + document.getPayerAccount()));

    }

    public List<AccountDTO> getAccountList(String crmId,
                                           List<ru.rosbank.platform.client.organizationapp.model.BisIdDTO> bisIdDTO) {
        try {
            return Objects.requireNonNull(accountAppApi.organizationAccountsGet(crmId,
                            bisIdMapper.organizationListToAccountList(bisIdDTO), false)
                    .getBody()).getAccounts();
        } catch (Exception e) {
            log.error("Ошибка получения списка счетов {}:{}", crmId, bisIdDTO, e);
            return Collections.emptyList();
        }
    }

    public BisIdDTO getBisId(String number) {
        try {
            return accountAppApi.idGet(number).getBody().getBisId();
        } catch (Exception e) {
            log.error("Не удалось получить аккаунт по номеру счета: " + number, e);
            return new BisIdDTO();
        }
    }
}
