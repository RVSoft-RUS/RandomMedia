package ru.rosbank.paymentapp.service.phub;

import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusFinal;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusMiddle;
import ru.rosbank.paymentapp.converters.DocumentStatusMessageDtoConverter;
import ru.rosbank.paymentapp.service.PaymentService;


@Slf4j
@Service
@Profile("!unit_test")
@RequiredArgsConstructor
@ConditionalOnProperty(name = "phub.enabled", havingValue = "true")
public class PaymentHubConsumer {
    private final PaymentService paymentService;
    private final DocumentStatusMessageDtoConverter converter;

    @KafkaListener(
            id = "${phub.kafka.topics.proc-status}",
            idIsGroup = false,
            topics = "${phub.kafka.topics.proc-status}",
            containerFactory = "paymentHubKafkaListenerContainerFactory",
            concurrency = "${kafka.configs.phub.listener.concurrency:1}")
    public void consumeProcStatus(DocumentStatusMiddle message) {
        log.debug("DocumentStatusMiddle message from PHUB.SendDocumentPaymentProcStatus = {}.", message);
        if (Objects.nonNull(message.getInputSystem()) && paymentService.isValidInputSystem(message)) {
            paymentService.processDocumentStatusMessage(converter.convert(message));
        }
    }

    @KafkaListener(
            id = "${phub.kafka.topics.finish-status}",
            idIsGroup = false,
            topics = "${phub.kafka.topics.finish-status}",
            containerFactory = "paymentHubKafkaListenerContainerFactory",
            concurrency = "${kafka.configs.phub.listener.concurrency:1}")
    public void consumeFinishStatus(DocumentStatusFinal message) {
        log.debug("DocumentStatusFinal message from PHUB.SendDocumentPaymentFinishStatus = {}.", message);
        if (Objects.nonNull(message.getInputSystem()) && paymentService.isValidInputSystem(message)) {
            paymentService.processDocumentStatusMessage(converter.convert(message));
        }
    }
}
