package ru.rosbank.paymentapp.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Summary.
 * @author rb068869
 */
@Entity(name = "document_rectification_new")
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DocumentRectification implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;
    private Date created;
    private String dboProId;
    private String documentId;
    private String payerAccount;

    private String status;

    private String payeeName;
    private String payeeAccount;
    private String payeeInn;
    private String payeeKpp;
    private String purpose;
    private String paymentBasis;
    private String basisDocumentNumber;
    private String basisDocumentCreated;
    private String taxPeriod;
    private String uin;
    private String kbk;
    private String oktmo;

    public enum DocumentRectificationStatus {
        CREATED,
        ACTIVE,
    }
}
