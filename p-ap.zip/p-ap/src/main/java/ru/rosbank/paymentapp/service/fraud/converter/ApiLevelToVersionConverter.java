package ru.rosbank.paymentapp.service.fraud.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class ApiLevelToVersionConverter {
    @Value("${anti-fraud.api-level}")
    String jsonValues;

    Map<String, String> values = null;

    public String getVersion(String apiLevel) {
        if (values == null) {
            values = getMap();
        }
        if (values == null || apiLevel == null) {
            return null;
        }

        return values.get(apiLevel);
    }

    private Map<String, String> getMap() {
        try {
            return new ObjectMapper().readValue(jsonValues, HashMap.class);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }

}
