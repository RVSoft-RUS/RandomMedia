package ru.rosbank.paymentapp.service.exceptions;


public class DocumentNotSignedException extends RuntimeException {

    public DocumentNotSignedException(String msg) {
        super(msg);
    }

}
