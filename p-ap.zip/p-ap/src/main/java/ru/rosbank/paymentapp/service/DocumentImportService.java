package ru.rosbank.paymentapp.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.converters.ImportedDocumentDtoToEntityConverter;
import ru.rosbank.paymentapp.converters.ImportedDocumentToPaymentConverter;
import ru.rosbank.paymentapp.entity.ImportedDocumentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.ImportedDocumentRepository;
import ru.rosbank.paymentapp.service.exceptions.CrmNotFoundException;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedBatchResultDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;
import ru.rosbank.platform.server.paymentapp.model.NextDocumentInfo;


/**
 * DocumentImportService.
 * @author rb068869
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentImportService {

    private static final String INVALID_PAYMENTS_COUNT_TEXT = "Нам не удалось сохранить ";
    private static final String INVALID_PAYMENTS_COUNT_TEXT_REASON = " документов, так как они с идентичными номерами."
            + " Такое бывает, если вы уже сохраняли или подписывали хотя бы один платёж с таким же номером и датой.";
    private static final String CLIENT_NOT_FOUND = "Клиент не найден dboProId: ";

    @Value("${import_document.process_batch.lock_period}")
    private int lockPeriod;

    private final ImportedDocumentRepository importedDocumentRepository;

    private final ImportedDocumentDtoToEntityConverter importedDocumentDtoToEntityConverter;
    private final ImportedDocumentToPaymentConverter importedDocumentToPaymentConverter;
    private final PaymentService paymentService;
    private final SharedLock sharedLock;
    private final AccountService accountService;
    private final UserService userService;
    private final OrganizationService organizationService;

    public String createBatch(String dboProId, List<ImportedDocumentDTO> importedDocumentDTO) {
        String batchId = UUID.randomUUID().toString();
        ClientDTO client = userService.getClientByDboProId(dboProId).orElseThrow(() ->
                new RuntimeException(CLIENT_NOT_FOUND + dboProId));

        importedDocumentRepository.saveAll(importedDocumentDTO.stream().map(i ->
                importedDocumentDtoToEntityConverter.convert(i, client, batchId)).collect(Collectors.toList()));

        return batchId;
    }


    public void deleteImportedDocument(String id, String dboProId) {
        Long idL = Long.valueOf(id);
        ImportedDocumentEntity importedDocumentEntity = importedDocumentRepository.findById(idL).orElseThrow(() ->
                new RuntimeException("Импортируемый документ не найден ID: " + id));
        ClientDTO client = userService.getClientByDboProId(dboProId).orElseThrow(() ->
                new RuntimeException(CLIENT_NOT_FOUND + dboProId));
        if (importedDocumentEntity.getClientId().equals(client.getLegacyId())) {
            importedDocumentRepository.deleteById(idL);
            return;
        }
        throw new RuntimeException("Попытка удалить импортируемый документ другого клиента");
    }


    public List<ImportedDocumentDTO> getImportedDocuments(String id, String dboProId, String status) {
        ClientDTO client = userService.getClientByDboProId(dboProId).orElseThrow(() ->
                new RuntimeException(CLIENT_NOT_FOUND + dboProId));

        if ("ALL".equals(status)) {
            return importedDocumentRepository.findByClientIdAndBatch(client.getLegacyId(), id).stream()
                    .map(importedDocumentDtoToEntityConverter::convertBack).collect(Collectors.toList());
        } else {
            return importedDocumentRepository.findByClientIdAndBatchAndStatus(client.getLegacyId(), id, status).stream()
                    .map(importedDocumentDtoToEntityConverter::convertBack).collect(Collectors.toList());
        }
    }

    public ImportedBatchResultDTO processBatch(String id, String dboProId) {
        ClientDTO client = userService.getClientByDboProId(dboProId).orElseThrow(() ->
                new RuntimeException(CLIENT_NOT_FOUND + dboProId));

        ImportedBatchResultDTO result = new ImportedBatchResultDTO();
        result.invalidPaymentsCount(0).paymentsCount(0).payrollPaymentsCount(0);
        List<OrganizationDTO> organizations = organizationService.rootGet(dboProId);
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        List<AccountDTO> accounts = new ArrayList<>();
        organizations.forEach(o -> accounts.addAll(accountService.getAccountList(o.getCrmId(), o.getBisIds())));
        accounts.forEach(a -> accountsMap.put(a.getNumber(), a));
        String key = "ImportDocBatch_" + id;
        if (sharedLock.lock(key, lockPeriod)) {
            List<ImportedDocumentEntity> importedDocumentList = importedDocumentRepository.findByClientIdAndBatchAndStatus(
                    client.getLegacyId(), id, ImportedDocumentDTO.StatusEnum.VALID.getValue());

            for (ImportedDocumentEntity importedDocument : importedDocumentList) {
                try {
                    saveNewDocument(importedDocument, organizations, accountsMap);
                    if (ImportedDocumentDTO.DocTypeEnum.DP.getValue().equals(importedDocument.getDocType())) {
                        result.setPayrollPaymentsCount(result.getPayrollPaymentsCount() + 1);
                    } else {
                        result.setPaymentsCount(result.getPaymentsCount() + 1);
                    }
                } catch (Exception e) {
                    result.setInvalidPaymentsCount(result.getInvalidPaymentsCount() + 1);

                    log.error(e.getMessage(), e);
                }
            }
            if (result.getInvalidPaymentsCount() > 0) {
                result.setErrorMessage(INVALID_PAYMENTS_COUNT_TEXT + result.getInvalidPaymentsCount()
                        + INVALID_PAYMENTS_COUNT_TEXT_REASON);
            }
            importedDocumentList.stream()
                    .findFirst()
                    .ifPresent(importedDocument -> result.setAccount(importedDocument.getPayerAccount()));
            result.setId(id);
            sharedLock.release(key);
            return result;
        } else {
            log.info("Не удалось захватить управление мьютексом");
        }
        throw new RuntimeException("Не удалось захватить управление мьютексом");
    }

    protected void saveNewDocument(ImportedDocumentEntity importedDocument, List<OrganizationDTO> organizations,
                                   Map<String, AccountDTO> accountsMap) throws CrmNotFoundException {
        PaymentEntity newDoc = new PaymentEntity();
        newDoc = importedDocumentToPaymentConverter.convert(importedDocument, newDoc);
        newDoc.setStatus(DocumentStatus.CREATED.name());
        NextDocumentInfo documentInfo = paymentService.getNextInfo(List.of(importedDocument.getPayerAccount()));
        if (StringUtils.isBlank(newDoc.getNumber())) {
            newDoc.setNumber(documentInfo.getNumber());
        }

        LocalDateTime currentTime = LocalDateTime.now();
        if (importedDocument.getDocumentDate().isAfter(currentTime)) {
            newDoc.setDate(currentTime);
            newDoc.setExecutionDate(importedDocument.getDocumentDate());
        } else {
            newDoc.setDate(importedDocument.getDocumentDate());
            newDoc.setExecutionDate(null);
        }

        BisIdDTO bisId = accountsMap.get(importedDocument.getPayerAccount()).getBisId();
        if (bisId == null) {
            throw new CrmNotFoundException("accountsNotFound: " + importedDocument.getPayerAccount());
        }
        newDoc.setOrganizationBisId(bisId.getId());
        newDoc.setOrganizationBisBranch(bisId.getBranch());
        newDoc.setOrganizationCrmId(organizations.stream().filter(o -> o.getBisIds().stream()
                .anyMatch(b -> bisId.getId().equals(b.getId()))).findFirst()
                .orElseThrow(() -> new CrmNotFoundException("CrmNotFound: " + organizations)).getCrmId());
        PaymentEntity persisted = paymentService.createDocument(newDoc);

        importedDocument.setDocument(persisted);
        importedDocumentRepository.save(importedDocument);
    }


    public ImportedDocumentDTO updateImportedDocument(ImportedDocumentDTO importedDocument, String dboProId) {
        Long idL = Long.valueOf(importedDocument.getId());
        ImportedDocumentEntity importedDocumentEntity = importedDocumentRepository.findById(idL).orElseThrow(() ->
                new RuntimeException("Импортируемый документ не найден ID: " + idL));

        ClientDTO client = userService.getClientByDboProId(dboProId).orElseThrow(() ->
                new RuntimeException(CLIENT_NOT_FOUND + dboProId));
        if (importedDocumentEntity.getClientId().equals(client.getLegacyId())) {
            return importedDocumentDtoToEntityConverter.convertBack(importedDocumentRepository.save(
                    importedDocumentDtoToEntityConverter.convert(importedDocument, client, importedDocument.getBatchId())));

        }
        throw new RuntimeException("Попытка сохранить импортируемый документ другого клиента");
    }

}
