package ru.rosbank.paymentapp.dto.pricing;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CustomerIdsDTO {
    private String id;
    private String branch;
}
