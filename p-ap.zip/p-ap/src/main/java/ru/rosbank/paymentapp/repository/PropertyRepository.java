package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.Property;

@Repository
public interface PropertyRepository extends CrudRepository<Property, Long> {

    Optional<Property> findByPropertyKey(String key);

}
