package ru.rosbank.paymentapp.mapper;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.client.portalpro.model.AppRequestDfmSaveAlertsRequestAlertsInnerDTO;


@Mapper(componentModel = "spring")
public interface DfmSaveAlertsRequestMapper {
    DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Mapping(source = "signDate", target = "signDate", qualifiedByName = "toDate")
    AppRequestDfmSaveAlertsRequestAlertsInnerDTO toAlert(PaymentEntity payment);

    @Named("toDate")
    default String toDate(LocalDateTime value) {
        if (value == null) {
            return null;
        }
        return DATE_TIME_FORMATTER.format(value);
    }

}
