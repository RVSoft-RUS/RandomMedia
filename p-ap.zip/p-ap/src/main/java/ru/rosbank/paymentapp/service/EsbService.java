package ru.rosbank.paymentapp.service;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.esb.support.BankProcessingException;
import ru.rosbank.paymentapp.esb.support.GetCustomerAccountListRequestBuilder;
import ru.rosbank.platform.esb.exception.EsbTimeoutException;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.DatePeriodTypeEsb;
import ru.rosbank.platform.esb.model.common.MessageInfoTypeEsb;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderRequestTypeEsb;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderResponseTypeEsb;
import ru.rosbank.platform.esb.model.getcustomeraccountlist.GetCustomerAccountListRequestTypeEsb;
import ru.rosbank.platform.esb.model.getcustomeraccountlist.GetCustomerAccountListResponseTypeEsb;
import ru.rosbank.platform.esb.model.getpaymentlist.GetPaymentListRequestTypeEsb;
import ru.rosbank.platform.esb.model.getpaymentlist.GetPaymentListResponseTypeEsb;
import ru.rosbank.platform.esb.model.message.MessageTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderListTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.esb.model.reversepaymentorder.ReversePaymentOrderRequestTypeEsb;
import ru.rosbank.platform.esb.model.reversepaymentorder.ReversePaymentOrderResponseTypeEsb;
import ru.rosbank.platform.esb.model.senddbomatrix.SendDBOMatrixRequestTypeEsb;
import ru.rosbank.platform.esb.model.senddbomatrix.SendDBOMatrixResponseTypeEsb;
import ru.rosbank.platform.esb.model.sendsms.SendSMSRequestTypeEsb;
import ru.rosbank.platform.esb.service.EsbClient;
import ru.rosbank.platform.esb.service.FaultCodeException;
import ru.rosbank.platform.esb.support.EsbRequestTypeEnum;

@RequiredArgsConstructor
@Service
public class EsbService {
    private static final Pattern BIS_RESPONSE_CODE_PATTERN = Pattern.compile("\\d{4}");
    private static final List<String> DEFAULT_ESB_PROCESSED_CODES = Lists.newArrayList("0", "3", "5", "6", "10", "11",
            "23", "30", "333", "601", "602", "603", "604", "605", "606", "607", "608", "609", "610", "611", "612");

    private final EsbClient esbClient;

    public SendDBOMatrixResponseTypeEsb sendDBOMatrix(SendDBOMatrixRequestTypeEsb request) {
        return (SendDBOMatrixResponseTypeEsb) processRequest(request);
    }

    public void produceGetPaymentList(MessageTypeEsb messageTypeEsb) {
        processEsbResponse(messageTypeEsb,
                EsbRequestTypeEnum.GET_PAYMENT_LIST_RESP);
    }

    public List<PaymentOrderTypeEsb> getPaymentList(String accountNumber13Digit, String branch, Date startDate, Date endDate) {
        GetPaymentListRequestTypeEsb requestTypeEsb = new GetPaymentListRequestTypeEsb();
        PaymentOrderTypeEsb paymentOrderTypeEsb = new PaymentOrderTypeEsb().withBranch(branch);
        paymentOrderTypeEsb.setPayer(new RequisiteTypeEsb().withNumber(
                new AccountNumberTypeEsb().withAccountNumber13Digit(accountNumber13Digit)));
        requestTypeEsb.setPaymentOrder(paymentOrderTypeEsb);
        DatePeriodTypeEsb datePeriodTypeEsb = new DatePeriodTypeEsb().withStartDate(startDate).withEndDate(endDate);
        requestTypeEsb.setReportPeriod(datePeriodTypeEsb);

        GetPaymentListResponseTypeEsb responseTypeEsb = (GetPaymentListResponseTypeEsb) processRequest(requestTypeEsb);

        return Optional.ofNullable(responseTypeEsb)
                .map(GetPaymentListResponseTypeEsb::getPaymentOrderList)
                .map(PaymentOrderListTypeEsb::getPaymentOrder)
                .orElse(new ArrayList<>());
    }

    public CreatePaymentOrderResponseTypeEsb createPaymentOrder(CreatePaymentOrderRequestTypeEsb request) {
        return (CreatePaymentOrderResponseTypeEsb) processRequest(request);
    }

    public void sendSms(SendSMSRequestTypeEsb request) {
        requestWithoutResponse(request);
    }

    public GetCustomerAccountListResponseTypeEsb getCustomerAccountList(PaymentEntity payment) throws Exception {

        GetCustomerAccountListRequestTypeEsb request =
                new GetCustomerAccountListRequestBuilder()
                        .cliendId(payment.getOrganizationBisId())
                        .branch(payment.getOrganizationBisBranch())
                        .build();

        return (GetCustomerAccountListResponseTypeEsb) esbClient.request(request);
    }

    public ReversePaymentOrderResponseTypeEsb reversePaymentOrder(ReversePaymentOrderRequestTypeEsb request) {
        return (ReversePaymentOrderResponseTypeEsb) processRequest(request);
    }

    private Object processRequest(final Object requestPayload) {
        Object response = null;
        try {
            response = esbClient.request(requestPayload);
        } catch (FaultCodeException ex) {
            MessageInfoTypeEsb responseMessageInfo = ex.getMessageInfoTypeEsb();
            if (defaultEsbErrors().apply(responseMessageInfo.getResultInfo().getCode())) {
                throw new BankProcessingException(responseMessageInfo.getResultInfo().getCode(),
                        responseMessageInfo.getResultInfo().getMessage());
            }
        } catch (EsbTimeoutException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
        return response;
    }

    private void processEsbResponse(MessageTypeEsb messageTypeEsb, EsbRequestTypeEnum typeEnum) {
        try {
            esbClient.response(messageTypeEsb, typeEnum);
        } catch (FaultCodeException ex) {
            MessageInfoTypeEsb responseMessageInfo = ex.getMessageInfoTypeEsb();
            if (defaultEsbErrors().apply(responseMessageInfo.getResultInfo().getCode())) {
                throw new BankProcessingException(responseMessageInfo.getResultInfo().getMessage());
            }
        } catch (EsbTimeoutException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    private void requestWithoutResponse(final Object requestPayload) {
        try {
            esbClient.requestWithoutResponse(requestPayload);
        } catch (FaultCodeException ex) {
            MessageInfoTypeEsb responseMessageInfo = ex.getMessageInfoTypeEsb();
            if (defaultEsbErrors().apply(responseMessageInfo.getResultInfo().getCode())) {
                throw new BankProcessingException(responseMessageInfo.getResultInfo().getMessage());
            }
        } catch (EsbTimeoutException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }

    private static Function<String, Boolean> defaultEsbErrors() {
        return errorCode ->
                BIS_RESPONSE_CODE_PATTERN.matcher(errorCode).matches() || DEFAULT_ESB_PROCESSED_CODES.contains(errorCode);
    }

}
