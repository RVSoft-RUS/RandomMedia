package ru.rosbank.paymentapp.entity;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity(name = "imported_document_new")
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(exclude = "errorMessage", callSuper = true)
public class ImportedDocumentEntity extends ImportedDocumentBase {
    private String errorMessage;
    private LocalDateTime documentDate;
}
