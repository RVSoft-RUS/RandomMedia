package ru.rosbank.paymentapp.service.validators;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.exceptions.DocumentContentDifferentException;

@RequiredArgsConstructor
@Service
public class DocumentValidator {

    private final DocumentContentValidator documentContentValidator;
    private final DocumentDateOnSendToEsbValidator documentDateOnSendToEsbValidator;


    public void validateDocumentContent(PaymentEntity document) throws DocumentContentDifferentException {
        documentContentValidator.validate(document);
        documentDateOnSendToEsbValidator.validate(document);
    }

}
