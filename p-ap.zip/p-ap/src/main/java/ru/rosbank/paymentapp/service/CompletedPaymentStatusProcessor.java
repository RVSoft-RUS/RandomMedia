package ru.rosbank.paymentapp.service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.DocumentRecallRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Slf4j
@Service
@RequiredArgsConstructor
public class CompletedPaymentStatusProcessor {

    @Value("${schedulers.completed-payment-status-job.count-minutes}")
    private Integer countMinutes;

    private final PaymentEntityRepository paymentEntityRepository;
    private final DocumentRecallRepository documentRecallRepository;
    private final StatementService statementService;

    public void process(List<PaymentEntity> paymentEntities) {
        try {
            var accountPaymentsMap = paymentEntities.stream()
                    .collect(Collectors.groupingBy(PaymentEntity::getPayerAccount));
            var now = OffsetDateTime.now();
            accountPaymentsMap.forEach((k, v) -> {
                var statement = statementService.getStatement(k, v.iterator().next().getOrganizationBisBranch(),
                        now.minusMinutes(countMinutes),
                        now);
                statement.ifPresent(accountStatementDTO ->
                        markDocumentsAsCompleted(
                                accountStatementDTO.getOperations().stream()
                                        .map(PaymentDTO::getId)
                                        .collect(Collectors.toList())));
            });

        } catch (Exception e) {
            log.error("Ошибка обновления статуса completed проведенных документов id", e);
        }
    }

    void markDocumentsAsCompleted(List<String> bisDocumentIds) {

        for (int i = 0; i < bisDocumentIds.size(); i++) {
            String bisId = bisDocumentIds.get(i);
            if (bisId.startsWith("Y01")) {
                String changedBisId = bisId.replace("Y01", "PP");
                changedBisId = changedBisId.substring(0, 8) + "-" + changedBisId.substring(8);
                bisDocumentIds.set(i, changedBisId);
            }
        }
        List<PaymentEntity> paymentEntities = paymentEntityRepository.findAllByBisDocumentIdInAndStatusNot(
                bisDocumentIds, DocumentStatus.COMPLETED.toString());
        for (PaymentEntity payment : paymentEntities) {
            payment.setStatus(Payment.StatusEnum.COMPLETED.toString());
            if (payment.getDocumentRecallEntity() != null) {
                var recallEntity = payment.getDocumentRecallEntity();
                recallEntity.setStatus(payment.getStatus());
                documentRecallRepository.save(recallEntity);
            }
            paymentEntityRepository.save(payment);
        }
    }
}
