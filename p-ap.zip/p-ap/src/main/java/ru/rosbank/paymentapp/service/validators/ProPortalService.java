package ru.rosbank.paymentapp.service.validators;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.entity.CurrencyControlEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.CurrencyControlRepository;
import ru.rosbank.platform.client.fileapp.api.FileAppApi;
import ru.rosbank.platform.client.fileapp.model.ElibCategoryDTO;
import ru.rosbank.platform.client.portalpro.api.PortalProApiApi;
import ru.rosbank.platform.client.portalpro.model.FreestyleMessageDTO;
import ru.rosbank.platform.redis.SharedLock;

@Slf4j
@RequiredArgsConstructor
@Service
public class ProPortalService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProPortalService.class);
    @Autowired
    private PortalProApiApi portalProApiApi;
    @Autowired
    private FileAppApi fileAppApi;
    @Value("${elib.document-type}")
    private String documentType;
    @Autowired
    private CurrencyControlRepository currencyControlRepository;
    @Autowired
    private SharedLock sharedLock;
    @Value("${schedulers.currency-control-job.lock.period}")
    private int period;

    @Transactional
    public void sendCurrencyControlInfoToProPortal(PaymentEntity documentSrc) {
        Long id = documentSrc.getCurrencyControlEntity().getId();
        PaymentEntity document = currencyControlRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("unable to find currencycontrol entity by id: " + id)).getPaymentEntity();
        String currencyControlId = document.getCurrencyControlEntity().getId().toString();
        boolean lock = false;
        String lockKey = "CurrencyControl_" + currencyControlId;
        try {
            lock = sharedLock.lock(lockKey, period);
            if (lock) {
                CurrencyControlEntity currencyControl = document.getCurrencyControlEntity();
                Integer attempts = currencyControl.getAttemptsSentProPortal();
                currencyControl.setAttemptsSentProPortal(attempts == null
                        ? 1 : attempts + 1);
                if (currencyControl.getIsSentToProPortal() == null) {
                    currencyControl.setIsSentToProPortal(false);
                }
                currencyControlRepository.save(currencyControl);
                LOGGER.info("Попытка отправки документов по ВЭД [{}] в Про Портал № {}", currencyControlId,
                        currencyControl.getAttemptsSentProPortal());
                //Формируем запрос в Про Портал
                FreestyleMessageDTO freestyleMessageDTO = new FreestyleMessageDTO();
                String messageId = "999" + currencyControl.getId().toString();
                freestyleMessageDTO.setMessageId(Long.parseLong(messageId));
                freestyleMessageDTO.setCrmId(document.getOrganizationCrmId());
                freestyleMessageDTO.setMessageRule("CSKO_CURRENCY_CONTROL");
                freestyleMessageDTO.setMessageText(createMessageForProPortal(document));
                freestyleMessageDTO.setMessageSubject("Валютный контроль");
                //проверяем, есть ли прикрепленные файлы
                if (currencyControl.getFileInfoEntityList() == null
                        || currencyControl.getFileInfoEntityList().isEmpty()) {
                    freestyleMessageDTO.setFile(false);
                } else {
                    //если есть файлы без елиб ид - то оправляем в елиб
                    currencyControl.getFileInfoEntityList()
                            .stream()
                            .map(fileInfoEntity -> fileAppApi.fileIdGet(fileInfoEntity.getFileId()).getBody())
                            .filter(fileInfoDTO -> fileInfoDTO.getElibId() == null)
                            .forEach(fileInfoDTO -> fileAppApi.fileIdElibPost(fileInfoDTO.getId(),
                                    new ElibCategoryDTO().id(documentType)));
                    LOGGER.info("Все файлы по ВЭД id= " + currencyControl.getId() + " успешно загружены в Elib");

                    //ищем все файлы по этой операции и добавляем их ид в запрос
                    List<String> fileElibIdList = currencyControl.getFileInfoEntityList()
                            .stream()
                            .map(fileInfoEntity -> fileAppApi.fileIdGet(fileInfoEntity.getFileId()).getBody().getElibId())
                            .collect(Collectors.toList());

                    freestyleMessageDTO.setFile(true);
                    freestyleMessageDTO.setElib(fileElibIdList);
                }

                LOGGER.info("CurrencyСontrol request to ProPortal: {}", freestyleMessageDTO);
                portalProApiApi.freestyleMessageElibPost(freestyleMessageDTO);
                LOGGER.info("Отправка инфо по валютному контролю успешно завершена, message_id = {}", messageId);
                currencyControl.setIsSentToProPortal(true);
                currencyControlRepository.save(currencyControl);
                sharedLock.release(lockKey);
            } else {
                log.info("Не удалось захватить управление CurrencyControl {}", currencyControlId);
            }
        } catch (Exception e) {
            if (lock) {
                sharedLock.release(lockKey);
            }
            log.error("Не удалось отправить документы по ВЭД № {} в Про Портал {}", currencyControlId, e.getMessage());
        }


    }

    private String createMessageForProPortal(PaymentEntity document) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter, true);
        String firstLine = "РМБ" + ". " + document.getOrganizationBisBranch() + ". " + document.getOrganizationBisId()
                + ". " + document.getOrganizationShortName();
        String secondLine = "Номер № " + document.getNumber() + " от " + document.getDate();
        CurrencyControlEntity currencyControl = document.getCurrencyControlEntity();
        String thirdLine = currencyControl.getIsSumContractLess200()
                ? "Подтверждаю, что сумма обязательств по договору с нерезидентом не превышает в эквиваленте 200 000 рублей"
                : "";
        String fourthLine = currencyControl.getComment();
        String fifthLine = currencyControl.getFullName() + " "
                + currencyControl.getPhone();

        printWriter.println(firstLine);
        printWriter.println(secondLine);
        printWriter.println(thirdLine);
        printWriter.println(fourthLine);
        printWriter.println(fifthLine);

        return stringWriter.toString();
    }
}
