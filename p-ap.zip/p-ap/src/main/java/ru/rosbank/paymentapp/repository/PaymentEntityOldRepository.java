package ru.rosbank.paymentapp.repository;

import org.springframework.data.repository.CrudRepository;
import ru.rosbank.paymentapp.entity.PaymentEntityOld;

public interface PaymentEntityOldRepository extends CrudRepository<PaymentEntityOld,Long> {

}
