package ru.rosbank.paymentapp.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.DocumentRectification;


/**
 * DocumentRectificationRepository.
 */
@Repository
public interface DocumentRectificationRepository extends JpaRepository<DocumentRectification, Long> {

    Optional<DocumentRectification> findDocumentRectificationByDocumentIdAndStatus(String bisDocumentId, String status);

    List<DocumentRectification> findAllDocumentRectificationByDocumentIdInAndStatus(List<String> documentsIds, String status);
}
