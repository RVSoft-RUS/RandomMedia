package ru.rosbank.paymentapp.client.pricing;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import ru.rosbank.paymentapp.dto.pricing.CommissionRequestDTO;
import ru.rosbank.paymentapp.dto.pricing.CommissionResponseDTO;
import ru.rosbank.paymentapp.dto.pricing.Response;

@FeignClient(value = "pricingRbspClient", url = "${rbsp.uri}/${rbsp.pricing.name}/${rbsp.pricing.version}")
public interface PricingRbspFeignClient {
    @RequestMapping(value = {"commission-calculation"}, produces = {"application/json"}, method = {RequestMethod.POST})
    Response<CommissionResponseDTO> getCommission(@RequestBody CommissionRequestDTO req);
}
