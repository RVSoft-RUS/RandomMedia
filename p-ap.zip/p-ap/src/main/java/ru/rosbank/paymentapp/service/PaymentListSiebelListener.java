package ru.rosbank.paymentapp.service;

import static ru.rosbank.paymentapp.service.audit.AuditService.SENT_PAYMENT_LIST_SIEBEL_STAGE;

import javax.jms.Message;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.audit.AuditService;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.esb.model.common.MessageInfoTypeEsb;
import ru.rosbank.platform.esb.model.common.ResultInfoTypeEsb;
import ru.rosbank.platform.esb.model.getpaymentlist.GetPaymentListResponseTypeEsb;
import ru.rosbank.platform.esb.model.message.MessageTypeEsb;
import ru.rosbank.platform.esb.support.InteractionSystem;
import ru.rosbank.platform.esb.support.InteractionType;
import ru.rosbank.platform.esb.support.JaxbEsbMessageConverter;
import ru.rosbank.platform.esb.support.MessageInfoBuilder;

@Service
@Slf4j
@Profile("!unit_test")
public class PaymentListSiebelListener {

    private static final String UNEXPECTED_EXCEPTION_MESSAGE = "Не удалось получить данные по техническим причинам";
    private static final String MESSAGE_INFO_IS_EMPTY_MESSAGE = "MessageInfo is empty";
    private static final String ERROR_RESULT_CODE = "0099";
    private static final String USER_LOGIN = "P777";

    @Autowired
    private JaxbEsbMessageConverter jaxbEsbMessageConverter;
    @Autowired
    private EsbService esbService;
    @Autowired
    private PaymentListSiebelHandler paymentListSiebelHandler;
    @Autowired
    private AuditService auditService;

    @JmsListener(destination = "${esb.dbo.queue.api}",
            containerFactory = "mqListenerContainerFactory",
            selector = "operationType='GetPaymentList'")
    public void receive(Message message) throws Exception {
        MessageInfoTypeEsb messageInfo = null;
        var response = new MessageTypeEsb()
                .withMessageBody(new MessageTypeEsb.MessageBody()
                        .withGetPaymentListResponse(new GetPaymentListResponseTypeEsb()));
        try {
            var request = (MessageTypeEsb) jaxbEsbMessageConverter.fromMessage(message);
            messageInfo = request.getMessageInfo();

            if (messageInfo == null) {
                auditService.sendEventAsync(new EventDTO()
                        .stage(SENT_PAYMENT_LIST_SIEBEL_STAGE)
                        .errorMessage(MESSAGE_INFO_IS_EMPTY_MESSAGE));

                esbService.produceGetPaymentList(response.withMessageInfo(new MessageInfoBuilder()
                        .resultCode(ERROR_RESULT_CODE)
                        .resultMessage(MESSAGE_INFO_IS_EMPTY_MESSAGE)
                        .interactionType(InteractionType.asynch)
                        .internalSystemNumber(message.getJMSCorrelationID())
                        .sourceSystem(InteractionSystem.CRM)
                        .targetSystem(InteractionSystem.PRO)
                        .build()));
                return;
            }

            esbService.produceGetPaymentList(paymentListSiebelHandler.handleWithResult(request));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            auditService.sendEventAsync(new EventDTO()
                    .errorMessage(UNEXPECTED_EXCEPTION_MESSAGE)
                    .stage(SENT_PAYMENT_LIST_SIEBEL_STAGE));

            if (messageInfo != null) {
                ResultInfoTypeEsb resultInfo = messageInfo.getResultInfo();
                resultInfo.setCode(ERROR_RESULT_CODE);
                resultInfo.setMessage(UNEXPECTED_EXCEPTION_MESSAGE);
                esbService.produceGetPaymentList(response.withMessageInfo(messageInfo));
            } else {
                esbService.produceGetPaymentList(response.withMessageInfo(new MessageInfoBuilder()
                        .resultCode(ERROR_RESULT_CODE)
                        .resultMessage(MESSAGE_INFO_IS_EMPTY_MESSAGE)
                        .interactionType(InteractionType.asynch)
                        .internalSystemNumber(message.getJMSCorrelationID())
                        .sourceSystem(InteractionSystem.CRM)
                        .userLogin(USER_LOGIN)
                        .targetSystem(InteractionSystem.PRO)
                        .build()));
            }
        }
    }
}
