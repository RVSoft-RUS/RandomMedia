package ru.rosbank.paymentapp.schedule;

import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.CurrencyControlEntity;
import ru.rosbank.paymentapp.repository.CurrencyControlRepository;
import ru.rosbank.paymentapp.service.validators.ProPortalService;


@Slf4j
@Service
@ConditionalOnProperty("schedulers.currency-control-job.enabled")
public class SendCurrencyControlToProPortalJob extends CronScheduledJob {
    @Autowired
    private ProPortalService proPortalService;
    @Autowired
    private CurrencyControlRepository currencyControlRepository;
    @Value("${schedulers.currency-control-job.attempts}")
    private int attempts;

    public SendCurrencyControlToProPortalJob(@Value("${schedulers.currency-control-job.enabled}") Boolean enable,
                                             @Value("${schedulers.currency-control-job.cron}") String cronExp) {
        super(enable, cronExp);
    }

    @Override
    public void run() {
        List<CurrencyControlEntity> currencyControlEntityList =
                currencyControlRepository
                        .findAllByIsSentToProPortalIsFalseAndAttemptsSentProPortalIsBetween(1, attempts - 1);
        currencyControlEntityList
                .forEach(currencyControlEntity -> {
                    try {
                        proPortalService
                                .sendCurrencyControlInfoToProPortal(Optional.ofNullable(currencyControlEntity.getPaymentEntity())
                                        .orElseThrow(() -> new RuntimeException("Невозможно найти связанный документ "
                                                + "для currencyControl с id: " + currencyControlEntity.getId())));
                    } catch (Exception e) {
                        log.error("Не удалось повторно отправить документы по ВЭД в Про Портал: " + e.getMessage(), e);
                    }
                });
    }
}
