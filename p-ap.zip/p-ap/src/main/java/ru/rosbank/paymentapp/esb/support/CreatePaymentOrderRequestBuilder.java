package ru.rosbank.paymentapp.esb.support;

import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderRequestTypeEsb;

public class CreatePaymentOrderRequestBuilder {
    public CreatePaymentOrderRequestTypeEsb build() {
        return new CreatePaymentOrderRequestTypeEsb();
    }
}