package ru.rosbank.paymentapp.entity;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Proxy;

//Imported from bs-app
@Entity
@Proxy(lazy = false)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeliveringResource implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private LocalDate created;
    private int attempts;
    private String phone;
    private String email;
    private String reference;
    private String resourceId;
    private String resourceName;
    private byte[] resourceContent;
    private String resourceContentType;

    public boolean isPhoneDelivering() {
        return this.phone != null && !this.phone.isEmpty();
    }

    public boolean isEmailDelivering() {
        return this.email != null && !this.email.isEmpty();
    }

}
