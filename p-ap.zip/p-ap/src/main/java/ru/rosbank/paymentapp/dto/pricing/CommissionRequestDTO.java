package ru.rosbank.paymentapp.dto.pricing;

import lombok.Data;

@Data
public class CommissionRequestDTO {
    private String siebelId;
    private CustomerIdsDTO customerIds;
    private String inputSystem;
    private String amount;
    private String currencyCode;
    private String purpose;
    private PayerDTO payer;
    private PayeeDTO payee;
}
