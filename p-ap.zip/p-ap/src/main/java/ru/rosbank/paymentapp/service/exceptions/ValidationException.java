package ru.rosbank.paymentapp.service.exceptions;


public class ValidationException extends BackendException {

    public ValidationException(String msg) {
        super(msg);
    }

    public ValidationException(String msg, Throwable t) {
        super(msg, t);
    }

}
