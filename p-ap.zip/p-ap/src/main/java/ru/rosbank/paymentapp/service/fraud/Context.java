package ru.rosbank.paymentapp.service.fraud;

public class Context {
    private String event;

    public Context(String event) {
        this.event = event;
    }
}