package ru.rosbank.paymentapp.dto;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 *                 Данные о плательщике/получателе
 *
 *              <p>account - номер счёта
 *                 name - имя
 *                 inn - ИНН
 *                 kpp - КПП
 *                 bank - информация о банке плательщика/получателя
 *
 * <p>Java class for Requisite complex type.
 */
@Data
@NoArgsConstructor
public class RequisiteDto implements Serializable {

    protected String account;
    protected String name;
    protected String inn;
    protected String kpp;
    protected BankInfoDto bank;

    public RequisiteDto withAccount(String account) {
        this.account = account;
        return this;
    }

    public RequisiteDto withName(String name) {
        this.name = name;
        return this;
    }

    public RequisiteDto withInn(String inn) {
        this.inn = inn;
        return this;
    }

    public RequisiteDto withKpp(String kpp) {
        this.kpp = kpp;
        return this;
    }

    public RequisiteDto withBank(BankInfoDto bank) {
        this.bank = bank;
        return this;
    }

}
