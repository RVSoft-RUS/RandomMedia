package ru.rosbank.paymentapp.dto;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 *                 Уточнение реквизитов платежа.
 *
 */
@Data
@NoArgsConstructor
public class DocumentRectificationDto implements Serializable {

    protected String documentId;
    protected Date created;
    protected String payeeName;
    protected String payeeAccount;
    protected String payeeInn;
    protected String payeeKpp;
    protected String purpose;
    protected String uin;
    protected String kbk;
    protected String oktmo;
    protected String paymentBasis;
    protected String taxPeriod;
    protected String basisDocumentNumber;
    protected String basisDocumentCreated;

}
