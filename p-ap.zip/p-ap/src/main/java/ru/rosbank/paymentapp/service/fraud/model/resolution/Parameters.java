package ru.rosbank.paymentapp.service.fraud.model.resolution;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude()
@ToString
public class Parameters {
    private String resolution;
    private String description;
    @JsonProperty(value = "descr_DBO")
    private String descrDBO;
    private String ruleId;
}
