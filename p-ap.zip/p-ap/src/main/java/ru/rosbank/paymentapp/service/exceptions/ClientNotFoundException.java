package ru.rosbank.paymentapp.service.exceptions;

public class ClientNotFoundException extends RuntimeException {

    public ClientNotFoundException(Long id) {
        super("Пользователь не найден [id=" + id + "]");
    }

    public ClientNotFoundException(String dboProId) {
        super("Пользователь не найден [dboProId=" + dboProId + "]");
    }

    public ClientNotFoundException(String msg, Throwable t) {
        super(msg, t);
    }
}
