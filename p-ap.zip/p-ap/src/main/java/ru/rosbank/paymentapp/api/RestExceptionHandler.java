package ru.rosbank.paymentapp.api;

import static ru.rosbank.platform.server.paymentapp.model.Error.TypeEnum.VALIDATION_ERROR;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import ru.rosbank.paymentapp.service.exceptions.DocumentNotSignedException;
import ru.rosbank.paymentapp.service.exceptions.DocumentNumberException;
import ru.rosbank.paymentapp.service.exceptions.DocumentRecallException;
import ru.rosbank.paymentapp.service.exceptions.PaymentNotFoundException;
import ru.rosbank.paymentapp.service.exceptions.PaymentNotRevertibleException;
import ru.rosbank.paymentapp.service.exceptions.UnprocessablePaymentException;
import ru.rosbank.paymentapp.service.exceptions.ValidationException;
import ru.rosbank.platform.server.paymentapp.model.Error;

@Slf4j
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(Exception.class)
    protected ResponseEntity<Object> handleException(Exception ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(Error.TypeEnum.UNEXPECTED, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(PaymentNotFoundException.class)
    protected ResponseEntity<Object> handleException(PaymentNotFoundException ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(Error.TypeEnum.DOCUMENT_NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(UnprocessablePaymentException.class)
    protected ResponseEntity<Object> handleException(UnprocessablePaymentException ex) {
        log.error(ex.getMessage());
        return new ResponseEntity<>(Error.TypeEnum.VALIDATION_ERROR, HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(PaymentNotRevertibleException.class)
    protected ResponseEntity<Object> handleException(PaymentNotRevertibleException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(VALIDATION_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(DocumentNumberException.class)
    protected ResponseEntity<Object> handleException(DocumentNumberException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().type(VALIDATION_ERROR).message(ex.getMessage()),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(DocumentRecallException.class)
    protected ResponseEntity<Object> handleException(DocumentRecallException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(Error.TypeEnum.ESBERROR, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(DocumentNotSignedException.class)
    protected ResponseEntity<Object> handleException(DocumentNotSignedException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(VALIDATION_ERROR, HttpStatus.NOT_ACCEPTABLE);
    }

    @ExceptionHandler(ValidationException.class)
    protected ResponseEntity<Object> handleException(ValidationException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().type(VALIDATION_ERROR).message(ex.getMessage()),
                HttpStatus.NOT_ACCEPTABLE);
    }
}