package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.AntifraudClientEntity;

@Repository
public interface AntifraudClientEntityRepository extends CrudRepository<AntifraudClientEntity, Long> {

    Optional<AntifraudClientEntity> findTopByClientIdAndStatusOrderByCreatedDesc(Long clientId, String status);

}
