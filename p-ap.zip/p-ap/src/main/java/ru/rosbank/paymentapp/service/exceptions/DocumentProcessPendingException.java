package ru.rosbank.paymentapp.service.exceptions;


public class DocumentProcessPendingException extends Exception {

    public DocumentProcessPendingException(String msg) {
        super(msg);
    }

}
