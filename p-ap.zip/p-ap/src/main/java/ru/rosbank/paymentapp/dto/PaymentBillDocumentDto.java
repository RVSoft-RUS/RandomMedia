package ru.rosbank.paymentapp.dto;

import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 *                 Платежное требование
 *
 *              <p>paymentOutputMode - Вид платежа
 *                 paymentPriority - Очередность платежа
 *                 uin - УИН
 *                 processedBy - Филиал банка, который обрабатывал документ
 *                 incomingDate - дата поступления в банк плательщика
 *                 paymentCondition - Условия оплаты
 *                 expirationAcceptance - Срок акцепта
 *                 endEexpirationAcceptance - Окончание срока акцепта
 *                 orderDate - Дата отсылки (вручения) плательщику предусмотренных договором документов
 *                 placeInFileDate - Дата помещения в картотеку
 *                 paymentPartialNumber - N ч. Плат
 *                 statusMessage - комментарий для документов со статусами "Отклонён" и "Отозван"
 *
 * <p>Java class for PaymentBillDocument complex type.
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PaymentBillDocumentDto extends AbstractDocumentDto {

    protected PaymentOutputModeDto paymentOutputMode;
    protected String paymentPriority;
    protected String uin;
    protected BankInfoDto processedBy;
    protected Date incomingDate;
    protected String paymentCondition;
    protected String expirationAcceptance;
    protected String endEexpirationAcceptance;
    protected Date orderDate;
    protected Date placeInFileDate;
    protected String paymentPartialNumber;
    protected String statusMessage;

    /**
     * {@inheritDoc}
     * 
     */
    @Override
    public PaymentBillDocumentDto withType(DocumentTypeDto type) {
        super.withType(type);
        return this;
    }

}
