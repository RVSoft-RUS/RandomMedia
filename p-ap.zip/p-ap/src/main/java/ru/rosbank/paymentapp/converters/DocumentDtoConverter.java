package ru.rosbank.paymentapp.converters;

import java.time.OffsetDateTime;
import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.dto.AmountDto;
import ru.rosbank.paymentapp.dto.BankInfoDto;
import ru.rosbank.paymentapp.dto.CurrencyDto;
import ru.rosbank.paymentapp.dto.DocumentTypeDto;
import ru.rosbank.paymentapp.dto.PaymentAssignmentDocumentDto;
import ru.rosbank.paymentapp.dto.RequisiteDto;
import ru.rosbank.paymentapp.util.FormatUtils;
import ru.rosbank.platform.server.paymentapp.model.Document;

//Imported from bs-app
@Service
public class DocumentDtoConverter {

    public PaymentAssignmentDocumentDto convert(Document document) {

        PaymentAssignmentDocumentDto documentDto = new PaymentAssignmentDocumentDto();

        documentDto.setPaymentPriority(document.getPaymentPriority());
        if (DocumentTypeDto.DE.value().equals(document.getType().getValue())) {
            documentDto.setPayerStatus(document.getPayerStatus());
            documentDto.setBasisDocumentCreated(document.getBasisDocumentCreated());
            documentDto.setBasisDocumentNumber(document.getBasisDocumentNumber());
            documentDto.setPaymentBasis(document.getPaymentBasis());
            documentDto.setTaxPeriod(document.getTaxPeriod());
            documentDto.setKbk(document.getKbk());
            documentDto.setOktmo(document.getOktmo());
        }
        documentDto.setConfirmed(false);

        documentDto.setId(document.getId() == null ? null : document.getId().toString());
        documentDto.setNumber(document.getNumber());
        documentDto.setCreated(dateFromOffsetDateTime(document.getDate()));
        documentDto.setExecutionDate(dateFromOffsetDateTime(document.getExecutionDate()));
        documentDto.setType(DocumentTypeDto.valueOf(document.getType().getValue()));
        documentDto.setPurpose(document.getPurpose());
        documentDto.setUin(document.getUin());
        documentDto.setAmount(new AmountDto(FormatUtils.parseAmount(document.getAmount()), CurrencyDto.RUB));
        RequisiteDto payer = new RequisiteDto();
        payer.setAccount(document.getPayer().getAccount());
        payer.setBank(new BankInfoDto(document.getPayer().getBank().getBic(),
            document.getPayer().getBank().getName(),
            document.getPayer().getBank().getCorrespondentAccount()));
        payer.setInn(StringUtils.isBlank(document.getPayer().getInn()) ? "0" : document.getPayer().getInn());
        payer.setName(document.getPayer().getName());
        payer.setKpp(document.getPayer().getKpp());
        documentDto.setPayer(payer);

        RequisiteDto payee = new RequisiteDto();
        payee.setAccount(document.getPayee().getAccount());
        payee.setBank(new BankInfoDto(document.getPayee().getBank().getBic(),
            document.getPayee().getBank().getName(),
            document.getPayee().getBank().getCorrespondentAccount()));
        payee.setInn(StringUtils.isBlank(document.getPayee().getInn()) ? "0" : document.getPayee().getInn());
        payee.setName(document.getPayee().getName());
        payee.setKpp(document.getPayee().getKpp());
        documentDto.setPayee(payee);

        if (Boolean.TRUE.equals(document.getShowError()) && StringUtils.isNotBlank(document.getStatusMessage())) {
            documentDto.setStatusMessage(document.getStatusMessage());
        }
        if (document.getCodeTypeIncome() != null) {
            documentDto.setCodeTypeIncome(Integer.valueOf(document.getCodeTypeIncome()));
        }
        if ("1".equals(document.getTypeTaxPayment())) {
            documentDto.setTypeTaxPayment(true);
        } else if ("0".equals(document.getTypeTaxPayment())) {
            documentDto.setTypeTaxPayment(false);
        }
        return documentDto;
    }

    private Date dateFromOffsetDateTime(OffsetDateTime offsetDateTime) {
        if (offsetDateTime != null) {
            return new Date(offsetDateTime.toInstant().toEpochMilli());
        } else {
            return null;
        }
    }
}
