package ru.rosbank.paymentapp.service.dfm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;

@Slf4j
@RequiredArgsConstructor
@Service
public class ToYourselfPaymentService {
    private static final int INDIVIDUAL_INN_LENGTH = 12;
    private static final int COMPANY_INN_LENGTH = 10;
    private static final String[] PAYEE_ACC_NUMBER_TO_YOURSELF_VALUES = new String[]{"40802", "40821"};
    private static final Set<String> PAYEE_ACC_NUMBER_TO_YOURSELF =
            new HashSet<>(Arrays.asList(PAYEE_ACC_NUMBER_TO_YOURSELF_VALUES));
    private static final String[] PAYEE_ACC_NUMBER_NOT_REVERTIBLE_VALUES = new String[]{"40817"};
    private static final Set<String> PAYEE_ACC_NUMBER_NOT_REVERTIBLE =
            new HashSet<>(Arrays.asList(PAYEE_ACC_NUMBER_NOT_REVERTIBLE_VALUES));

    private final ReferenceAppApiClient referenceApi;
    private Set<String> rosbankBic = null;

    public boolean isToYourself(PaymentEntity document) {
        if (StringUtils.isNotEmpty(document.getPayerInn()) && StringUtils.isNotEmpty(document.getPayeeInn())
                && StringUtils.isNotEmpty(document.getPayerBankBic()) && StringUtils.isNotEmpty(document.getPayeeBankBic())
                && document.getPayerInn().equals(document.getPayeeInn())
                && document.getPayerBankBic().equals(document.getPayeeBankBic()) && isBicRosbank(document.getPayerBankBic())) {
            if (document.getPayeeInn().length() == COMPANY_INN_LENGTH) {
                return true;
            } else if (document.getPayeeInn().length() == INDIVIDUAL_INN_LENGTH
                    && StringUtils.isNotEmpty(document.getPayeeAccount())) {
                return PAYEE_ACC_NUMBER_TO_YOURSELF.contains(document.getPayeeAccount().substring(0, 5));
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public boolean isBicRosbank(String bic) {
        try {
            if (rosbankBic == null) {
                rosbankBic = new HashSet<>();
                List<BranchDTO> branchDTOS = Optional.ofNullable(referenceApi.branchGet(null)).map(ResponseEntity::getBody)
                        .orElse(new ArrayList<>());
                rosbankBic.addAll(branchDTOS.stream().map(BranchDTO::getBik).collect(Collectors.toList()));
            }
            return rosbankBic.contains(bic);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return false;
        }
    }

    public boolean isNotRevertible(PaymentEntity document) {
        return isToYourself(document)
                || (StringUtils.isNotEmpty(document.getPayerInn()) && StringUtils.isNotEmpty(document.getPayeeInn())
                && StringUtils.isNotEmpty(document.getPayeeBankBic())
                && document.getPayerInn().equals(document.getPayeeInn())
                && isBicRosbank(document.getPayeeBankBic()) && document.getPayeeInn().length() == INDIVIDUAL_INN_LENGTH
                && StringUtils.isNotEmpty(document.getPayeeAccount())
                && PAYEE_ACC_NUMBER_NOT_REVERTIBLE.contains(document.getPayeeAccount().substring(0, 5)));
    }
}
