package ru.rosbank.paymentapp.dto;

import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 *                 Инкассовое поручение
 *
 *              <p>paymentOutputMode - Вид платежа
 *                 paymentPriority - Очередность платежа
 *                 uin - УИН
 *                 processedBy - Филиал банка, который обрабатывал документ
 *                 incomingDate - дата поступления в банк плательщика
 *                 placeInFileDate - Дата помещения в картотеку
 *                 paymentPartialNumber - N ч. Плат
 *
 *              <p>payerStatus - Статус плательщика
 *                 kbk - КБК
 *                 oktmo - ОКТМО
 *                 paymentBasis - Основание платежа (идентификатор)
 *                 taxPeriod - Налоговый период
 *                 basisDocumentNumber - Номер документа основания
 *                 basisDocumentCreated - Дата документа основания
 *                 statusMessage - комментарий для документов со статусами "Отклонён" и "Отозван"
 *
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class CollectionAssignmentDocumentDto extends AbstractDocumentDto {

    protected PaymentOutputModeDto paymentOutputMode;
    protected String paymentPriority;
    protected String uin;
    protected BankInfoDto processedBy;
    protected Date incomingDate;
    protected Date placeInFileDate;
    protected String paymentPartialNumber;
    protected String payerStatus;
    protected String kbk;
    protected String oktmo;
    protected String paymentBasis;
    protected String taxPeriod;
    protected String basisDocumentNumber;
    protected String basisDocumentCreated;
    protected String statusMessage;

    @Override
    public AbstractDocumentDto withType(DocumentTypeDto type) {
        super.withType(type);
        return this;
    }
}
