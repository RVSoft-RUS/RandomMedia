package ru.rosbank.paymentapp.dto;

/**
 * Java class for ResourceContentType.
 */
public enum ResourceContentTypeDto {

    XLS,
    PDF,
    PNG,
    TXT,
    CSV,
    ZIP,
    HTML,
    XLSX;

    public String value() {
        return name();
    }
}
