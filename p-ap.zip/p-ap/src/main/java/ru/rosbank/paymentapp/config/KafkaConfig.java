package ru.rosbank.paymentapp.config;

import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.apache.avro.generic.GenericRecord;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import ru.rosbank.paymentapp.service.fraud.model.AbstractEvent;
import ru.rosbank.paymentapp.service.fraud.model.resolution.Message;


@EnableKafka
@Configuration
@RequiredArgsConstructor
public class KafkaConfig {
    private final MultipleKafkaProperties kafkaProperties;

    @Bean
    @ConditionalOnProperty(name = "phub.enabled", havingValue = "true")
    public ConsumerFactory<String, GenericRecord> paymentHubConsumerFactory() {
        Map<String, Object> props = kafkaProperties.getConfigs().get("phub").buildConsumerProperties();
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    @ConditionalOnProperty(name = "phub.enabled", havingValue = "true")
    public ConcurrentKafkaListenerContainerFactory<String, GenericRecord> paymentHubKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, GenericRecord> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(paymentHubConsumerFactory());
        return factory;
    }

    @Bean
    public ConsumerFactory<String, Message> antifraudConsumerFactory() {
        Map<String, Object> props = kafkaProperties.getConfigs().get("antifraud").buildConsumerProperties();
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Message> antifraudKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Message> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(antifraudConsumerFactory());
        return factory;
    }

    @Bean
    public ProducerFactory<String, AbstractEvent> antifraudProducerFactory() {
        Map<String, Object> props = kafkaProperties.getConfigs().get("antifraud").buildProducerProperties();
        return new DefaultKafkaProducerFactory<>(props);
    }

    @Bean(name = "antifraudKafkaTemplate")
    public KafkaTemplate<String, AbstractEvent> antifraudKafkaTemplate() {
        return new KafkaTemplate<>(antifraudProducerFactory());
    }
}
