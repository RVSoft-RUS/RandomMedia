package ru.rosbank.paymentapp.service.email;

import java.util.List;
import java.util.Objects;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@Service
public class LocalEmailSender {
    private static final Logger LOGGER = LoggerFactory.getLogger(LocalEmailSender.class);

    private JavaMailSender emailSender;
    @Value("${email.smtp.mail.host}")
    private String smtpMailHost;
    @Value("${email.subject.esb}")
    private String emailSubject;
    @Value("${email.sender.name.esb}")
    private String senderName;
    @Value("${email.sender.email.esb}")
    private String senderEmail;

    public void sendSimpleEmail(String email, String subject, String text) {
        sendSimpleEmailFrom(email, subject, text, senderEmail);
    }

    public void sendSimpleEmailFrom(String email, String subject, String text, String from) {
        emailSender = getJavaMailSender();

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject(subject);
        message.setText(text);
        message.setFrom(from);

        this.emailSender.send(message);
    }


    @SuppressWarnings("checkstyle:ParameterNumber")
    public void sendMimeEmailAudited(
            ClientDTO client, String htmlText, String plainText, String subject,
            List<Resource> inlineFiles, List<Resource> attachments) {
        this.sendMimeEmail(client.getEmail(), htmlText, plainText, subject, inlineFiles, attachments);
    }

    @SuppressWarnings("checkstyle:ParameterNumber")
    public void sendMimeEmailAudited(
            String email, String htmlText, String plainText, String subject,
            List<Resource> inlineFiles, List<Resource> attachments) {
        this.sendMimeEmail(email, htmlText, plainText, subject, inlineFiles, attachments);
    }

    public void sendMimeEmail(
            Object email, String htmlText, String plainText, String subject,
            List<Resource> inlineFiles, List<Resource> attachments) {

        emailSender = getJavaMailSender();

        MimeMessagePreparator preparator = message -> {

            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED, "utf-8");
            helper.setText(plainText, htmlText);

            if (CollectionUtils.isNotEmpty(inlineFiles)) {
                inlineFiles.forEach(i -> {
                    try {
                        helper.addInline(Objects.requireNonNull(i.getFilename()), i);
                    } catch (MessagingException e) {
                        LOGGER.warn("Failed to add inline file!", e);
                    }
                });
            }

            if (CollectionUtils.isNotEmpty(attachments)) {
                attachments.forEach(at -> {
                    try {
                        helper.addAttachment(Objects.requireNonNull(at.getFilename()), at);
                    } catch (MessagingException e) {
                        LOGGER.warn("Failed to add attachment!", e);
                    }
                });
            }

            if (email.getClass().isArray()) {
                helper.setTo((String[]) email);
            } else {
                helper.setTo((String) email);
            }

            if (StringUtils.isNotBlank(subject)) {
                helper.setSubject(subject);
            } else {
                helper.setSubject(emailSubject);
            }
            helper.setFrom(new InternetAddress(senderEmail, senderName));

        };

        this.emailSender.send(preparator);

    }

    private JavaMailSender getJavaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(smtpMailHost);

        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");

        return mailSender;
    }


}
