package ru.rosbank.paymentapp.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.ImportedDocumentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;

@Repository
public interface ImportedDocumentRepository extends CrudRepository<ImportedDocumentEntity, Long> {
    List<ImportedDocumentEntity> findByClientIdAndBatch(Long clientId, String batch);

    List<ImportedDocumentEntity> findByClientIdAndBatchAndDocumentIsNotNull(Long clientId, String batch);

    List<ImportedDocumentEntity> findByClientIdAndBatchAndStatus(Long clientId, String batch, String status);

    @Modifying
    void deleteByDocument(PaymentEntity paymentEntity);
}
