package ru.rosbank.paymentapp.service.fraud.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude()
public class PaymentEvent extends AbstractEvent {
    private String id;
    private Integer documentNumber;
    private Date documentDate;
    private String amount;
    private String amountRur;
    private String currency;
    private String paymentClass;
    private String payerBic;
    private String payerBankName;
    private String payerInn;
    private String payerAccountNumber;
    private String payeeInn;
    private String payeeAccountNumber;
    private String payeeBic;
    private String payeeBankName;
    private String payeePlace;
    private String payeeKpp;
    // KBK
    private String payeeBcc;
    private String description;
    private String payerAccountBalance;
    private String payerAccountCurrency;
    private String payerAccountBalanceRur;
    private String payerPlace;
    private String contact;
    private String userIp;
    private Date reviewDeadline;
    private String branch;
    private String senderName;
    private String recipientName;
    private String incomeType;
    private String paymentType;
    private String flagAml;

    @Override
    public String toString() {
        return "PaymentEvent{"
                + "id='" + id + '\''
                + ", documentNumber=" + documentNumber
                + ", documentDate=" + documentDate
                + ", amount='" + amount + '\''
                + ", amountRur='" + amountRur + '\''
                + ", currency='" + currency + '\''
                + ", paymentClass='" + paymentClass + '\''
                + ", payerBic='" + payerBic + '\''
                + ", payerBankName='" + payerBankName + '\''
                + ", payerInn='" + payerInn + '\''
                + ", payerAccountNumber='" + payerAccountNumber + '\''
                + ", payeeInn='" + payeeInn + '\''
                + ", payeeAccountNumber='" + payeeAccountNumber + '\''
                + ", payeeBic='" + payeeBic + '\''
                + ", payeeBankName='" + payeeBankName + '\''
                + ", payeePlace='" + payeePlace + '\''
                + ", payeeKpp='" + payeeKpp + '\''
                + ", payeeBcc='" + payeeBcc + '\''
                + ", description='" + description + '\''
                + ", payerAccountBalance='" + payerAccountBalance + '\''
                + ", payerAccountCurrency='" + payerAccountCurrency + '\''
                + ", payerAccountBalanceRur='" + payerAccountBalanceRur + '\''
                + ", payerPlace='" + payerPlace + '\''
                + ", contact='" + contact + '\''
                + ", userIp='" + userIp + '\''
                + ", reviewDeadline=" + reviewDeadline
                + ", branch='" + branch + '\''
                + ", senderName='" + senderName + '\''
                + ", recipientName='" + recipientName + '\''
                + ", incomeType='" + incomeType + '\''
                + ", paymentType='" + paymentType + '\''
                + ", flagAml='" + flagAml + '\''
                + '}';
    }
}
