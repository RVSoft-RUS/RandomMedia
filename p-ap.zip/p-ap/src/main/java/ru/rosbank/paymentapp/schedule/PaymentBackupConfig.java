package ru.rosbank.paymentapp.schedule;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties("schedulers.backup-payment-job")
@Component
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PaymentBackupConfig {
    boolean enable = true;
    int lockTimePeriod = 120;
    int taskTimeLimit = 7200;
    int batchRequest = 3000;
    int maxCountRequest = 100;
    int dayAgo = 21;

}
