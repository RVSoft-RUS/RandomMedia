package ru.rosbank.paymentapp.service.exceptions;


public class DocumentNumberException extends RuntimeException {
    public DocumentNumberException(String msg) {
        super(msg);
    }

    public DocumentNumberException(String msg, Throwable t) {
        super(msg, t);
    }
}
