package ru.rosbank.paymentapp.entity;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity(name = "last_payment_number")
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LastPaymentNumberEntity {
    @EmbeddedId
    @EqualsAndHashCode.Include
    NumberYearKey id;
    Long number;
}
