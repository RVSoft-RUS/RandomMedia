package ru.rosbank.paymentapp.repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.entity.PaymentEntity;


public interface PaymentEntityRepository extends CrudRepository<PaymentEntity, Long> {

    @Query("select d.id from document d where d.status in (?1)")
    List<Long> findAllIdsByStatusIn(List<String> statusList);

    List<PaymentEntity> findAllByStatusIn(List<String> statusList);

    List<PaymentEntity> findAllByStatusInAndClientIdIsNotNullAndPayeeBankBicNotInOrderByClientId(List<String> statusList,
                                                                                                  List<String> payeeBankBicList);

    @Query(value = "SELECT p FROM document p WHERE p.status in :statusList AND p.payeeBankBic in :payeeBankBicList "
            + " AND p.clientId is not null AND (p.executionDate > :dateFrom OR p.signDate > :dateFrom) ORDER BY p.clientId")
    List<PaymentEntity> findAllByStatusInAndPayeeBankBicInAndExecutionDateOrSignDateAfterAndClientIdIsNotNullOrderByClientId(
            @Param("statusList") Collection<String> statusList, @Param("payeeBankBicList") Collection<String> payeeBankBicList,
            @Param("dateFrom") LocalDateTime dateFrom);

    List<PaymentEntity> getByPayerAccountAndStatusIn(String account, List<String> statusList);

    List<PaymentEntity> findByIdInOrderByIdDesc(List<Long> documentIds);

    Optional<PaymentEntity> findByBisDocumentId(String bisDocumentId);

    List<PaymentEntity> findByPayerAccountInAndDateBetween(List<String> acctList, LocalDateTime dateFrom, LocalDateTime dateTo);

    Optional<PaymentEntity> findTopByPayerInnAndNumberAndIdNotAndDateBetween(String inn, String number, Long id,
                                                                             LocalDateTime dateFrom, LocalDateTime dateTo);

    Optional<PaymentEntity> findTopByPayerInnAndNumberAndIdNotAndDateBetweenAndStatusIn(String inn, String number, Long id,
        LocalDateTime dateFrom, LocalDateTime dateTo, List<String> statuses);

    List<PaymentEntity> findAllByDateBetweenAndPayerAccountInAndNumberIsNotNull(LocalDateTime dateFrom,
                                                                                LocalDateTime dateTo, List<String> account);

    Set<PaymentEntity> findAllBySignDateBetweenAndPayerAccountAndStatusInAndNumberIsNotNull(
            LocalDateTime dateFrom, LocalDateTime dateTo, String account, List<String> statuses);

    List<PaymentEntity> findAllByBisDocumentIdInAndStatusNot(List<String> bisDocumentIds, String status);

    @Query("select p from document p left join fetch p.documentRecallEntity where p.id = :id")
    Optional<PaymentEntity> findByIdFetchDocumentRecall(@Param("id") Long id);

    List<PaymentEntity> findAllByStatusAndSignDateBefore(String status, LocalDateTime date, Pageable pageable);

    @Transactional
    void deleteByBisDocumentId(String id);

    List<PaymentEntity> findAllBySignDateBetweenAndOrganizationCrmIdAndStatusInAndNumberIsNotNull(
            LocalDateTime dateFrom, LocalDateTime dateTo, String crmId, List<String> statuses);

    List<PaymentEntity> findAllByStatusAndIdIn(String status, List<Long> ids);

}
