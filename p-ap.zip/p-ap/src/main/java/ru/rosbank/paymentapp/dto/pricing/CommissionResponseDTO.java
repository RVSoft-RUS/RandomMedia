package ru.rosbank.paymentapp.dto.pricing;

import java.math.BigDecimal;
import lombok.Data;

@Data
public class CommissionResponseDTO {
    private String paymentId;
    private BigDecimal commissionAmount;
    private String currencyCode;
    private boolean precalculationFlag;
}
