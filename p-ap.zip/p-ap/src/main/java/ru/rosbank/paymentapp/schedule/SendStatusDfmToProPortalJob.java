package ru.rosbank.paymentapp.schedule;

import java.util.List;
import java.util.stream.Collectors;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.dfm.DfmPaymentService;
import ru.rosbank.platform.client.portalpro.model.AppRequestDfmSaveAlertsRequestAlertsInnerDTO;
import ru.rosbank.platform.client.portalpro.model.AppRequestDfmSaveAlertsRequestDTO;
import ru.rosbank.platform.redis.SharedLock;

@Service
@Slf4j
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class SendStatusDfmToProPortalJob {

    SendStatusDfmToProPortalConfig config;
    DfmPaymentService dfmPaymentService;
    SharedLock sharedLock;
    String keyLock = "SendStatusDfmToProPortalJob";

    //TODO временное решение, необходимо переодически проверять актуальность.
    @Scheduled(cron = "${schedulers.send-status-dfm-job.cron:0 0/5 * * * *}", zone = "Europe/Moscow")
    public void run() {
        if (!config.isEnable()) {
            return;
        }
        long startTime = System.currentTimeMillis();
        log.debug("Starting sendStatusDfmToProPortalJob...");
        boolean sendStatusDfmToProPortalJob = sharedLock.lock(keyLock, config.getLockTimePeriod());

        if (sendStatusDfmToProPortalJob) {
            AppRequestDfmSaveAlertsRequestDTO alerts = dfmPaymentService.getAppRequestDfmSaveAlertsRequest();
            if (alerts.getAlerts().size() > 0) {
                dfmPaymentService.sendDocumentAlertsToProPortal(alerts);
            }

            sharedLock.release(keyLock);
            log.info("sendStatusDfmToProPortalJob completed successfully");
            log.info("successful successSendStatusId = {} ", alerts.getAlerts().stream()
                    .map(AppRequestDfmSaveAlertsRequestAlertsInnerDTO::getIdPayment)
                    .collect(Collectors.toList()).toString());
            log.info("sendStatusDfmToProPortalJob execution time = {} s",(System.currentTimeMillis() - startTime) / 1000);
        } else {
            log.info("sendStatusDfmToProPortalJob failed to capture lock");
        }
    }
}
