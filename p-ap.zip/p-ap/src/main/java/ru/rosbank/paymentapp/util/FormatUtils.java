package ru.rosbank.paymentapp.util;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import org.apache.commons.lang3.math.NumberUtils;


/**
 * Утилиты для форматирования.
 *
 * <p>В системе жестко заданы параметры локализации. Текущая локаль сервера/клиентов не учитывается.
 * Поэтому здесь эти параметры явно определены.</p>
 *
 * @author Q-APE
 * @author Q-DSH
 */
public class FormatUtils {

    private static final Locale LOCALE_RU = new Locale("ru", "RU");

    /**
     * Формат по умолчанию для даты.
     */
    public static final String DATE_PATTERN = "dd.MM.yyyy";
    public static final String DATE_TIME_MS_PATTERN = "dd-MM-yyyy HH:mm:ss.SSS";

    public static BigDecimal parseAmount(String string) {
        if (string == null || string.isEmpty()) {
            return null;
        }
        return NumberUtils.toScaledBigDecimal(string, 2, RoundingMode.HALF_UP);
    }

    /**
     * Форматирует дату.
     *
     * @param date    Date дата
     * @param pattern String шаблон формата даты. К примеру "yyyy/mm/dd"
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(Date date, String pattern) {
        return formatDate(date, pattern, LOCALE_RU.getLanguage());
    }

    /**
     * Форматирует дату.
     *
     * @param date     Date дата
     * @param pattern  String шаблон формата даты. К примеру "yyyy/mm/dd"
     * @param language String двухсимвольный код языка локали (ru, en, ...)
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(Date date, String pattern, String language) {
        if (date == null) {
            return "";
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern, new Locale(language));
        return toLocalDateTime(date).format(formatter);
    }

    /**
     * Форматирует дату с использованием стандартного шаблона ({@link #DATE_PATTERN}).
     *
     * @param localDate LocalDate дата
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(LocalDate localDate) {
        Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        return formatDate(date, DATE_PATTERN);
    }

    /**
     * Конвертирует дату из типа {@link Date} в тип {@link LocalDateTime}.
     *
     * @param date Date дата
     * @return LocalDateTime дата
     */
    public static LocalDateTime toLocalDateTime(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static String formatLocalDateTimeMs(LocalDateTime date) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_MS_PATTERN, LOCALE_RU);
        return date.format(dateTimeFormatter);
    }
}
