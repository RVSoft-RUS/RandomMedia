package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.DeliveringResource;

//Imported from bs-app
@Repository
public interface DeliveringResourceRepository extends CrudRepository<DeliveringResource, Long> {

    Optional<DeliveringResource> getDeliveringResourceByReference(String reference);

}
