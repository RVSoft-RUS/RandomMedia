package ru.rosbank.paymentapp.service.fraud;

import static ru.rosbank.paymentapp.entity.AntifraudResolutionEntity.ALLOW;
import static ru.rosbank.paymentapp.entity.AntifraudResolutionEntity.ALLOW_TIMEOUT;
import static ru.rosbank.paymentapp.entity.AntifraudResolutionEntity.DENY;
import static ru.rosbank.paymentapp.entity.AntifraudResolutionEntity.REVIEW_TIMEOUT;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.AntifraudResolutionEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.AntifraudResolutionEntityRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.audit.AuditContext;
import ru.rosbank.paymentapp.service.audit.ThreadLocalAuditContext;
import ru.rosbank.paymentapp.service.fraud.model.resolution.Message;
import ru.rosbank.paymentapp.util.Utils;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Slf4j
@Service
public class AntifraudPaymentService extends AbstractAntifraudService {

    private static final String DENY_MESSAGE = "Платёж был отклонён для обеспечения безопасности Ваших средств."
            + " В ближайшее время с Вами свяжется сотрудник Росбанка для его подтверждения,"
            + " после чего Вы сможете повторно оформить платёж.";

    private static final String DENY_IN_REVIEW_MESSAGE =
            "Платёж отменён по результатам коммуникации с сотрудником Контакт Центра.";

    @Autowired
    private PaymentEntityRepository documentRepository;
    @Autowired
    private AntifraudResolutionEntityRepository resolutionRepository;
    @Autowired
    private PaymentEventService paymentEventService;
    @Autowired
    private UserAntifraudService userAntifraudService;
    @Autowired
    private PaymentStatusEventService paymentStatusEventService;


    @Value("${anti-fraud.resolution.timeout}")
    private Long timeout;

    public void consumeResolution(Message message) {
        List<String> terminalStatuses = Arrays.asList(REVIEW_TIMEOUT, ALLOW_TIMEOUT, ALLOW, DENY);
        Optional<AntifraudResolutionEntity> opResolution = resolutionRepository.findByRequestId(
                message.getResponse().getRequestId()
        );
        if (opResolution.isPresent()) {
            AntifraudResolutionEntity ar = opResolution.get();
            if (terminalStatuses.contains(ar.getStatus())) {
                log.info("Резолюция уже в конечном статусе {}", ar.getStatus());
            } else {
                ar.setStatus(message.getParameters().getResolution());
                ar = resolutionRepository.save(ar);
                log.info("Новый статус по платежу: {}", ar.getStatus());
            }
        } else {
            log.error("Не найдена резолюция! [requestId={}]", message.getResponse().getRequestId());
        }
    }

    public boolean isProcessed(PaymentEntity document) {
        Optional<AntifraudResolutionEntity> optAr = resolutionRepository.findByDocumentId(document.getId());
        if (optAr.isPresent()) {
            return isPaymentProcessed(document, optAr.get());
        } else {
            paymentEventService.sendPaymentEvent(document);
            return false;
        }
    }

    public void sendPaymentStatusEvent(PaymentEntity document) {
        AuditContext context = ThreadLocalAuditContext.get();
        if (context.getPaymentStatusEvent() != null) {
            paymentStatusEventService.sendPaymentEvent(document, context.getPaymentStatusEvent());
            context.setPaymentStatusEvent(null);
        }
    }

    private boolean isPaymentProcessed(PaymentEntity document, AntifraudResolutionEntity ar) {
        AuditContext context = ThreadLocalAuditContext.get();
        if (ALLOW.equals(ar.getStatus())) {
            if (DocumentStatus.REVIEW.toString().equals(document.getStatus())) {
                context.setPaymentStatusEvent(PaymentStatusEvents.ANTI_FRAUD_ALLOW_IN_REVIEW);
            } else {
                context.setPaymentStatusEvent(PaymentStatusEvents.ANTI_FRAUD_ALLOW);
            }
            return true;
        }
        if (DENY.equals(ar.getStatus())) {
            if (DocumentStatus.REVIEW.toString().equals(document.getStatus())) {
                document.setStatusMessage(DENY_IN_REVIEW_MESSAGE);
                paymentStatusEventService.sendPaymentEvent(document, PaymentStatusEvents.ANTI_FRAUD_DENY_IN_REVIEW);
            } else {
                document.setStatusMessage(DENY_MESSAGE);
                paymentStatusEventService.sendPaymentEvent(document, PaymentStatusEvents.ANTI_FRAUD_DENY);
            }
            document.setStatus(DocumentStatus.REJECTED.name());
            paymentEventService.sendDocumentStatus(document);
            document.setShowError(true);
            documentRepository.save(document);
            return false;
        }
        if (AntifraudResolutionEntity.REVIEW.equals(ar.getStatus())) {
            return isReviewProcessed(document, ar);
        }
        if (AntifraudResolutionEntity.ANTIFRAUD_PROCESSING.equals(ar.getStatus()) && isOutdated(ar)) {
            log.info("Таймаут резолюции {}", ar.getId());
            ar.setStatus(ALLOW_TIMEOUT);
            resolutionRepository.save(ar);
            context.setPaymentStatusEvent(PaymentStatusEvents.ANTI_FRAUD_ALLOW_TIMEOUT);
            return true;
        }
        return Arrays.asList(ALLOW_TIMEOUT, REVIEW_TIMEOUT)
                .contains(ar.getStatus());
    }

    private boolean isOutdated(AntifraudResolutionEntity ar) {
        return ar.getCreated().isBefore(LocalDateTime.now().minus(Duration.ofMillis(timeout)));
    }

    private boolean isReviewProcessed(PaymentEntity document, AntifraudResolutionEntity ar) {
        if (Utils.workingDaysElapsedFrom(ar.getCreated().toLocalDate()) >= reviewTimeoutDays) {

            log.info("Таймаут ожидания резолюции {}", ar.getId());
            ar.setStatus(REVIEW_TIMEOUT);
            resolutionRepository.save(ar);

            userAntifraudService.revokeBlockOnClient(ar.getClientId());

            AuditContext context = ThreadLocalAuditContext.get();
            context.setPaymentStatusEvent(PaymentStatusEvents.ANTI_FRAUD_REVIEW_TIMEOUT);

            return true;
        } else {
            if (!DocumentStatus.REVIEW.toString().equals(document.getStatus())) {
                document.setStatus(DocumentStatus.REVIEW.toString());
                document.setStatusMessage(DocumentStatus.PROCESSING.name());
                documentRepository.save(document);
                paymentStatusEventService.sendPaymentEvent(document, PaymentStatusEvents.ANTI_FRAUD_REVIEW);
                paymentEventService.sendDocumentStatus(document);
            }
            return false;
        }
    }

}
