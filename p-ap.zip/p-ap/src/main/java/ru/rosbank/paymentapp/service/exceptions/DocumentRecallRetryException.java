package ru.rosbank.paymentapp.service.exceptions;


public class DocumentRecallRetryException extends RuntimeException {

    public DocumentRecallRetryException(String msg) {
        super(msg);
    }

}
