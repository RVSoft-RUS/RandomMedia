package ru.rosbank.paymentapp.service.validators;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;


/**
 * Summary.
 * Field 4
 */
@Service
public class DocumentDateOnSendToEsbValidator {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final int FIELD_ID = 4;
    private static final int MIN_DAYS_BEFORE = 11;
    private static final int MAX_DAYS_AFTER = 30;
    private static final String FIELD_NAME = "date";
    private static final String ERROR_MESSAGE_INCORRECT_DATE = "Дата документа должна быть в интервале от %s до %s.";

    public void validate(PaymentEntity document) {
        LocalDateTime date = document.getExecutionDate() != null
                ? document.getExecutionDate()
                : document.getDate();
        LocalDateTime now = LocalDateTime.now();

        LocalDateTime latestDateTime = now.plusDays(MAX_DAYS_AFTER);
        LocalDateTime earliestDateTime = now.minusDays(MIN_DAYS_BEFORE);

        if (date.isBefore(earliestDateTime) || date.isAfter(latestDateTime)) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME,
                    String.format(ERROR_MESSAGE_INCORRECT_DATE,
                            earliestDateTime.plusDays(1).toLocalDate().format(DATE_FORMATTER),
                            latestDateTime.toLocalDate().format(DATE_FORMATTER)));
        }
    }
}
