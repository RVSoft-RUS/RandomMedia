package ru.rosbank.paymentapp.converters;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import org.springframework.stereotype.Service;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusFinal;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusMiddle;
import ru.rosbank.paymentapp.dto.phub.DocumentStatusMessageDto;

/**
 * Summary.
 * @author rb197115
 *      Converts DocumentStatusMiddle or DocumentStatusFinal to DocumentStatusMessageDto
 */
@Service
public class DocumentStatusMessageDtoConverter {
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

    public DocumentStatusMessageDto convert(DocumentStatusMiddle message) {
        DocumentStatusMessageDto documentStatusMessageDto = new DocumentStatusMessageDto();
        documentStatusMessageDto.setBisId(transformBisId(message.getBISID()));

        try {
            Instant statusDateTime = message.getStatusDateTime();
            LocalDateTime from = LocalDateTime.parse(statusDateTime.toString(), formatter);
            documentStatusMessageDto.setStatusDateTime(from);
        } catch (RuntimeException ignored) {
            documentStatusMessageDto.setStatusDateTime(null);
        }

        documentStatusMessageDto.setStatusSysName(message.getStatusSysName());
        documentStatusMessageDto.setStatusComment(message.getStatusComment());

        try {
            documentStatusMessageDto.setUuid(UUID.fromString(message.getDocumentID()));
        } catch (IllegalArgumentException e) {
            documentStatusMessageDto.setUuid(null);
        }

        return documentStatusMessageDto;
    }

    public DocumentStatusMessageDto convert(DocumentStatusFinal message) {
        DocumentStatusMessageDto documentStatusMessageDto = new DocumentStatusMessageDto();
        documentStatusMessageDto.setBisId(transformBisId(message.getBISID()));
        documentStatusMessageDto.setStatusCode(message.getStatusCode());
        documentStatusMessageDto.setStatusComment(message.getStatusComment());
        documentStatusMessageDto.setStatusSysName(message.getStatusSysName());

        try {
            Instant statusDateTime = message.getStatusDateTime();
            LocalDateTime from = LocalDateTime.parse(statusDateTime.toString(), formatter);
            documentStatusMessageDto.setStatusDateTime(from);
        } catch (RuntimeException ignored) {
            documentStatusMessageDto.setStatusDateTime(null);
        }

        try {
            documentStatusMessageDto.setUuid(UUID.fromString(message.getDocumentID()));
        } catch (IllegalArgumentException ignored) {
            documentStatusMessageDto.setUuid(null);
        }

        return documentStatusMessageDto;
    }

    private String transformBisId(String oldBisId) {
        StringBuilder stringBuilder = new StringBuilder(oldBisId);
        stringBuilder
                .delete(0, 5)
                .insert(0, "PP")
                .append("01");
        return stringBuilder.toString();
    }
}