package ru.rosbank.paymentapp.entity;


import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.Getter;
import lombok.Setter;

/**
 * Summary.
 * @author rb067368
 * @since 10.10.2019
 */
@Entity(name = "template_new")
@Getter
@Setter
public class TemplateEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Date dateCreated;
    private Date lastModifiedDate;

    private String status;
    private String docType;
    private String purpose;
    private BigDecimal amount;
    private String payPriority;
    private String payerStatus;
    private String paymentBasis;
    private String basisDocumentNumber;
    private String basisDocumentCreated;
    private String taxPeriod;
    private String uin;
    private String kbk;
    private String oktmo;
    private String payerName;
    private String payerAccount;
    private String payerInn;
    private String payerKpp;
    private String payerBankName;
    private String payerBankBic;
    private String payerBankCorrespondentAccount;
    private String payeeName;
    private String payeeAccount;
    private String payeeInn;
    private String payeeKpp;
    private String payeeBankName;
    private String payeeBankBic;
    private String payeeBankCorrespondentAccount;
    private String dboProId;
    // поле 20: Назначение платежа (Код вида дохода)
    protected Short codeTypeIncome;
    //Тип налогового платежа поле 110
    protected Boolean typeTaxPayment;
    private Long count;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        TemplateEntity that = (TemplateEntity) o;
        return  Objects.equals(id, that.id)
                && Objects.equals(name, that.name)
                && Objects.equals(status, that.status)
                && Objects.equals(docType, that.docType)
                && Objects.equals(purpose, that.purpose)
                && Objects.equals(amount, that.amount)
                && Objects.equals(payPriority, that.payPriority)
                && Objects.equals(payerStatus, that.payerStatus)
                && Objects.equals(paymentBasis, that.paymentBasis)
                && Objects.equals(basisDocumentNumber, that.basisDocumentNumber)
                && Objects.equals(basisDocumentCreated, that.basisDocumentCreated)
                && Objects.equals(taxPeriod, that.taxPeriod)
                && Objects.equals(uin, that.uin)
                && Objects.equals(kbk, that.kbk)
                && Objects.equals(oktmo, that.oktmo)
                && Objects.equals(payerName, that.payerName)
                && Objects.equals(payerAccount, that.payerAccount)
                && Objects.equals(payerInn, that.payerInn)
                && Objects.equals(payerKpp, that.payerKpp)
                && Objects.equals(payerBankName, that.payerBankName)
                && Objects.equals(payerBankBic, that.payerBankBic)
                && Objects.equals(payerBankCorrespondentAccount, that.payerBankCorrespondentAccount)
                && Objects.equals(payeeName, that.payeeName)
                && Objects.equals(payeeAccount, that.payeeAccount)
                && Objects.equals(payeeInn, that.payeeInn)
                && Objects.equals(payeeKpp, that.payeeKpp)
                && Objects.equals(payeeBankName, that.payeeBankName)
                && Objects.equals(payeeBankBic, that.payeeBankBic)
                && Objects.equals(payeeBankCorrespondentAccount, that.payeeBankCorrespondentAccount)
                && Objects.equals(dboProId, that.dboProId)
                && Objects.equals(codeTypeIncome, that.codeTypeIncome)
                && Objects.equals(typeTaxPayment, that.typeTaxPayment);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, status, docType, purpose, amount, payPriority,
                payerStatus, paymentBasis, basisDocumentNumber, basisDocumentCreated, taxPeriod, uin, kbk, oktmo, payerName,
                payerAccount, payerInn, payerKpp, payerBankName, payerBankBic, payerBankCorrespondentAccount, payeeName,
                payeeAccount, payeeInn, payeeKpp, payeeBankName, payeeBankBic, payeeBankCorrespondentAccount, dboProId,
                codeTypeIncome, typeTaxPayment);
    }

    public enum Status {
        ACTIVE,
        INACTIVE;

        public String value() {
            return name();
        }

        public static Status fromValue(String v) {
            return valueOf(v);
        }
    }

    public TemplateEntity() {
        status = Status.ACTIVE.value();
    }

}
