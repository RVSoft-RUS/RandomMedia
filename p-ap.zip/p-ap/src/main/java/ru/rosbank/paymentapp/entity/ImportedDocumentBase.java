package ru.rosbank.paymentapp.entity;



import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public abstract class ImportedDocumentBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    private String batch;
    private LocalDateTime created;

    private Long clientId;
    private String number;
    @OneToOne
    @JoinColumn(name = "document_id")
    private PaymentEntity document;

    private String status;

    private String docType;
    private String purpose;
    private BigDecimal amount;
    private String payPriority;
    private Boolean urgent;
    private String payerStatus;
    private String paymentBasis;
    private String basisDocumentNumber;
    private String basisDocumentCreated;
    private String taxPeriod;
    private String uin;
    private String kbk;
    private String oktmo;
    private String payerName;
    private String payerAccount;
    private String payerInn;
    private String payerKpp;
    private String payerBankName;
    private String payerBankBic;
    private String payerBankCorrespondentAccount;
    private String payeeName;
    private String payeeAccount;
    private String payeeInn;
    private String payeeKpp;
    private String payeeBankName;
    private String payeeBankBic;
    private String payeeBankCorrespondentAccount;
    // поле 20: Назначение платежа (Код вида дохода)
    protected Short codeTypeIncome;
    //Тип налогового платежа поле 110
    protected Boolean typeTaxPayment;


    public enum Status {
        VALID,
        INVALID;

        public String value() {
            return name();
        }

        public static ImportedDocumentBase.Status fromValue(String v) {
            return valueOf(v);
        }
    }
}
