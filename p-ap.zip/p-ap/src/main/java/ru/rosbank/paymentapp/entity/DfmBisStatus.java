package ru.rosbank.paymentapp.entity;

public enum DfmBisStatus {
    PROCESSING,
    COMPLETED,
    ERROR;

    public String value() {
        return name();
    }

    public static DfmBisStatus fromValue(String v) {
        return valueOf(v);
    }
}
