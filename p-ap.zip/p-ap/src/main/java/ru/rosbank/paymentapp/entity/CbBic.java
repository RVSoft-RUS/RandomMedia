package ru.rosbank.paymentapp.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
public class CbBic implements Serializable {

    @Id
    @EqualsAndHashCode.Include
    private String bic;

    private String namep;

    //localityType
    private String tnp;

    //localityName
    private String nnp;
}
