package ru.rosbank.paymentapp.service.exceptions;

public class CreatePaymentResponseProcessingException extends RuntimeException {

    public CreatePaymentResponseProcessingException(Long id) {
        super("Ошибка обработки ответа БИС при создании платежа [id=" + id + "]");
    }

    public CreatePaymentResponseProcessingException(String msg, Throwable t) {
        super(msg, t);
    }
}
