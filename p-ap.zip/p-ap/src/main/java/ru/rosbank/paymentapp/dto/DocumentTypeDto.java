package ru.rosbank.paymentapp.dto;

/**
 * Java class for DocumentType.
 */
public enum DocumentTypeDto {

    DA,
    DB,
    DC,
    DD,
    DE,
    DF,
    DG,
    DH,
    DI,
    DP,
    DJ,
    CA,
    CB,
    CC,
    CD,
    CE,
    CF,
    CG,
    CH,
    CJ;

    public String value() {
        return name();
    }

    public static DocumentTypeDto fromValue(String v) {
        return valueOf(v);
    }

}
