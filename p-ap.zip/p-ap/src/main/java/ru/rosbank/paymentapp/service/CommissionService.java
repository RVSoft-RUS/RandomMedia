package ru.rosbank.paymentapp.service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.client.pricing.PricingRbspFeignClient;
import ru.rosbank.paymentapp.converters.DocumentConverter;
import ru.rosbank.paymentapp.converters.PricingCommissionConverter;
import ru.rosbank.paymentapp.dto.pricing.CommissionRequestDTO;
import ru.rosbank.paymentapp.dto.pricing.CommissionResponseDTO;
import ru.rosbank.paymentapp.dto.pricing.Response;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.entity.PricingCommissionEntity;
import ru.rosbank.paymentapp.esb.service.PaymentOrderService;
import ru.rosbank.paymentapp.repository.PricingCommissionRepository;
import ru.rosbank.platform.client.paymentapp.model.AmountDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderRequestTypeEsb;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderResponseTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;


/**
 * bis create paymentOrder service.
 */
@Slf4j
@RequiredArgsConstructor
@Service
public class CommissionService {
    private static final String CALCULATE_COMMISSION_ERROR = "Не удалось расчитать коммиссию для документа № ";

    private final PaymentService documentService;
    private final EsbService esbService;
    private final DocumentConverter documentConverter;
    private final PricingCommissionConverter commissionConverter;
    private final PaymentOrderService paymentOrderService;
    private final PricingRbspFeignClient pricingRbspFeignClient;
    private final PricingCommissionRepository commissionRepository;

    @Value("${rbsp.tariff-codes}")
    private List<String> rbspTariffCodes;

    public AmountDTO calculateCommission(DocumentDTO doc) {
        PaymentEntity entity = documentConverter.fromDTO(doc);
        BigDecimal bisCommission = calculateBisCommission(entity);
        BigDecimal rbspCommission = calculateAndSaveCommissionRbsp(doc, bisCommission);
        boolean isTariffCodeRbsp = rbspTariffCodes.contains(doc.getTariffCode());
        if (!isTariffCodeRbsp && bisCommission == null) {
            throw new RuntimeException("Error while getting commission from bis");
        }
        return new AmountDTO().sum(isTariffCodeRbsp ? rbspCommission : bisCommission);
    }

    private BigDecimal calculateBisCommission(PaymentEntity doc) {
        try {
            CreatePaymentOrderRequestTypeEsb reqTypeForCommission = fillRequestType(
                    doc);
            reqTypeForCommission.getCreatePaymentOrderRequest().getPaymentOrder().getDocumentIndicator().setVerifyMode("T");
            CreatePaymentOrderResponseTypeEsb response;

            response = esbService.createPaymentOrder(reqTypeForCommission);
            String commission = Optional.ofNullable(response)
                    .map(CreatePaymentOrderResponseTypeEsb::getCreatePaymentOrderResponse)
                    .orElseThrow(() -> new RuntimeException(CALCULATE_COMMISSION_ERROR + doc.getNumber()))
                    .stream()
                    .findFirst().map(CreatePaymentOrderResponseTypeEsb.CreatePaymentOrderResponse::getPaymentOrder)
                    .map(PaymentOrderTypeEsb::getCommission)
                    .orElseThrow(() -> new RuntimeException(CALCULATE_COMMISSION_ERROR + doc.getNumber()));

            return new BigDecimal(commission.replaceFirst("^0+(?!$)", "")).scaleByPowerOfTen(-2);
        } catch (Exception e) {
            log.error("Error while getting commission from bis, {}", e.getMessage(), e);
            return null;
        }
    }

    private CreatePaymentOrderRequestTypeEsb fillRequestType(PaymentEntity doc) {

        CreatePaymentOrderRequestTypeEsb req
                = paymentOrderService.buildRequest(doc, "DBO");
        CreatePaymentOrderRequestTypeEsb.CreatePaymentOrderRequest orderRequest = req.getCreatePaymentOrderRequest();
        PaymentOrderTypeEsb paymentOrder = orderRequest.getPaymentOrder();
        //PRODBO-1927 необходимо дату документа передавать в бис= текущему дню
        paymentOrder.setDocumentDate(documentService.getDocumentCreationDate());
        RequisiteTypeEsb payer = paymentOrder.getPayer();
        Optional.ofNullable(payer).orElse(new RequisiteTypeEsb()).setStatus(doc.getPayerStatus());

        return req;
    }

    private BigDecimal calculateAndSaveCommissionRbsp(DocumentDTO dto, BigDecimal bisCommission) {
        PricingCommissionEntity entity = new PricingCommissionEntity();
        entity.setStartDt(OffsetDateTime.now());
        entity.setBisCommission(bisCommission);
        entity.setOrganizationBisId(Optional.ofNullable(dto.getBisId()).map(BisIdDTO::getId).orElse(null));
        try {
            CommissionRequestDTO requestDTO = commissionConverter.convert(dto);
            Response<CommissionResponseDTO> commission = pricingRbspFeignClient.getCommission(requestDTO);
            entity.setEndDt(OffsetDateTime.now());
            entity.setPricingCommission(commission.getData().getCommissionAmount());
            entity.setStatus("SUCCESS");
            commissionRepository.save(entity);
            return commission.getData().getCommissionAmount();
        } catch (Exception e) {
            log.error("Error getting commission from rbsp, {}", e.getMessage(), e);
            entity.setEndDt(OffsetDateTime.now());
            entity.setStatus("ERROR");
            entity.setErrorMsg(e.getMessage());
            commissionRepository.save(entity);
            if (bisCommission == null) {
                throw new RuntimeException("Error while getting commission from bis after rbsp error");
            }
            return bisCommission;
        }
    }
}
