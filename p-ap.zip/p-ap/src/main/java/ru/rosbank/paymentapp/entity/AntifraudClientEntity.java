package ru.rosbank.paymentapp.entity;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity(name = "antifraud_client")
public class AntifraudClientEntity {
    public static final String BLOCK_ACTIVE_OPERATION = "block_active_operations";
    public static final String REVOKE_BLOCK = "revoke_block";
    public static final String BLOCK_USER = "block_user";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(AccessLevel.NONE)
    @EqualsAndHashCode.Include
    private Long id;

    private LocalDateTime created;

    private Long clientId;
    private String resolutionId;

    private String status;
    private String crmIdNatural;
    private String crmIdLegal;
}
