package ru.rosbank.paymentapp.schedule;

import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.COMPLETED;
import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.SENT_TO_BIS;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.RejectedVtbPaymentStatusProcessor;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.exceptions.ClientNotFoundException;
import ru.rosbank.platform.redis.SharedLock;

@Slf4j
@Service
public class RejectedVtbPaymentStatusJob extends CronScheduledJob {

    private static final List<String> APPROPRIATE_STATUSES = List.of(SENT_TO_BIS.name(), COMPLETED.name());
    private static List<String> APPROPRIATE_BIC = null;
    private static final String JOB_NAME = "RejectedVTBPaymentStatusJob";

    @Autowired
    private PaymentEntityRepository paymentEntityRepository;
    @Autowired
    private SharedLock sharedLock;
    @Autowired
    private RejectedVtbPaymentStatusProcessor rejectedVTBPaymentStatusProcessor;

    @Value("${schedulers.reject-vtb-payment-status-job.lock.period:3600}")
    private int period;
    @Value("${rejected.VTBPaymentStatus.maxDeepDays:3}")
    private int maxDeepDays;
    @Value("${rejected.VTBPaymentStatus.bicsVtb}")
    private String[] bicsVtb;
    @Autowired
    UserService userService;

    public RejectedVtbPaymentStatusJob(@Value("${schedulers.reject-vtb-payment-status-job.enabled}") Boolean enable,
                                       @Value("${schedulers.reject-vtb-payment-status-job.cron}") String cronExp) {
        super(enable, cronExp);

    }

    @Override
    public void run() {
        try {
            if (APPROPRIATE_BIC == null) {
                APPROPRIATE_BIC = Arrays.asList(bicsVtb);
            }
            boolean lock = sharedLock.lock(JOB_NAME, period);
            if (lock) {
                paymentEntityRepository
                        .findAllByStatusInAndPayeeBankBicInAndExecutionDateOrSignDateAfterAndClientIdIsNotNullOrderByClientId(
                        APPROPRIATE_STATUSES, APPROPRIATE_BIC, LocalDateTime.now().minusDays(maxDeepDays)).stream()
                        .collect(Collectors.groupingBy(PaymentEntity::getClientId))
                        .forEach((clientId, paymentEntities) ->
                                rejectedVTBPaymentStatusProcessor.process(
                                        paymentEntities,
                                        userService.getClientById(clientId)
                                                .orElseThrow(() -> new ClientNotFoundException(clientId))));
                sharedLock.release(JOB_NAME);
            } else {
                log.info("Не удалось захватить управление джобой {}", JOB_NAME);
            }
        } catch (Throwable t) {
            log.error("Не удалось получить платежи джоба {}", JOB_NAME, t);
        }
    }
}
