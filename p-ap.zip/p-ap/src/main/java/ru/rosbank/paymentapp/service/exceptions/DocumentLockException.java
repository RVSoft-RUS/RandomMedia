package ru.rosbank.paymentapp.service.exceptions;


public class DocumentLockException extends Exception {

    public DocumentLockException(String msg) {
        super(msg);
    }

}
