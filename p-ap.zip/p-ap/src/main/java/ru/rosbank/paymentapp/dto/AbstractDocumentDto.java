package ru.rosbank.paymentapp.dto;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;


/**
 *                 Базовый тип для всех документов. Содержит общие данные для всех типов документов.
 *
 *              <p>id - идентификатор документа;
 *                 organizationId - идентификатор организации, к которой относится документ;
 *                 number - номер документа;
 *                 created - дата создания;
 *                 executionDate - дата исполнения платежа;
 *                 completed - дата исполнения;
 *                 amount - сумма;
 *                 status - статус;
 *                 amountString - сумма прописью;
 *                 type - тип документа;
 *                 payer - плательщик;
 *                 payee - получатель;
 *                 purpose - назначение;
 *                 rectification - уточнение платежа;
 */
@Data
public abstract class AbstractDocumentDto implements Serializable {

    protected String id;
    protected String organizationId;
    protected String number;
    protected Date created;
    protected Date executionDate;
    protected Date completed;
    protected AmountDto amount;
    protected DocumentStatusDto status;
    protected String amountString;
    protected DocumentTypeDto type;
    protected RequisiteDto payer;
    protected RequisiteDto payee;
    protected String purpose;
    protected DocumentRectificationDto rectification;

    /**
     * Default constructor.
     */
    protected AbstractDocumentDto() {
    }

    /**
     * Sets the value of {@link AbstractDocumentDto#status} and returns itself.
     *
     * @param status
     *     new value to assign to {@link AbstractDocumentDto#status}
     * @return
     *     this object
     */
    public AbstractDocumentDto withStatus(DocumentStatusDto status) {
        this.status = status;
        return this;
    }

    /**
     * Sets the value of {@link AbstractDocumentDto#type} and returns itself.
     *
     * @param type
     *     new value to assign to {@link AbstractDocumentDto#type}
     * @return
     *     this object
     */
    public AbstractDocumentDto withType(DocumentTypeDto type) {
        this.type = type;
        return this;
    }
}
