package ru.rosbank.paymentapp.service.bs;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.exceptions.ClientNotFoundException;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@RequiredArgsConstructor
@Service
public class BsService {

    private final  UserService userService;

    public ClientDTO getClient(Long id) {
        return userService.getClientById(id).orElseThrow(() -> new ClientNotFoundException(id));
    }

    public ClientDTO getClient(String dboProId) {
        return userService.getClientByDboProId(dboProId).orElseThrow(() -> new ClientNotFoundException(dboProId));
    }

}
