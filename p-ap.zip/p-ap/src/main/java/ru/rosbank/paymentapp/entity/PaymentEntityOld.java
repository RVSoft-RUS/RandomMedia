package ru.rosbank.paymentapp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Entity(name = "document_old")
public class PaymentEntityOld extends PaymentBase {
    @Id
    @Getter
    @Setter
    @EqualsAndHashCode.Include
    private Long id;

    @Override
    public String toString() {
        return super.toString()
                + "id="
                + id
                + '}';
    }
}
