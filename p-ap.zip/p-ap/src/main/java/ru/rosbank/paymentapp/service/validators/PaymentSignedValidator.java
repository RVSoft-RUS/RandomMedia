package ru.rosbank.paymentapp.service.validators;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.exceptions.UnprocessablePaymentException;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Service
@RequiredArgsConstructor
public class PaymentSignedValidator {

    public void validate(PaymentEntity document) {
        if (DocumentStatus.CREATED.name().equals(document.getStatus())) {
            return;
        }
        throw new UnprocessablePaymentException(document.getId(), "Документ уже подписан.");
    }

}
