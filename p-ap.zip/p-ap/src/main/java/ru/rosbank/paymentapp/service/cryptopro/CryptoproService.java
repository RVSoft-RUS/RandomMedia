package ru.rosbank.paymentapp.service.cryptopro;

import feign.FeignException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateDTO;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateRequestDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;

@Slf4j
@Service
public class CryptoproService {

    @Autowired
    private CryptoproAppApi cryptoproAppApi;
    public static final String DOCUMENT = "DOCUMENT";

    public List<SignatureDTO> getDocumentSignatures(PaymentEntity paymentEntity) {
        String signatureId;
        String signatureType;
        try {
            if (paymentEntity.getReferenceId() != null && paymentEntity.getReferenceType() != null) {
                signatureId = paymentEntity.getReferenceId();
                signatureType = paymentEntity.getReferenceType();
            } else {
                signatureId = paymentEntity.getId().toString();
                signatureType = DOCUMENT;
            }
            return cryptoproAppApi.signatureGet(signatureId, signatureType).getBody().stream()
                    .filter(SignatureDTO::getConfirmed).collect(Collectors.toList());
        } catch (FeignException e) {
            log.error("Ошибка получения подписей документа {} ", paymentEntity, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
    }

    public Optional<CertificateRequestDTO> getCertificateRequest(String id) {
        CertificateRequestDTO certificateRequest;
        try {
            certificateRequest = cryptoproAppApi.getCertificateRequest(id).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения названия оргранизации {} ", id, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        return Optional.of(certificateRequest);
    }

    public CertificateDTO getCertificate(String id) {
        CertificateDTO certificate;
        try {
            certificate = cryptoproAppApi.certificateIdGet(id).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения сертификата {} ", id, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }

        return certificate;
    }

}
