package ru.rosbank.paymentapp.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.Property;
import ru.rosbank.paymentapp.repository.PropertyRepository;


@RequiredArgsConstructor
@Service
public class PropertyService {

    public static final String IS_DISABLED_PROCESSING_DOCS = "IS_DISABLED_PROCESSING_DOCS";

    private final PropertyRepository propertyRepository;

    public String get(String key) {
        Optional<Property> property = propertyRepository.findByPropertyKey(key);
        return property.map(Property::getValue).orElse(null);
    }

    public Date getDate(String key, String format) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
            return simpleDateFormat.parse(this.get(key));
        } catch (Exception e) {
            return null;
        }
    }

    public Optional<Integer> getInt(String key) {
        return propertyRepository.findByPropertyKey(key)
                .map(Property::getValue)
                .map(value -> {
                    try {
                        return Integer.parseInt(value);
                    } catch (NumberFormatException e) {
                        return null;
                    }
                });
    }

    public Optional<Boolean> getBoolean(String key) {
        return propertyRepository.findByPropertyKey(key)
                .map(Property::getValue)
                .map(Boolean::parseBoolean);
    }

}
