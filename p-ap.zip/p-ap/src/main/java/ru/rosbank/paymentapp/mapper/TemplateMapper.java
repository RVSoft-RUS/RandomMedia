package ru.rosbank.paymentapp.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.paymentapp.model.Template;


@Mapper
public interface TemplateMapper {
    TemplateMapper INSTANCE = Mappers.getMapper(TemplateMapper.class);

    Template fromDTO(TemplateDTO cardDTO);

    TemplateDTO toDTO(Template cardDTO);
}
