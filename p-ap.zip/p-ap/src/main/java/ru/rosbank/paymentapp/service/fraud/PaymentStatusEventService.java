package ru.rosbank.paymentapp.service.fraud;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.AntifraudResolutionEntityRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.fraud.model.AntifraudPaymentStatusEvent;
import ru.rosbank.paymentapp.service.fraud.model.Customer;
import ru.rosbank.paymentapp.service.fraud.model.Entity;
import ru.rosbank.paymentapp.service.fraud.model.Request;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Slf4j
@RequiredArgsConstructor
@Service
public class PaymentStatusEventService extends AbstractUserEventService {
    public static final String TIMEOUT_PAYMENT_STATUS = "исполнен по timeout";
    public static final String EXECUTED_AT_ONCE_PAYMENT_STATUS = "исполнен сразу";
    public static final String REJECTED_AT_ONCE_PAYMENT_STATUS = "отклонен сразу";
    public static final String REVIEW_PAYMENT_STATUS = "приостановлен";
    public static final String EXECUTED_POST_REVIEW_PAYMENT_STATUS = "исполнен после проверки";
    public static final String REJECTED_POST_REVIEW_PAYMENT_STATUS = "отклонен после проверки";
    public static final String RECALLED_IN_REVIEW_PAYMENT_STATUS = "отклонен клиентом";
    // статусы по таймауту 1
    private static final int REJECTED_AT_ONCE_STATUS_CODE = 0;
    private static final int EXECUTED_AT_ONCE_STATUS_CODE = 1;
    private static final int POSTPONED_STATUS_CODE = 2;
    private static final int FIRST_TIMEOUT_EXECUTED_STATUS_CODE = 3;
    // статусы по таймауту 2
    private static final int SECOND_TIMEOUT_EXECUTED_STATUS_CODE = 4;
    private static final int REJECTED_STATUS_CODE = 5;
    private static final int EXECUTED_STATUS_CODE = 6;
    private static final int RECALLED_STATUS_CODE = 7;

    private final FraudSenderService fraudSenderService;
    private final AntifraudResolutionEntityRepository antifraudResolutionRepository;
    private final PaymentEntityRepository paymentEntityRepository;

    @Async("antifraud_executor")
    public void sendPaymentEvent(PaymentEntity document, PaymentStatusEvents event) {
        switch (event) {
            case ANTI_FRAUD_ALLOW:
                sendExecutedAtOnceEvent(document);
                break;
            case ANTI_FRAUD_DENY:
                sendRejectedAtOnceEvent(document);
                break;
            case ANTI_FRAUD_REVIEW:
                sendReviewEvent(document);
                break;
            case ANTI_FRAUD_ALLOW_TIMEOUT:
                sendPaymentFirstTimeoutEvent(document);
                break;
            case ANTI_FRAUD_REVIEW_TIMEOUT:
                sendPaymentSecondTimeoutEvent(document);
                break;
            case ANTI_FRAUD_ALLOW_IN_REVIEW:
                sendAllowInReviewEvent(document);
                break;
            case ANTI_FRAUD_DENY_IN_REVIEW:
                sendDenyInReviewEvent(document);
                break;
            case ANTI_FRAUD_RECALLED_IN_REVIEW:
                sendRecalledInReviewEvent(document);
                break;
            default:
                break;
        }
    }

    @Transactional
    public void checkDocumentAndSave(String info, PaymentEntity document) {
        PaymentEntity paymentEntity = document;
        Optional<PaymentEntity> documentOpt = paymentEntityRepository.findById(paymentEntity.getId());
        if (documentOpt.isPresent()) {
            paymentEntity = documentOpt.get();
        }
        paymentEntity.setStatus(DocumentStatus.RECALLED.name());
        paymentEntity.setStatusMessage(info);
        paymentEntityRepository.save(paymentEntity);
    }

    private void sendExecutedAtOnceEvent(PaymentEntity document) {
        sendEvent(document, EXECUTED_AT_ONCE_STATUS_CODE, null, EXECUTED_AT_ONCE_PAYMENT_STATUS);
    }

    private void sendRejectedAtOnceEvent(PaymentEntity document) {
        sendEvent(document, REJECTED_AT_ONCE_STATUS_CODE, null, REJECTED_AT_ONCE_PAYMENT_STATUS);
    }

    private void sendReviewEvent(PaymentEntity document) {
        sendEvent(document, POSTPONED_STATUS_CODE, null, REVIEW_PAYMENT_STATUS);
    }

    private void sendAllowInReviewEvent(PaymentEntity document) {
        sendEvent(document, POSTPONED_STATUS_CODE, EXECUTED_STATUS_CODE, EXECUTED_POST_REVIEW_PAYMENT_STATUS);
    }

    private void sendDenyInReviewEvent(PaymentEntity document) {
        sendEvent(document, POSTPONED_STATUS_CODE, REJECTED_STATUS_CODE, REJECTED_POST_REVIEW_PAYMENT_STATUS);
    }

    private void sendRecalledInReviewEvent(PaymentEntity document) {
        sendEvent(document, POSTPONED_STATUS_CODE, RECALLED_STATUS_CODE, RECALLED_IN_REVIEW_PAYMENT_STATUS);
    }

    private void sendPaymentFirstTimeoutEvent(PaymentEntity document) {
        sendTimeoutEvent(document, FIRST_TIMEOUT_EXECUTED_STATUS_CODE);
    }

    private void sendPaymentSecondTimeoutEvent(PaymentEntity document) {
        sendTimeoutEvent(document, SECOND_TIMEOUT_EXECUTED_STATUS_CODE);
    }

    private void sendTimeoutEvent(PaymentEntity document, int statusCode) {
        if (!respectUserEvent) {
            return;
        }
        AntifraudPaymentStatusEvent event = createEvent(document, TIMEOUT_PAYMENT_STATUS);
        if (statusCode < SECOND_TIMEOUT_EXECUTED_STATUS_CODE) {
            event.setStatusCodeT1(statusCode);
            event.setStatusCodeT2(null);
        } else {
            event.setStatusCodeT1(POSTPONED_STATUS_CODE);
            event.setStatusCodeT2(statusCode);
        }
        fraudSenderService.sendPaymentActionEventMessage(event);
    }

    private void sendEvent(PaymentEntity document, Integer statusCode1, Integer statusCode2, String status) {
        if (!respectUserEvent) {
            return;
        }
        AntifraudPaymentStatusEvent event = createEvent(document, status);
        event.setStatusCodeT1(statusCode1);
        event.setStatusCodeT2(statusCode2);
        fraudSenderService.sendPaymentActionEventMessage(event);
    }

    private AntifraudPaymentStatusEvent createEvent(PaymentEntity document, String status) {

        AntifraudPaymentStatusEvent request = new AntifraudPaymentStatusEvent();
        request.setId(String.valueOf(document.getId()));
        request.setStatus(status);
        request.setRequest(createStatusEventRequest(document));
        request.setCustomer(new Customer());
        request.setEntity(new Entity());

        return request;
    }

    private Request createStatusEventRequest(PaymentEntity document) {
        return antifraudResolutionRepository.findByDocumentId(document.getId())
                .map(resolution -> {
                    Request request = createRequest();
                    request.setId(resolution.getRequestId());
                    return request;
                }).orElse(createRequest());
    }

}
