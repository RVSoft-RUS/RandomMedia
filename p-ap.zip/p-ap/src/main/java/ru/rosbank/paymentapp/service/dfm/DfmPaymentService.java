package ru.rosbank.paymentapp.service.dfm;

import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.SENT_TO_BIS;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;
import ru.rosbank.paymentapp.entity.DfmBisStatus;
import ru.rosbank.paymentapp.entity.DocumentType;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.mapper.DfmSaveAlertsRequestMapper;
import ru.rosbank.paymentapp.mapper.OffsetDateTimeMapper;
import ru.rosbank.paymentapp.repository.DFMPaymentRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.SendStatusDfmToProPortalConfig;
import ru.rosbank.paymentapp.service.exceptions.PaymentValidationException;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.paymentapp.service.validators.ProPortalService;
import ru.rosbank.platform.client.portalpro.api.PortalProApiApi;
import ru.rosbank.platform.client.portalpro.model.AppRequestDfmSaveAlertsRequestAlertsInnerDTO;
import ru.rosbank.platform.client.portalpro.model.AppRequestDfmSaveAlertsRequestDTO;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Slf4j
@RequiredArgsConstructor
@Service
public class DfmPaymentService {

    private final DFMPaymentRepository dfmPaymentRepository;
    private final PaymentEntityRepository paymentEntityRepository;
    private final DfmEmailService dfmEmailService;
    private final ProPortalService proPortalService;
    private final ToYourselfPaymentService toYourselfPaymentService;
    private final PaymentEventService paymentEventService;
    private final SendStatusDfmToProPortalConfig config;
    private final PortalProApiApi portalProApiApi;
    private final DfmSaveAlertsRequestMapper dfmSaveAlertsRequestMapper;
    private final OffsetDateTimeMapper offsetDateTimeMapper;

    @Value("${paymentorder.inputUser}")
    private String inputUser;
    @Value("${dfm.payment.bis.order.user}")
    private String bisDfmProUser;
    @Value("${dfm.payment.daysOfStorage}")
    private Integer daysOfStorage;

    private static final String[] ACC_NUMBER_VALUES = new String[]{"405", "406", "407", "408"};
    private static final Set<String> ACC_NUMBER = new HashSet<>(Arrays.asList(ACC_NUMBER_VALUES));


    public boolean isProcessed(PaymentEntity document) {
        if (isDfmPayment(document)) {
            // Документ контрагенту и подлежит проверке ДФМ
            DFMPaymentEntity dfmPayment = dfmPaymentRepository.findByDocSerial(document.getId()).orElse(null);
            // проверка создана ли запись ДФМ
            if (dfmPayment != null) {
                // запись ДФМ создана
                // проверка ДФМ проверил документ и выставил флаг, при этом документ еще не был проведен:
                // дфм статус PROCESSING и у документа не заполнено поле BisDocumentId
                if (dfmPayment.getFlag() != null && dfmPayment.isProcessable()) {
                    log.debug("Документ обработан ДФМ = {}", document.getId());
                    return true;
                }
            } else {
                log.debug("Отправка в ДФМ документа = {}", document.getId());
                createDFMPayment(document);
                paymentEventService.sendDocumentStatus(document);
                if (document.getCurrencyControlEntity() != null) {
                    try {
                        proPortalService.sendCurrencyControlInfoToProPortal(document);
                    } catch (Exception e) {
                        log.error("Ошибка отправки документов по ВЭД в ПРО Портал {}", e.getMessage());
                    }
                }
            }
            return false;
        } else {
            // Отправляем в бис бюджетные платежи без проверки ДФМ
            return true;
        }
    }


    public void finalizeStatusOnSuccess(PaymentEntity document) {
        if (isDfmPayment(document)) {
            dfmPaymentRepository.findByDocSerial(document.getId())
                    .map(p -> {
                        p.setStatus(DfmBisStatus.COMPLETED.value());
                        return dfmPaymentRepository.save(p);
                    }).filter(dfm -> !dfm.getFlag().equals(1))
                    .ifPresent(dfm -> {
                        dfmEmailService.sendMailToDfm(dfm, document, false, false);
                    });
        }
    }

    public void finalizeStatusOnError(PaymentEntity document) {
        if (isDfmPayment(document)) {
            dfmPaymentRepository.findByDocSerial(document.getId())
                    .map(dfm -> {
                        dfm.setStatus(DfmBisStatus.ERROR.value());
                        return dfmPaymentRepository.save(dfm);
                    }).filter(dfm -> !dfm.getFlag().equals(1))
                    .ifPresent(dfm -> {
                        dfmEmailService.sendMailToDfm(dfm, document, true, false);
                    });
        }
    }

    public String getInputUser(PaymentEntity document) {
        if (isDfmPayment(document)) {
            return dfmPaymentRepository
                    .findByDocSerial(document.getId())
                    .map(DFMPaymentEntity::getFlag)
                    .map(flag -> flag == 1 || flag == 3 ? inputUser : bisDfmProUser)
                    .orElseThrow(() -> new PaymentValidationException(document.getId(),
                            "Отсутствует запись в таблице ДФМ для документа "));
        } else {
            return inputUser;
        }
    }

    private void createDFMPayment(PaymentEntity doc) {
        DFMPaymentEntity createDfm = new DFMPaymentEntity(doc, LocalDateTime.now());
        DFMPaymentEntity dfmPayment = dfmPaymentRepository.save(createDfm);
        log.debug("DFM payment created [id={}]", dfmPayment.getId());
        doc.setStatus(DocumentStatus.DFM_PROCESSING.name());
        paymentEntityRepository.save(doc);
        log.debug("Changed status on DFM_PROCESSING for document [id={}]", doc.getId());
    }

    private boolean isDfmPayment(PaymentEntity document) {
        if (StringUtils.isNotBlank(document.getDoctype())) {
            DocumentType doctype = DocumentType.fromValue(document.getDoctype());
            if (DocumentType.DE.equals(doctype) || DocumentType.DH.equals(doctype)
                    || 'C' == doctype.name().charAt(0)) {
                return false;
            }
        } else {
            return false;
        }

        if (toYourselfPaymentService.isToYourself(document)) {
            return false;
        }

        if (StringUtils.isNotBlank(document.getPayerAccount())) {
            String acc3 = document.getPayerAccount().substring(0, 3);
            return ACC_NUMBER.contains(acc3);
        }
        return false;
    }

    public void deleteOutdatedCompleted() {
        dfmPaymentRepository.deleteByFlagNotNullAndIdateBeforeAndStatus(getDateDaysOfStorage(),
                DfmBisStatus.COMPLETED.value());
    }

    private LocalDateTime getDateDaysOfStorage() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.add(Calendar.DATE, -(daysOfStorage + 1));
        return new java.sql.Timestamp(calendar.getTime().getTime()).toLocalDateTime();
    }


    public AppRequestDfmSaveAlertsRequestDTO getAppRequestDfmSaveAlertsRequest() {

        List<DFMPaymentEntity> dfmPayments = dfmPaymentRepository.findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(
                1, LocalDateTime.now().minusHours(config.getHourAgo()));
        List<Long> ids = dfmPayments.stream().map(DFMPaymentEntity::getDocSerial).collect(Collectors.toList());
        Map<Long, DFMPaymentEntity> dfmMap = new HashMap<>();
        dfmPayments.forEach(d -> dfmMap.put(d.getDocSerial(), d));
        List<PaymentEntity> paymentEntities = paymentEntityRepository.findAllByStatusAndIdIn(SENT_TO_BIS.name(), ids);

        AppRequestDfmSaveAlertsRequestDTO alertsRequestDTO = new AppRequestDfmSaveAlertsRequestDTO();
        alertsRequestDTO.alerts(paymentEntities.stream().filter(p -> dfmMap.containsKey(p.getId())).map(p ->
                buildAppRequestDfmSaveAlertsRequest(dfmMap.get(p.getId()), p)).collect(Collectors.toList()));

        return alertsRequestDTO;
    }

    private AppRequestDfmSaveAlertsRequestAlertsInnerDTO buildAppRequestDfmSaveAlertsRequest(DFMPaymentEntity dfm,
                                                                                             PaymentEntity payment) {
        AppRequestDfmSaveAlertsRequestAlertsInnerDTO alert = dfmSaveAlertsRequestMapper.toAlert(payment);

        alert.setIdPayment(dfm.getId().toString());
        alert.setiDate(offsetDateTimeMapper.toDate(dfm.getIdate().atZone(ZoneId.systemDefault()).toOffsetDateTime()));
        alert.setInf(dfm.getInf());

        return alert;
    }

    public void sendDocumentAlertsToProPortal(AppRequestDfmSaveAlertsRequestDTO alerts) {
        try {
            log.debug(alerts.getAlerts().toString());
            portalProApiApi.appDfmAlertsPut(alerts);
        } catch (Exception e) {
            log.error("sendDocumentAlertsToProPortal = " + alerts.getAlerts().stream()
                    .map(AppRequestDfmSaveAlertsRequestAlertsInnerDTO::getIdPayment)
                    .collect(Collectors.toList()).toString(), e);
            throw e;
        }
    }
}
