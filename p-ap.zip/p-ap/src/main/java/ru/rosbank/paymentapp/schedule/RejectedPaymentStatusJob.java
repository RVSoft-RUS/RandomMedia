package ru.rosbank.paymentapp.schedule;

import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.DFM_PROCESSING;
import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.ERROR;
import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.PROCESSING;
import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.REVIEW;
import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.SENT_TO_BIS;

import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.RejectedPaymentStatusProcessor;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.service.exceptions.ClientNotFoundException;
import ru.rosbank.platform.redis.SharedLock;

@Slf4j
@Service
public class RejectedPaymentStatusJob extends CronScheduledJob {

    private static final List<String> APPROPRIATE_STATUSES = List.of(
            DFM_PROCESSING.name(), SENT_TO_BIS.name(), ERROR.name(),
            PROCESSING.name(), REVIEW.name());
    private static final String JOB_NAME = "RejectedPaymentStatusJob";

    @Value("${rejected.VTBPaymentStatus.bicsVtb}")
    private List<String> bicsVtb;

    @Autowired
    private PaymentEntityRepository paymentEntityRepository;
    @Autowired
    private SharedLock sharedLock;
    @Autowired
    private RejectedPaymentStatusProcessor rejectedPaymentStatusProcessor;
    @Autowired
    UserService userService;

    @Value("${schedulers.reject-payment-status-job.lock.period}")
    private int period;

    public RejectedPaymentStatusJob(@Value("${schedulers.reject-payment-status-job.enabled}") Boolean enable,
                                    @Value("${schedulers.reject-payment-status-job.cron}") String cronExp) {
        super(enable, cronExp);
    }

    @Override
    public void run() {
        try {
            boolean lock = sharedLock.lock(JOB_NAME, period);
            if (lock) {
                paymentEntityRepository
                        .findAllByStatusInAndClientIdIsNotNullAndPayeeBankBicNotInOrderByClientId(APPROPRIATE_STATUSES, bicsVtb)
                        .stream()
                        .collect(Collectors.groupingBy(PaymentEntity::getClientId))
                        .forEach((clientId, paymentEntities) ->
                                rejectedPaymentStatusProcessor.process(
                                        paymentEntities,
                                        userService.getClientById(clientId)
                                        .orElseThrow(() -> new ClientNotFoundException(clientId))));
                sharedLock.release(JOB_NAME);
            } else {
                log.info("Не удалось захватить управление джобой {}", JOB_NAME);
            }
        } catch (Throwable t) {
            log.error("Не удалось получить платежи джоба {}", JOB_NAME, t);
        }
    }
}
