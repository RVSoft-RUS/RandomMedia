package ru.rosbank.paymentapp.service.exceptions;

public class BackendException extends RuntimeException {

    private static final long serialVersionUID = -1L;

    private String code;

    private boolean system;

    private String description;

    public BackendException(String message) {
        super(message);
    }

    public BackendException(String message, Throwable cause) {
        super(message, cause);
    }

    public BackendException(String message, String code, boolean system) {
        super(message);
        this.code = code;
        this.system = system;
    }

    public BackendException(String message, Throwable cause, String code, boolean system) {
        super(message, cause);
        this.code = code;
        this.system = system;
    }

    public BackendException(String message, Throwable cause, String code, boolean system, String description) {
        super(message, cause);
        this.code = code;
        this.system = system;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public boolean isSystem() {
        return system;
    }

    public String getDescription() {
        return description;
    }
}
