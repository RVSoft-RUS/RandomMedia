package ru.rosbank.paymentapp.service.fraud.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude()
public class DocumentStatusEvent extends AbstractEvent {

    @JsonProperty("pay_id")
    private String payId;
    @JsonProperty("pay_status")
    private String payStatus;
    @JsonProperty("pay_status_datetime")
    private Date payStatusDatetime;
    @JsonProperty("pay_client_id")
    private String payClientId;
    @JsonProperty("pay_amount")
    private String payAmount;
    @JsonProperty("pay_currency")
    private String payCurrency;
    @JsonProperty("pay_account_sender")
    private String payAccountSender;
    @JsonProperty("pay_account_recipient")
    private String payAccountRecipient;
    @JsonProperty("pay_type")
    private String payType;
    @JsonProperty("pay_datetime")
    private String payDatetime;
    @JsonProperty("pay_reference_id")
    private String payReferenceId;
    @JsonProperty("pay_reference_client_id")
    private String payReferenceClientId;
    @JsonProperty("pay_reference_branch")
    private String payReferenceBranch;
    @JsonProperty("pay_BIC_sender")
    private String payBICSender;
    @JsonProperty("pay_BIC_recipient")
    private String payBICRecipient;

}
