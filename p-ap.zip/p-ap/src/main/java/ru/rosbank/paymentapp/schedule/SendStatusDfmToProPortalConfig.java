package ru.rosbank.paymentapp.schedule;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties("schedulers.send-status-dfm-job")
@Component
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SendStatusDfmToProPortalConfig {
    boolean enable = true;
    int lockTimePeriod = 300;
    int hourAgo = 5;
}
