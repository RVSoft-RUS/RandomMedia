package ru.rosbank.paymentapp.service.fraud.model.constant;

public enum EventType {
    PAYMENT,
    DBO_EVENT,
    PAYMENT_STATUS
}
