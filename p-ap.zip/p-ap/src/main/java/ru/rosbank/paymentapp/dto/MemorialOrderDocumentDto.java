package ru.rosbank.paymentapp.dto;

import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 *                 Мемориальный ордер
 *
 *              <p>valueDate - Дата валютирования
 *                 orderStampSinger - Составитель
 *                 content - Содержание операции, наименование, номер и дата документа, на основании которого
 *                 составлен мемориальный ордер
 *                 ITMTransId - Референс
 *
 * <p>Java class for MemorialOrderDocument complex type.
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MemorialOrderDocumentDto extends AbstractDocumentDto {

    protected Date valueDate;
    protected String content;
    protected String orderStampSinger;
    protected BankInfoDto processedBy;
    protected String itmTransId;
}
