package ru.rosbank.paymentapp.repository;

import org.springframework.data.repository.CrudRepository;
import ru.rosbank.paymentapp.entity.ImportedDocumentEntityOld;
import ru.rosbank.paymentapp.entity.PaymentEntity;



public interface ImportedDocumentRepositoryOld extends CrudRepository<ImportedDocumentEntityOld, Long> {

    void deleteByDocument(PaymentEntity paymentEntity);
}
