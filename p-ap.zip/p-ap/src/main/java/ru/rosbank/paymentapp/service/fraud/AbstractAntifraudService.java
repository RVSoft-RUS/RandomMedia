package ru.rosbank.paymentapp.service.fraud;

import org.springframework.beans.factory.annotation.Value;

public abstract class AbstractAntifraudService {

    protected static final String OS_TYPE_ANDROID = "ANDROID";
    protected static final String OS_TYPE_IOS = "IOS";

    @Value("${anti-fraud.review.timeout}")
    Integer reviewTimeoutDays;

}
