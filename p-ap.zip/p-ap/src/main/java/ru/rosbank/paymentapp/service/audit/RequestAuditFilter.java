package ru.rosbank.paymentapp.service.audit;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

@Component
public class RequestAuditFilter implements Filter {

    public static final String IP = "ip";
    public static final String DEVICE_ID = "device-id";
    public static final String PLATFORM = "platform";
    public static final String MACADDRESS = "macaddress";
    public static final String SESSION_ID = "session-id";
    public static final String USER_AGENT = "User-Agent";
    public static final String APP_VERSION = "app-version";
    public static final String COMPANY_INN = "company-inn";
    public static final String BIS_COMPANY_ID = "bis-company-id";
    public static final String CRM_COMPANY_ID = "crm-company-id";

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response, FilterChain chain) throws IOException, ServletException {
        AuditContext context = createAuditContext((HttpServletRequest) request);
        ThreadLocalAuditContext.set(context);
        chain.doFilter(request, response);
    }

    private AuditContext createAuditContext(HttpServletRequest request) {

        AuditContext auditContext = new AuditContext();
        auditContext.setSessionId(request.getHeader(SESSION_ID));
        auditContext.setDeviceId(request.getHeader(DEVICE_ID));
        auditContext.setIp(request.getHeader(IP));
        auditContext.setUserAgent(request.getHeader(USER_AGENT));
        auditContext.setPlatform(request.getHeader(PLATFORM));
        auditContext.setApplicationVersion(request.getHeader(APP_VERSION));
        auditContext.setServerId(request.getServerName());
        auditContext.setMacAddress(request.getHeader(MACADDRESS));
        auditContext.setCompanyInn(request.getHeader(COMPANY_INN));
        auditContext.setBisCompanyId(request.getHeader(BIS_COMPANY_ID));
        auditContext.setCrmCompanyId(request.getHeader(CRM_COMPANY_ID));

        return auditContext;
    }
}
