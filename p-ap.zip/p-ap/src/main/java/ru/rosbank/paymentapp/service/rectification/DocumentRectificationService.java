package ru.rosbank.paymentapp.service.rectification;


import static ru.rosbank.paymentapp.entity.DocumentRectification.DocumentRectificationStatus.ACTIVE;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.DocumentRectification;
import ru.rosbank.paymentapp.mapper.RectificationMapper;
import ru.rosbank.paymentapp.repository.DocumentRectificationRepository;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.paymentapp.service.exceptions.ValidationException;
import ru.rosbank.paymentapp.util.DocumentUtils;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;

@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentRectificationService {

    private final DocumentRectificationRepository documentRectificationRepository;


    public RectificationDTO register(RectificationDTO documentRectificationDto) {

        DocumentRectification document;
        try {
            document = createDocument(RectificationMapper.INSTANCE.fromDTO(documentRectificationDto));
        } catch (DataIntegrityViolationException e) {
            throw new ValidationException("Уточнение для документа id="
                    + documentRectificationDto.getDocumentId() + " уже создано.");
        }

        return RectificationMapper.INSTANCE.toDTO(document);
    }

    public void processDocument(Long id) {

        try {
            DocumentRectification documentRectification = findById(id);
            documentRectification.setStatus(ACTIVE.name());
            documentRectificationRepository.save(documentRectification);

        } catch (Exception e) {
            log.error("Ошибка уточнения реквизитов документа RectificationID=" + id, e);
            throw e;
        }

    }

    public RectificationDTO getRectificationById(Long id) {

        return RectificationMapper.INSTANCE.toDTO(findById(id));
    }

    public DocumentRectification findById(Long id) {
        Optional<DocumentRectification> odoc = documentRectificationRepository.findById(id);
        if (odoc.isPresent()) {
            return odoc.get();
        } else {
            log.error("Не найдено уточнение реквизитов платежа RectificationID=" + id);
            throw new ValidationException("Не найдено уточнение реквизитов платежа RectificationID=" + id);
        }

    }


    public List<RectificationDTO> findAllByDocumentIdAndStatus(List<String> ids) {
        if (ids != null) {
            List<DocumentRectification> documentRectificationList =
                    documentRectificationRepository.findAllDocumentRectificationByDocumentIdInAndStatus(ids, ACTIVE.name());
            if (CollectionUtils.isNotEmpty(documentRectificationList)) {
                return documentRectificationList
                        .stream()
                        .map(RectificationMapper.INSTANCE::toDTO)
                        .collect(Collectors.toList());
            } else {
                log.debug("Не найдены уточнения реквизитов платежей Collection empty");
                List<RectificationDTO> documentRectificationEmptyList =
                        Collections.emptyList();
                return documentRectificationEmptyList;
            }
        } else {
            log.error("Параметр метода findAllById равен null");
            throw new BackendException("Параметр метода findAllById равен null");
        }
    }

    private DocumentRectification createDocument(DocumentRectification documentRectification) {
        documentRectification.setStatus(DocumentRectification.DocumentRectificationStatus.CREATED.toString());
        documentRectification.setCreated(new Date());
        return documentRectificationRepository.save(documentRectification);
    }

    public RectificationDTO getActiveDocumentRectificationByBisId(String bisId) {
        RectificationDTO documentRectificationDto = null;
        Optional<DocumentRectification> odocument =
                documentRectificationRepository.findDocumentRectificationByDocumentIdAndStatus(bisId, ACTIVE.name());
        if (odocument.isEmpty()) {
            odocument = documentRectificationRepository.findDocumentRectificationByDocumentIdAndStatus(
                    DocumentUtils.replaceBisId(bisId), ACTIVE.name());
        }

        if (odocument.isPresent()) {
            documentRectificationDto = RectificationMapper.INSTANCE.toDTO(odocument.get());
        }

        return documentRectificationDto;
    }
}
