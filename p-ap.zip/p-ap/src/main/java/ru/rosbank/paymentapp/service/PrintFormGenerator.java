package ru.rosbank.paymentapp.service;

import static java.util.Map.entry;

import freemarker.template.Configuration;
import freemarker.template.TemplateException;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import ru.rosbank.paymentapp.dto.AbstractDocumentDto;
import ru.rosbank.paymentapp.dto.AccountCashWarrantDocumentDto;
import ru.rosbank.paymentapp.dto.BankOrderDocumentDto;
import ru.rosbank.paymentapp.dto.CashReceiptOrderDocumentDto;
import ru.rosbank.paymentapp.dto.CollectionAssignmentDocumentDto;
import ru.rosbank.paymentapp.dto.MemorialOrderDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentAssignmentDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentBillDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentOrderDocumentDto;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.paymentapp.util.DocumentUtils;
import ru.rosbank.platform.utils.FormatUtils;
import ru.rosbank.platform.utils.pdf.template.TemplateMerger;
import ru.rosbank.platform.utils.pdf.template.impl.FreeMarkerTemplateEngine;

//Imported from bs-app
@Service
public class PrintFormGenerator {

    private static final String TEMPLATES_PATH = "templates/";
    private static final String DOCUMENT_PATH = "templates/document/";
    //todo там еще и лого старое... это точно работало?
    private static final String ROSBANK_LOGO_RELATIVE_PATH = "img/bankLogo.png";
    private static final Map<String, Object> COMMON_TEMPLATE_PARAMETERS = Map.ofEntries(
            entry("formatter", new FormatUtils()));

    public String generatePaymentHtml(AbstractDocumentDto documentDto) throws TemplateException, IOException {
        TemplateMerger merger = newFreeMarkerTemplateMerger()
                .template(DOCUMENT_PATH + getTemplateByDocument(documentDto))
                .parameters(COMMON_TEMPLATE_PARAMETERS)
                .parameter("paymentDocument", documentDto)
                .parameter("documentUtils", new DocumentUtils());
        return merger.merge();
    }

    public List<Resource> createEmailInlineResources() {
        return Collections.singletonList(
                new DefaultResourceLoader().getResource(TEMPLATES_PATH + ROSBANK_LOGO_RELATIVE_PATH));
    }

    public String buildEmailPlainTextMessage(AbstractDocumentDto document, String reference)
            throws TemplateException, IOException {
        return buildEmailPart(document, reference, "documentBrief.txt.ftl");
    }

    public String buildEmailMessage(AbstractDocumentDto document, String reference) throws TemplateException, IOException {
        return buildEmailPart(document, reference, "documentBrief.html.ftl");
    }

    public String getTitle(AbstractDocumentDto document) {
        if (document instanceof PaymentOrderDocumentDto) {
            return "Платёжный ордер № ";
        } else if (document instanceof PaymentAssignmentDocumentDto) {
            if (StringUtils.isNotBlank(((PaymentAssignmentDocumentDto) document).getCardPan())) {
                return "Операция по карте";
            } else {
                return "Платёжное поручение № ";
            }
        } else if (document instanceof BankOrderDocumentDto) {
            return "Банковский ордер № ";
        } else if (document instanceof MemorialOrderDocumentDto) {
            return "МЕМОРИАЛЬНЫЙ ОРДЕР № ";
        } else if (document instanceof PaymentBillDocumentDto) {
            return "ПЛАТЕЖНОЕ ТРЕБОВАНИЕ № ";
        } else if (document instanceof AccountCashWarrantDocumentDto) {
            return "РАСХОДНЫЙ КАССОВЫЙ ОРДЕР № ";
        } else if (document instanceof CashReceiptOrderDocumentDto) {
            return "ПРИХОДНЫЙ КАССОВЫЙ ОРДЕР № ";
        } else if (document instanceof CollectionAssignmentDocumentDto) {
            return "ИНКАССОВОЕ ПОРУЧЕНИЕ № ";
        } else {
            return "";
        }
    }

    private String buildEmailPart(AbstractDocumentDto document, String reference, String templateName)
            throws TemplateException, IOException {
        Message message = new Message(document, getTitle(document), reference);
        TemplateMerger merger = newFreeMarkerTemplateMerger()
                .template(DOCUMENT_PATH + templateName)
                .parameters(COMMON_TEMPLATE_PARAMETERS)
                .parameter("msg", message);
        return merger.merge();
    }

    private TemplateMerger newFreeMarkerTemplateMerger() throws TemplateException, IOException {
        FreeMarkerConfigurationFactoryBean configurationFactoryBean = new FreeMarkerConfigurationFactoryBean();
        configurationFactoryBean.setPreferFileSystemAccess(false);
        configurationFactoryBean.setDefaultEncoding("UTF-8");
        return new TemplateMerger(getFreeMarkerTemplateEngine(configurationFactoryBean.createConfiguration()));
    }

    private FreeMarkerTemplateEngine getFreeMarkerTemplateEngine(Configuration freeMarkerConfiguration) {
        FreeMarkerTemplateEngine freeMarkerTemplateEngine = new FreeMarkerTemplateEngine(freeMarkerConfiguration);
        freeMarkerConfiguration.setClassForTemplateLoading(this.getClass(), "/templates/");
        return freeMarkerTemplateEngine;
    }

    public String getTemplateByDocument(AbstractDocumentDto documentDto) {
        if (documentDto instanceof PaymentOrderDocumentDto) {
            return "paymentOrder.html.ftl";
        } else if (documentDto instanceof PaymentAssignmentDocumentDto) {
            if (StringUtils.isNotBlank(((PaymentAssignmentDocumentDto) documentDto).getCardPan())) {
                return "cardOperation.html.ftl";
            } else if (DocumentUtils.isRejectedOrRecalled(documentDto)) {
                return "paymentAssignmentWithComment.html.ftl";
            } else {
                return "paymentAssignment.html.ftl";
            }
        } else if (documentDto instanceof BankOrderDocumentDto) {
            return "bankingOrder.html.ftl";
        } else if (documentDto instanceof MemorialOrderDocumentDto) {
            return "memorialOrder.html.ftl";
        } else if (documentDto instanceof PaymentBillDocumentDto) {
            if (DocumentUtils.isCredit(documentDto)) {
                return "paymentRequestCredit.html.ftl";
            } else {
                return "paymentRequestDebit.html.ftl";
            }
        } else if (documentDto instanceof CollectionAssignmentDocumentDto) {
            if (DocumentUtils.isCredit(documentDto)) {
                return "collectionOrderCredit.html.ftl";
            } else {
                return "collectionOrderDebit.html.ftl";
            }
        } else {
            throw new BackendException("Для документа с типом "
                    + documentDto.getClass().getSimpleName().replace("Dto", "")
                    + " не предусмотрена печатная форма.");
        }
    }

    @AllArgsConstructor
    @Data
    public static class Message {
        private AbstractDocumentDto document;
        private String title;
        private String reference;
    }
}
