package ru.rosbank.paymentapp.esb.service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Optional;
import java.util.TimeZone;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.esb.support.BankProcessingException;
import ru.rosbank.paymentapp.esb.support.CreatePaymentOrderRequestBuilder;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.EsbService;
import ru.rosbank.paymentapp.service.PaymentOrderLogService;
import ru.rosbank.paymentapp.service.PaymentService;
import ru.rosbank.paymentapp.service.dfm.DfmPaymentService;
import ru.rosbank.paymentapp.service.exceptions.CreatePaymentResponseProcessingException;
import ru.rosbank.paymentapp.service.exceptions.DocumentContentDifferentException;
import ru.rosbank.paymentapp.service.exceptions.SendToBisPaymentException;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.paymentapp.service.sms.SendSmsService;
import ru.rosbank.paymentapp.service.validators.DocumentValidator;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.BankTypeEsb;
import ru.rosbank.platform.esb.model.common.MoneyAmountTypeEsb;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderRequestTypeEsb;
import ru.rosbank.platform.esb.model.createpaymentorder.CreatePaymentOrderResponseTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.DocumentIndicatorTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.TaxDataTypeEsb;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

@Slf4j
@RequiredArgsConstructor
@Service
@Data
public class PaymentOrderService {

    private static final int STATUS_MESSAGE_MAX_LENGTH = 260;
    private static final String OPERATION_TYPE_PAYMENT_ASSIGNMENT = "01";
    private static final String STATUS_MESSAGE_TECHNICAL_PROBLEMS = "Операция недоступна по техническим причинам.";

    @Value("${paymentorder.bis.user}")
    private String bisUser;
    @Value("${paymentorder.controlUser}")
    private String controlUser;
    @Value("${paymentorder.isNewFieldsEnable}")
    private boolean isNewFieldsEnable;
    @Value("${payment.systems-active}")
    private boolean isSystemsActive;

    @Autowired
    private SendSmsService sendSmsService;

    private final PaymentService documentService;
    private final DfmPaymentService dfmPaymentService;
    private final EsbService esbService;
    private final PaymentEntityRepository documentRepository;
    private final DocumentValidator documentValidator;
    private final PaymentOrderLogService paymentOrderLogService;
    private final PaymentEventService paymentEventService;

    public boolean createPaymentOrderInBis(PaymentEntity document) {

        try {
            documentValidator.validateDocumentContent(document);
            log.debug("Пройдены проверки документа перед отправкой в БИС {}", document.getId());
            if (!paymentOrderLogService.savePaymentOrderLog(document.getId())) {
                log.error("Документ не содержит рефференс проводки, но уже отправлен в шину {}", document.getId());
                return false;
            }
            String bisDocumentId = process(document);
            try {
                document.setStatus(DocumentStatus.SENT_TO_BIS.toString());
                document.setBisDocumentId(bisDocumentId);
                documentRepository.save(document);
                log.info("Документ создан в БИС {}", document.getId());
                paymentEventService.sendDocumentStatus(document);
            } catch (Exception e) {
                throw new SendToBisPaymentException(e.getMessage(), e);
            }
            return true;
        } catch (BankProcessingException exception) {
            document.setStatus(DocumentStatus.REJECTED.toString());
            paymentEventService.sendDocumentStatus(document);
            document.setShowError(true);
            document.setStatusMessage(exception.getRuMessage());
            sendSmsService.sendSmsTechnicalProblemsForPayment(document);
            log.error(exception.getMessage(), exception);
        } catch (DocumentContentDifferentException | ValidationPaymentException e) {
            document.setStatus(DocumentStatus.REJECTED.toString());
            paymentEventService.sendDocumentStatus(document);
            document.setStatusMessage(e.getMessage());
            log.error("Ошибка обработки платежа", e);
            document.setShowError(true);
            sendSmsService.sendSmsTechnicalProblemsForPayment(document);
        } catch (SendToBisPaymentException e) {
            document.setStatus(DocumentStatus.ERROR.toString());
            String statusMessage;
            if (e.getMessage() != null && e.getMessage().length() > STATUS_MESSAGE_MAX_LENGTH) {
                statusMessage = e.getMessage().substring(0, STATUS_MESSAGE_MAX_LENGTH);
            } else {
                statusMessage = e.getMessage();
            }
            document.setStatusMessage(statusMessage);
            log.error(e.getMessage(), e);
            log.error("Платеж положен в шину, в процессе произошла ошибка или разрыв сети id = " + document.getId());
        } catch (Exception e) {
            if (isSystemsActive) {
                document.setStatus(DocumentStatus.REJECTED.toString());
                paymentEventService.sendDocumentStatus(document);
                document.setStatusMessage(STATUS_MESSAGE_TECHNICAL_PROBLEMS);
                document.setShowError(true);
                documentRepository.save(document);
                sendSmsService.sendSmsTechnicalProblemsForPayment(document);
            }
            log.error(e.getMessage(), e);
        }
        documentRepository.save(document);
        log.debug("Документ сохранен: {}", document);
        return false;
    }

    private String process(PaymentEntity document) {

        CreatePaymentOrderRequestTypeEsb request = buildRequest(document, dfmPaymentService.getInputUser(document));
        LocalDateTime localDateTimeToSend = document.getExecutionDate() != null
                ? document.getExecutionDate()
                : document.getDate();
        Date dateToSend = Date.from(localDateTimeToSend.atZone(ZoneId.systemDefault()).toInstant());
        request.getCreatePaymentOrderRequest()
                .getPaymentOrder().setDocumentDate(new Date(dateToSend.getTime() + TimeZone.getDefault().getRawOffset() + 1));

        log.debug("Отправка запроса на создание документа в БИС {}", document.getId());

        try {
            CreatePaymentOrderResponseTypeEsb response = esbService.createPaymentOrder(request);
            return  response.getCreatePaymentOrderResponse().stream().findFirst()
                    .map(CreatePaymentOrderResponseTypeEsb.CreatePaymentOrderResponse::getPaymentOrder)
                    .map(PaymentOrderTypeEsb::getDocumentID)
                    .map(id -> id.trim() + OPERATION_TYPE_PAYMENT_ASSIGNMENT)
                    .orElseThrow(() -> new CreatePaymentResponseProcessingException(document.getId()));
        }  catch (BankProcessingException ex) {
            throw ex;
        } catch (Exception e) {
            throw new SendToBisPaymentException(e.getMessage(), e);
        }
    }

    public CreatePaymentOrderRequestTypeEsb buildRequest(PaymentEntity doc, String inputUser) {

        CreatePaymentOrderRequestTypeEsb.CreatePaymentOrderRequest req
                = new CreatePaymentOrderRequestTypeEsb.CreatePaymentOrderRequest();
        req.setUser(bisUser);
        req.setBranch(doc.getOrganizationBisBranch());

        PaymentOrderTypeEsb paymentOrder = new PaymentOrderTypeEsb();
        paymentOrder.setDocumentType("01");
        paymentOrder.setInputUser(inputUser);
        paymentOrder.setOrderNumber(doc.getNumber());

        RequisiteTypeEsb payer = new RequisiteTypeEsb();
        payer.setNumber(new AccountNumberTypeEsb().withAccountNumber20Digit(doc.getPayerAccount()));
        payer.setPayerName(doc.getPayerName());
        payer.setKPP(doc.getPayerKpp());
        if ("0".equals(doc.getPayerKpp())) {
            payer.setKPP(null);
        }
        payer.setINN(doc.getPayerInn());
        payer.setPersonalAccount(doc.getPayerAccount());
        payer.setPayerBank(new BankTypeEsb());
        payer.getPayerBank().setBIK(doc.getPayerBankBic());

        paymentOrder.setPayer(payer);

        RequisiteTypeEsb payee = new RequisiteTypeEsb();
        payee.setPayerBank(new BankTypeEsb().withBik(doc.getPayeeBankBic())
                        .withCorrespondentAccount(doc.getPayeeBankCorrespondentAccount())
        );
        payee.setNumber(new AccountNumberTypeEsb().withAccountNumber20Digit(doc.getPayeeAccount()));
        payee.setINN(doc.getPayeeInn());
        payee.setPayerName(doc.getPayeeName());

        paymentOrder.setPayee(payee);

        paymentOrder.setDocumentAuthorStatus(doc.getPayerStatus());

        TaxDataTypeEsb taxData = new TaxDataTypeEsb();
        taxData.setRecipientKpp(doc.getPayeeKpp());
        taxData.setKbkCode(doc.getKbk());
        taxData.setTaxPeriod(doc.getTaxPeriod());
        taxData.setDocNumber(doc.getBasisDocumentNumber());
        taxData.setPaymentReason(doc.getPaymentBasis());
        taxData.setCode22(doc.getUin());
        taxData.setOkatoCode(doc.getOktmo());
        if (StringUtils.isNotBlank(doc.getBasisDocumentCreated())) {
            taxData.setDocDate(doc.getBasisDocumentCreated());
        }
        taxData.setPayerKpp(doc.getPayerKpp());
        if (isNewFieldsEnable) {
            if (doc.getTypeTaxPayment() != null && doc.getTypeTaxPayment()) {
                taxData.setPaymentType("1");
            }
            if (doc.getCodeTypeIncome() != null && doc.getCodeTypeIncome() != 0) {
                paymentOrder.setTypeIncome(doc.getCodeTypeIncome().toString());
            }
        }
        paymentOrder.setTaxData(taxData);

        // TODO: межбанк?
        DocumentIndicatorTypeEsb docIndicator = new DocumentIndicatorTypeEsb();
        docIndicator.setInterbankPayment("Y");
        docIndicator.setExecutionMode("N");
        docIndicator.setInputSystem("C");
        paymentOrder.setDocumentIndicator(docIndicator);

        paymentOrder.setExternalOrderNumber(doc.getNumber());

        MoneyAmountTypeEsb moneyAmount = new MoneyAmountTypeEsb();
        moneyAmount.setAmount(doc.getAmount().movePointRight(2));
        moneyAmount.setCurrencyCode("RUR");
        paymentOrder.setAmount(moneyAmount);
        paymentOrder.setPurpose(doc.getPurpose());

        paymentOrder.setDataOperation("BC-1234");
        paymentOrder.setInetCoefficient("1");
        paymentOrder.setControlUser(controlUser);

        paymentOrder.setSubtypeOperation(Integer.valueOf(Optional.ofNullable(doc.getPaypriority()).orElse("5")).toString());

        req.setPaymentOrder(paymentOrder);

        CreatePaymentOrderRequestTypeEsb reqType = new CreatePaymentOrderRequestBuilder().build();
        reqType.setCreatePaymentOrderRequest(req);

        return reqType;
    }

}
