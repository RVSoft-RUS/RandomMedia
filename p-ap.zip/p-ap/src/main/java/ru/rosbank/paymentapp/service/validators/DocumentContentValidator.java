package ru.rosbank.paymentapp.service.validators;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.cryptopro.CryptoproService;
import ru.rosbank.paymentapp.service.exceptions.DocumentContentDifferentException;
import ru.rosbank.paymentapp.util.DocumentUtils;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.server.paymentapp.model.Document;
import ru.rosbank.platform.server.paymentapp.model.Requisite;

@RequiredArgsConstructor
@Service
public class DocumentContentValidator {
    private static final String ERROR_MESSAGE = "Подпись не соответствует документу";

    @Value("${feature.doc-content-validator}")
    private boolean isValidatorEnabled;

    private final CryptoproService cryptoproService;

    public void validate(PaymentEntity documentToCheck) throws DocumentContentDifferentException {
        if (!isValidatorEnabled) {
            return;
        }

        Document document = cryptoproService.getDocumentSignatures(documentToCheck)
                .stream()
                .findFirst()
                .map(SignatureDTO::getResult)
                .map(DocumentUtils::stringToDocument)
                .orElse(null);

        //TODO add validation. DocumentUtils::stringToDocument always returns null
        if (document == null) {
            return;
        }

        if (!documentToCheck.getPayerAccount().equals(Optional.ofNullable(document.getPayer())
                .map(Requisite::getAccount)
                .orElse(null))) {
            throw new DocumentContentDifferentException(ERROR_MESSAGE);
        }
        if (!documentToCheck.getPayeeAccount().equals(Optional.ofNullable(document.getPayee())
                .map(Requisite::getAccount)
                .orElse(null))) {
            throw new DocumentContentDifferentException(ERROR_MESSAGE);
        }
        if (!documentToCheck.getAmount().toString().equals(document.getAmount())) {
            throw new DocumentContentDifferentException(ERROR_MESSAGE);
        }
    }

}
