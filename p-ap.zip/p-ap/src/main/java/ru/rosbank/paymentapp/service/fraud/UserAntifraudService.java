package ru.rosbank.paymentapp.service.fraud;

import java.time.LocalDateTime;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.AntifraudBlockEntity;
import ru.rosbank.paymentapp.entity.AntifraudClientEntity;
import ru.rosbank.paymentapp.esb.service.SendDboMatrixService;
import ru.rosbank.paymentapp.repository.AntifraudBlockEntityRepository;
import ru.rosbank.paymentapp.repository.AntifraudClientEntityRepository;
import ru.rosbank.paymentapp.service.bs.BsService;
import ru.rosbank.paymentapp.util.Utils;

@Slf4j
@RequiredArgsConstructor
@Service
public class UserAntifraudService extends AbstractAntifraudService {

    private final AntifraudBlockEntityRepository antifraudBlockRepository;
    private final AntifraudClientEntityRepository antifraudClientRepository;
    private final BsService bsService;
    private final SendDboMatrixService sendDboMatrixService;
    private final DboEventBlockOperationsService dboEventBlockOperationsService;

    @Value("${anti-fraud.block.respect}")
    private boolean respectBlock;

    public void revokeBlockOnClient(Long clientId) {
        antifraudClientRepository.findTopByClientIdAndStatusOrderByCreatedDesc(clientId,
                AntifraudClientEntity.BLOCK_ACTIVE_OPERATION).ifPresent(antifraudClient -> {
                    revokeBlockOperation(antifraudClient);
                    dboEventBlockOperationsService
                            .sendUnblockActiveOperationsTimeoutEvent(bsService.getClient(antifraudClient.getClientId()));
                });
    }


    private void isBlockActiveOperationProcessed(AntifraudClientEntity antifraudClient) {

        Optional<AntifraudBlockEntity> oblock = antifraudBlockRepository
                .findByClientIdAndReleasedIsNull(antifraudClient.getClientId());

        if (oblock.isPresent()) {
            if (Utils.workingDaysElapsedFrom(antifraudClient.getCreated().toLocalDate()) > reviewTimeoutDays) {
                releaseClient(antifraudClient, oblock.get());
            }

        } else {

            antifraudBlockRepository.save(new AntifraudBlockEntity(antifraudClient.getClientId()));

            if (respectBlock) {
                blockClient(antifraudClient);
                dboEventBlockOperationsService
                        .sendBlockActiveOperationsEvent(bsService.getClient(antifraudClient.getClientId()));
            }
        }

    }

    private void revokeBlockOperation(AntifraudClientEntity antifraudClient) {
        Optional<AntifraudBlockEntity> oblock =
                antifraudBlockRepository.findByClientIdAndReleasedIsNull(antifraudClient.getClientId());
        if (!oblock.isPresent()) {
            log.error("Блокировки по пользователю id=[{}] уже сняты", antifraudClient.getClientId());
            oblock = antifraudBlockRepository.findTopByClientIdOrderByCreatedDesc(antifraudClient.getClientId());
        }
        oblock.ifPresent(b -> releaseClient(antifraudClient, b));
    }


    private void blockClient(AntifraudClientEntity antifraudClient) {
        sendDboMatrixClient(antifraudClient, true);
    }

    private void releaseClient(AntifraudClientEntity antifraudClient, AntifraudBlockEntity block) {
        // Снятие флага antifraud_block
        sendDboMatrixClient(antifraudClient, false);
        block.setReleased(LocalDateTime.now());
        antifraudBlockRepository.save(block);
    }

    private void sendDboMatrixClient(AntifraudClientEntity antifraudClient, boolean block) {
        sendDboMatrixService.setAntifraudBlockFlag(antifraudClient.getCrmIdLegal(),
                antifraudClient.getCrmIdNatural(), block);
    }


}
