package ru.rosbank.paymentapp.converters;

import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.dto.pricing.CommissionRequestDTO;
import ru.rosbank.paymentapp.dto.pricing.CustomerIdsDTO;
import ru.rosbank.paymentapp.dto.pricing.PayeeDTO;
import ru.rosbank.paymentapp.dto.pricing.PayerDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

@Service
public class PricingCommissionConverter {
    public CommissionRequestDTO convert(DocumentDTO dto) {
        CommissionRequestDTO requestDTO = new CommissionRequestDTO();
        requestDTO.setAmount(dto.getAmount());
        requestDTO.setCurrencyCode("RUB");
        requestDTO.setInputSystem("RMB");
        requestDTO.setPurpose(dto.getPurpose());
        requestDTO.setSiebelId(dto.getCrmId());
        requestDTO.setPayee(PayeeDTO.builder()
                .correspondentAccount(dto.getPayee().getBank().getCorrespondentAccount())
                .bic(dto.getPayee().getBank().getBic())
                .inn(dto.getPayee().getInn())
                .accountNumber(dto.getPayee().getAccount())
                .name(dto.getPayee().getName())
                .build());
        requestDTO.setPayer(PayerDTO.builder()
                .accountNumber(dto.getPayer().getAccount())
                .bic(dto.getPayer().getBank().getBic())
                .inn(dto.getPayer().getInn())
                .name(dto.getPayer().getName())
                .build());
        requestDTO.setCustomerIds(CustomerIdsDTO.builder()
                .id(dto.getBisId().getId())
                .branch(dto.getBisId().getBranch()).build());
        return requestDTO;
    }
}
