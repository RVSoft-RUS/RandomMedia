package ru.rosbank.paymentapp.esb.service;

import static ru.rosbank.platform.esb.support.InteractionSystem.CRM;

import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.EsbService;
import ru.rosbank.platform.esb.model.common.AppSystemIDTypeEsb;
import ru.rosbank.platform.esb.model.customer.CustomerIDListTypeEsb;
import ru.rosbank.platform.esb.model.customer.CustomerIDTypeEsb;
import ru.rosbank.platform.esb.model.dboprofile.DBOUserParameterListTypeEsb;
import ru.rosbank.platform.esb.model.dboprofile.DBOUserParameterTypeEsb;
import ru.rosbank.platform.esb.model.naturalperson.NaturalPersonTypeEsb;
import ru.rosbank.platform.esb.model.senddbomatrix.SendDBOMatrixRequestTypeEsb;
import ru.rosbank.platform.esb.model.senddbomatrix.SendDBOMatrixResponseTypeEsb;

@RequiredArgsConstructor
@Service
public class SendDboMatrixService {

    private static final String ANTIFRAUD_BLOCK_ACCESS_GROUP = "Antifraud_block";
    private static final String DBOPRO_APP_SYSTEM_ID = "DBO";
    private static final String CRM_APP_SYSTEM_ID = "CRM";
    private static final String ALL_RIGHTS_ACCESS_GROUP = "All Rights";

    private final EsbService esbService;

    public SendDBOMatrixResponseTypeEsb unBlockUserInSiebel(String crmIdLegal,
                                                                  String dboProId, String crmIdNatural) {
        setAntifraudBlockFlag(crmIdLegal, crmIdNatural, false);
        return changeAccessGroup(crmIdLegal, dboProId, crmIdNatural, ALL_RIGHTS_ACCESS_GROUP);
    }

    public SendDBOMatrixResponseTypeEsb setAntifraudBlockFlag(String crmId, String personId, boolean block) {

        SendDBOMatrixRequestTypeEsb sendDBOMatrixRequest = new SendDBOMatrixRequestTypeEsb()
                .withCustomerIDList(
                        new CustomerIDListTypeEsb(
                                Stream.of(new CustomerIDTypeEsb()
                                        .withAppSystemID(new AppSystemIDTypeEsb().withInstanceID(CRM.name()))
                                        .withCustomerID(crmId)).collect(Collectors.toList())
                        )
                ).withDboUserList(
                        new DBOUserParameterListTypeEsb(
                                Stream.of(new DBOUserParameterTypeEsb()
                                        .withDboUser(new NaturalPersonTypeEsb()
                                                .withCustomerIDList(
                                                        new CustomerIDListTypeEsb(
                                                                Stream.of(new CustomerIDTypeEsb()
                                                                        .withAppSystemID(new AppSystemIDTypeEsb()
                                                                                .withInstanceID(CRM.name()))
                                                                        .withCustomerID(personId))
                                                                        .collect(Collectors.toList())
                                                        )
                                                )
                                        ).withAccessGroup(ANTIFRAUD_BLOCK_ACCESS_GROUP).withAccessDate(new Date())
                                        .withChangeUserParameter(block)
                                ).collect(Collectors.toList())
                        )
                );

        return esbService.sendDBOMatrix(sendDBOMatrixRequest);

    }


    private SendDBOMatrixResponseTypeEsb changeAccessGroup(String crmIdLegal,
                                                               String dboProId, String crmIdNatural, String accessGroup) {
        SendDBOMatrixRequestTypeEsb sendDBOMatrixRequestTypeEsb = new SendDBOMatrixRequestTypeEsb();

        sendDBOMatrixRequestTypeEsb.setCustomerIDList(getCustomerIdListCRM(crmIdLegal));

        DBOUserParameterTypeEsb dboUserParameterTypeEsb = new DBOUserParameterTypeEsb();
        dboUserParameterTypeEsb.setAccessGroup(accessGroup);
        dboUserParameterTypeEsb.setAccessDate(new Date());
        dboUserParameterTypeEsb.setChangeUserParameter(true);
        dboUserParameterTypeEsb.setDBOUser(getUser(dboProId));

        DBOUserParameterListTypeEsb dboUserParameterListTypeEsb = new DBOUserParameterListTypeEsb();

        if (StringUtils.isNotBlank(crmIdNatural)) {
            AppSystemIDTypeEsb appSystemIDTypeEsb = new AppSystemIDTypeEsb();
            appSystemIDTypeEsb.setInstanceID(CRM_APP_SYSTEM_ID);
            CustomerIDTypeEsb customerIDTypeEsb = new CustomerIDTypeEsb();
            customerIDTypeEsb.setAppSystemID(appSystemIDTypeEsb);
            customerIDTypeEsb.setCustomerID(crmIdNatural);
            dboUserParameterTypeEsb.getDBOUser().getCustomerIDList().getCustomerID().add(customerIDTypeEsb);
        }

        dboUserParameterListTypeEsb.getDBOUserParameter().add(dboUserParameterTypeEsb);
        sendDBOMatrixRequestTypeEsb.setDBOUserList(dboUserParameterListTypeEsb);

        return esbService.sendDBOMatrix(sendDBOMatrixRequestTypeEsb);
    }

    private NaturalPersonTypeEsb getUser(String dboProId) {
        CustomerIDTypeEsb customerIDTypeEsb = new CustomerIDTypeEsb();
        AppSystemIDTypeEsb appSystemIDTypeEsb = new AppSystemIDTypeEsb();
        appSystemIDTypeEsb.setInstanceID(DBOPRO_APP_SYSTEM_ID);
        customerIDTypeEsb.setAppSystemID(appSystemIDTypeEsb);
        customerIDTypeEsb.setCustomerID(dboProId);
        NaturalPersonTypeEsb naturalPersonTypeEsb = new NaturalPersonTypeEsb();
        CustomerIDListTypeEsb customerIDListTypeEsb = new CustomerIDListTypeEsb();
        customerIDListTypeEsb.getCustomerID().add(customerIDTypeEsb);
        naturalPersonTypeEsb.setCustomerIDList(customerIDListTypeEsb);
        return naturalPersonTypeEsb;
    }

    private CustomerIDListTypeEsb getCustomerIdListCRM(String crmIdLegal) {
        CustomerIDTypeEsb customerIDTypeEsb = new CustomerIDTypeEsb();
        AppSystemIDTypeEsb appSystemIDTypeEsb = new AppSystemIDTypeEsb();
        appSystemIDTypeEsb.setInstanceID(CRM_APP_SYSTEM_ID);
        customerIDTypeEsb.setAppSystemID(appSystemIDTypeEsb);
        customerIDTypeEsb.setCustomerID(crmIdLegal);
        CustomerIDListTypeEsb customerIDListTypeEsb = new CustomerIDListTypeEsb();
        customerIDListTypeEsb.getCustomerID().add(customerIDTypeEsb);
        return customerIDListTypeEsb;
    }

}
