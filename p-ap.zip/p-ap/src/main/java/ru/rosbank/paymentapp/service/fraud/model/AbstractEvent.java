package ru.rosbank.paymentapp.service.fraud.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude()
public abstract class AbstractEvent {

    private Request request;
    private Customer customer;
    private Entity entity;
    private Parameters parameters;

}
