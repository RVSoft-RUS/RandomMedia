package ru.rosbank.paymentapp.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.esb.model.common.MoneyAmountTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.DocumentIndicatorTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;
import ru.rosbank.platform.utils.async.mdc.MdcAwareExecutors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RejectedPaymentStatusProcessor {

    public static final String REJECTED_DOCUMENT_STATUS_MESSAGE = "Платёж отклонён Банком";
    public static final String BIS_PAYMENT_ORDER_PRO_INPUT_SYSTEM = "C";
    public static final String BIS_PAYMENT_ORDER_REJECTED_STATUS = "B";

    @Value("${feature.bis.get.payment.list.enabled}")
    private boolean enabled;
    @Value("${payment.list.max.deep.days}")
    private Integer paymentListMaxDeepDays;
    @Value("${rejected.numberOfDaysAfterDocumentCreation}")
    private Integer numberOfDaysAfterDocumentCreation;
    @Value("${account.pool.size:20}")
    private int accountsLoadThreadPoolSize;

    private final OrganizationService organizationService;
    private final EsbService esbService;
    private final AccountService accountService;
    private final PaymentEventService paymentEventService;
    private final PaymentEntityRepository paymentEntityRepository;

    private ExecutorService executorService;

    @PostConstruct
    void init() {
        executorService = MdcAwareExecutors.newMdcAwareFixedThreadPool(accountsLoadThreadPoolSize);
    }

    protected List<AccountDTO> getPayerAccounts(List<PaymentEntity> paymentEntities, ClientDTO client) {
        List<OrganizationDTO> organizations = organizationService.rootGet(client.getId());
        List<String> payerAccounts = paymentEntities.stream()
                .map(PaymentEntity::getPayerAccount)
                .collect(Collectors.toList());
        List<CompletableFuture<List<AccountDTO>>> accountLoadTasks = new ArrayList<>();
        for (OrganizationDTO organization : organizations) {
            CompletableFuture<List<AccountDTO>> accountLoadTask =
                    CompletableFuture.supplyAsync(() -> accountService.getAccountList(
                                    organization.getCrmId(),
                                    organization.getBisIds()),
                            executorService
                    );
            accountLoadTasks.add(accountLoadTask);
        }
        List<AccountDTO> accounts = accountLoadTasks.stream()
                .map(CompletableFuture::join)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());

        return accounts.stream()
                .filter(account -> payerAccounts.contains(account.getNumber()))
                .collect(Collectors.toList());
    }

    public void process(List<PaymentEntity> paymentEntities, ClientDTO client) {
        if (!enabled) {
            return;
        }
        updateRejectedPaymentStatus(paymentEntities, client);
    }

    public List<PaymentEntity> updateRejectedPaymentStatus(List<PaymentEntity> paymentEntities, ClientDTO client) {
        try {
            List<AccountDTO> accounts = getPayerAccounts(paymentEntities, client);

            Map<String, Date> startDates = calculateStartDatesForAccount(paymentEntities, accounts);
            Map<String, Date> endDates = calculateEndDatesForAccount(paymentEntities, accounts);

            List<PaymentOrderTypeEsb> paymentOrders = accounts.stream()
                    .filter(account -> startDates.get(account.getNumber()).before(endDates.get(account.getNumber())))
                    .map(account -> esbService.getPaymentList(
                            account.getNumber13(),
                            account.getBisId().getBranch(),
                            startDates.get(account.getNumber()),
                            endDates.get(account.getNumber())))
                    .flatMap(List::stream).collect(Collectors.toList());
            paymentOrders = filterOnlyRejected(paymentOrders);

            for (PaymentOrderTypeEsb payment : paymentOrders) {
                for (PaymentEntity document : paymentEntities) {
                    if (isSameDocumentAndPayment(document, payment)) {
                        makeDocumentRejected(document, REJECTED_DOCUMENT_STATUS_MESSAGE);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error("Ошибка при обработке зависших документов клиент id {}", client.getId(), e);
        }
        return paymentEntities;
    }

    public boolean isSameDocumentAndPayment(PaymentEntity paymentEntity, PaymentOrderTypeEsb paymentOrder) {
        if (DocumentStatus.RECALLED.name().equals(paymentEntity.getStatus())
                || DocumentStatus.REJECTED.name().equals(paymentEntity.getStatus())) {
            return false;
        }
        if (paymentEntity.getDate() == null || paymentOrder.getDocumentDate() == null) {
            return false;
        }
        LocalDate documentDateNoTimeStart = paymentEntity.getDate().toLocalDate();
        LocalDate documentDateNoTimeEnd = paymentEntity.getDate().toLocalDate().plusDays(numberOfDaysAfterDocumentCreation + 1);
        LocalDate paymentDateNoTime = paymentOrder.getDocumentDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        if (!Objects.equals(documentDateNoTimeStart, paymentDateNoTime)
                && !(documentDateNoTimeStart.isBefore(paymentDateNoTime) && documentDateNoTimeEnd.isAfter(paymentDateNoTime))) {
            return false;
        }

        if (!Objects.equals(paymentEntity.getPayeeAccount(), paymentOrder.getPayee().getNumber().getAccountNumber20Digit())) {
            return false;
        }

        if (!Objects.equals(paymentEntity.getAmount(), Optional.ofNullable(paymentOrder.getAmount())
                .map(MoneyAmountTypeEsb::getAmount)
                .orElse(null))) {
            return false;
        }

        return Objects.equals(paymentEntity.getNumber(), paymentOrder.getOrderNumber());
    }

    protected void makeDocumentRejected(PaymentEntity document, String message) {
        document.setStatusMessage(message);
        document.setStatus(DocumentStatus.REJECTED.name());
        paymentEventService.sendDocumentStatus(document);
        document.setShowError(true);
        paymentEntityRepository.save(document);
    }

    protected List<PaymentOrderTypeEsb> filterOnlyRejected(List<PaymentOrderTypeEsb> paymentsOrders) {
        return paymentsOrders.stream().filter(payment -> BIS_PAYMENT_ORDER_REJECTED_STATUS.equals(payment.getStatus())
                        && BIS_PAYMENT_ORDER_PRO_INPUT_SYSTEM.equals(Optional.ofNullable(payment.getDocumentIndicator())
                        .map(DocumentIndicatorTypeEsb::getInputSystem)
                        .orElse(null)))
                .collect(Collectors.toList());
    }

    private Map<String, Date> calculateStartDatesForAccount(List<PaymentEntity> payments, List<AccountDTO> accounts) {
        Map<String, Date> startDates = new HashMap<>();
        accounts.forEach(account -> startDates.put(account.getNumber(),
                calculateStartDate(payments.stream()
                        .filter(document ->
                                document.getPayerAccount().equals(
                                        account.getNumber()))
                        .min(Comparator.comparing(PaymentEntity::getDate))
                        .get().getDate())));
        return startDates;
    }

    private Map<String, Date> calculateEndDatesForAccount(List<PaymentEntity> payments, List<AccountDTO> accounts) {
        Map<String, Date> endDates = new HashMap<>();
        accounts.forEach(account -> endDates.put(account.getNumber(),
                Date.from(payments.stream()
                        .filter(document ->
                                document.getPayerAccount().equals(account.getNumber()))
                        .max(Comparator.comparing(PaymentEntity::getDate))
                        .get().getDate().toLocalDate().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant())));
        return endDates;
    }

    private Date calculateStartDate(LocalDateTime firstProcessingDocumentDate) {
        LocalDate maxDeepStartDate = LocalDate.now().minusDays(paymentListMaxDeepDays);
        LocalDate firstProcessingDocumentDateNoTime = firstProcessingDocumentDate.toLocalDate();
        return firstProcessingDocumentDateNoTime.isBefore(maxDeepStartDate)
                ? Date.from(maxDeepStartDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant())
                : Date.from(firstProcessingDocumentDateNoTime.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }

}
