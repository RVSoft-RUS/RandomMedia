package ru.rosbank.paymentapp.service;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.CbBic;
import ru.rosbank.paymentapp.entity.CbBicRstr;
import ru.rosbank.paymentapp.repository.CbBicRepository;
import ru.rosbank.paymentapp.repository.CbBicRstrRepository;
import ru.rosbank.paymentapp.service.reference.ReferenceService;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;

@RequiredArgsConstructor
@Service
public class CbBicService {
    private final CbBicRepository cbBicRepository;
    private final CbBicRstrRepository cbBicRstrRepository;
    private final ReferenceService referenceService;

    public String getBankNameByBic(String bic) {
        Optional<CbBic> cbBic = cbBicRepository.findByBic(bic);
        if (cbBic.isPresent()) {
            return cbBic.get().getNamep();
        }
        return "Not found";
    }

    public boolean isBicValid(String bic) {

        Optional<CbBic> cbBic = cbBicRepository.findByBic(bic);

        if (cbBic.isPresent()) {
            Optional<CbBicRstr> cbBicRstr = cbBicRstrRepository.findByBic(bic);
            return !cbBicRstr.isPresent();
        } else {
            return false;
        }

    }

    public List<BankDTO> getBanks(String bic) {
        return referenceService.getBanks(bic);
    }

}
