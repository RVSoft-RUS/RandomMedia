package ru.rosbank.paymentapp.template.exception;

import ru.rosbank.paymentapp.service.exceptions.ValidationException;

/**
 * Summary.
 * @author rb067368
 * @since 16.09.2020
 */
public class DuplicateTemplateNameException extends ValidationException {

    public DuplicateTemplateNameException(String msg) {
        super(msg);
    }

    public DuplicateTemplateNameException(String msg, Throwable t) {
        super(msg, t);
    }
}
