package ru.rosbank.paymentapp.service.fraud;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.audit.AuditContext;
import ru.rosbank.paymentapp.service.bs.BsService;
import ru.rosbank.paymentapp.service.fraud.model.DboEvent;
import ru.rosbank.paymentapp.service.fraud.model.Entity;
import ru.rosbank.paymentapp.service.fraud.model.Parameters;
import ru.rosbank.paymentapp.service.fraud.model.constant.CustomerType;
import ru.rosbank.paymentapp.service.fraud.model.constant.DboActionType;
import ru.rosbank.paymentapp.service.fraud.model.constant.EventType;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@RequiredArgsConstructor
@Service
public class DboEventRegisterPaymentService extends AbstractUserEventService {

    @Value("${anti-fraud.user.event.topic.name}")
    private String userEventTopicName;

    private final BsService bsService;

    @Async("antifraud_executor")
    public void sendRegisterPaymentEvent(PaymentEntity document, AuditContext context) {
        context.setCompanyName(document.getPayerName());
        sendDboEvent(document.getId(), bsService.getClient(document.getClientId()), context);
    }

    private void sendDboEvent(Long documentId, ClientDTO client, AuditContext context) {
        if (!respectUserEvent) {
            return;
        }
        fraudSenderService.sendMessage(userEventTopicName, createEvent(documentId, client, context));
    }

    private DboEvent createEvent(Long documentId, ClientDTO client, AuditContext context) {

        DboEvent event = new DboEvent();

        event.setId(String.valueOf(documentId));
        event.setUserIp(context.getIp());
        event.setAction(DboActionType.REGISTRATION_PAYMENT.toString());

        event.setCustomer(createCustomer(client));
        //TODO Передавать контекст пользователя
        event.setRequest(createRequest(context));
        event.setEntity(createEntity(context));
        event.setParameters(createParameters(context));

        return event;
    }

    private Entity createEntity(AuditContext context) {
        Entity entity = new Entity();
        entity.setInn(context.getCompanyInn());
        entity.setOrganizationName(context.getCompanyName());
        entity.setAbsId(context.getBisCompanyId());
        entity.setSiebelId(context.getCrmCompanyId());
        entity.setType(CustomerType.LEGAL.getText());

        return entity;
    }

    private Parameters createParameters(AuditContext context) {
        Parameters parameters = new Parameters();
        parameters.setSystemId(PARAMETER_SYSTEM_ID_PRO_ONLINE);
        parameters.setChannelType(mapPlatformToChannelType(context.getPlatform()));
        parameters.setTypeCode(EventType.DBO_EVENT.toString());
        return parameters;
    }

}
