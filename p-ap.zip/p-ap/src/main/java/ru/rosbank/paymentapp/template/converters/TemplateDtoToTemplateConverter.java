package ru.rosbank.paymentapp.template.converters;

import java.time.ZoneId;
import java.util.Date;
import java.util.Optional;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.TemplateEntity;
import ru.rosbank.paymentapp.util.FormatUtils;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.paymentapp.model.Requisite;
import ru.rosbank.platform.server.paymentapp.model.Template;


/**
 * Summary.
 * @author rb067368
 */

@Service
public class TemplateDtoToTemplateConverter {
    public TemplateEntity convert(TemplateDTO templateDto) {
        TemplateEntity entity = new TemplateEntity();
        entity.setId(Optional.ofNullable(templateDto.getId())
                .map(ti -> Long.valueOf(ti)).orElse(null));
        entity.setDboProId(templateDto.getDboProId());
        entity.setName(templateDto.getName());

        entity.setLastModifiedDate(Optional.ofNullable(templateDto.getLastModifiedDate()).map(d ->
                Date.from(d.atStartOfDay(ZoneId.systemDefault()).toInstant())).orElse(null));
        entity.setAmount(FormatUtils.parseAmount(templateDto.getAmount()));
        entity.setDocType(templateDto.getDocType().getValue());

        RequisiteDTO payer = templateDto.getPayer();
        entity.setPayerName(payer.getName());
        entity.setPayerAccount(payer.getAccount());
        entity.setPayerInn(payer.getInn());
        entity.setPayerKpp(payer.getKpp());
        entity.setPayerBankBic(payer.getBank().getBic());
        entity.setPayerBankName(payer.getBank().getName());
        entity.setPayerBankCorrespondentAccount(payer.getBank().getCorrespondentAccount());

        entity.setPayerStatus(templateDto.getPayerStatus());

        RequisiteDTO payee = templateDto.getPayee();
        entity.setPayeeName(payee.getName());
        entity.setPayeeAccount(payee.getAccount());
        entity.setPayeeInn(payee.getInn());
        entity.setPayeeKpp(payee.getKpp());
        entity.setPayeeBankBic(payee.getBank().getBic());
        entity.setPayeeBankName(payee.getBank().getName());
        entity.setPayeeBankCorrespondentAccount(payee.getBank().getCorrespondentAccount());


        entity.setPurpose(templateDto.getPurpose());
        entity.setPayPriority(templateDto.getPayPriority().getValue());
        entity.setUin(templateDto.getUin());
        entity.setPayerStatus(templateDto.getPayerStatus());
        entity.setKbk(templateDto.getKbk());
        entity.setOktmo(templateDto.getOktmo());
        entity.setPaymentBasis(templateDto.getPaymentBasis());
        entity.setTaxPeriod(templateDto.getTaxPeriod());
        entity.setBasisDocumentNumber(templateDto.getBasisDocumentNumber());
        entity.setBasisDocumentCreated(templateDto.getBasisDocumentCreated());
        entity.setCodeTypeIncome(Optional.ofNullable(templateDto.getCodeTypeIncome()).map(Short::valueOf).orElse(null));
        entity.setTypeTaxPayment("1".equals(templateDto.getTypeTaxPayment())
                || Boolean.parseBoolean(templateDto.getTypeTaxPayment()));
        return entity;
    }

    public TemplateEntity convert(Template templateDto) {
        TemplateEntity entity = new TemplateEntity();
        entity.setId(Optional.ofNullable(templateDto.getId())
                .map(ti -> Long.valueOf(ti)).orElse(null));
        entity.setDboProId(templateDto.getDboProId());
        entity.setName(templateDto.getName());

        entity.setLastModifiedDate(Optional.ofNullable(templateDto.getLastModifiedDate()).map(d ->
                Date.from(d.atStartOfDay(ZoneId.systemDefault()).toInstant())).orElse(null));
        entity.setAmount(FormatUtils.parseAmount(templateDto.getAmount()));
        entity.setDocType(templateDto.getDocType().getValue());

        Requisite payer = templateDto.getPayer();
        entity.setPayerName(payer.getName());
        entity.setPayerAccount(payer.getAccount());
        entity.setPayerInn(payer.getInn());
        entity.setPayerKpp(payer.getKpp());
        entity.setPayerBankBic(payer.getBank().getBic());
        entity.setPayerBankName(payer.getBank().getName());
        entity.setPayerBankCorrespondentAccount(payer.getBank().getCorrespondentAccount());

        entity.setPayerStatus(templateDto.getPayerStatus());

        Requisite payee = templateDto.getPayee();
        entity.setPayeeName(payee.getName());
        entity.setPayeeAccount(payee.getAccount());
        entity.setPayeeInn(payee.getInn());
        entity.setPayeeKpp(payee.getKpp());
        entity.setPayeeBankBic(payee.getBank().getBic());
        entity.setPayeeBankName(payee.getBank().getName());
        entity.setPayeeBankCorrespondentAccount(payee.getBank().getCorrespondentAccount());


        entity.setPurpose(templateDto.getPurpose());
        entity.setPayPriority(templateDto.getPayPriority().getValue());
        entity.setUin(templateDto.getUin());
        entity.setPayerStatus(templateDto.getPayerStatus());
        entity.setKbk(templateDto.getKbk());
        entity.setOktmo(templateDto.getOktmo());
        entity.setPaymentBasis(templateDto.getPaymentBasis());
        entity.setTaxPeriod(templateDto.getTaxPeriod());
        entity.setBasisDocumentNumber(templateDto.getBasisDocumentNumber());
        entity.setBasisDocumentCreated(templateDto.getBasisDocumentCreated());
        entity.setCodeTypeIncome(Optional.ofNullable(templateDto.getCodeTypeIncome()).map(Short::valueOf).orElse(null));
        entity.setTypeTaxPayment("1".equals(templateDto.getTypeTaxPayment())
                || Boolean.parseBoolean(templateDto.getTypeTaxPayment()));
        return entity;
    }
}
