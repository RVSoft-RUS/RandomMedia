package ru.rosbank.paymentapp.service.exceptions;

public class AvaliableBalanceExcessException extends DocumentRejectedException {

    public AvaliableBalanceExcessException(String msg) {
        super(msg);
    }
}
