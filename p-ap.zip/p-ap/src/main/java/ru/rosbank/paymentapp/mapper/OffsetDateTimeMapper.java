package ru.rosbank.paymentapp.mapper;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import org.mapstruct.Mapper;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface OffsetDateTimeMapper {
    DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

    @Named("toDate")
    public default OffsetDateTime toDate(OffsetDateTime value) {
        if (value == null) {
            return null;
        }
        return OffsetDateTime.parse(DATE_TIME_FORMATTER.format(value), DATE_TIME_FORMATTER);
    }
}
