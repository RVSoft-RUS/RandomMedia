package ru.rosbank.paymentapp.service.fraud;

import static ru.rosbank.paymentapp.entity.AntifraudResolutionEntity.ANTIFRAUD_PROCESSING;
import static ru.rosbank.paymentapp.util.Utils.formatAmountWithDot;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.AntifraudResolutionEntity;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;
import ru.rosbank.paymentapp.entity.DocumentType;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.AntifraudResolutionEntityRepository;
import ru.rosbank.paymentapp.repository.CbBicRepository;
import ru.rosbank.paymentapp.repository.DFMPaymentRepository;
import ru.rosbank.paymentapp.service.AccountService;
import ru.rosbank.paymentapp.service.bs.BsService;
import ru.rosbank.paymentapp.service.cryptopro.CryptoproService;
import ru.rosbank.paymentapp.service.exceptions.DocumentGetSignatureException;
import ru.rosbank.paymentapp.service.fraud.converter.ApiLevelToVersionConverter;
import ru.rosbank.paymentapp.service.fraud.model.Customer;
import ru.rosbank.paymentapp.service.fraud.model.DocumentStatusEvent;
import ru.rosbank.paymentapp.service.fraud.model.Entity;
import ru.rosbank.paymentapp.service.fraud.model.Parameters;
import ru.rosbank.paymentapp.service.fraud.model.PaymentEvent;
import ru.rosbank.paymentapp.service.fraud.model.Request;
import ru.rosbank.paymentapp.service.fraud.model.constant.ChannelType;
import ru.rosbank.paymentapp.service.fraud.model.constant.CustomerType;
import ru.rosbank.paymentapp.service.fraud.model.constant.EventType;
import ru.rosbank.paymentapp.util.FormatUtils;
import ru.rosbank.paymentapp.util.Utils;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateDTO;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateRequestDTO;
import ru.rosbank.platform.client.cryptoproapp.model.MetaDataDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;


@Slf4j
@RequiredArgsConstructor
@Service
public class PaymentEventService extends AbstractAntifraudService {

    private static final String PARAMETER_SYSTEM_ID_PRO_ONLINE = "2";
    private static final String PAYMENT_CLASS_BUDGET = "5";
    private static final String PAYMENT_CLASS_PAYROLL = "33";
    private static final String CURRENCY_RUB = "RUB";

    @Value("${server.ip}")
    private String serverIp;

    private final AccountService accountService;
    private final FraudSenderService fraudSenderService;
    private final AntifraudResolutionEntityRepository antifraudResolutionRepository;
    private final DFMPaymentRepository dfmPaymentRepository;
    private final CryptoproService cryptoproService;
    private final CbBicRepository cbBicRepository;
    private final BsService bsService;
    private final ApiLevelToVersionConverter apiLevelToVersionConverter;

    public void sendPaymentEvent(PaymentEntity document) {
        try {
            SignatureDTO signature = getSignatureFromDocument(document);
            PaymentEvent event = createSignedPaymentEvent(document, signature);
            event.setRequest(createRequest(signature));
            event.setParameters(createParameters(signature));
            Optional.ofNullable(signature.getCreated())
                    .map(OffsetDateTime::toInstant).map(Date::from).ifPresent(event::setDocumentDate);

            ClientDTO client = bsService.getClient(document.getClientId());
            event.setCustomer(createCustomer(document, client));
            event.setContact(client.getPhone());
            event.setPayerPlace(getPayerPlace(document));
            event.setPayeePlace(getPayeePlace(document));
            String balance = Optional
                    .ofNullable(accountService.getAccountBalance(document))
                    .map(String::valueOf).orElse("");
            event.setPayerAccountBalance(balance);
            event.setPayerAccountBalanceRur(balance);
            event.setFlagAml(getDfmPaymentFlag(document));

            createResolution(event, document);
            log.debug("Создан запрос в Антифрод: {}", event.toString());
            fraudSenderService.sendPaymentEventMessage(event);

        } catch (Exception e) {
            log.error("Error sending PaymentEvent: " + e.getMessage(), e);
        }

    }

    public void sendDocumentStatus(PaymentEntity document) {
        try {
            DocumentStatusEvent event = new DocumentStatusEvent();
            SignatureDTO signature = null;
            try {
                signature = getSignatureFromDocument(document);
            } catch (Exception e) {
                log.error("Error getSignatureFromDocument: " + e.getMessage(), e);
            }

            event.setParameters(createParameters(signature));
            event.setRequest(createRequest(signature));
            ClientDTO client = null;
            try {
                client = bsService.getClient(document.getClientId());
            } catch (Exception e) {
                log.error("Error bsService.getClient: " + e.getMessage(), e);
            }
            event.setCustomer(createCustomer(document, client));
            event.setEntity(createEntity(document, signature));
            event.setPayId(document.getId() != null ? String.valueOf(document.getId()) : "");
            event.setPayStatus(Optional.ofNullable(document.getStatus()).orElse(""));
            event.setPayStatusDatetime(new Date());
            event.setPayClientId(Optional.ofNullable(document.getOrganizationCrmId()).orElse(""));
            event.setPayAmount(document.getAmount() != null ? document.getAmount().toString() : "");
            event.setPayCurrency("RUR");
            event.setPayAccountSender(Optional.ofNullable(document.getPayerAccount()).orElse(""));
            event.setPayAccountRecipient(Optional.ofNullable(document.getPayeeAccount()).orElse(""));
            event.setPayType(Optional.ofNullable(document.getDoctype()).orElse(""));
            event.setPayDatetime(document.getDate() != null ? FormatUtils.formatLocalDateTimeMs(document.getDate()) : "");
            event.setPayReferenceId(Optional.ofNullable(document.getBisDocumentId()).orElse(""));
            event.setPayReferenceClientId(Optional.ofNullable(document.getOrganizationBisId()).orElse(""));
            event.setPayReferenceBranch(Optional.ofNullable(document.getOrganizationBisBranch()).orElse(""));
            event.setPayBICSender(Optional.ofNullable(document.getPayerBankBic()).orElse(""));
            event.setPayBICRecipient(Optional.ofNullable(document.getPayeeBankBic()).orElse(""));
            log.debug("Создан запрос в Антифрод: {}", event);
            fraudSenderService.sendDocumentStatusEventMessage(event);
        } catch (Exception e) {
            log.error("Error sending DocumentStatusEvent: " + e.getMessage(), e);
        }

    }

    private PaymentEvent createSignedPaymentEvent(PaymentEntity document, SignatureDTO signature) {

        PaymentEvent paymentEvent = new PaymentEvent();
        paymentEvent.setEntity(createEntity(document, signature));

        paymentEvent.setPayeeBcc(Optional.ofNullable(document.getKbk()).orElse(""));
        paymentEvent.setPayerAccountNumber(Optional.ofNullable(document.getPayerAccount()).orElse(""));
        paymentEvent.setPayeeAccountNumber(Optional.ofNullable(document.getPayeeAccount()).orElse(""));
        paymentEvent.setPayerInn(Optional.ofNullable(document.getPayerInn()).orElse(""));
        paymentEvent.setPayeeInn(Optional.ofNullable(document.getPayeeInn()).orElse(""));

        paymentEvent.setPayerBic(Optional.ofNullable(document.getPayerBankBic()).orElse(""));
        paymentEvent.setPayeeBic(Optional.ofNullable(document.getPayeeBankBic()).orElse(""));
        paymentEvent.setPayerBankName(Optional.ofNullable(document.getPayerBankName()).orElse(""));
        paymentEvent.setPayeeBankName(Optional.ofNullable(document.getPayeeBankName()).orElse(""));

        paymentEvent.setDescription(Optional.ofNullable(document.getPurpose()).orElse(""));

        paymentEvent.setId(String.valueOf(document.getId()));
        paymentEvent.setDocumentNumber(Optional.ofNullable(document.getNumber()).map(Integer::parseInt).orElse(null));
        paymentEvent.setPayeeKpp(Optional.ofNullable(document.getPayeeKpp()).orElse(""));

        paymentEvent.setAmount(formatAmountWithDot(document.getAmount()));
        paymentEvent.setAmountRur(formatAmountWithDot(document.getAmount()));
        paymentEvent.setCurrency(CURRENCY_RUB);

        if (DocumentType.DE.name().equals(document.getDoctype())) {
            paymentEvent.setPaymentClass(PAYMENT_CLASS_BUDGET);
        } else if (DocumentType.DP.name().equals(document.getDoctype())) {
            paymentEvent.setPaymentClass(PAYMENT_CLASS_PAYROLL);
        } else {
            paymentEvent.setPaymentClass("");
        }

        paymentEvent.setPayerAccountBalanceRur("");
        paymentEvent.setPayerAccountCurrency(CURRENCY_RUB);
        paymentEvent.setUserIp(Optional.ofNullable(document.getRemIp()).orElse(""));
        paymentEvent.setReviewDeadline(Date.from(Utils.overWorkingDaysDate(reviewTimeoutDays)
                .atStartOfDay(ZoneId.systemDefault()).toInstant()));
        paymentEvent.setBranch(Optional.ofNullable(document.getOrganizationBisBranch()).orElse(""));
        paymentEvent.setSenderName(Optional.ofNullable(document.getPayerName()).orElse(""));
        paymentEvent.setRecipientName(Optional.ofNullable(document.getPayeeName()).orElse(""));

        paymentEvent.setIncomeType(document.getCodeTypeIncome() == null || document.getCodeTypeIncome() == 0 ? ""
                : document.getCodeTypeIncome().toString());
        paymentEvent.setPaymentType(document.getTypeTaxPayment() == null || !document.getTypeTaxPayment() ? ""
                : "1");

        return paymentEvent;

    }

    private Request createRequest(SignatureDTO signature) {
        Request request = new Request();
        request.setId(UUID.randomUUID().toString());
        request.setReqDate(new Date());
        request.setServerIp(serverIp);
        request.setSessionId(Optional.ofNullable(signature).map(SignatureDTO::getMetaData)
                .map(MetaDataDTO::getSessionId).orElse(""));
        request.setDeviceId(Optional.ofNullable(signature).map(SignatureDTO::getMetaData)
                .map(MetaDataDTO::getDeviceId).orElse(""));
        request.setAppVersion(Optional.ofNullable(signature).map(SignatureDTO::getMetaData)
                .map(MetaDataDTO::getAppVersion).orElse(""));
        return request;
    }

    private Customer createCustomer(PaymentEntity document, ClientDTO client) {

        Customer customer = new Customer();
        customer.setUserId(Optional.ofNullable(client).map(ClientDTO::getId).orElse(null));
        customer.setName(Optional.ofNullable(client).map(ClientDTO::getFio).orElse(null));
        customer.setUserLogin(Optional.ofNullable(client).map(ClientDTO::getLogin).orElse(null));
        // TODO add natural bis id
        customer.setAbsId("");
        customer.setSiebelId(Optional.ofNullable(client).map(ClientDTO::getCrmId).orElse(""));
        customer.setType(CustomerType.PHYSICAL.getText());
        customer.setRegDate(Optional.ofNullable(client).map(ClientDTO::getRegistrationCompleted)
                .map(Utils::toDate).orElse(null));
        customer.setRegDateIn(Optional.ofNullable(client).map(ClientDTO::getPermPassPrimeSet)
                .map(Utils::toDate).orElse(null));

        return customer;
    }

    private Entity createEntity(PaymentEntity document, SignatureDTO signature) {
        Entity entity = new Entity();
        entity.setSiebelId(Optional.ofNullable(document.getOrganizationCrmId()).orElse(""));
        entity.setAbsId(Optional.ofNullable(document.getOrganizationBisId()).orElse("")
                + Optional.ofNullable(document.getOrganizationBisBranch()).orElse(""));
        entity.setOrganizationName(Optional.ofNullable(document.getOrganizationShortName())
                .orElse(Optional.ofNullable(signature).map(SignatureDTO::getCertificateId)
                        .map(this::getOrgNameFromCertRequest).orElse(Optional.empty()).orElse("")));
        entity.setInn(document.getPayerInn());
        entity.setType(CustomerType.LEGAL.getText());
        return entity;
    }

    public Optional<String> getOrgNameFromCertRequest(String certificateId) {
        CertificateDTO certificate = cryptoproService.getCertificate(certificateId);
        return  Optional.ofNullable(certificate).map(CertificateDTO::getCrmId)
                .flatMap(cryptoproService::getCertificateRequest)
                .map(CertificateRequestDTO::getNameShort);

    }

    private Parameters createParameters(SignatureDTO signature) {
        Parameters parameters = new Parameters();
        parameters.setSystemId(PARAMETER_SYSTEM_ID_PRO_ONLINE);
        parameters.setChannelType(Optional.ofNullable(signature).map(SignatureDTO::getMetaData)
                .map(MetaDataDTO::getPlatform).map(this::mapPlatformToChannelType).orElse(null));
        parameters.setTypeCode(EventType.PAYMENT.toString());
        MetaDataDTO metaDataDTO = Optional.ofNullable(signature).map(SignatureDTO::getMetaData).orElse(null);
        if (metaDataDTO != null) {
            parameters.setIp(metaDataDTO.getIp());
            parameters.setOs(apiLevelToVersionConverter.getVersion(metaDataDTO.getOs()));
            parameters.setMan(metaDataDTO.getMan());
            parameters.setModel(metaDataDTO.getModel());
            parameters.setPlatform(metaDataDTO.getPlatform());
        }

        return parameters;
    }

    private String mapPlatformToChannelType(String platform) {
        if (OS_TYPE_ANDROID.equals(platform) || OS_TYPE_IOS.equals(platform)) {
            return ChannelType.MOBILE.getText();
        } else {
            return ChannelType.WEB.getText();
        }
    }

    private String getPayerPlace(PaymentEntity document) {
        return getPlaceByBic(document.getPayerBankBic());
    }

    private String getPayeePlace(PaymentEntity document) {
        return getPlaceByBic(document.getPayeeBankBic());
    }

    private String getPlaceByBic(String bic) {
        return cbBicRepository.findByBic(bic)
                .map(cbBic -> Optional.ofNullable(cbBic.getTnp()).orElse("")
                        + " "
                        + Optional.ofNullable(cbBic.getNnp()).orElse("")
                ).orElse("");
    }

    private void createResolution(PaymentEvent paymentEvent, PaymentEntity document) {
        AntifraudResolutionEntity entity = new AntifraudResolutionEntity();
        entity.setRequestId(paymentEvent.getRequest().getId());
        entity.setCreated(LocalDateTime.now());
        entity.setDocumentId(Long.parseLong(paymentEvent.getId()));
        entity.setClientId(document.getClientId());
        entity.setStatus(ANTIFRAUD_PROCESSING);
        antifraudResolutionRepository.save(entity);
    }

    private SignatureDTO getSignatureFromDocument(PaymentEntity document) throws DocumentGetSignatureException {

        return cryptoproService.getDocumentSignatures(document)
                .stream()
                .filter(SignatureDTO::getConfirmed)
                .findFirst()
                .orElseThrow(() -> new DocumentGetSignatureException("Не найдена подпись документа с id=" + document.getId()));

    }

    public String getDfmPaymentFlag(PaymentEntity document) {
        return dfmPaymentRepository
                .findByDocSerial(document.getId())
                .map(DFMPaymentEntity::getFlag)
                .map((f) -> (Optional.of(f).orElse(-1) > 1) ? "1" : "")
                .orElse("");
    }
}
