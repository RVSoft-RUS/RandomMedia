package ru.rosbank.paymentapp.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.AntifraudResolutionEntity;

@Repository
public interface AntifraudResolutionEntityRepository extends CrudRepository<AntifraudResolutionEntity, Long> {

    Optional<AntifraudResolutionEntity> findByRequestId(String requestId);

    Optional<AntifraudResolutionEntity> findByDocumentId(Long documentId);

}
