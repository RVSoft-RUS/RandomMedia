package ru.rosbank.paymentapp.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

@Configuration
@EnableScheduling
@Profile("!unit_test")
public class ScheduledConfiguration implements SchedulingConfigurer {

    @Value("${scheduler.pool.size}")
    int poolSize;

    @Autowired
    PaymentProcessCheckJob paymentProcessCheckJob;
    @Autowired
    RejectedPaymentStatusJob rejectedPaymentStatusJob;
    @Autowired
    RejectedVtbPaymentStatusJob rejectedVtbPaymentStatusJob;
    @Autowired
    SendCurrencyControlToProPortalJob sendCurrencyControlToProPortalJob;

    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {

        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.setPoolSize(poolSize);
        threadPoolTaskScheduler.setThreadNamePrefix("scheduler-thread");
        threadPoolTaskScheduler.initialize();

        paymentProcessCheckJob.schedule(threadPoolTaskScheduler);
        rejectedPaymentStatusJob.schedule(threadPoolTaskScheduler);
        rejectedVtbPaymentStatusJob.schedule(threadPoolTaskScheduler);
        sendCurrencyControlToProPortalJob.schedule(threadPoolTaskScheduler);


        taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);

    }

}
