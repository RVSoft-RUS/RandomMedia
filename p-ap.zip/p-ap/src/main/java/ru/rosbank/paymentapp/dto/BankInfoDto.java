package ru.rosbank.paymentapp.dto;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 *                 Данные банка
 *
 *              <p>bic - БИК
 *                 name - наименование банка
 *                 correspondentAccount - К/с банка
 *
 * <p>Java class for BankInfo complex type.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankInfoDto implements Serializable {

    protected String bic;
    protected String name;
    protected String correspondentAccount;

    /**
     * Sets the value of {@link BankInfoDto#bic} and returns itself.
     *
     * @param bic
     *     new value to assign to {@link BankInfoDto#bic}
     * @return
     *     this object
     */
    public BankInfoDto withBic(String bic) {
        this.bic = bic;
        return this;
    }

    /**
     * Sets the value of {@link BankInfoDto#name} and returns itself.
     *
     * @param name
     *     new value to assign to {@link BankInfoDto#name}
     * @return
     *     this object
     */
    public BankInfoDto withName(String name) {
        this.name = name;
        return this;
    }

    /**
     * Sets the value of {@link BankInfoDto#correspondentAccount} and returns itself.
     *
     * @param correspondentAccount
     *     new value to assign to {@link BankInfoDto#correspondentAccount}
     * @return
     *     this object
     */
    public BankInfoDto withCorrespondentAccount(String correspondentAccount) {
        this.correspondentAccount = correspondentAccount;
        return this;
    }

}
