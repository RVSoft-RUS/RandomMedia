package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.AntifraudBlockEntity;

@Repository
public interface AntifraudBlockEntityRepository extends CrudRepository<AntifraudBlockEntity, Long> {

    Optional<AntifraudBlockEntity> findByClientIdAndReleasedIsNull(Long clientId);

    Optional<AntifraudBlockEntity> findTopByClientIdOrderByCreatedDesc(Long clientId);

}
