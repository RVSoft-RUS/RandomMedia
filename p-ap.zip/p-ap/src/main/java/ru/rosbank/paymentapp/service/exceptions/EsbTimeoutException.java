package ru.rosbank.paymentapp.service.exceptions;


public class EsbTimeoutException extends RuntimeException {

    public EsbTimeoutException(String message) {
        super(message);
    }

}
