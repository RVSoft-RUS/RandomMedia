package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.CbBicRstr;

@Repository
public interface CbBicRstrRepository extends CrudRepository<CbBicRstr, Long> {

    Optional<CbBicRstr> findByBic(String bic);

}
