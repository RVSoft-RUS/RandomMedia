package ru.rosbank.paymentapp.service.reference;

import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;

@RequiredArgsConstructor
@Slf4j
@Service
public class ReferenceService {

    private final ReferenceAppApiClient referenceApi;


    public List<BankDTO> getBanks(String query) {
        try {
            return referenceApi.bankGet(query).getBody();
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return new ArrayList<>();
    }

}
