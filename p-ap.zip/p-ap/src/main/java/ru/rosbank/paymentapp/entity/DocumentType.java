package ru.rosbank.paymentapp.entity;

public enum DocumentType {

    DA,
    DB,
    DC,
    DD,
    DE,
    DF,
    DG,
    DH,
    DI,
    DP,
    CA,
    CB,
    CC,
    CD,
    CE,
    CF,
    CG,
    CH;

    public String value() {
        return name();
    }

    public static DocumentType fromValue(String v) {
        return valueOf(v);
    }
}
