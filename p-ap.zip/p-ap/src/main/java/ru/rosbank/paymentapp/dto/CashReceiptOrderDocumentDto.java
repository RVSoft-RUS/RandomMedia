package ru.rosbank.paymentapp.dto;

import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 *                 Приходный кассовый ордер
 *
 *              <p>valueDate - Дата валютирования
 *                 orderStampSinger - Составитель
 *                 content - Содержание операции, наименование, номер и дата документа,
 *                 на основании которого составлен мемориальный ордер
 *                 ITMTransId - Референс
 *
 * <p>Java class for CashReceiptOrderDocument complex type.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class CashReceiptOrderDocumentDto extends AbstractDocumentDto {

    protected Date valueDate;
    protected BankInfoDto processedBy;
    protected String orderStampSinger;
    protected String itmTransId;
    protected String content;

}
