package ru.rosbank.paymentapp.service.exceptions;


public class DocumentGetSignatureException extends Exception {

    public DocumentGetSignatureException(String msg) {
        super(msg);
    }

}
