package ru.rosbank.paymentapp.template;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.TemplateEntity;
import ru.rosbank.paymentapp.repository.TemplateRepository;
import ru.rosbank.paymentapp.template.exception.DuplicateTemplateNameException;


/**
 * Summary.
 * @author rb067368
 *      22.09.2020
 */

@Service
public class TemplateNameValidator {

    @Autowired
    private TemplateRepository templateRepository;

    private static final String TEMPLATE_NAME_EXISTS_ERROR = "Шаблон с таким именем уже существует. Пожалуйста, "
        + "введите другое имя";


    public void validateNewTemplateName(String templateName, String dboProId) throws DuplicateTemplateNameException {
        Optional<TemplateEntity> optionalTemplate = templateRepository
            .findFirstByDboProIdAndStatusAndName(dboProId, TemplateEntity.Status.ACTIVE.value(), templateName);
        if (optionalTemplate.isPresent()) {
            throw new DuplicateTemplateNameException(TEMPLATE_NAME_EXISTS_ERROR);
        }
    }

    public void validateExistingTemplateName(TemplateEntity template) throws DuplicateTemplateNameException {
        Optional<TemplateEntity> optionalTemplate = templateRepository
            .findFirstByDboProIdAndStatusAndNameAndIdIsNot(template.getDboProId(), TemplateEntity.Status.ACTIVE.value(),
                template.getName(), template.getId());
        if (optionalTemplate.isPresent()) {
            throw new DuplicateTemplateNameException(TEMPLATE_NAME_EXISTS_ERROR);
        }
    }
}
