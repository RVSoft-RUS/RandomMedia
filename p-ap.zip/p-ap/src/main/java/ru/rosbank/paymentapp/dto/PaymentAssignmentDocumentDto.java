package ru.rosbank.paymentapp.dto;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 *                 Платежное поручение
 *
 *              <p>paymentOutputMode - Вид платежа
 *                 paymentPriority - Очередность платежа
 *                 uin - УИН
 *                 processedBy - Филиал банка, который обрабатывал документ
 *                 incomingDate - дата поступления в банк плательщика
 *                 payerStatus - Статус плательщика
 *                 kbk - КБК
 *                 oktmo - ОКТМО
 *                 paymentBasis - Основание платежа (идентификатор)
 *                 taxPeriod - Налоговый период
 *                 basisDocumentNumber - Номер документа основания
 *                 basisDocumentCreated - Дата документа основания
 *                 statusMessage - комментарий для документов со статусами "Отклонён" и "Отозван"
 *                 confirmed - признак того, что текущий пользователь (подтвердил) подписал документ
 *                 CardPan - Карта
 *                 CardHolder - Держатель
 *                 ApproveCode - Код авторизации
 *                 mcc - МСС
 *                 codeTypeIncome - поле 20: Назначение платежа (Код вида дохода)
 *                 typeTaxPayment - Тип налогового платежа поле 110
 *
 * <p>Java class for PaymentAssignmentDocument complex type.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class PaymentAssignmentDocumentDto extends AbstractDocumentDto {

    protected PaymentOutputModeDto paymentOutputMode;
    protected String paymentPriority;
    protected String uin;
    protected BankInfoDto processedBy;
    protected Date incomingDate;
    protected String payerStatus;
    protected String kbk;
    protected String oktmo;
    protected String paymentBasis;
    protected String taxPeriod;
    protected String basisDocumentNumber;
    protected String basisDocumentCreated;
    protected String statusMessage;
    protected Boolean confirmed;
    protected String cardPan;
    protected String cardHolder;
    protected String approveCode;
    protected String mcc;
    protected Integer codeTypeIncome;
    protected Boolean typeTaxPayment;

    /**
     * {@inheritDoc}
     *
     */
    @Override
    public PaymentAssignmentDocumentDto withStatus(DocumentStatusDto status) {
        super.withStatus(status);
        return this;
    }


    /**
     * Sets the value of {@link PaymentAssignmentDocumentDto#cardPan} and returns itself.
     *
     * @param cardPan
     *     new value to assign to {@link PaymentAssignmentDocumentDto#cardPan}
     * @return
     *     this object
     */
    public PaymentAssignmentDocumentDto withCardPan(String cardPan) {
        this.cardPan = cardPan;
        return this;
    }
}
