package ru.rosbank.paymentapp.service.fraud;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import ru.rosbank.paymentapp.service.audit.AuditContext;
import ru.rosbank.paymentapp.service.fraud.model.Customer;
import ru.rosbank.paymentapp.service.fraud.model.Request;
import ru.rosbank.paymentapp.service.fraud.model.constant.ChannelType;
import ru.rosbank.paymentapp.service.fraud.model.constant.CustomerType;
import ru.rosbank.paymentapp.util.Utils;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

public abstract class AbstractUserEventService extends AbstractAntifraudService {

    protected static final String PARAMETER_SYSTEM_ID_PRO_ONLINE = "2";

    @Autowired
    protected FraudSenderService fraudSenderService;

    @Value("${anti-fraud.user.respect}")
    protected boolean respectUserEvent;
    @Value("${anti-fraud.user.event.topic.name}")
    protected String userEventTopicName;
    @Value("${server.ip}")
    protected String serverIp;

    protected Request createRequest() {
        Request request = new Request();
        request.setId(UUID.randomUUID().toString());
        request.setReqDate(new Date());
        request.setServerIp(serverIp);
        return request;
    }

    protected Request createRequest(AuditContext context) {
        Request request = createRequest();
        request.setSessionId(context.getSessionId());
        request.setDeviceId(Optional.ofNullable(context.getDeviceId()).orElse(""));
        request.setAppVersion(Optional.ofNullable(context.getApplicationVersion()).orElse(""));
        return request;
    }

    protected Customer createCustomer(ClientDTO client) {
        Customer customer = new Customer();
        customer.setUserId(client.getId());
        customer.setName(client.getFio());
        customer.setUserLogin(client.getLogin());

        // TODO add natural bis id
        customer.setAbsId("");

        customer.setSiebelId(Optional.ofNullable(client.getCrmId()).orElse(""));

        customer.setType(CustomerType.PHYSICAL.getText());
        Optional.ofNullable(client.getRegistrationCompleted()).map(Utils::toDate).ifPresent(customer::setRegDate);
        Optional.ofNullable(client.getPermPassPrimeSet()).map(Utils::toDate).ifPresent(customer::setRegDateIn);

        return customer;
    }


    protected String mapPlatformToChannelType(String platform) {
        if (OS_TYPE_ANDROID.equals(platform) || OS_TYPE_IOS.equals(platform)) {
            return ChannelType.MOBILE.getText();
        } else {
            return ChannelType.WEB.getText();
        }
    }

}
