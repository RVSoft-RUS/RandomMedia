package ru.rosbank.paymentapp.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.entity.DocumentRecallEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.esb.service.ReversePaymentOrderService;
import ru.rosbank.paymentapp.esb.support.BankProcessingException;
import ru.rosbank.paymentapp.repository.DFMPaymentRepository;
import ru.rosbank.paymentapp.repository.DocumentRecallRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.dfm.DfmEmailService;
import ru.rosbank.paymentapp.service.exceptions.DocumentLockException;
import ru.rosbank.paymentapp.service.exceptions.DocumentNotSignedException;
import ru.rosbank.paymentapp.service.exceptions.DocumentRecallException;
import ru.rosbank.paymentapp.service.exceptions.PaymentNotFoundException;
import ru.rosbank.paymentapp.service.exceptions.PaymentNotRevertibleException;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService;
import ru.rosbank.paymentapp.service.fraud.PaymentStatusEvents;
import ru.rosbank.platform.esb.exception.EsbTimeoutException;
import ru.rosbank.platform.redis.SharedLock;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentRecallService {

    private final PaymentEntityRepository paymentEntityRepository;
    private final DocumentRecallRepository documentRecallRepository;
    private final SharedLock sharedLock;
    private final ReversePaymentOrderService reversePaymentOrderService;
    private final PaymentEventService paymentEventService;
    private final PaymentStatusEventService paymentStatusEventService;
    private final DFMPaymentRepository dfmPaymentRepository;
    private final DfmEmailService dfmEmailService;

    @Value("${dfm.payment.lock.task.period}")
    int period;

    public enum RecallStatus {
        CREATED,
        RETRY,
        ERROR,
        TIMEOUT,
        SIGNED,
        RECALLED
    }

    public static final List<String> NON_REVERTIBLE_STATUS
            = List.of(DocumentStatus.COMPLETED.name(), DocumentStatus.REJECTED.name(),
            DocumentStatus.RECALLED.name(), DocumentStatus.ERROR.name());

    @Transactional
    public DocumentRecallEntity initiate(Long paymentId) {
        PaymentEntity document = paymentEntityRepository
                .findById(paymentId)
                .orElseThrow(() -> new PaymentNotFoundException(paymentId));
        if (document.getDocumentRecallEntity() != null) {
            return document.getDocumentRecallEntity();
        } else {
            return createRecallEntity(document);
        }
    }

    @Transactional
    public DocumentRecallEntity setSigned(DocumentRecallEntity recallEntity) {
        recallEntity.setStatus(RecallStatus.SIGNED.name());
        return documentRecallRepository.save(recallEntity);
    }

    @Transactional
    public DocumentRecallEntity setRetry(DocumentRecallEntity recallEntity) {
        recallEntity.setStatus(RecallStatus.RETRY.name());
        return documentRecallRepository.save(recallEntity);
    }

    @Retryable(value = DocumentLockException.class, maxAttemptsExpression = "${payment.recall.retry.maxAttempts}",
            backoff = @Backoff(delayExpression = "${payment.recall.retry.maxDelay}"))
    public void process(DocumentRecallEntity recallEntity) throws DocumentLockException, DocumentRecallException {
        boolean lock = false;
        Long paymentId = recallEntity.getPaymentEntity().getId();
        String lockKey = "DFMPayment_" + paymentId;
        try {
            lock = sharedLock.lock(lockKey, period);
            if (lock) {
                var document = paymentEntityRepository.findById(paymentId)
                        .orElseThrow(() -> new PaymentNotFoundException(paymentId));
                if (NON_REVERTIBLE_STATUS.contains(document.getStatus())) {
                    recallEntity.setStatus(recallEntity.getPaymentEntity().getStatus());
                    documentRecallRepository.save(recallEntity);
                    throw new PaymentNotRevertibleException("Документ нельзя отозвать");
                } else if (DocumentStatus.SENT_TO_BIS.name().equals(document.getStatus())) {
                    if (isSigned(recallEntity)) {
                        reversePaymentOrderService.reversePaymentOrder(recallEntity.getPaymentEntity());
                        saveRecalledStatus(recallEntity);
                        sendEmailToDfmAfterRecall(document);
                    } else {
                        throw new DocumentNotSignedException("Отзыв документа не подписан");
                    }
                } else {
                    saveRecalledStatus(recallEntity);
                }
                sharedLock.release(lockKey);
            } else {
                throw new DocumentLockException("Не удалось захватить управление документом " + paymentId);
            }
        } catch (BankProcessingException e) {
            recallEntity.setStatus(RecallStatus.ERROR.name());
            recallEntity.setInfo("code: " + e.getCode() + " " + e.getRuMessage());
            documentRecallRepository.save(recallEntity);
            if (lock) {
                sharedLock.release(lockKey);
            }
            throw new DocumentRecallException("Ошибка отзыва документа " + paymentId);
        } catch (EsbTimeoutException e) {
            recallEntity.setStatus(RecallStatus.TIMEOUT.name());
            recallEntity.setInfo(e.getMessage());
            documentRecallRepository.save(recallEntity);
            if (lock) {
                sharedLock.release(lockKey);
            }
            throw new DocumentRecallException("Ошибка отзыва документа " + paymentId);
        } finally {
            if (lock) {
                sharedLock.release(lockKey);
                log.info("lock " + lockKey + " is released");
            }
        }

    }

    private void sendEmailToDfmAfterRecall(PaymentEntity doc) {
        dfmPaymentRepository.findByDocSerial(doc.getId())
                .filter(dfm -> !dfm.getFlag().equals(1) && StringUtils.isNotBlank(doc.getBisDocumentId()))
                .ifPresent(dfm -> dfmEmailService
                        .sendMailToDfm(dfm, doc, false, true));
    }

    private void saveRecalledStatus(DocumentRecallEntity recallEntity) {
        String info = "Отозвано пользователем " + new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(new Date());
        recallEntity.setStatus(RecallStatus.RECALLED.name());
        recallEntity.setInfo(info);
        documentRecallRepository.save(recallEntity);
        var document = recallEntity.getPaymentEntity();
        if (DocumentStatus.REVIEW.toString().equals(document.getStatus())) {
            paymentStatusEventService.sendPaymentEvent(document, PaymentStatusEvents.ANTI_FRAUD_RECALLED_IN_REVIEW);
        }
        document.setStatus(DocumentStatus.RECALLED.name());
        paymentEventService.sendDocumentStatus(document);
        paymentStatusEventService.checkDocumentAndSave(info, document);
    }

    private boolean isSigned(DocumentRecallEntity recallEntity) {
        return DocumentStatus.SIGNED.name().equals(recallEntity.getStatus());
    }

    private DocumentRecallEntity createRecallEntity(PaymentEntity document) {
        DocumentRecallEntity recallEntity = new DocumentRecallEntity();
        recallEntity.setPaymentEntity(document);
        recallEntity.setStatus(RecallStatus.CREATED.name());
        return documentRecallRepository.save(recallEntity);
    }

}
