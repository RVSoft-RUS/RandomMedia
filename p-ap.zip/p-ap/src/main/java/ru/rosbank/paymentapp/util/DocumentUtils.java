package ru.rosbank.paymentapp.util;

import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CA;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CB;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CC;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CD;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CE;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CF;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CG;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CH;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.CJ;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DA;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DB;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DC;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DD;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DE;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DF;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DG;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DH;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DI;
import static ru.rosbank.paymentapp.dto.DocumentTypeDto.DJ;

import com.google.gson.Gson;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import lombok.extern.slf4j.Slf4j;
import ru.rosbank.paymentapp.dto.AbstractDocumentDto;
import ru.rosbank.paymentapp.dto.DocumentStatusDto;
import ru.rosbank.paymentapp.dto.DocumentTypeDto;
import ru.rosbank.paymentapp.dto.PaymentOrderDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentOutputModeDto;
import ru.rosbank.platform.server.paymentapp.model.Document;

@Slf4j
public class DocumentUtils {

    public static final Collection<DocumentTypeDto> INCOME = Collections.unmodifiableCollection(
            Arrays.asList(CA, CB, CD, CC, CE, CF, CG, CH, CJ)
    );

    public static final Collection<DocumentTypeDto> OUTCOME = Collections.unmodifiableCollection(
            Arrays.asList(DA, DB, DD, DC, DE, DF, DG, DH, DI, DJ)
    );

    public static Document stringToDocument(String base64) {
        try {
            StringReader reader = new StringReader(new String(Base64.getDecoder().decode(base64)));
            return new Gson().fromJson(reader, Document.class);
        } catch (Exception e) {
            return null;
        }
    }

    public static String toPaymentBisId(String bisId) {
        if (bisId.startsWith("Y01")) {
            String changedBisId = bisId.replace("Y01", "PP");
            changedBisId = changedBisId.substring(0, 8) + '-' + changedBisId.substring(8);
            return changedBisId;
        }
        return bisId;
    }

    public static String toStatementBisId(String bisId) {
        if (bisId.startsWith("PP")) {
            String changedBisId = bisId.replace("PP", "Y01");
            changedBisId = changedBisId.replace("-", "");
            return changedBisId;
        }
        return bisId;
    }

    public static String replaceBisId(String bisId) {
        String changedBisId;
        if (bisId.startsWith("Y01")) {
            changedBisId = bisId.replace("Y01", "PP");
            changedBisId = changedBisId.substring(0, 8) + '-' + changedBisId.substring(8);
            return changedBisId;
        }
        if (bisId.startsWith("PP")) {
            changedBisId = bisId.replace("PP", "Y01");
            changedBisId = changedBisId.replace("-", "");
            return changedBisId;
        }
        return bisId;
    }

    //Imported from bs-app, using in print forms
    public static boolean isDebit(AbstractDocumentDto documentDto) {
        return OUTCOME.contains(documentDto.getType());
    }

    public static boolean isCredit(AbstractDocumentDto documentDto) {
        return INCOME.contains(documentDto.getType());
    }

    public static boolean isCompleted(AbstractDocumentDto documentDto) {
        return documentDto.getStatus() != null && documentDto.getStatus().equals(DocumentStatusDto.COMPLETED);
    }

    public static String getPaymentType(PaymentOutputModeDto paymentOutputModeDto) {
        return PaymentOutputModeDto.URGENT.equals(paymentOutputModeDto) ? "Срочно" : "";
    }

    public static boolean isPartialAccept(AbstractDocumentDto documentDto) {
        if (documentDto instanceof PaymentOrderDocumentDto) {
            return !(((PaymentOrderDocumentDto) documentDto).getDocumentContent() != null
                    && ((PaymentOrderDocumentDto) documentDto).getDocumentContent().equals("ЧА"));
        } else {
            return false;
        }
    }

    public static boolean isRejectedOrRecalled(AbstractDocumentDto documentDto) {
        return documentDto.getStatus() != null && (documentDto.getStatus().equals(DocumentStatusDto.RECALLED)
                || documentDto.getStatus().equals(DocumentStatusDto.REJECTED));
    }
}
