package ru.rosbank.paymentapp.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity(name = "payment_vk_info")
public class CurrencyControlEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "is_sum_contract_less_200")
    private Boolean isSumContractLess200;

    @Column(name = "is_sent_to_pro_portal", columnDefinition = "boolean default false")
    private Boolean isSentToProPortal;

    private String comment;

    private String fullName;

    private String phone;

    @Column(columnDefinition = "integer default 0")
    private Integer attemptsSentProPortal;

    @OneToOne(mappedBy = "currencyControlEntity")
    private PaymentEntity paymentEntity;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "currencyControlEntity")
    private List<FileInfoEntity> fileInfoEntityList;
}
