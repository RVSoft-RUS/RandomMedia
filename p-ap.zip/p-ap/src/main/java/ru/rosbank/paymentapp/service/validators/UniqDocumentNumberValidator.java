package ru.rosbank.paymentapp.service.validators;

import static java.time.temporal.TemporalAdjusters.firstDayOfYear;
import static java.time.temporal.TemporalAdjusters.lastDayOfYear;
import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.StringUtils.isNumeric;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.exceptions.DocumentNumberException;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;


@Service
public class UniqDocumentNumberValidator {
    private static final String ERROR_MESSAGE_COUNT_OF_CHARS = "3: Максимум 6 символов. Для ввода доступны только цифры";
    private static final String ERROR_MESSAGE_NOT_UNIQUE = "3: Такой № документа уже существует. Введите другой №";
    private static final String ERROR_MESSAGE_ZEROS = "3: Все цифры не могут быть нулями";
    private static final String ERROR_MESSAGE_ONE_ZERO = "3: Номер не может быть \"0\"";
    private static final String ERROR_MESSAGE_EMPTY = "3: Заполните поле";
    private static final String ERROR_MESSAGE_NOT_UNIQUE_PER_DEY = "Документ с таким номером уже существует. "
            + "Проверьте, возможно сегодня вы сохраняли или подписывали такой же платёж.";
    private static final List<String> SUITABLE_STATUS = List.of(
            DocumentStatus.CREATED.getValue(),
            DocumentStatus.SIGNED.getValue(),
            DocumentStatus.DFM_PROCESSING.getValue(),
            DocumentStatus.REVIEW.getValue(),
            DocumentStatus.PLANNED.getValue(),
            DocumentStatus.SENT_TO_BIS.getValue(),
            DocumentStatus.COMPLETED.getValue(),
            DocumentStatus.PROCESSING.getValue());


    @Autowired
    private PaymentEntityRepository documentRepository;

    public void validate(PaymentEntity doc) throws DocumentNumberException {

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime firstDayOfYear = now.with(firstDayOfYear());
        LocalDateTime lastDayOfYear = now.with(lastDayOfYear());

        Long excludeID = Optional.ofNullable(doc.getId()).orElse((long) Integer.MIN_VALUE);

        Optional<PaymentEntity> checkUnique = documentRepository
                .findTopByPayerInnAndNumberAndIdNotAndDateBetween(doc.getPayerInn(),
                doc.getNumber(), excludeID, firstDayOfYear, lastDayOfYear);
        if (checkUnique.isPresent()) {
            throw new DocumentNumberException(ERROR_MESSAGE_NOT_UNIQUE);
        }

        checkNumber(doc.getNumber());

    }

    public void validatePerDey(PaymentEntity doc, LocalDateTime now) throws DocumentNumberException {
        LocalDate documentDate = (doc.getExecutionDate() != null
                ? doc.getExecutionDate()
                : doc.getDate()
        ).toLocalDate();
        LocalDateTime firstDate = LocalDateTime.of(documentDate, LocalTime.of(0, 0, 0, 0));
        LocalDateTime lastDate = LocalDateTime.of(documentDate, LocalTime.of(23, 59, 59, 999));

        Long excludeID = Optional.ofNullable(doc.getId()).orElse((long) Integer.MIN_VALUE);

        Optional<PaymentEntity> checkUnique = documentRepository
                .findTopByPayerInnAndNumberAndIdNotAndDateBetweenAndStatusIn(doc.getPayerInn(),
                        doc.getNumber(), excludeID, firstDate, lastDate, SUITABLE_STATUS);
        if (checkUnique.isPresent()) {
            throw new DocumentNumberException(ERROR_MESSAGE_NOT_UNIQUE_PER_DEY);
        }
    }

    private void checkNumber(String number) throws DocumentNumberException {

        if (StringUtils.isBlank(number)) {
            throw new DocumentNumberException(ERROR_MESSAGE_EMPTY);
        }

        if (number.equals("0")) {
            throw new DocumentNumberException(ERROR_MESSAGE_ONE_ZERO);
        }

        if (StringUtils.containsOnly(number, "0")) {
            throw new DocumentNumberException(ERROR_MESSAGE_ZEROS);
        }

        if (isFalse(isNumeric(number)) || number.length() > 6) {
            throw new DocumentNumberException(ERROR_MESSAGE_COUNT_OF_CHARS);
        }

    }

}
