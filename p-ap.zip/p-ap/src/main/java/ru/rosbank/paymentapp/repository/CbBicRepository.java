package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.CbBic;

@Repository
public interface CbBicRepository extends CrudRepository<CbBic, Long> {

    Optional<CbBic> findByBic(String bic);

}
