package ru.rosbank.paymentapp.config;

import java.util.Map;
import lombok.Data;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("kafka")
public class MultipleKafkaProperties {
    private Map<String, KafkaProperties> configs;
}
