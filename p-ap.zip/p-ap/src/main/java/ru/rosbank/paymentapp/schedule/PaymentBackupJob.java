package ru.rosbank.paymentapp.schedule;

import java.util.List;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.BackupService;
import ru.rosbank.platform.redis.SharedLock;

@Service
@Slf4j
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PaymentBackupJob {
    BackupService backupService;
    SharedLock sharedLock;
    PaymentBackupConfig config;
    String keyLock = "BackupDocumentJob";

    @Scheduled(cron = "${schedulers.backup-payment-job.cron:0 0 23 * * *}", zone = "Europe/Moscow")
    public void backup() {
        if (!config.isEnable()) {
            return;
        }
        backupTask();
    }

    private void backupTask() {
        log.debug("Starting backup...");
        long startTime = System.currentTimeMillis();
        Pageable batch = PageRequest.of(0, config.getBatchRequest());
        int cycleCount = 0;
        boolean paymentBackupJob = sharedLock.lock(keyLock, config.getLockTimePeriod());
        int successBackupEntity = 0;
        if (paymentBackupJob) {
            for (List<PaymentEntity> paymentsCompleted = backupService.getBatchPayments(batch);
                 cycleCount < config.getMaxCountRequest() && !paymentsCompleted.isEmpty() && !isExceededTimeLimit(startTime);) {
                for (PaymentEntity payment : paymentsCompleted) {
                    try {
                        backupService.saveAndDeletePayment(payment);
                        successBackupEntity++;
                        log.debug("success delete entity");
                    } catch (Exception e) {
                        log.error("error while backup data with id {} {}", payment.getId(), e);
                        sharedLock.release(keyLock);
                        return;
                    }
                }
                paymentsCompleted = backupService.getBatchPayments(batch);
                cycleCount++;
            }
            sharedLock.release(keyLock);
            log.info("PaymentBackupJob backup completed successfully");
            log.info("the number of successful backup entity = {} ",successBackupEntity);
            log.info("backup execution time = {} s",(System.currentTimeMillis() - startTime) / 1000);
        } else {
            log.error("backup failed to capture lock");
        }

    }

    private boolean isExceededTimeLimit(long startTime) {
        return (System.currentTimeMillis() - startTime) / 1000 > config.getTaskTimeLimit();
    }

}
