package ru.rosbank.paymentapp.service.exceptions;

public class PaymentValidationException extends RuntimeException {

    public PaymentValidationException(Long id, String msg) {
        super(msg + " [id=" + id + "]");
    }

    public PaymentValidationException(String msg) {
        super(msg);
    }

    public PaymentValidationException(String msg, Throwable t) {
        super(msg, t);
    }
}
