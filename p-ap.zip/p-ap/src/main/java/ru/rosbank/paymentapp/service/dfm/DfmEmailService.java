package ru.rosbank.paymentapp.service.dfm;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.email.LocalEmailSender;

@Slf4j
@RequiredArgsConstructor
@Service
public class DfmEmailService {

    private static final String[] FM_ANALIZ_ZAPAD = {"R19", "R24", "R38"};
    protected static final Set<String> FM_ANALIZ_ZAPAD_MAP = new HashSet<>(Arrays.asList(FM_ANALIZ_ZAPAD));
    private static final String[] OTDEL_ANALIZA_V = {"R26", "R62", "R70", "R73", "R87"};
    protected static final Set<String> OTDEL_ANALIZA_V_MAP = new HashSet<>(Arrays.asList(OTDEL_ANALIZA_V));
    private final LocalEmailSender emailSender;
    @Value("${email.analiz.zapad.mail}")
    private String[] analizZapadMailList;
    @Value("${email.analiz.vostok.mail}")
    private String[] analizVostokMailList;

    @Async
    public void sendMailToDfm(DFMPaymentEntity dfmPayment, PaymentEntity doc, Boolean isError, Boolean isAfterRecall) {

        if (FM_ANALIZ_ZAPAD_MAP.contains(doc.getOrganizationBisBranch())) {
            sendMailToAnalyze(dfmPayment, doc, isError, isAfterRecall, analizZapadMailList);
        } else if (OTDEL_ANALIZA_V_MAP.contains(doc.getOrganizationBisBranch())) {
            sendMailToAnalyze(dfmPayment, doc, isError, isAfterRecall, analizVostokMailList);
        } else {
            log.error("incorrect branch number");
        }
    }

    private void sendMailToAnalyze(DFMPaymentEntity dfmPayment, PaymentEntity doc, Boolean isError,
                                   Boolean isAfterRecall, String[] emailList) {
        Stream.of(emailList).forEach(mail ->
                emailSender.sendSimpleEmail(mail,
                        isAfterRecall ? getSubjectAfterRecall(doc) : getSubject(dfmPayment, doc),
                        isAfterRecall ? getTextAfterRecall(doc) : getText(dfmPayment, isError))
        );
    }

    private String getSubject(DFMPaymentEntity dfmPayment, PaymentEntity doc) {
        return "ALERT - Платеж ДБО ПРО приостановлен для ДФМ " + doc.getOrganizationBisBranch() + " "
                + doc.getOrganizationBisId() + " " + DateFormatUtils.format(java.sql.Timestamp
                .valueOf(dfmPayment.getIdate()), "dd.MM.yy ") + dfmPayment.getDocNumber();
    }

    private String getText(DFMPaymentEntity dfmPayment, Boolean isError) {
        StringBuilder sb = new StringBuilder();
        sb.append("1. Дата создания документа - ").append(dfmPayment.getDocDate()).append("\t\n");
        sb.append("2. Назначение платежа - ").append(dfmPayment.getReason()).append("\t\n");
        sb.append("3. Сумма платежа - ").append(dfmPayment.getDocSum()).append("\t\n");
        sb.append("4. Наименование плательщика - ").append(dfmPayment.getName()).append("\t\n");
        sb.append("5. Счет плательщика - ").append(dfmPayment.getPayeracccode()).append("\t\n");
        sb.append("6. ИНН плательщика - ").append(dfmPayment.getPayerinn()).append("\t\n");
        sb.append("7. Наименование банка плательщика - ").append(dfmPayment.getPayerbank()).append("\t\n");
        sb.append("8. Наименование получателя - ").append(dfmPayment.getBenefname()).append("\t\n");
        sb.append("9. Счет получателя - ").append(dfmPayment.getBenefacccode()).append("\t\n");
        sb.append("10. ИНН получателя - ").append(dfmPayment.getBenefinn()).append("\t\n");
        sb.append("11. Банк получателя - ").append(dfmPayment.getBenefbank()).append("\t\n");
        sb.append("12. БИК банка получателя - ").append(dfmPayment.getBenefbik()).append("\t\n");
        sb.append("13. Номер документа в ДБО ПРО - ").append(dfmPayment.getDocNumber()).append("\t\n");
        sb.append("14. Причина приостановки - ").append(dfmPayment.getInf()).append("\t\n");
        if (isError) {
            sb.append("\t\n").append("///Тайм-аут///").append("\t\n");
        }
        log.debug(sb.toString());
        return sb.toString();
    }

    private String getTextAfterRecall(PaymentEntity doc) {
        return "ОТЗЫВ ПЛАТЕЖА" + "\n\n"
                + doc.getOrganizationShortName() + ", ИНН " + doc.getPayerInn() + "\n\n"
                + "Платежное поручение № " + doc.getNumber() + " от "
                + doc.getDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")) + "\n\n"
                + "Сумма " + doc.getAmount() + " руб.";
    }

    private String getSubjectAfterRecall(PaymentEntity doc) {
        return "Отзыв клиента_Платеж ДБО ПРО для ДФМ_"
                + doc.getOrganizationBisBranch() + "_"
                + doc.getOrganizationShortName() + "_"
                + doc.getOrganizationBisId() + "_"
                + doc.getDate().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")) + "_"
                + doc.getNumber();
    }
}
