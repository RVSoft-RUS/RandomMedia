package ru.rosbank.paymentapp.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 *                 Денежная сумма и связанная валюта.
 *
 * <p>Java class for Amount complex type.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AmountDto implements Serializable {

    protected BigDecimal sum;
    protected CurrencyDto currency;

    /**
     * Sets the value of {@link AmountDto#sum} and returns itself.
     *
     * @param sum
     *     new value to assign to {@link AmountDto#sum}
     * @return
     *     this object
     */
    public AmountDto withSum(BigDecimal sum) {
        this.sum = sum;
        return this;
    }

    /**
     * Sets the value of {@link AmountDto#currency} and returns itself.
     *
     * @param currency
     *     new value to assign to {@link AmountDto#currency}
     * @return
     *     this object
     */
    public AmountDto withCurrency(CurrencyDto currency) {
        this.currency = currency;
        return this;
    }
}
