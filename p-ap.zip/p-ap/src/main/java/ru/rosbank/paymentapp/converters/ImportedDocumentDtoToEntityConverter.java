package ru.rosbank.paymentapp.converters;


import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.ImportedDocumentEntity;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.paymentapp.util.FormatUtils;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;


/**
 * Summary.
 * @author rb067368
 */

@Service
public class ImportedDocumentDtoToEntityConverter {
    @Autowired
    UserService userService;

    public ImportedDocumentEntity convert(ImportedDocumentDTO importedDocumentDto, ClientDTO client, String batchId) {
        ImportedDocumentEntity entity = new ImportedDocumentEntity();
        entity.setId(Optional.ofNullable(importedDocumentDto.getId())
                .map(Long::valueOf).orElse(null));

        entity.setClientId(client.getLegacyId());
        entity.setBatch(batchId);

        entity.setStatus(importedDocumentDto.getStatus().getValue());
        entity.setNumber(importedDocumentDto.getNumber());
        entity.setCreated(importedDocumentDto.getDateCreated().toLocalDateTime());

        entity.setAmount(FormatUtils.parseAmount(importedDocumentDto.getAmount()));
        entity.setDocType(importedDocumentDto.getDocType().getValue());

        RequisiteDTO payer = importedDocumentDto.getPayer();
        entity.setPayerName(payer.getName());
        entity.setPayerAccount(payer.getAccount());
        entity.setPayerInn(payer.getInn());
        entity.setPayerKpp(payer.getKpp());
        entity.setPayerBankBic(payer.getBank().getBic());
        entity.setPayerBankName(payer.getBank().getName());
        entity.setPayerBankCorrespondentAccount(payer.getBank().getCorrespondentAccount());

        entity.setPayerStatus(importedDocumentDto.getPayerStatus());

        RequisiteDTO payee = importedDocumentDto.getPayee();
        entity.setPayeeName(payee.getName());
        entity.setPayeeAccount(payee.getAccount());
        entity.setPayeeInn(payee.getInn());
        entity.setPayeeKpp(payee.getKpp());
        entity.setPayeeBankBic(payee.getBank().getBic());
        entity.setPayeeBankName(payee.getBank().getName());
        entity.setPayeeBankCorrespondentAccount(payee.getBank().getCorrespondentAccount());


        entity.setPurpose(importedDocumentDto.getPurpose());
        entity.setPayPriority(importedDocumentDto.getPayPriority());
        entity.setUin(importedDocumentDto.getUin());
        entity.setPayerStatus(importedDocumentDto.getPayerStatus());
        entity.setKbk(importedDocumentDto.getKbk());
        entity.setOktmo(importedDocumentDto.getOktmo());
        entity.setDocumentDate(importedDocumentDto.getDocumentDate().toLocalDateTime());
        entity.setPaymentBasis(importedDocumentDto.getPaymentBasis());
        entity.setTaxPeriod(importedDocumentDto.getTaxPeriod());
        entity.setBasisDocumentNumber(importedDocumentDto.getBasisDocumentNumber());
        entity.setBasisDocumentCreated(importedDocumentDto.getBasisDocumentCreated());
        entity.setCodeTypeIncome(Optional.ofNullable(importedDocumentDto.getCodeTypeIncome()).map(Short::valueOf).orElse(null));
        entity.setTypeTaxPayment(Optional.ofNullable(Boolean.valueOf(importedDocumentDto.getTypeTaxPayment())).orElse(null));
        entity.setErrorMessage(importedDocumentDto.getErrorMessage());
        return entity;
    }

    public ImportedDocumentDTO convertBack(ImportedDocumentEntity entity) {
        ImportedDocumentDTO importedDocumentDto = new ImportedDocumentDTO();
        Optional<ClientDTO> client = userService.getClientById(entity.getClientId());
        client.ifPresent(clientDTO -> importedDocumentDto.setDboProId(clientDTO.getId()));
        importedDocumentDto.setId(Optional.ofNullable(entity.getId())
                .map(ti -> ti.toString()).orElse(null));

        importedDocumentDto.setBatchId(entity.getBatch());

        importedDocumentDto.setStatus(ImportedDocumentDTO.StatusEnum.fromValue(entity.getStatus()));
        importedDocumentDto.setNumber(entity.getNumber());
        importedDocumentDto.setDateCreated(entity.getCreated().atZone(ZoneId.systemDefault()).toOffsetDateTime());


        Optional.ofNullable(entity.getAmount()).map(String::valueOf).ifPresent(importedDocumentDto::setAmount);
        importedDocumentDto.setDocType(ImportedDocumentDTO.DocTypeEnum.fromValue(entity.getDocType()));

        RequisiteDTO payer = new RequisiteDTO();
        payer.setAccount(entity.getPayerAccount());
        BankInfoDTO payerBank = new BankInfoDTO();
        payerBank.bic(entity.getPayerBankBic()).correspondentAccount(entity.getPayerBankCorrespondentAccount())
                .name(entity.getPayerBankName());
        payer.setBank(payerBank);
        payer.setInn(StringUtils.isBlank(entity.getPayerInn()) ? "0" : entity.getPayerInn());
        payer.setName(entity.getPayerName());
        payer.setKpp(entity.getPayerKpp());
        importedDocumentDto.setPayer(payer);

        RequisiteDTO payee = new RequisiteDTO();
        payee.setAccount(entity.getPayeeAccount());
        BankInfoDTO payeeBank = new BankInfoDTO();
        payeeBank.bic(entity.getPayeeBankBic()).correspondentAccount(entity.getPayeeBankCorrespondentAccount())
                .name(entity.getPayeeBankName());
        payee.setBank(payeeBank);
        payee.setInn(StringUtils.isBlank(entity.getPayeeInn()) ? "0" : entity.getPayeeInn());
        payee.setName(entity.getPayeeName());
        payee.setKpp(entity.getPayeeKpp());
        importedDocumentDto.setPayee(payee);

        importedDocumentDto.setPurpose(entity.getPurpose());
        importedDocumentDto.setPayPriority(Optional.ofNullable(entity.getPayPriority()).orElse("5").trim());
        importedDocumentDto.setUin(entity.getUin());
        importedDocumentDto.setPayerStatus(entity.getPayerStatus());
        importedDocumentDto.setKbk(entity.getKbk());
        importedDocumentDto.setOktmo(entity.getOktmo());
        importedDocumentDto.setDocumentDate(entity.getDocumentDate().atOffset(ZoneOffset.UTC));
        importedDocumentDto.setPaymentBasis(entity.getPaymentBasis());
        importedDocumentDto.setTaxPeriod(entity.getTaxPeriod());
        importedDocumentDto.setBasisDocumentNumber(entity.getBasisDocumentNumber());
        importedDocumentDto.setBasisDocumentCreated(entity.getBasisDocumentCreated());
        importedDocumentDto.setCodeTypeIncome(Optional.ofNullable(entity.getCodeTypeIncome())
                .map(ti -> ti.toString()).orElse(null));
        importedDocumentDto.setTypeTaxPayment(Optional.ofNullable(entity.getTypeTaxPayment()).map(t -> t ? "1" : "0")
                .orElse(null));
        importedDocumentDto.setErrorMessage(entity.getErrorMessage());
        return importedDocumentDto;
    }
}
