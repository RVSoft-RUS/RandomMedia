package ru.rosbank.paymentapp.service;

import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApi;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationService {

    private final OrganizationAppApi organizationAppApi;

    public List<OrganizationDTO> rootGet(String dboProId) {
        try {
            return organizationAppApi.rootGet(dboProId).getBody();
        } catch (Exception e) {
            log.error("Feign exception get organizations",  e);
            return new ArrayList<>();
        }
    }
}
