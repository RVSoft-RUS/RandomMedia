package ru.rosbank.paymentapp.service;


import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.util.Utils;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;

@Slf4j
@Service
@RequiredArgsConstructor
public class RejectedVtbPaymentStatusProcessor {

    public static final String REJECTED_DOCUMENT_STATUS_MESSAGE = "Отклонен банком получателя платежа: "
            + "неверно указаны реквизиты получателя.";
    @Value("${rejected.VTBPaymentStatus.maxDeepDays:3}")
    private Integer maxDeepDays;

    private final EsbService esbService;

    private final RejectedPaymentStatusProcessor rejectedPaymentStatusProcessor;
    private final PaymentService documentService;

    public void process(List<PaymentEntity> paymentEntities, ClientDTO client) {
        try {
            List<AccountDTO> accounts = rejectedPaymentStatusProcessor.getPayerAccounts(paymentEntities, client);
            Date date = documentService.getDocumentCreationDate();
            List<PaymentOrderTypeEsb> paymentOrders = accounts.stream()
                .map(account -> esbService.getPaymentList(account.getNumber13(), account.getBisId().getBranch(),
                    new Date(Date.from(Utils.getLocalDate(date).minusDays(maxDeepDays).atStartOfDay()
                            .atZone(ZoneId.systemDefault()).toInstant()).getTime() + TimeZone.getDefault().getRawOffset() + 1),
                    new Date(date.getTime() + TimeZone.getDefault().getRawOffset() + 1)))
                .flatMap(List::stream).collect(Collectors.toList());
            paymentOrders = rejectedPaymentStatusProcessor.filterOnlyRejected(paymentOrders);

            for (PaymentOrderTypeEsb payment : paymentOrders) {
                for (PaymentEntity document : paymentEntities) {
                    if (rejectedPaymentStatusProcessor.isSameDocumentAndPayment(document, payment)) {
                        rejectedPaymentStatusProcessor.makeDocumentRejected(document, REJECTED_DOCUMENT_STATUS_MESSAGE);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error("Ошибка при обработке зависших документов клиент id {}", client.getId(), e);
        }
    }
}
