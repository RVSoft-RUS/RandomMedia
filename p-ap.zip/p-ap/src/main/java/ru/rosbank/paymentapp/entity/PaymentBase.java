package ru.rosbank.paymentapp.entity;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
public abstract  class PaymentBase {

    private String bisDocumentId;
    private String number;
    private LocalDateTime date;
    private LocalDateTime executionDate;
    private LocalDateTime signDate;
    private String status;
    private String statusMessage;

    // Only for search
    private String doctype;
    private String purpose;
    private BigDecimal amount;
    //PaymentFields
    private String paypriority;
    private boolean urgent;

    //BudgetPaymentFields
    private String payerStatus;
    private String paymentBasis;
    private String basisDocumentNumber;
    private String basisDocumentCreated;
    private String taxPeriod;
    private String uin;
    private String kbk;
    private String oktmo;

    //Requsites
    private String payerAccount;
    private String payerName;
    private String payerInn;
    private String payerKpp;
    private String payerBankBic;
    private String payerBankName;
    private String payerBankCorrespondentAccount;

    private String payeeAccount;
    private String payeeName;
    private String payeeInn;
    private String payeeKpp;
    private String payeeBankBic;
    private String payeeBankName;
    private String payeeBankCorrespondentAccount;

    private String remIp;
    private String remMac;
    private boolean showError;

    private String organizationBisId;
    private String organizationBisBranch;
    private String organizationCrmId;
    private String organizationShortName;

    private Long clientId;

    // поле 20: Назначение платежа (Код вида дохода)
    private Short codeTypeIncome;

    //Тип налогового платежа поле 110
    private Boolean typeTaxPayment;

    //Объект связи платежа(подписка и тд)
    private String referenceId;
    private String referenceType;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "vk_info_id", referencedColumnName = "id")
    private CurrencyControlEntity currencyControlEntity;

    @OneToOne(mappedBy = "paymentEntity", cascade = CascadeType.ALL)
    @PrimaryKeyJoinColumn
    private DocumentRecallEntity documentRecallEntity;

    //Payment HUB fields
    private UUID uuid;
    @Column(name = "status_date_time")
    private LocalDateTime statusDateTime;
    @Column(name = "status_comment")
    private String statusComment;
    @Column(name = "status_code", length = 100)
    private String statusCode;
    @Column(name = "status_sys_name", length = 100)
    private String statusSysName;

    //Дата зачисления на публичный депозитный счет  (Платежка для Нотариуса)
    @Column(name = "enrollment_date")
    private LocalDateTime enrollmentDate;

    public static final List<String> PROCESSING_STATUS
            = Collections.unmodifiableList(Arrays.asList(DocumentStatus.SIGNED.name(), DocumentStatus.DFM_PROCESSING.name(),
            DocumentStatus.PLANNED.name(), DocumentStatus.REVIEW.name()));

    public static final List<String> REVERTIBLE_STATUS
            = Collections.unmodifiableList(Arrays.asList(DocumentStatus.SIGNED.name(),
            DocumentStatus.PROCESSING.name(), DocumentStatus.PLANNED.name()));

    @Override
    public String toString() {
        return "PaymentEntity{"
                + "bisDocumentId='" + bisDocumentId + '\''
                + ", number='" + number + '\''
                + ", date=" + date
                + ", executionDate=" + executionDate
                + ", signDate=" + signDate
                + ", status='" + status + '\''
                + ", statusMessage='" + statusMessage + '\''
                + ", doctype='" + doctype + '\''
                + ", purpose='" + purpose + '\''
                + ", amount=" + amount
                + ", paypriority='" + paypriority + '\''
                + ", urgent=" + urgent
                + ", payerStatus='" + payerStatus + '\''
                + ", paymentBasis='" + paymentBasis + '\''
                + ", basisDocumentNumber='" + basisDocumentNumber + '\''
                + ", basisDocumentCreated='" + basisDocumentCreated + '\''
                + ", taxPeriod='" + taxPeriod + '\''
                + ", uin='" + uin + '\''
                + ", kbk='" + kbk + '\''
                + ", oktmo='" + oktmo + '\''
                + ", payerAccount='" + payerAccount + '\''
                + ", payerName='" + payerName + '\''
                + ", payerInn='" + payerInn + '\''
                + ", payerKpp='" + payerKpp + '\''
                + ", payerBankBic='" + payerBankBic + '\''
                + ", payerBankName='" + payerBankName + '\''
                + ", payerBankCorrespondentAccount='" + payerBankCorrespondentAccount + '\''
                + ", payeeAccount='" + payeeAccount + '\''
                + ", payeeName='" + payeeName + '\''
                + ", payeeInn='" + payeeInn + '\''
                + ", payeeKpp='" + payeeKpp + '\''
                + ", payeeBankBic='" + payeeBankBic + '\''
                + ", payeeBankName='" + payeeBankName + '\''
                + ", payeeBankCorrespondentAccount='" + payeeBankCorrespondentAccount + '\''
                + ", remIp='" + remIp + '\''
                + ", remMac='" + remMac + '\''
                + ", showError=" + showError
                + ", organizationBisId='" + organizationBisId + '\''
                + ", organizationBisBranch='" + organizationBisBranch + '\''
                + ", organizationCrmId='" + organizationCrmId + '\''
                + ", organizationShortName='" + organizationShortName + '\''
                + ", clientId=" + clientId
                + ", codeTypeIncome=" + codeTypeIncome
                + ", typeTaxPayment=" + typeTaxPayment
                + ", referenceId=" + referenceId
                + ", referenceType=" + referenceType
                + ", uuid=" + uuid
                + ", statusDateTime=" + statusDateTime
                + ", statusComment=" + statusComment
                + ", statusCode=" + statusCode
                + ", statusSysName=" + statusSysName + ", ";
    }
}
