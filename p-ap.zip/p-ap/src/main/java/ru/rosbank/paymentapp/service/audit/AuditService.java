package ru.rosbank.paymentapp.service.audit;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.auditapp.api.AuditAppApi;
import ru.rosbank.platform.client.auditapp.model.AntifraudRequestDTO;
import ru.rosbank.platform.client.auditapp.model.EventDTO;

/**
 * Summary.
 * @author rb066284
 */
@RequiredArgsConstructor
@Slf4j
@Service
public class AuditService {

    public static final String SENT_PAYMENT_LIST_SIEBEL_STAGE = "Запрос платежей из Siebel";

    private final AuditAppApi auditApi;

    @Async("audit_executor")
    public void sendEventAsync(EventDTO event) {
        sendEvent(event);
    }

    public void sendEvent(EventDTO event) {

        try {
            auditApi.rootPost(event);
        } catch (Exception e) {
            log.error("Failed audit log {}", e.getMessage());
        }
    }

    public void sendAntifraudEvent(AntifraudRequestDTO event) {
        try {
            auditApi.antifraudPost(event);
        } catch (FeignException e) {
            log.error("Ошибка отправки запроса в Антифрод", e);
        }
    }

}
