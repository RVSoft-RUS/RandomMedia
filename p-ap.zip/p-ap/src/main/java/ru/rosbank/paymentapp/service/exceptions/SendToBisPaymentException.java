package ru.rosbank.paymentapp.service.exceptions;

public class SendToBisPaymentException extends RuntimeException {

    public SendToBisPaymentException(String message, Throwable cause) {
        super(message, cause);
    }

}
