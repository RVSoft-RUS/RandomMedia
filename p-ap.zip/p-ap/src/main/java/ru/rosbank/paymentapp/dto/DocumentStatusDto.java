package ru.rosbank.paymentapp.dto;

/**
 * Java class for DocumentStatus.
 */
public enum DocumentStatusDto {

    CREATED,
    SIGNED,
    SIGNING,
    PROCESSING,
    COMPLETED,
    REJECTED,
    RECALLED,
    PLANNED,
    REVIEW;

    public static DocumentStatusDto fromValue(String v) {
        return valueOf(v);
    }

}
