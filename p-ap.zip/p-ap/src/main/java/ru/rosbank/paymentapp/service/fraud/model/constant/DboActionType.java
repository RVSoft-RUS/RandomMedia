package ru.rosbank.paymentapp.service.fraud.model.constant;

public enum DboActionType {
    REGISTRATION_PAYMENT,
    ACTIVE_OPERATIONS_BLOCKED,
    ACTIVE_OPERATIONS_UNBLOCKED_TIMEOUT
}
