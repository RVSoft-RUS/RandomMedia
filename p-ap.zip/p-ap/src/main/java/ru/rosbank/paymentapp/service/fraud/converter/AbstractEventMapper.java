package ru.rosbank.paymentapp.service.fraud.converter;

import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.EXECUTED_AT_ONCE_PAYMENT_STATUS;
import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.EXECUTED_POST_REVIEW_PAYMENT_STATUS;
import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.RECALLED_IN_REVIEW_PAYMENT_STATUS;
import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.REJECTED_AT_ONCE_PAYMENT_STATUS;
import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.REJECTED_POST_REVIEW_PAYMENT_STATUS;
import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.REVIEW_PAYMENT_STATUS;
import static ru.rosbank.paymentapp.service.fraud.PaymentStatusEventService.TIMEOUT_PAYMENT_STATUS;

import java.time.OffsetDateTime;
import java.util.Date;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import ru.rosbank.paymentapp.service.fraud.model.AntifraudDboEvent;
import ru.rosbank.paymentapp.service.fraud.model.AntifraudPaymentStatusEvent;
import ru.rosbank.paymentapp.service.fraud.model.Customer;
import ru.rosbank.paymentapp.service.fraud.model.DboEvent;
import ru.rosbank.paymentapp.service.fraud.model.Entity;
import ru.rosbank.paymentapp.service.fraud.model.Request;
import ru.rosbank.platform.client.auditapp.model.AntifraudEventDTO;
import ru.rosbank.platform.client.auditapp.model.AntifraudPaymentStatusDTO;
import ru.rosbank.platform.client.auditapp.model.CustomerDTO;
import ru.rosbank.platform.client.auditapp.model.DboEventDTO;
import ru.rosbank.platform.client.auditapp.model.EntityDTO;
import ru.rosbank.platform.client.auditapp.model.PaymentStatusDTO;
import ru.rosbank.platform.client.auditapp.model.RequestDTO;

@Mapper
public abstract class AbstractEventMapper {

    public Date map(OffsetDateTime value) {
        return Date.from(value.toInstant());
    }

    public OffsetDateTime map(Date value) {
        return value.toInstant().atOffset(OffsetDateTime.now().getOffset());
    }

    @Mappings({
            @Mapping(target = "srmPersonId", source = "customer.siebelId")
    })
    public abstract CustomerDTO toCustomerDto(Customer customer);

    @Mappings({
            @Mapping(target = "organizationId", source = "entity.siebelId")
    })
    public abstract EntityDTO toEntityDto(Entity entity);

    public abstract DboEventDTO toDboEventDto(AntifraudDboEvent antifraudDboEvent);

    @Mappings({
            @Mapping(target = "requestId", source = "request.id")
    })
    public abstract RequestDTO toRequestDTO(Request request);

    PaymentStatusDTO.StatusEnum mapStatusEnum(String value) {
        switch (value) {
            case EXECUTED_AT_ONCE_PAYMENT_STATUS:
                return PaymentStatusDTO.StatusEnum.EXECUTED_AT_ONCE;
            case TIMEOUT_PAYMENT_STATUS:
                return PaymentStatusDTO.StatusEnum.TIMEOUT_EXECUTED;
            case EXECUTED_POST_REVIEW_PAYMENT_STATUS:
                return PaymentStatusDTO.StatusEnum.EXECUTED_WITH_CHECK;
            case REJECTED_POST_REVIEW_PAYMENT_STATUS:
                return PaymentStatusDTO.StatusEnum.REJECTED_WITH_CHECK;
            case REJECTED_AT_ONCE_PAYMENT_STATUS:
                return PaymentStatusDTO.StatusEnum.REJECTED_AT_ONCE;
            case REVIEW_PAYMENT_STATUS:
                return PaymentStatusDTO.StatusEnum.POSTPONED;
            case RECALLED_IN_REVIEW_PAYMENT_STATUS:
                return PaymentStatusDTO.StatusEnum.RECALLED_IN_REVIEW;
            default:
                return null;
        }
    }

    PaymentStatusDTO.StatusCodeT1Enum mapStatusCodeT1(Integer value) {
        if (value == null) {
            return null;
        }
        switch (value) {
            case 0:
                return PaymentStatusDTO.StatusCodeT1Enum.ZERO;
            case 1:
                return PaymentStatusDTO.StatusCodeT1Enum.ONE;
            case 2:
                return PaymentStatusDTO.StatusCodeT1Enum.TWO;
            case 3:
                return PaymentStatusDTO.StatusCodeT1Enum.THREE;
            default:
                return null;
        }
    }

    PaymentStatusDTO.StatusCodeT2Enum mapStatusCodeT2(Integer value) {
        if (value == null) {
            return null;
        }
        switch (value) {
            case 4:
                return PaymentStatusDTO.StatusCodeT2Enum.FOUR;
            case 5:
                return PaymentStatusDTO.StatusCodeT2Enum.FIVE;
            case 6:
                return PaymentStatusDTO.StatusCodeT2Enum.SIX;
            case 7:
                return PaymentStatusDTO.StatusCodeT2Enum.SEVEN;
            default:
                return null;
        }
    }

    public abstract DboEventDTO toDboEventDTO(DboEvent dboEvent);

    public abstract PaymentStatusDTO toPaymentStatusDTO(AntifraudPaymentStatusEvent antifraudPaymentStatusEvent);

    @Mappings({
            @Mapping(target = "paymentStatus", source = "antifraudPaymentStatusEvent")
    })
    public abstract AntifraudPaymentStatusDTO toPaymentStatusEventDto(AntifraudPaymentStatusEvent antifraudPaymentStatusEvent);

    public abstract AntifraudEventDTO toAntifraudEventDTO(AntifraudDboEvent antifraudDboEvent);

}
