package ru.rosbank.paymentapp.schedule;

import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.support.CronTrigger;

public abstract class CronScheduledJob implements Runnable {

    private Boolean enable;
    private String cronExp;

    public CronScheduledJob(Boolean enable, String cronExp) {
        this.enable = enable;
        this.cronExp = cronExp;
    }

    void schedule(TaskScheduler scheduler) {
        if (enable) {
            this.schedule(scheduler, cronExp);
        }
    }

    private void schedule(TaskScheduler scheduler, String cronExp) {
        scheduler.schedule(this, (TriggerContext triggerContext) -> new CronTrigger(cronExp).nextExecutionTime(triggerContext));
    }

}
