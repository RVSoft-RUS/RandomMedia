package ru.rosbank.paymentapp.api;

import static ru.rosbank.platform.server.depositapp.model.Error.TypeEnum.UNEXPECTED;
import static ru.rosbank.platform.server.depositapp.model.Error.TypeEnum.VALIDATION_ERROR;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import ru.rosbank.paymentapp.service.CommissionService;
import ru.rosbank.paymentapp.service.DeliveringResourceService;
import ru.rosbank.paymentapp.service.DocumentImportService;
import ru.rosbank.paymentapp.service.DuplicatesService;
import ru.rosbank.paymentapp.service.LimitService;
import ru.rosbank.paymentapp.service.PaymentService;
import ru.rosbank.paymentapp.service.TemplateService;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.paymentapp.service.rectification.DocumentRectificationService;
import ru.rosbank.paymentapp.template.exception.DuplicateTemplateNameException;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.AmountDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentSendRequestAppDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.FileResourceDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedBatchResultDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.LimitRequestDTO;
import ru.rosbank.platform.client.paymentapp.model.LimitResponseDTO;
import ru.rosbank.platform.client.paymentapp.model.MetaDataDTO;
import ru.rosbank.platform.client.paymentapp.model.NextDocumentInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;
import ru.rosbank.platform.client.paymentapp.model.SummDTO;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.depositapp.model.Error;

@RequiredArgsConstructor
@Controller
public class DocumentApiController implements PaymentAppApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentApiController.class);

    @Autowired
    TemplateService templateService;

    private final PaymentService paymentService;
    private final DuplicatesService duplicatesService;
    private final DocumentImportService documentImportService;
    private final CommissionService commissionService;
    private final DocumentRectificationService rectificationService;
    private final LimitService limitService;
    private final DeliveringResourceService deliveringResourceService;

    @Override
    public ResponseEntity documentGet(@Valid List<String> payerAccounts,
                                      @Valid String from,
                                      @Valid String to,
                                      @Valid String limit,
                                      @Valid String offset,
                                      @Valid String bisRefference,
                                      @Valid List<DocumentStatusDTO> statuses) {
        Object result = paymentService
                .getDocumentList(payerAccounts,
                        LocalDateTime.parse(from),
                        LocalDateTime.parse(to),
                        bisRefference,
                        statuses,
                        Long.parseLong(limit),
                        Integer.parseInt(offset),
                        new ArrayList<>()
                );
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<DocumentDTO>> documentsGet(@Valid List<String> payerAccounts,
                                                          @Valid String from,
                                                          @Valid String to,
                                                          @Valid String limit,
                                                          @Valid String offset,
                                                          @Valid String bisRefference,
                                                          @Valid List<DocumentStatusDTO> statuses,
                                                          @Valid List<String> types) {
        Object result = paymentService
                .getDocumentList(payerAccounts,
                        LocalDateTime.parse(from),
                        LocalDateTime.parse(to),
                        bisRefference,
                        statuses,
                        Long.parseLong(limit),
                        Integer.parseInt(offset),
                        types
                );
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<FileResourceDTO> documentIdContentGet(String id) {
        Object result = paymentService.getContent(Long.parseLong(id));
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> documentIdDelete(String id) {
        paymentService.deleteDocument(Long.parseLong(id));
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<DocumentDTO> documentIdGet(String id) {
        Object result = paymentService.getDocument(Long.parseLong(id));
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<DocumentDTO> documentIdPost(String id, @Valid DocumentDTO documentDTO) {
        Object result = paymentService.updateDocument(Long.parseLong(id), documentDTO);
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> documentIdRecallPost(String id) {
        paymentService.recall(Long.parseLong(id));
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<Void> documentIdRecallSignedPost(String id, Boolean signed) {
        paymentService.recall(Long.parseLong(id), signed);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<Void> documentIdSignPost(String id, @Valid MetaDataDTO metaDataDTO) {
        paymentService.setSigned(Long.parseLong(id), metaDataDTO);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<NextDocumentInfoDTO> documentNextInfoGet(@NotNull @Valid List<String> payerAccounts) {
        Object result = paymentService.getNextInfo(payerAccounts);
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<DocumentDTO> documentPost(@Valid DocumentDTO documentDTO) {
        Object result = paymentService.createDocument(documentDTO);
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<RectificationDTO>> documentRectificationBatchGet(@NotNull @Valid List<String> documentsIds) {
        if (CollectionUtils.isNotEmpty(documentsIds)) {
            return new ResponseEntity(rectificationService.findAllByDocumentIdAndStatus(documentsIds), HttpStatus.OK);
        } else {
            throw new BackendException("Пустые идентификаторы в запросе documentRectificationBatchGet");
        }
    }

    @Override
    public ResponseEntity<Void> refferenceIdCompletePost(String id) {
        paymentService.setCompleteByReference(id);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<DocumentDTO> refferenceIdGet(String id) {
        Object result = paymentService.getDocumentByReference(id);
        return new ResponseEntity(result, (result instanceof Error) ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
    }

    @Override
    public ResponseEntity<SummDTO> summAccountNumber20Get(String accountNumber20, @Valid List<DocumentStatusDTO> statuses) {
        try {
            Double sum = paymentService
                    .getSum(accountNumber20, statuses.stream()
                            .map(DocumentStatusDTO::getValue).collect(Collectors.toList()));
            SummDTO summDTO = new SummDTO();
            summDTO.setValue(sum);
            return new ResponseEntity(summDTO, HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<List<TemplateDTO>> templateGet(@NotNull @Valid String dboProId, @NotNull @Valid String count,
                                                         @NotNull @Valid String offset, @Valid List<String> accounts) {
        try {
            return new ResponseEntity(templateService.getTemplateList(dboProId, count, offset, accounts), HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<Void> templateIdDelete(String id, String dboProId) {
        try {
            templateService.deleteTemplate(Long.valueOf(id), dboProId);
            return new ResponseEntity(HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<TemplateDTO> templateIdGet(String id, String dboProId) {
        try {
            return new ResponseEntity(templateService.getTemplate(Long.valueOf(id), dboProId), HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<Void> templateIdIncrementPost(String id) {
        try {
            templateService.increment(Long.valueOf(id));
            return new ResponseEntity(HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<TemplateDTO> templateIdPost(String id, @Valid TemplateDTO templateDTO) {
        try {
            return new ResponseEntity(templateService.saveTemplate(templateDTO), HttpStatus.OK);
        } catch (DuplicateTemplateNameException e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(VALIDATION_ERROR).message(e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<TemplateDTO> templatePost(@Valid TemplateDTO templateDTO) {
        try {
            return new ResponseEntity(templateService.createTemplateFromDocument(templateDTO, templateDTO.getName(),
                    templateDTO.getDboProId()), HttpStatus.OK);
        } catch (DuplicateTemplateNameException e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(VALIDATION_ERROR).message(e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<List<TemplateDTO>> templateSearchGet(@NotNull @Valid String dboProId, @Valid String query,
                                                               @Valid List<String> accounts) {
        try {
            return new ResponseEntity(templateService.search(dboProId, query, accounts), HttpStatus.OK);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ResponseEntity(new Error().type(UNEXPECTED).message(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<List<DocumentDTO>> documentDublicatesPost(List<String> requestBody) {
        return new ResponseEntity(duplicatesService.getDuplicatesList(requestBody), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<DocumentDTO>> importedDocumentsGet(@Valid String batchId, @Valid String clientId) {
        return new ResponseEntity(paymentService.getImportedDocumentList(batchId, clientId), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<String> importedPost(String dboProId, List<ImportedDocumentDTO> importedDocumentDTO) {

        return new ResponseEntity(documentImportService.createBatch(dboProId, importedDocumentDTO), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<ImportedDocumentDTO>> importedBatchIdGet(String id, String dboProId, String status) {
        return new ResponseEntity(documentImportService.getImportedDocuments(id, dboProId, status), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ImportedBatchResultDTO> importedBatchIdProcessPost(String id, String dboProId) {
        return new ResponseEntity(documentImportService.processBatch(id, dboProId), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> importedDocumentIdDelete(String id, String dboProId) {
        documentImportService.deleteImportedDocument(id, dboProId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ImportedDocumentDTO> importedDocumentPost(String dboProId, ImportedDocumentDTO importedDocumentDTO) {

        return new ResponseEntity(documentImportService.updateImportedDocument(importedDocumentDTO, dboProId), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<AmountDTO> documentCommissionCalculationPost(DocumentDTO documentDTO) {
        return new ResponseEntity(commissionService.calculateCommission(documentDTO), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RectificationDTO> documentRectificationGet(@Valid Long id, @Valid String bisDocId) {
        if (Optional.ofNullable(id).isPresent()) {
            return new ResponseEntity(rectificationService.getRectificationById(id), HttpStatus.OK);
        } else if (Optional.ofNullable(bisDocId).isPresent() && !bisDocId.isBlank()) {
            return new ResponseEntity(rectificationService.getActiveDocumentRectificationByBisId(bisDocId), HttpStatus.OK);
        } else {
            throw new RuntimeException("Пустые идентификаторы в запросе documentRectificationGet");
        }
    }

    @Override
    public ResponseEntity<Void> documentRectificationIdExecutePost(Long id) {
        rectificationService.processDocument(id);
        return new ResponseEntity(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RectificationDTO> documentRectificationPost(@Valid RectificationDTO rectificationDTO) {
        return new ResponseEntity(rectificationService.register(rectificationDTO), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<OffsetDateTime> documentTestOperDateGet() {
        return new ResponseEntity(paymentService.getDocumentCreationDate().toInstant().atOffset(ZoneOffset.UTC),
                HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> documentsComplete(@Valid List<String> bisReferences) {
        paymentService.setCompleteByReferenceList(bisReferences);
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<LimitResponseDTO> limitOrganizationIdPost(String organizationId,
                                                                    LimitRequestDTO limitRequestDTO) {
        return new ResponseEntity(limitService.process(organizationId, limitRequestDTO), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<FileResourceDTO> deliveringResourceIdGet(String id) {
        return ResponseEntity.ok(deliveringResourceService.getDeliveringResource(id));
    }

    @Override
    public ResponseEntity<Void> documentSendPost(@Valid DocumentSendRequestAppDTO request) {
        paymentService.sendDocument(request.getDocumentId(), request.getPhone(), request.getEmail(), request.getDboProId());
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<Integer> documentSignedCountGet(@NotNull @Valid List<Long> documentIds) {
        return ResponseEntity.ok(paymentService.getSignedDocumentCount(documentIds));
    }
}
