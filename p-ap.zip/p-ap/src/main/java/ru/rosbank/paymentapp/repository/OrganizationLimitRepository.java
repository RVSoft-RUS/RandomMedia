package ru.rosbank.paymentapp.repository;


import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.OrganizationLimit;

/**
 * DocumentRectificationRepository.
 */
@Repository
public interface OrganizationLimitRepository extends CrudRepository<OrganizationLimit, Long> {
    List<OrganizationLimit> findByOrganizationIdAndStatus(String organizationId, String status);
}
