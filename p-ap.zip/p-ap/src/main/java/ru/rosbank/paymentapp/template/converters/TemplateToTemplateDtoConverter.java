package ru.rosbank.paymentapp.template.converters;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.TemplateEntity;
import ru.rosbank.paymentapp.util.Utils;
import ru.rosbank.platform.server.paymentapp.model.BankInfo;
import ru.rosbank.platform.server.paymentapp.model.Requisite;
import ru.rosbank.platform.server.paymentapp.model.Template;





/**
 * TemplateToTemplateDtoConverter.
 * @author rb067368
 */

@Service
public class TemplateToTemplateDtoConverter {

    public Template convert(TemplateEntity entity) {
        Template templateDto = new Template();
        templateDto.setDboProId(entity.getDboProId());
        templateDto.setId(Optional.ofNullable(entity.getId())
                .map(ti -> ti.toString()).orElse(null));
        templateDto.setName(entity.getName());

        templateDto.setLastModifiedDate(Utils.getLocalDate(entity.getLastModifiedDate()));
        Optional.ofNullable(entity.getAmount()).map(String::valueOf).ifPresent(templateDto::setAmount);
        templateDto.setDocType(Template.DocTypeEnum.fromValue(entity.getDocType()));

        Requisite payer = new Requisite();
        payer.setAccount(entity.getPayerAccount());
        BankInfo payerBank = new BankInfo();
        payerBank.bic(entity.getPayerBankBic()).correspondentAccount(entity.getPayerBankCorrespondentAccount())
                .name(entity.getPayerBankName());
        payer.setBank(payerBank);
        payer.setInn(StringUtils.isBlank(entity.getPayerInn()) ? "0" : entity.getPayerInn());
        payer.setName(entity.getPayerName());
        payer.setKpp(entity.getPayerKpp());
        templateDto.setPayer(payer);

        Requisite payee = new Requisite();
        payee.setAccount(entity.getPayeeAccount());
        BankInfo payeeBank = new BankInfo();
        payeeBank.bic(entity.getPayeeBankBic()).correspondentAccount(entity.getPayeeBankCorrespondentAccount())
                .name(entity.getPayeeBankName());
        payee.setBank(payeeBank);
        payee.setInn(StringUtils.isBlank(entity.getPayeeInn()) ? "0" : entity.getPayeeInn());
        payee.setName(entity.getPayeeName());
        payee.setKpp(entity.getPayeeKpp());
        templateDto.setPayee(payee);

        templateDto.setPurpose(entity.getPurpose());
        entity.setPayPriority(entity.getPayPriority().trim());
        templateDto.setPayPriority(Template.PayPriorityEnum.fromValue(
                entity.getPayPriority().length() == 1 ? "0" + entity.getPayPriority() : entity.getPayPriority()));
        templateDto.setUin(entity.getUin());
        templateDto.setPayerStatus(entity.getPayerStatus());
        templateDto.setKbk(entity.getKbk());
        templateDto.setOktmo(entity.getOktmo());
        templateDto.setPaymentBasis(entity.getPaymentBasis());
        templateDto.setTaxPeriod(entity.getTaxPeriod());
        templateDto.setBasisDocumentNumber(entity.getBasisDocumentNumber());
        templateDto.setBasisDocumentCreated(entity.getBasisDocumentCreated());
        templateDto.setCodeTypeIncome(Optional.ofNullable(entity.getCodeTypeIncome())
            .map(ti -> ti.toString()).orElse(null));
        templateDto.setTypeTaxPayment(Optional.ofNullable(entity.getTypeTaxPayment()).map(t -> t.toString()).orElse(null));
        return templateDto;
    }
}
