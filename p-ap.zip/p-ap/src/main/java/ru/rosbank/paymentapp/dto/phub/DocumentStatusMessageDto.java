package ru.rosbank.paymentapp.dto.phub;

import java.time.LocalDateTime;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DocumentStatusMessageDto {
    private String bisId;
    private Integer statusCode;
    private String statusComment;
    private LocalDateTime statusDateTime;
    private String statusSysName;
    private UUID uuid;

}
