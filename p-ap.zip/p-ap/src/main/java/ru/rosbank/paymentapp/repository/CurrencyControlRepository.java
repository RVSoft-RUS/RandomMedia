package ru.rosbank.paymentapp.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.CurrencyControlEntity;

/**
 * Summary.
 * @author rb067368
 * @since 11.10.2019
 */
@Repository
public interface CurrencyControlRepository extends CrudRepository<CurrencyControlEntity, Long> {
    List<CurrencyControlEntity> findAllByIsSentToProPortalIsFalseAndAttemptsSentProPortalIsBetween(int firstAttempt,
                                                                                                   int lastAttempt);
}
