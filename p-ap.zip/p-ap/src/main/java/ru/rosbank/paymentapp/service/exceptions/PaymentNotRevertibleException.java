package ru.rosbank.paymentapp.service.exceptions;


public class PaymentNotRevertibleException extends RuntimeException {

    public PaymentNotRevertibleException(String msg) {
        super(msg);
    }

    public PaymentNotRevertibleException(String msg, Throwable t) {
        super(msg, t);
    }
}
