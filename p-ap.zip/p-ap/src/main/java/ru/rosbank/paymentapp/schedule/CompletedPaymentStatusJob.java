package ru.rosbank.paymentapp.schedule;

import static ru.rosbank.platform.server.paymentapp.model.DocumentStatus.SENT_TO_BIS;

import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.CompletedPaymentStatusProcessor;
import ru.rosbank.platform.redis.SharedLock;

@Slf4j
@Service
public class CompletedPaymentStatusJob extends CronScheduledJob {

    private static final String JOB_NAME = "CompletedPaymentStatusJob";

    @Autowired
    private PaymentEntityRepository paymentEntityRepository;
    @Autowired
    private SharedLock sharedLock;
    @Autowired
    private CompletedPaymentStatusProcessor completedPaymentStatusProcessor;
    @Value("${schedulers.completed-payment-status-job.lock.period}")
    private int period;

    public CompletedPaymentStatusJob(@Value("${schedulers.completed-payment-status-job.enabled}") Boolean enable,
                                     @Value("${schedulers.completed-payment-status-job.cron}") String cronExp) {
        super(enable, cronExp);
    }

    @Override
    public void run() {
        try {
            boolean lock = sharedLock.lock(JOB_NAME, period);
            if (lock) {
                completedPaymentStatusProcessor.process(paymentEntityRepository.findAllByStatusIn(List.of(SENT_TO_BIS.name())));
                sharedLock.release(JOB_NAME);
            } else {
                log.info("Не удалось захватить управление джобой {}", JOB_NAME);
            }
        } catch (Throwable t) {
            log.error("Не удалось получить платежи джоба {}", JOB_NAME, t);
        }
    }
}
