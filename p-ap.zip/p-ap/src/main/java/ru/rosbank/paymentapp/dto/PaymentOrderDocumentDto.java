package ru.rosbank.paymentapp.dto;

import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


/**
 *                 Платежный ордер
 *
 *              <p>documentContent - содержимое операции
 *                 paymentOutputMode - Вид платежа
 *                 paymentPriority - Очередность платежа
 *                 uin - УИН
 *                 paymentPartialNumber - N ч. Плат
 *                 typeCodeOrder - Шифр плат.док.
 *                 paymentOrderNumber - № плат.док.
 *                 paymentOrderDate - Дата плат.док.
 *                 paymentBalanceAmount Сумма ост. плат.
 *                 processedBy - Филиал банка, который обрабатывал документ
 *                 incomingDate - дата поступления в банк плательщика
 *                 payerStatus - Статус плательщика
 *                 kbk - КБК
 *                 oktmo - ОКТМО
 *                 paymentBasis - Основание платежа (идентификатор)
 *                 taxPeriod - Налоговый период
 *                 basisDocumentNumber - Номер документа основания
 *                 basisDocumentCreated - Дата документа основания
 *                 statusMessage - комментарий для документов со статусами "Отклонён" и "Отозван"
 *
 * <p>Java class for PaymentOrderDocument complex type.
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class PaymentOrderDocumentDto extends AbstractDocumentDto {

    protected String documentContent;
    protected PaymentOutputModeDto paymentOutputMode;
    protected String paymentPriority;
    protected String uin;
    protected String paymentPartialNumber;
    protected String typeCodeOrder;
    protected String paymentOrderNumber;
    protected Date paymentOrderDate;
    protected String paymentBalanceAmount;
    protected BankInfoDto processedBy;
    protected Date incomingDate;
    protected String kbk;
    protected String payerStatus;
    protected String oktmo;
    protected String paymentBasis;
    protected String taxPeriod;
    protected String basisDocumentCreated;
    protected String basisDocumentNumber;
    protected String statusMessage;

}
