package ru.rosbank.paymentapp.esb.support;

/**
 * Исключение для случая, если ответ из банка получен и содержит код ошибки.
 */
public class BankProcessingException extends RuntimeException {

    public static final String SERVER_INITIALIZED_CODE = "IS";

    private String code;

    private String ruMessage;
    private String enMessage;
    private String frMessage;

    private String localizedMessage;

    public BankProcessingException(String message) {
        super(message);
        code = SERVER_INITIALIZED_CODE;
        ruMessage = enMessage = frMessage = localizedMessage = message;
    }

    public BankProcessingException(String code, String message) {
        this(null, code, message);
    }

    public BankProcessingException(Throwable cause, String code, String message) {
        super(code + ": " + message, cause);

        this.code = code;

        String[] messages = message.split("<br/?>");

        ruMessage = enMessage = frMessage = messages[0].trim();
        if (messages.length > 1) {
            enMessage = frMessage = messages[1].trim();
            if (messages.length > 2) {
                frMessage = messages[2].trim();
            }
        }

        localizedMessage = ruMessage;
    }

    public String getCode() {
        return code;
    }

    public String getRuMessage() {
        return ruMessage;
    }

    public String getEnMessage() {
        return enMessage;
    }

    public String getFrMessage() {
        return frMessage;
    }

    public String getLocalizedMessage() {
        return localizedMessage;
    }

    public boolean isKeepLoginToken() {
        return false;
    }

    @Override
    public String toString() {
        return "BankProcessingException{"
                + "code='" + code + '\''
                + ", ruMessage='" + ruMessage + '\''
                + ", enMessage='" + enMessage + '\''
                + ", frMessage='" + frMessage + '\''
                + ", localizedMessage='" + localizedMessage + '\''
                + '}';
    }

}
