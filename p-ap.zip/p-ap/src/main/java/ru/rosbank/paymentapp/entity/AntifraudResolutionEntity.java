package ru.rosbank.paymentapp.entity;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity(name = "antifraud_resolution")
public class AntifraudResolutionEntity {
    public static final String DENY = "deny";
    public static final String ALLOW = "allow";
    public static final String REVIEW = "review";
    public static final String ANTIFRAUD_PROCESSING = "antifraud_processing";
    public static final String ALLOW_TIMEOUT = "allow_timeout";
    public static final String REVIEW_TIMEOUT = "review_timeout";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    private String requestId;
    private Long clientId;
    private Long documentId;
    private String status;
    private LocalDateTime created;
}
