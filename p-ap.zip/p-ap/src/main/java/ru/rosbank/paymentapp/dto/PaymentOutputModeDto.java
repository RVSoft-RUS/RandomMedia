package ru.rosbank.paymentapp.dto;

/**
 * Java class for PaymentOutputMode.
 */
public enum PaymentOutputModeDto {

    URGENT,
    TELEGRAPH,
    POSTMAIL,
    EMPTY;

    public static PaymentOutputModeDto fromValue(String v) {
        return valueOf(v);
    }

}
