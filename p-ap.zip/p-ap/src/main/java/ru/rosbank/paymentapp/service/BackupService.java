package ru.rosbank.paymentapp.service;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntityOld;
import ru.rosbank.paymentapp.repository.DocumentRecallRepository;
import ru.rosbank.paymentapp.repository.ImportedDocumentRepository;
import ru.rosbank.paymentapp.repository.ImportedDocumentRepositoryOld;
import ru.rosbank.paymentapp.repository.PaymentEntityOldRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.schedule.PaymentBackupConfig;


@Slf4j
@RequiredArgsConstructor
@Service
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class BackupService {
    PaymentEntityRepository paymentEntityRepository;
    PaymentEntityOldRepository paymentEntityOldRepository;
    ImportedDocumentRepository importedDocumentRepository;
    ImportedDocumentRepositoryOld importedDocumentRepositoryOld;
    DocumentRecallRepository documentRecallRepository;
    PaymentBackupConfig config;

    @Transactional
    public void saveAndDeletePayment(PaymentEntity payment)
            throws IllegalAccessException, InvocationTargetException {
        PaymentEntityOld paymentEntityOld = new PaymentEntityOld();
        BeanUtils.copyProperties(paymentEntityOld, payment);
        try {
            paymentEntityOldRepository.save(paymentEntityOld);
        } catch (Exception e) {
            log.error("backup UNKNOWN ex payment is {} {}", paymentEntityOld, e);
            throw e;
        }
        paymentEntityRepository.delete(payment);
        importedDocumentRepository.deleteByDocument(payment);
        importedDocumentRepositoryOld.deleteByDocument(payment);
        documentRecallRepository.deleteAllByPaymentEntity(payment);

    }

    public List<PaymentEntity> getBatchPayments(Pageable batch) {
        return paymentEntityRepository
                .findAllByStatusAndSignDateBefore("COMPLETED", LocalDateTime.now().minusDays(config.getDayAgo()), batch);
    }
}
