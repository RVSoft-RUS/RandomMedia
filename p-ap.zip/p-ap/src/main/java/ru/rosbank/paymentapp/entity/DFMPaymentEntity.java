package ru.rosbank.paymentapp.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity(name = "DFM_Payment")
public class DFMPaymentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    private LocalDateTime docDate;
    private String reason;
    private BigDecimal docSum;
    private String name;
    private String payeracccode;
    private String payerinn;
    private String payerbank;
    private String payerbik;
    private String benefname;
    private String benefacccode;
    private String benefinn;
    private String benefbank;
    private String benefbik;
    private String benefbankacc;
    @Column(name = "I_DATE")
    private LocalDateTime idate;
    private String cliCode;
    private Integer flag;
    private String inf;
    private String status;
    private String docNumber;
    private String docType;
    private Long docSerial;

    public DFMPaymentEntity(PaymentEntity document, LocalDateTime signDate) {
        this.setDocDate(document.getDate());
        this.setReason(document.getPurpose());
        this.setDocSum(document.getAmount());
        this.setName(document.getPayerName());
        this.setPayeracccode(document.getPayerAccount());
        this.setPayerinn(document.getPayerInn());
        this.setPayerbank(document.getPayerBankName());
        this.setPayerbik(document.getPayerBankBic());
        this.setBenefname(document.getPayeeName());
        this.setBenefacccode(document.getPayeeAccount());
        this.setBenefinn(document.getPayeeInn());
        this.setBenefbank(document.getPayeeBankName());
        this.setBenefbik(document.getPayeeBankBic());
        this.setBenefbankacc(document.getPayeeBankCorrespondentAccount());
        this.setDocNumber(document.getNumber());
        this.setDocType(document.getDoctype());
        this.setIdate(signDate);
        this.setStatus(DfmBisStatus.PROCESSING.value());
        this.setDocSerial(document.getId());
        this.setCliCode(document.getOrganizationBisBranch() + document.getOrganizationBisId());
    }

    public boolean isProcessable() {
        return DfmBisStatus.PROCESSING.equals(DfmBisStatus.fromValue(getStatus()));
    }
}
