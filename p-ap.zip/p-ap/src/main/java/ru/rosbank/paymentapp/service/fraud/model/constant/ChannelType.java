package ru.rosbank.paymentapp.service.fraud.model.constant;

public enum ChannelType {
    WEB("web"),
    MOBILE("mobile");
    private String text;

    ChannelType(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

}
