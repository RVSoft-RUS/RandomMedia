package ru.rosbank.paymentapp.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.rosbank.paymentapp.entity.DFMPaymentEntity;


@Repository
public interface DFMPaymentRepository extends CrudRepository<DFMPaymentEntity, Long> {

    @Transactional
    void deleteByFlagNotNullAndIdateBeforeAndStatus(LocalDateTime date, String status);

    Optional<DFMPaymentEntity> findByDocSerial(Long docSerial);

    List<DFMPaymentEntity> findAllByFlagIsNotAndIdateAfterAndFlagIsNotNull(Integer flag,
                                                                           LocalDateTime dateTime);
}
