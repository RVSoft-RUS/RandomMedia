package ru.rosbank.paymentapp.converters;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.ImportedDocumentEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.platform.server.paymentapp.model.Document;

/**
 * Summary.
 * @author rb068774
 *      Converts Document Entity
 */
@Service
public class ImportedDocumentToPaymentConverter {
    @Autowired
    UserService userService;

    public PaymentEntity convert(ImportedDocumentEntity importedDocument, PaymentEntity documentSrc) {
        PaymentEntity document = documentSrc;
        document.setNumber(importedDocument.getNumber());
        document.setClientId(importedDocument.getClientId());
        document.setDate(LocalDateTime.now());
        document.setPurpose(importedDocument.getPurpose());
        document.setUin(importedDocument.getUin());
        document.setAmount(Optional.ofNullable(importedDocument.getAmount()).orElse(BigDecimal.ZERO));
        document.setPayerAccount(importedDocument.getPayerAccount());
        document.setPayerBankBic(importedDocument.getPayerBankBic());
        document.setPayerBankName(importedDocument.getPayerBankName());
        document.setPayerBankCorrespondentAccount(importedDocument.getPayerBankCorrespondentAccount());
        document.setPayerInn(StringUtils.isBlank(importedDocument.getPayerInn()) ? "0" : importedDocument.getPayerInn());
        document.setPayerName(importedDocument.getPayerName());
        document.setPayerKpp(importedDocument.getPayerKpp());

        document.setPayeeAccount(importedDocument.getPayeeAccount());
        document.setPayeeBankBic(importedDocument.getPayeeBankBic());
        document.setPayeeBankName(importedDocument.getPayeeBankName());
        document.setPayeeBankCorrespondentAccount(importedDocument.getPayeeBankCorrespondentAccount());
        document.setPayeeInn(StringUtils.isBlank(importedDocument.getPayeeInn()) ? "0" : importedDocument.getPayeeInn());
        document.setPayeeName(importedDocument.getPayeeName());
        document.setPayeeKpp(importedDocument.getPayeeKpp());

        document.setDoctype(importedDocument.getDocType());
        if (Document.TypeEnum.valueOf(document.getDoctype()).equals(Document.TypeEnum.DE)) {
            document.setPayerStatus(importedDocument.getPayerStatus());
            document.setBasisDocumentCreated(importedDocument.getBasisDocumentCreated());
            document.setBasisDocumentNumber(importedDocument.getBasisDocumentNumber());
            document.setPaymentBasis(importedDocument.getPaymentBasis());
            document.setTaxPeriod(importedDocument.getTaxPeriod());
            document.setKbk(importedDocument.getKbk());
            document.setOktmo(importedDocument.getOktmo());
        }
        document.setPaypriority(importedDocument.getPayPriority());
        document.setCodeTypeIncome(importedDocument.getCodeTypeIncome());
        document.setTypeTaxPayment(importedDocument.getTypeTaxPayment());
        return document;
    }

}
