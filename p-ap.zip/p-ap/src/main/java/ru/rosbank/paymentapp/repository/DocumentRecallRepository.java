package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.DocumentRecallEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;

@Repository
public interface DocumentRecallRepository extends CrudRepository<DocumentRecallEntity, Long> {

    Optional<DocumentRecallEntity> findByPaymentEntityId(Long id);

    @Modifying
    @Query(value = "delete from document_recall documentRecall where documentRecall.paymentEntity=:paymentEntity")
    void deleteAllByPaymentEntity(PaymentEntity paymentEntity);

}
