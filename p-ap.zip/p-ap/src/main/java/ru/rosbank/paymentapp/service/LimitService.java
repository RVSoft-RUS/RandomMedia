package ru.rosbank.paymentapp.service;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.OrganizationLimit;
import ru.rosbank.paymentapp.entity.PaymentBase;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.OrganizationLimitRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.dfm.ToYourselfPaymentService;
import ru.rosbank.paymentapp.service.exceptions.ValidationException;
import ru.rosbank.platform.client.paymentapp.model.LimitRequestDTO;
import ru.rosbank.platform.client.paymentapp.model.LimitResponseDTO;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Slf4j
@Service
@RequiredArgsConstructor
public class LimitService {
    private static final String RUB_CODE = "RUB";

    private static final List<String> APPROPRIATE_STATUSES = List.of(
            DocumentStatus.DFM_PROCESSING.getValue(),
            DocumentStatus.SENT_TO_BIS.getValue(),
            DocumentStatus.REVIEW.getValue(),
            DocumentStatus.COMPLETED.getValue(),
            DocumentStatus.SIGNED.getValue());

    private final OrganizationLimitRepository organizationLimitRepository;
    private final PaymentEntityRepository paymentEntityRepository;
    private final ToYourselfPaymentService toYourselfPaymentService;
    @Value("${rosbank.inn:7730060164}")
    private String rosbankInn;


    public LimitResponseDTO process(String organizationId, LimitRequestDTO limitRequestDTO) {
        List<OrganizationLimit> organizationLimits = organizationLimitRepository.findByOrganizationIdAndStatus(
                organizationId, OrganizationLimit.Status.ACTIVE.name());
        LimitResponseDTO response = new LimitResponseDTO();
        if (organizationLimits == null || organizationLimits.size() == 0) {
            response.setResult(LimitResponseDTO.ResultEnum.NO_LUMITS_FOUND);
            response.setMessage("Для организации лимитов не установлено");
            return response;
        }
        List<PaymentEntity> paymentsRequest = paymentEntityRepository.findByIdInOrderByIdDesc(
                limitRequestDTO.getDocumentIds().stream().map(Long::valueOf).collect(Collectors.toList()));
        if (organizationLimits.stream().filter(l -> OrganizationLimit.Type.ONE_OPERATION_LIMIT.name().equals(l.getType())
                && RUB_CODE.equals(l.getCurrency())).anyMatch(l -> paymentsRequest.stream().anyMatch(
                    p -> isPaymentType(l, p) && p.getAmount().abs().compareTo(l.getLimitSum().abs()) > 0))) {
            throw new ValidationException("Превышен лимит суммы операции");
        }

        if (organizationLimits.stream().filter(l -> OrganizationLimit.Type.LIMIT_FOR_PERIOD.name().equals(l.getType())
                && RUB_CODE.equals(l.getCurrency())).anyMatch(l ->
                getFullSum(l, organizationId, paymentsRequest).compareTo(l.getLimitSum().abs()) > 0)) {
            throw new ValidationException("Превышен лимит по сумме операций за период");
        }
        response.setResult(LimitResponseDTO.ResultEnum.LIMIT_NOT_EXCEEDED);
        response.setMessage("Лимит не превышен");
        return response;
    }

    BigDecimal getFullSum(OrganizationLimit limit, String orgId, List<PaymentEntity> paymentsRequest) {
        BigDecimal sum = BigDecimal.ZERO;
        List<BigDecimal> sumList = paymentsRequest.stream().filter(p -> isPaymentType(limit, p))
                .map(PaymentBase::getAmount).collect(Collectors.toList());
        for (BigDecimal s : sumList) {
            sum = sum.add(s.abs());
        }
        sum = sum.add(getSumFromPeriod(limit, orgId));
        return sum;
    }

    BigDecimal getSumFromPeriod(OrganizationLimit limit, String organizationId) {
        LocalDateTime from = LocalDateTime.now().minusDays((long)limit.getLimitPeriod() - 1).withHour(0).withMinute(0)
                .withSecond(0).withNano(0);
        List<PaymentEntity> payments = paymentEntityRepository
                .findAllBySignDateBetweenAndOrganizationCrmIdAndStatusInAndNumberIsNotNull(from, LocalDateTime.now(),
                        organizationId, APPROPRIATE_STATUSES);
        BigDecimal sum = BigDecimal.ZERO;
        List<BigDecimal> sumList = payments.stream().filter(p -> isPaymentType(limit, p))
                .map(PaymentEntity::getAmount).collect(Collectors.toList());
        for (BigDecimal s : sumList) {
            sum = sum.add(s.abs());
        }

        return sum;
    }

    boolean isPaymentType(OrganizationLimit limit, PaymentEntity payment) {
        OrganizationLimit.PaymentType paymentType = OrganizationLimit.PaymentType.valueOf(limit.getPaymentType());
        switch (paymentType) {
            case INNER_OWN_ACCOUNT:
                return isInnerOwnAccount(payment);
            case FAVOR_OF_BANK:
                return isFavorOfBank(payment);
            case OTHER :
                return !isInnerOwnAccount(payment) && !isFavorOfBank(payment);
            case ALL:
            default:
                return true;
        }
    }

    boolean isInnerOwnAccount(PaymentEntity payment) {
        return payment.getPayerInn().equals(payment.getPayeeInn())
                && toYourselfPaymentService.isBicRosbank(payment.getPayeeBankBic());
    }

    boolean isFavorOfBank(PaymentEntity payment) {
        return rosbankInn.equals(payment.getPayeeInn())
                && toYourselfPaymentService.isBicRosbank(payment.getPayeeBankBic());
    }
}
