package ru.rosbank.paymentapp.converters;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.Date;
import java.util.Optional;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.dto.AbstractDocumentDto;
import ru.rosbank.paymentapp.dto.AccountCashWarrantDocumentDto;
import ru.rosbank.paymentapp.dto.AmountDto;
import ru.rosbank.paymentapp.dto.BankInfoDto;
import ru.rosbank.paymentapp.dto.BankOrderDocumentDto;
import ru.rosbank.paymentapp.dto.CashReceiptOrderDocumentDto;
import ru.rosbank.paymentapp.dto.CollectionAssignmentDocumentDto;
import ru.rosbank.paymentapp.dto.CurrencyDto;
import ru.rosbank.paymentapp.dto.DocumentStatusDto;
import ru.rosbank.paymentapp.dto.DocumentTypeDto;
import ru.rosbank.paymentapp.dto.MemorialOrderDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentAssignmentDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentBillDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentOrderDocumentDto;
import ru.rosbank.paymentapp.dto.PaymentOutputModeDto;
import ru.rosbank.paymentapp.dto.RequisiteDto;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;

//Imported from bs-app
@Service
public class PaymentDTOToAbstractDocumentDtoConverter {
    public AbstractDocumentDto convert(PaymentDTO payment) {
        AbstractDocumentDto documentDto;
        switch (payment.getSubtype()) {
            //TODO: Other types
            case PAYMENT_BILL:
                documentDto = new PaymentBillDocumentDto();
                setPaymentBill((PaymentBillDocumentDto) documentDto, payment);
                break;
            case PAYMENT_ORDER:
                documentDto = new PaymentOrderDocumentDto();
                setPaymentOrder((PaymentOrderDocumentDto) documentDto, payment);
                break;
            case BANK_ORDER:
                documentDto = new BankOrderDocumentDto();
                setBankOrder((BankOrderDocumentDto) documentDto, payment);
                break;
            case MEMORIAL_ORDER:
                documentDto = new MemorialOrderDocumentDto();
                setMemorialOrder((MemorialOrderDocumentDto) documentDto, payment);
                break;
            case CASH_RECEIPT_ORDER:
                documentDto = new CashReceiptOrderDocumentDto();
                setCashReceiptOrder((CashReceiptOrderDocumentDto) documentDto, payment);
                break;
            case ACCOUNT_CASH_WARRANT:
                documentDto = new AccountCashWarrantDocumentDto();
                setAccountCashWarrant((AccountCashWarrantDocumentDto) documentDto, payment);
                break;
            case COLLECTION_ASSIGNMENT:
                documentDto = new CollectionAssignmentDocumentDto();
                setCollectionAssignment((CollectionAssignmentDocumentDto) documentDto, payment);
                break;
            default:
                documentDto = new PaymentAssignmentDocumentDto();
                setPaymentAssignment((PaymentAssignmentDocumentDto) documentDto, payment);
                break;
        }
        return documentDto;
    }

    private void setCollectionAssignment(CollectionAssignmentDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        documentDto.setPaymentOutputMode(PaymentOutputModeDto.fromValue(payment.getPaymentOutputMode().getValue()));
        documentDto.setIncomingDate(new Date(payment.getIncomingDate().toInstant().toEpochMilli()));
        documentDto.setPaymentPriority(payment.getPaymentPriority());
        documentDto.setUin(payment.getUin());
        documentDto.setKbk(payment.getKbk());
        documentDto.setOktmo(payment.getOktmo());
        documentDto.setPaymentBasis(payment.getPaymentBasis());
        documentDto.setTaxPeriod(payment.getTaxPeriod());
        documentDto.setBasisDocumentNumber(payment.getBasisDocumentNumber());
        documentDto.setBasisDocumentCreated(payment.getBasisDocumentCreated());
        documentDto.setPayerStatus(payment.getPayerStatus());
        Optional.ofNullable(payment.getPlaceInFileDate()).map(OffsetDateTime::toInstant).map(Instant::toEpochMilli)
                .ifPresent(it -> documentDto.setPlaceInFileDate(new Date(it)));
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
    }

    private void setAccountCashWarrant(AccountCashWarrantDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        documentDto.setValueDate(new Date(payment.getValueDate().toInstant().toEpochMilli()));
        documentDto.setContent(payment.getContent());
        documentDto.setOrderStampSinger(payment.getOrderStampSinger());
        documentDto.setItmTransId(payment.getItmTransId());
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
    }

    private void setCashReceiptOrder(CashReceiptOrderDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        documentDto.setValueDate(new Date(payment.getValueDate().toInstant().toEpochMilli()));
        documentDto.setContent(payment.getContent());
        documentDto.setOrderStampSinger(payment.getOrderStampSinger());
        documentDto.setItmTransId(payment.getItmTransId());
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
    }

    private void setMemorialOrder(MemorialOrderDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        documentDto.setValueDate(new Date(payment.getValueDate().toInstant().toEpochMilli()));
        documentDto.setContent(payment.getContent());
        documentDto.setOrderStampSinger(payment.getOrderStampSinger());
        documentDto.setItmTransId(payment.getItmTransId());
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
    }

    private void setBankOrder(BankOrderDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        documentDto.setPaymentPriority(payment.getPaymentPriority());
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
    }

    private void setPaymentOrder(PaymentOrderDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        Optional.ofNullable(payment.getPaymentOutputMode())
                .map(PaymentDTO.PaymentOutputModeEnum::getValue)
                .ifPresent(it -> documentDto.setPaymentOutputMode(PaymentOutputModeDto.fromValue(it)));
        documentDto.setPaymentPartialNumber(payment.getPaymentPartialNumber());
        documentDto.setTypeCodeOrder(payment.getTypeCodeOrder());
        documentDto.setPaymentOrderNumber(payment.getPaymentOrderNumber());
        documentDto.setPaymentOrderDate(new Date(payment.getPaymentOrderDate().toInstant().toEpochMilli()));
        documentDto.setPaymentBalanceAmount(payment.getPaymentBalanceAmount());
        documentDto.setIncomingDate(new Date(payment.getIncomingDate().toInstant().toEpochMilli()));
        documentDto.setDocumentContent(payment.getContent());
        documentDto.setUin(payment.getUin());
        documentDto.setKbk(payment.getKbk());
        documentDto.setOktmo(payment.getOktmo());
        documentDto.setPaymentBasis(payment.getPaymentBasis());
        documentDto.setTaxPeriod(payment.getTaxPeriod());
        documentDto.setBasisDocumentNumber(payment.getBasisDocumentNumber());
        documentDto.setBasisDocumentCreated(payment.getBasisDocumentCreated());
        documentDto.setPayerStatus(payment.getPayerStatus());
        documentDto.setDocumentContent(payment.getContent());
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
    }

    private void setPaymentBill(PaymentBillDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        // Вид платежа
        documentDto.setPaymentOutputMode(PaymentOutputModeDto.fromValue(payment.getPaymentOutputMode().getValue()));
        // Очерёдность платежа
        documentDto.setPaymentPriority(payment.getPaymentPriority());
        documentDto.setPaymentCondition(payment.getPaymentCondition());
        documentDto.setExpirationAcceptance(payment.getExpirationAcceptance());
        documentDto.setExpirationAcceptance(payment.getEndExpirationAcceptance());
        Optional.ofNullable(payment.getOrderDate())
                .map(OffsetDateTime::toInstant)
                .map(Instant::toEpochMilli)
                .ifPresent(it -> documentDto.setOrderDate(new Date(it)));
        Optional.ofNullable(payment.getIncomingDate())
                .map(OffsetDateTime::toInstant)
                .map(Instant::toEpochMilli)
                .ifPresent(it -> documentDto.setIncomingDate(new Date(it)));
        documentDto.setUin(payment.getUin());
        documentDto.setCompleted(new Date(payment.getCompleted().toInstant().toEpochMilli()));
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
    }

    private void setPaymentAssignment(PaymentAssignmentDocumentDto documentDto, PaymentDTO payment) {
        setDefault(documentDto, payment);
        // Вид платежа
        Optional.ofNullable(payment.getPaymentOutputMode())
                .map(PaymentDTO.PaymentOutputModeEnum::getValue)
                .ifPresent(it -> documentDto.setPaymentOutputMode(PaymentOutputModeDto.fromValue(it)));
        // Очерёдность платежа
        documentDto.setPaymentPriority(payment.getPaymentPriority());
        // Дата поступления в банк плательщика
        Optional.ofNullable(payment.getIncomingDate())
                .map(OffsetDateTime::toInstant)
                .map(Instant::toEpochMilli)
                .ifPresent(it -> documentDto.setIncomingDate(new Date(it)));
        documentDto.setUin(payment.getUin());
        documentDto.setKbk(payment.getKbk());
        documentDto.setOktmo(payment.getOktmo());
        documentDto.setPaymentBasis(payment.getPaymentBasis());
        documentDto.setTaxPeriod(payment.getTaxPeriod());
        documentDto.setBasisDocumentNumber(payment.getBasisDocumentNumber());
        documentDto.setBasisDocumentCreated(payment.getBasisDocumentCreated());
        
        documentDto.setTypeTaxPayment("1".equals(payment.getTaxPaymentType())
                || Boolean.parseBoolean(payment.getTaxPaymentType()));
        documentDto.setPayerStatus(payment.getPayerStatus());
        documentDto.setProcessedBy(
            new BankInfoDto()
                .withBic(payment.getProcessedBy().getBic())
                .withName(payment.getProcessedBy().getName())
                .withCorrespondentAccount(payment.getProcessedBy().getCorrespondentAccount())
        );
        documentDto.setConfirmed(true);
        if (payment.getCodeTypeIncome() != null) {
            documentDto.setCodeTypeIncome(Integer.parseInt(payment.getCodeTypeIncome()));
        }
        documentDto.setMcc(payment.getMcc());
        documentDto.setCardHolder(payment.getCardHolder());
        documentDto.setApproveCode(payment.getApproveCode());
        documentDto.setCardPan(payment.getCardPan());
    }

    private void setDefault(AbstractDocumentDto documentDto, PaymentDTO payment) {
        documentDto.setId(payment.getId());
        documentDto.setNumber(payment.getNumber());
        documentDto.setAmount(new AmountDto()
            .withSum(payment.getAmount().getSum())
            .withCurrency(CurrencyDto.fromValue(payment.getAmount().getCurrency()))
        );
        documentDto.setCompleted(new Date(payment.getCompleted().toInstant().toEpochMilli()));
        documentDto.setCreated(new Date(payment.getCreated().toInstant().toEpochMilli()));
        documentDto.setAmountString(payment.getAmountString());
        documentDto.setPurpose(payment.getPurpose());
        documentDto.setStatus(DocumentStatusDto.COMPLETED);
        documentDto.setType(DocumentTypeDto.fromValue(String.valueOf(getTypeDTO(payment.getType()))));
        documentDto.setPayee(
            new RequisiteDto()
                .withAccount(payment.getPayee().getAccount())
                .withInn(payment.getPayee().getInn())
                .withKpp(payment.getPayee().getKpp())
                .withName(payment.getPayee().getName())
                .withBank(
                    new BankInfoDto()
                        .withBic(payment.getPayee().getBank().getBic())
                        .withName(payment.getPayee().getBank().getName())
                        .withCorrespondentAccount(payment.getPayee().getBank().getCorrespondentAccount())
                )
        );
        documentDto.setPayer(
            new RequisiteDto()
                .withAccount(payment.getPayer().getAccount())
                .withInn(payment.getPayer().getInn())
                .withKpp(payment.getPayer().getKpp())
                .withName(payment.getPayer().getName())
                .withBank(
                    new BankInfoDto()
                        .withBic(payment.getPayer().getBank().getBic())
                        .withName(payment.getPayer().getBank().getName())
                        .withCorrespondentAccount(payment.getPayer().getBank().getCorrespondentAccount())
                )
        );
    }

    static PaymentDTO.TypeEnum getTypeDTO(PaymentDTO.TypeEnum type) {
        if (type.equals(PaymentDTO.TypeEnum.DP) || type.equals(PaymentDTO.TypeEnum.DJ)
                || type.equals(PaymentDTO.TypeEnum.DK)) {
            return PaymentDTO.TypeEnum.DF;
        } else if (type.equals(PaymentDTO.TypeEnum.CJ) || type.equals(PaymentDTO.TypeEnum.CK)) {
            return PaymentDTO.TypeEnum.CF;
        } else {
            return type;
        }
    }
}
