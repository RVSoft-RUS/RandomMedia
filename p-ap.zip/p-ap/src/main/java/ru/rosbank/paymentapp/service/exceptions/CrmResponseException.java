package ru.rosbank.paymentapp.service.exceptions;

public class CrmResponseException extends Exception {

    public CrmResponseException(String message) {
        super(message);
    }

}
