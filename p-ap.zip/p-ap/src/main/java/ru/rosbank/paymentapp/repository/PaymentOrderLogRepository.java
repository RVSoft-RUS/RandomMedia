package ru.rosbank.paymentapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.rosbank.paymentapp.entity.PaymentOrderLog;

public interface PaymentOrderLogRepository extends JpaRepository<PaymentOrderLog, Long> {}
