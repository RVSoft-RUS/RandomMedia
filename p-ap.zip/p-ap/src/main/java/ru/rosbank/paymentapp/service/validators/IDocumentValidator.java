package ru.rosbank.paymentapp.service.validators;

import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.exceptions.ValidationException;

public interface IDocumentValidator {

    void validate(PaymentEntity document) throws ValidationException;

}
