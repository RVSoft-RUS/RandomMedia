package ru.rosbank.paymentapp.service.exceptions;


public class DocumentRejectedException extends Exception {

    public DocumentRejectedException(String msg) {
        super(msg);
    }

}
