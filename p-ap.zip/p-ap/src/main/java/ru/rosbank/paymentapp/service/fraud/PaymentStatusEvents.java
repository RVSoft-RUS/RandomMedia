package ru.rosbank.paymentapp.service.fraud;

public enum PaymentStatusEvents {
    ANTI_FRAUD_ALLOW,
    ANTI_FRAUD_DENY,
    ANTI_FRAUD_REVIEW,
    ANTI_FRAUD_ALLOW_TIMEOUT,
    ANTI_FRAUD_REVIEW_TIMEOUT,
    ANTI_FRAUD_ALLOW_IN_REVIEW,
    ANTI_FRAUD_DENY_IN_REVIEW,
    ANTI_FRAUD_RECALLED_IN_REVIEW
}
