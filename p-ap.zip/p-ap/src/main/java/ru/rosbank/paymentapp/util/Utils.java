package ru.rosbank.paymentapp.util;

import de.jollyday.Holiday;
import de.jollyday.HolidayManager;
import de.jollyday.ManagerParameters;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

/**
 * Generic utility methods.
 *
 * @author Q-APE
 */
public class Utils {

    /**
     * Разделитель целой дробной частей.
     */
    public static final char DECIMAL_SEPARATOR = '.';
    private static final String AMOUNT_PATTERN_1C = "###0.00;- ###0.00";
    private static final Locale LOCALE_RU = new Locale("ru", "RU");

    static final EnumSet<DayOfWeek> WEEKEND = EnumSet.range(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);
    static final Set<LocalDate> WORKING_WEEKENDS_24 = Set.of(LocalDate.of(2024, 4, 27),
            LocalDate.of(2024, 11, 2), LocalDate.of(2024, 12, 28));
    static final Set<LocalDate> HOLIDAYS = HolidayManager.getInstance(ManagerParameters.create("ru_2024"))
            .getHolidays(LocalDate.now().getYear()).stream().map(Holiday::getDate).collect(Collectors.toSet());

    /**
     * workingDaysElapsedFrom - Количество рабочих дней, прошедших включительно с заданной даты.
     *
     * @param date дата
     * @return кол-во дней
     */
    public static long workingDaysElapsedFrom(LocalDate date) {
        final long days = date.until(LocalDate.now(), ChronoUnit.DAYS);
        return LongStream.range(0, days)
                .mapToObj(date::plusDays)
                .filter(d -> !WEEKEND.contains(d.getDayOfWeek()) || WORKING_WEEKENDS_24.contains(d))
                .filter(d -> !HOLIDAYS.contains(d)).count();
    }

    /**
     * overWorkingDaysDate - Получение даты через заданное кол-во рабочих дней от текущей даты.
     *
     * @param days кол-во рабочих дней
     * @return дата
     */
    public static LocalDate overWorkingDaysDate(int days) {
        LocalDate result = LocalDate.now();
        int daysElapsed = 0;
        while (daysElapsed < days) {
            if (!(WEEKEND.contains(result.getDayOfWeek()) || HOLIDAYS.contains(result))) {
                daysElapsed++;
            }
            result = result.plusDays(1);
        }
        return result;
    }

    /**
     * Возвращает локаль приложения.
     *
     * @return Locale экземпляр локали.
     */
    public static Locale getLocale() {
        return LOCALE_RU;
    }

    public static String formatAmountWithDot(BigDecimal amount) {
        if (amount == null) {
            return "";
        }
        DecimalFormatSymbols formatSymbols = DecimalFormatSymbols.getInstance(getLocale());
        formatSymbols.setDecimalSeparator(DECIMAL_SEPARATOR);
        NumberFormat numberFormat = new DecimalFormat(AMOUNT_PATTERN_1C, formatSymbols);
        return numberFormat.format(amount);
    }

    public static Date toDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date toDate(OffsetDateTime localDateTime) {
        return Date.from(localDateTime.atZoneSameInstant(ZoneId.systemDefault()).toInstant());
    }

    public static LocalDate getLocalDate(Date date) {
        return date == null ? null : date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
}
