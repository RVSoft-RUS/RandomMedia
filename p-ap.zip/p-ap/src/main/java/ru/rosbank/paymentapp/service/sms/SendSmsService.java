package ru.rosbank.paymentapp.service.sms;

import static ru.rosbank.paymentapp.util.FormatUtils.DATE_PATTERN;

import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.EsbService;
import ru.rosbank.paymentapp.service.UserService;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.esb.model.sendsms.SendSMSRequestTypeEsb;
import ru.rosbank.platform.esb.model.smsmessage.SMSMessageListTypeEsb;
import ru.rosbank.platform.esb.model.smsmessage.SMSMessageTypeEsb;
import ru.rosbank.platform.esb.model.smsmessage.TemplateParameterListTypeEsb;
import ru.rosbank.platform.esb.model.smsmessage.TemplateParameterTypeEsb;

@Slf4j
@Service
public class SendSmsService {

    public static final String OTP_NOTIFICATION_TYPE = "dbopro_otp";

    @Value("${sms.technical-problems.text}")
    public String technicalProblemsText;

    @Autowired
    private EsbService esbService;

    @Autowired
    UserService userService;

    public void sendSMS(String phone, TemplateParameterListTypeEsb templateParameterList, String msgType) {

        String taskID = UUID.randomUUID().toString();

        SendSMSRequestTypeEsb sendSMSReq = new SendSMSRequestTypeEsb();
        SMSMessageListTypeEsb smsList = new SMSMessageListTypeEsb();
        sendSMSReq.setSMSMessageList(smsList);
        SMSMessageTypeEsb smsMessage = new SMSMessageTypeEsb();

        smsMessage.setTaskId(taskID);
        smsMessage.setCreateDate(new Date());
        smsMessage.setPriority(1);
        smsMessage.setLanguage("ru");
        smsMessage.setPhoneNumber(phone.replaceAll("\\+", ""));
        smsMessage.setType(msgType);

        smsMessage.setTemplateParameters(templateParameterList);
        List<SMSMessageTypeEsb> smsListInstance = smsList.getSMSMessage();
        smsListInstance.add(smsMessage);
        try {
            esbService.sendSms(sendSMSReq);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
        }
    }

    public void sendSmsTechnicalProblems(String phone, PaymentEntity document) {
        if (phone == null) {
            log.info("Failed to get phone by document with id " + document.getId());
            return;
        }
        TemplateParameterListTypeEsb templateParameterListTypeEsb = new TemplateParameterListTypeEsb();
        List<TemplateParameterTypeEsb> templateList = templateParameterListTypeEsb.getTemplateParameter();
        String smsText = String.format(technicalProblemsText,
                document.getSignDate().format(DateTimeFormatter.ofPattern(DATE_PATTERN)),
                document.getNumber(),
                document.getPayeeName(),
                document.getPurpose());
        templateList.add(new TemplateParameterTypeEsb("text", smsText));
        try {
            sendSMS(phone, templateParameterListTypeEsb, OTP_NOTIFICATION_TYPE);
        } catch (Exception e) {
            log.info("Failed to send sms by document with id {} message {}", document.getId(), e.getLocalizedMessage());
        }
    }

    public void sendSmsTechnicalProblemsForPayment(PaymentEntity document) {
        if (document.getClientId() != null) {
            try {
                Optional<ClientDTO> client = userService.getClientById(document.getClientId());
                client.ifPresent(value -> sendSmsTechnicalProblems(value.getPhone(), document));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }
}
