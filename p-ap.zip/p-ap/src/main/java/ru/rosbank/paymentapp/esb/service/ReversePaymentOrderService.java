package ru.rosbank.paymentapp.esb.service;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.EsbService;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.reversepaymentorder.ReversePaymentOrderRequestTypeEsb;
import ru.rosbank.platform.esb.model.reversepaymentorder.ReversePaymentOrderResponseTypeEsb;

@Slf4j
@RequiredArgsConstructor
@Service
@Data
public class ReversePaymentOrderService {

    private final EsbService esbService;

    public String reversePaymentOrder(PaymentEntity document) {

        var request = buildRequest(document);
        log.debug("Отправка запроса на отзыв документа в БИС {}", document.getId());
        var response = esbService.reversePaymentOrder(request);

        return response.getReversePaymentOrderResponse().stream().findFirst()
                .map(ReversePaymentOrderResponseTypeEsb.ReversePaymentOrderResponse::getPaymentOrder)
                .map(PaymentOrderTypeEsb::getDocumentID)
                .orElseThrow();
    }

    public ReversePaymentOrderRequestTypeEsb buildRequest(PaymentEntity doc) {
        var req = new ReversePaymentOrderRequestTypeEsb();
        req.setReversePaymentOrderRequest(new ReversePaymentOrderRequestTypeEsb.ReversePaymentOrderRequest()
                .withUser("P700")
                .withBranch(doc.getOrganizationBisBranch())
                .withPaymentOrder(new PaymentOrderTypeEsb()
                        .withCancellationsReason("Отзыв по инициативе клиента")
                        .withDocumentID(doc.getBisDocumentId().substring(0, doc.getBisDocumentId().length() - 2))
                        .withDocumentType("01")
                        .withControlUser("PRO")
                        .withInputUser("PRO")));
        return req;
    }

}
