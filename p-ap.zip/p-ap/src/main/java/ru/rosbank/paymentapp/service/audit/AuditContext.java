package ru.rosbank.paymentapp.service.audit;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import ru.rosbank.paymentapp.service.fraud.PaymentStatusEvents;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

/**
 * Контекст выполнения запроса. Заполняется интерсептером перед запросом
 *
 * @author rb064742
 * @since 22.10.2019
 */
@Getter
@Setter
public class AuditContext implements Serializable {

    protected String sessionId;
    protected String deviceId;
    protected String ip;
    protected String userAgent;
    protected String platform;
    protected String vendor;
    protected String model;
    protected String applicationVersion;
    protected String serverId;
    protected String macAddress;
    protected String companyInn;
    protected String crmCompanyId;
    protected String bisCompanyId;
    protected String companyName;
    protected String logMessage;
    protected ClientDTO client;
    protected Object subject;
    protected PaymentStatusEvents paymentStatusEvent;

}
