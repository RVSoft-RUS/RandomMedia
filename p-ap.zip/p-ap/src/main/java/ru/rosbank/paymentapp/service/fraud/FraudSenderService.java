package ru.rosbank.paymentapp.service.fraud;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.audit.AuditService;
import ru.rosbank.paymentapp.service.fraud.converter.AbstractEventMapper;
import ru.rosbank.paymentapp.service.fraud.model.AbstractEvent;
import ru.rosbank.paymentapp.service.fraud.model.AntifraudDboEvent;
import ru.rosbank.paymentapp.service.fraud.model.AntifraudPaymentStatusEvent;

@Slf4j
@Service
public class FraudSenderService {

    @Value("${anti-fraud.payment.topic.name}")
    private String paymentTopicName;

    @Value("${anti-fraud.document-status.topic.name}")
    private String documentStatusTopicName;

    private final KafkaTemplate<String, AbstractEvent> kafkaTemplate;
    private final AuditService auditService;
    private final AbstractEventMapper eventMapper = Mappers.getMapper(AbstractEventMapper.class);

    private static final Gson GSON = new Gson();

    public FraudSenderService(
            @Qualifier("antifraudKafkaTemplate") KafkaTemplate<String, AbstractEvent> template,
            AuditService auditService
    ) {
        this.kafkaTemplate = template;
        this.auditService = auditService;
    }

    //TODO Move Payment event to audit app
    public void sendPaymentEventMessage(AbstractEvent event) {
        sendMessage(paymentTopicName, event);
    }

    public void sendDocumentStatusEventMessage(AbstractEvent event) {
        sendMessage(documentStatusTopicName, event);
    }

    public void sendUserEventMessage(AntifraudDboEvent event) {
        auditService.sendAntifraudEvent(eventMapper.toAntifraudEventDTO(event));
    }

    public void sendPaymentActionEventMessage(AntifraudPaymentStatusEvent event) {
        auditService.sendAntifraudEvent(eventMapper.toPaymentStatusEventDto(event));
    }

    public void sendMessage(String topicName, AbstractEvent event) {
        try {
            log.info("Send message into topic {}, body = {}", topicName, GSON.toJson(event));
        } catch (Exception e) {
            log.error("Failed to convert json for log: {}", e.getMessage());
        }
        kafkaTemplate.send(topicName, event);

    }

}
