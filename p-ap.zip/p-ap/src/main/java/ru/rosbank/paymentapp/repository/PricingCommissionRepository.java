package ru.rosbank.paymentapp.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.CurrencyControlEntity;
import ru.rosbank.paymentapp.entity.PricingCommissionEntity;

/**
 * Summary.
 * @author rb067368
 * @since 11.10.2019
 */
@Repository
public interface PricingCommissionRepository extends CrudRepository<PricingCommissionEntity, Long> {
}
