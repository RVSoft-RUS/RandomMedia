package ru.rosbank.paymentapp.service.exceptions;

public class DocumentContentDifferentException extends DocumentRejectedException {

    public DocumentContentDifferentException(String msg) {
        super(msg);
    }

}
