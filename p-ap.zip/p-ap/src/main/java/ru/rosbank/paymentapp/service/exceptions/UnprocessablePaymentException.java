package ru.rosbank.paymentapp.service.exceptions;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class UnprocessablePaymentException extends RuntimeException {
    private final Long id;
    private final String message;
}
