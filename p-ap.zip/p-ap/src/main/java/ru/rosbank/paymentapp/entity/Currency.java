package ru.rosbank.paymentapp.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
public class Currency implements Serializable {

    @Id
    @EqualsAndHashCode.Include
    private String code;
    private short numeric;
    private String description;
    private String currencySymbol;

    public Currency(String code, short numeric, String description, String currencySymbol) {
        this.code = code;
        this.numeric = numeric;
        this.description = description;
        this.currencySymbol = currencySymbol;
    }
}
