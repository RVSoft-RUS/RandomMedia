package ru.rosbank.paymentapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.LastPaymentNumberEntity;
import ru.rosbank.paymentapp.entity.NumberYearKey;

@Repository
public interface LastPaymentNumberEntityRepository extends CrudRepository<LastPaymentNumberEntity, NumberYearKey> {

}
