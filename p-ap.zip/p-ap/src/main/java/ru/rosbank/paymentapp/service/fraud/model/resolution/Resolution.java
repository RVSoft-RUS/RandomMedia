package ru.rosbank.paymentapp.service.fraud.model.resolution;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude()
@ToString
public class Resolution {
    private String id;             // идентификатор события в СПМ
    private String tableName;      // название типа события в СПМ
    private String incidentId;     // номер инцидента в СПМ
    private String requestId;      // идентификатор события запроса
    private String rqTime;           // дата события запроса
    private String userId;         // идентификатор пользователя в ДБО
    private String paymentClass;   // классификация платежа
    private String siebelId;       // Siebel ID связанного лица
    private String entitySiebelId; // Siebel ID юр.лица
}
