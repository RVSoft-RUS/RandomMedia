package ru.rosbank.paymentapp.service.exceptions;

public class ShowStatusErrorException extends Exception {

    public ShowStatusErrorException(String message) {
        super(message);
    }

    public ShowStatusErrorException(String message, Throwable cause) {
        super(message, cause);
    }
}
