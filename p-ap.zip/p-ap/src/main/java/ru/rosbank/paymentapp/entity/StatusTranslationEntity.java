package ru.rosbank.paymentapp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity(name = "status_translation")
public class StatusTranslationEntity {

    @Id
    @EqualsAndHashCode.Include
    private String statusComment;

    private String translation;
}
