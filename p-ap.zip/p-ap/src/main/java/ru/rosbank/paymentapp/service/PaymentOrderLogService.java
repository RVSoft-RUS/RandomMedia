package ru.rosbank.paymentapp.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentOrderLog;
import ru.rosbank.paymentapp.repository.PaymentOrderLogRepository;

@Slf4j
@Service
@AllArgsConstructor
public class PaymentOrderLogService {

    private final PaymentOrderLogRepository paymentOrderLogRepository;

    public boolean savePaymentOrderLog(Long documentId) {
        try {
            if (paymentOrderLogRepository.findById(documentId).isPresent()) {
                return false;
            }
            PaymentOrderLog paymentOrderLog = new PaymentOrderLog();
            paymentOrderLog.setDocumentId(documentId);
            paymentOrderLogRepository.save(paymentOrderLog);
            return true;
        } catch (Exception e) {
            log.error("Ошибка записи лога отправки в бис {}", documentId, e);
            return false;
        }
    }
}
