package ru.rosbank.paymentapp.esb.support;

import java.util.Collections;
import org.springframework.util.Assert;
import ru.rosbank.platform.esb.model.customer.CustomerIDListTypeEsb;
import ru.rosbank.platform.esb.model.customer.CustomerIDTypeEsb;
import ru.rosbank.platform.esb.model.getcustomeraccountlist.GetCustomerAccountListRequestTypeEsb;
import ru.rosbank.platform.esb.model.naturalperson.NaturalPersonTypeEsb;

public class GetCustomerAccountListRequestBuilder {

    private String clientId;
    private String branch;

    public GetCustomerAccountListRequestBuilder cliendId(String cliendId) {
        this.clientId = cliendId;
        return this;
    }

    public GetCustomerAccountListRequestBuilder branch(String branch) {
        this.branch = branch;
        return this;
    }

    public GetCustomerAccountListRequestTypeEsb build() {
        Assert.notNull(clientId, "clientId can not be null");
        Assert.notNull(branch, "branch can not be null");

        GetCustomerAccountListRequestTypeEsb.GetCustomerAccountListRequest request;
        request = new GetCustomerAccountListRequestTypeEsb.GetCustomerAccountListRequest();
        request.setNaturalPerson(createNaturalPerson());
        request.setUser("P700");
        GetCustomerAccountListRequestTypeEsb requestTypeEsb = new GetCustomerAccountListRequestTypeEsb();
        requestTypeEsb.setGetCustomerAccountListRequest(request);

        return requestTypeEsb;
    }


    private NaturalPersonTypeEsb createNaturalPerson() {
        NaturalPersonTypeEsb naturalPerson = new NaturalPersonTypeEsb();
        naturalPerson.setCustomerIDList(new CustomerIDListTypeEsb(Collections.singletonList(createCustomerIDTypeEsb(clientId))));
        naturalPerson.setBranch(branch);
        return naturalPerson;
    }

    private CustomerIDTypeEsb createCustomerIDTypeEsb(String clientId) {
        CustomerIDTypeEsb id = new CustomerIDTypeEsb();
        id.setCustomerID(clientId);
        return id;
    }
}