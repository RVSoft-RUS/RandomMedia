package ru.rosbank.paymentapp.service.exceptions;


public class PaymentNotFoundException extends RuntimeException {

    public PaymentNotFoundException(Long id) {
        super("Платеж не найден [id=" + id + "]");
    }

    public PaymentNotFoundException(String bisId) {
        super("Платеж не найден [BIS id=" + bisId + "]");
    }

    public PaymentNotFoundException(String msg, Throwable t) {
        super(msg, t);
    }
}
