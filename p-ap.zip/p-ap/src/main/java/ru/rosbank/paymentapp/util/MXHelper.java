package ru.rosbank.paymentapp.util;

import java.lang.management.ManagementFactory;
import lombok.experimental.UtilityClass;

@UtilityClass
public class MXHelper {

    private final PlainTextThreadDumpFormatter threadDumpFormatter = new PlainTextThreadDumpFormatter();

    public String getFormattedThreadDump(boolean lockedMonitors, boolean lockedSynchronizers) {
        return threadDumpFormatter.format(
                ManagementFactory.getThreadMXBean().dumpAllThreads(lockedMonitors, lockedSynchronizers));
    }

}
