package ru.rosbank.paymentapp.dto.pricing;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Результат обработки запроса.
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseMetaData {

    /**
     * Дата и время.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS", timezone = "UTC")
    private Date timestamp;

    /**
     * Http статус ответа.
     */
    private int status;

    /**
     * Код результата обработки запроса.
     */
    private String code;

    /**
     * Описание кода обработки запроса.
     */
    private String message;

    public ResponseMetaData(String code) {
        this.code = code;
    }
}