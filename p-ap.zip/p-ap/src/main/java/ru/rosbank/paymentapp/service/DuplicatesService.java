package ru.rosbank.paymentapp.service;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.converters.DocumentConverter;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.platform.server.paymentapp.model.Document;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;


@Slf4j
@Service
@RequiredArgsConstructor
public class DuplicatesService {

    public static final List<String> DUPLICATES_STATUS = Collections.unmodifiableList(Arrays.asList(DocumentStatus.SIGNED.name(),
            DocumentStatus.DFM_PROCESSING.name(), DocumentStatus.PLANNED.name(), DocumentStatus.REVIEW.name(),
            DocumentStatus.RECALLED.name(), DocumentStatus.REJECTED.name(), DocumentStatus.SENT_TO_BIS.name(),
            DocumentStatus.COMPLETED.name()));

    private final PaymentEntityRepository paymentEntityRepository;
    private final DocumentConverter documentConverter;

    public List<Document> getDuplicatesList(List<String> docIds) {

        List<PaymentEntity> paymentsRequest = new ArrayList<>();

        paymentEntityRepository.findAllById(docIds.stream().map(Long::parseLong)
                .collect(Collectors.toList())).forEach(paymentsRequest::add);

        paymentsRequest = paymentsRequest.stream().sorted((pay1, pay2) -> {
            if (equals(pay1, pay2)) {
                return 0;
            }
            return hashCode(pay1).compareTo(hashCode(pay2));
        }).collect(Collectors.toList());

        Map<Long, PaymentEntity> paymentsDuplicateMap = new HashMap<>();

        PaymentEntity old = null;
        for (PaymentEntity p: paymentsRequest) {
            if (old != null && equals(p, old)) {
                p.setStatus(DocumentStatus.CREATED.toString());
                paymentsDuplicateMap.put(p.getId(), p);
                paymentsDuplicateMap.put(old.getId(), old);
            }
            old = p;
        }

        List<PaymentEntity> paymentsDuplicate = new ArrayList<>(paymentsDuplicateMap.values());

        List<PaymentEntity> paymentsFromTable = new ArrayList<>();

        paymentEntityRepository.findByPayerAccountInAndDateBetween(paymentsRequest.stream().map(PaymentEntity::getPayerAccount)
                .collect(Collectors.toList()), LocalDateTime.now().minusDays(5), LocalDateTime.now())
                .forEach(paymentsFromTable::add);
        final List<PaymentEntity> paymentsRequestFinal = paymentsRequest;
        paymentsDuplicate.addAll(paymentsFromTable.stream()
                .filter(paymentFromTable -> DUPLICATES_STATUS.contains(paymentFromTable.getStatus()))
                .filter(paymentFromTable -> paymentsRequestFinal.stream().anyMatch(pay -> equals(pay, paymentFromTable)))
                .collect(Collectors.toList()));

        return  paymentsDuplicate.stream().map(documentConverter::toDTO).sorted((pay1, pay2) ->
                (pay1.getNumber() == null || pay1.getNumber().equals(pay2.getNumber()))
                        ? pay1.getDate().compareTo(pay2.getDate())
                        : pay1.getNumber().compareTo(pay2.getNumber())).collect(Collectors.toList());
    }
    
    public static boolean equals(PaymentEntity pay1, PaymentEntity pay2) {

        return (pay1.getPurpose() != null ? pay1.getPurpose().equals(pay2.getPurpose()) : pay2.getPurpose() == null)
                && (pay1.getAmount() != null ? pay1.getAmount().equals(pay2.getAmount()) : pay2.getAmount() == null)
                && (pay1.getPaypriority() != null ? pay1.getPaypriority().equals(pay2.getPaypriority())
                : pay2.getPaypriority() == null)
                && (pay1.getPayerStatus() != null ? pay1.getPayerStatus().equals(pay2.getPayerStatus())
                : pay2.getPayerStatus() == null)
                && (pay1.getPaymentBasis() != null ? pay1.getPaymentBasis().equals(pay2.getPaymentBasis())
                : pay2.getPaymentBasis() == null)
                && (pay1.getBasisDocumentNumber() != null ? pay1.getBasisDocumentNumber()
                .equals(pay2.getBasisDocumentNumber()) : pay2.getBasisDocumentNumber() == null)
                && (pay1.getBasisDocumentCreated() != null ? pay1.getBasisDocumentCreated()
                .equals(pay2.getBasisDocumentCreated()) : pay2.getBasisDocumentCreated() == null)
                && (pay1.getTaxPeriod() != null ? pay1.getTaxPeriod().equals(pay2.getTaxPeriod()) : pay2.getTaxPeriod() == null)
                && (pay1.getKbk() != null ? pay1.getKbk().equals(pay2.getKbk()) : pay2.getKbk() == null)
                && (pay1.getOktmo() != null ? pay1.getOktmo().equals(pay2.getOktmo()) : pay2.getOktmo() == null)
                && (pay1.getPayerAccount() != null ? pay1.getPayerAccount().equals(pay2.getPayerAccount())
                : pay2.getPayerAccount() == null)
                && (pay1.getPayerName() != null ? pay1.getPayerName().equals(pay2.getPayerName()) : pay2.getPayerName() == null)
                && (pay1.getPayerInn() != null ? pay1.getPayerInn().equals(pay2.getPayerInn()) : pay2.getPayerInn() == null)
                && (pay1.getPayerKpp() != null ? pay1.getPayerKpp().equals(pay2.getPayerKpp()) : pay2.getPayerKpp() == null)
                && (pay1.getPayerBankBic() != null ? pay1.getPayerBankBic().equals(pay2.getPayerBankBic())
                : pay2.getPayerBankBic() == null)
                && (pay1.getPayerBankName() != null ? pay1.getPayerBankName().equals(pay2.getPayerBankName())
                : pay2.getPayerBankName() == null)
                && (pay1.getPayerBankCorrespondentAccount() != null ? pay1.getPayerBankCorrespondentAccount()
                .equals(pay2.getPayerBankCorrespondentAccount()) : pay2.getPayerBankCorrespondentAccount() == null)
                && (pay1.getPayeeAccount() != null ? pay1.getPayeeAccount().equals(pay2.getPayeeAccount())
                : pay2.getPayeeAccount() == null)
                && (pay1.getPayeeName() != null ? pay1.getPayeeName().equals(pay2.getPayeeName()) : pay2.getPayeeName() == null)
                && (pay1.getPayeeInn() != null ? pay1.getPayeeInn().equals(pay2.getPayeeInn()) : pay2.getPayeeInn() == null)
                && (pay1.getPayeeKpp() != null ? pay1.getPayeeKpp().equals(pay2.getPayeeKpp()) : pay2.getPayeeKpp() == null)
                && (pay1.getPayeeBankBic() != null ? pay1.getPayeeBankBic().equals(pay2.getPayeeBankBic())
                : pay2.getPayeeBankBic() == null)
                && (pay1.getPayeeBankName() != null ? pay1.getPayeeBankName().equals(pay2.getPayeeBankName())
                : pay2.getPayeeBankName() == null)
                && (pay1.getPayeeBankCorrespondentAccount() != null ? pay1.getPayeeBankCorrespondentAccount()
                .equals(pay2.getPayeeBankCorrespondentAccount()) : pay2.getPayeeBankCorrespondentAccount() == null);
    }


    static Integer hashCode(PaymentEntity pay) {
        return Objects.hash(pay.getPurpose(),
                pay.getAmount(),
                pay.getPaypriority(),
                pay.getPayerStatus(),
                pay.getPaymentBasis(),
                pay.getBasisDocumentNumber(),
                pay.getBasisDocumentCreated(),
                pay.getTaxPeriod(),
                pay.getKbk(),
                pay.getOktmo(),
                pay.getPayerAccount(),
                pay.getPayerName(),
                pay.getPayerInn(),
                pay.getPayerKpp(),
                pay.getPayerBankBic(),
                pay.getPayerBankName(),
                pay.getPayerBankCorrespondentAccount(),
                pay.getPayeeAccount(),
                pay.getPayeeName(),
                pay.getPayeeInn(),
                pay.getPayeeKpp(),
                pay.getPayeeBankBic(),
                pay.getPayeeBankName(),
                pay.getPayeeBankCorrespondentAccount());
    }
}
