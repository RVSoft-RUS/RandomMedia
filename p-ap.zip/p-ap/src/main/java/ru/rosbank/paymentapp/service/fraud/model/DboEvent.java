package ru.rosbank.paymentapp.service.fraud.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.Setter;

/**
 * Summary.
 * @author rb068869
 */
@Getter
@Setter
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude()
public class DboEvent extends AbstractEvent {

    private String id;
    private String userIp;
    private String action;
    private String oldValue;
    private String newValue;

}
