package ru.rosbank.paymentapp.config;

import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
@Profile("!unit_test")
public class AsyncConfig implements AsyncConfigurer {

    @Value("${scheduler.pool.size}")
    private int poolSize;
    @Value("${scheduler.queue.size:1000}")
    private int queueSize;
    @Value("${audit.pool.size}")
    private int poolSizeAudit;

    @Override
    @Bean
    @Primary
    public Executor getAsyncExecutor() {
        return new SimpleAsyncTaskExecutor("pool1-");
    }

    @Bean(name = "document_executor")
    public Executor getDocumentExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(poolSize);
        executor.setMaxPoolSize(poolSize);
        executor.setQueueCapacity(queueSize);
        executor.setThreadNamePrefix("document-");
        executor.setRejectedExecutionHandler(new DocumentRejectedExecutionHandlerImpl());
        executor.initialize();
        return executor;
    }

    @Bean(name = "audit_executor")
    public Executor getAuditExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(poolSizeAudit);
        executor.setMaxPoolSize(poolSizeAudit);
        executor.setQueueCapacity(poolSizeAudit * 100);
        executor.setThreadNamePrefix("audit-");
        executor.initialize();
        return executor;
    }

    @Bean(name = "antifraud_executor")
    public Executor getAntiFraudExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(poolSize);
        executor.setMaxPoolSize(poolSize);
        executor.setQueueCapacity(poolSize * 100);
        executor.setThreadNamePrefix("antifraud-");
        executor.initialize();
        return executor;
    }
}
