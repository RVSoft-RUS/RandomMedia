package ru.rosbank.paymentapp.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import ru.rosbank.paymentapp.entity.TemplateEntity;

/**
 * Summary.
 * @author rb067368
 * @since 11.10.2019
 */

public interface TemplateRepository extends CrudRepository<TemplateEntity, Long> {
    List<TemplateEntity> findAllByDboProIdAndStatusAndPayerAccountIn(String dboProId, String status, List<String> accounts);

    List<TemplateEntity> findByDboProIdAndStatus(String dboProId, String status);

    Optional<TemplateEntity> findByIdAndDboProIdAndStatus(Long id, String dboProId, String status);

    Optional<TemplateEntity> findFirstByDboProIdAndStatusAndNameAndIdIsNot(String dboProId, String status, String name, Long id);

    Optional<TemplateEntity> findFirstByDboProIdAndStatusAndName(String dboProId, String status, String name);

}
