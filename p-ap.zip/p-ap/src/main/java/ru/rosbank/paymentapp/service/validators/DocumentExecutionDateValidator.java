package ru.rosbank.paymentapp.service.validators;

import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.service.exceptions.DocumentExecutionDateException;
import ru.rosbank.paymentapp.util.FormatUtils;


@Service
public class DocumentExecutionDateValidator {

    @Value("${document.list.futurePeriod}")
    private Integer futureDocumentListPeriod;

    private static final String DATE_IS_NOT_AFTER = "Дата исполнения платежа не должна быть позднее ";
    private static final String DATE_IS_NOT_BEFORE = "Дата исполнения платежа не может быть раньше текущей даты";

    public void validate(PaymentEntity document) throws DocumentExecutionDateException {
        LocalDateTime dateIn31Days = LocalDateTime.now().plusDays(futureDocumentListPeriod);
        if (document.getExecutionDate().isAfter(dateIn31Days)) {
            throw new DocumentExecutionDateException(DATE_IS_NOT_AFTER + FormatUtils.formatDate(dateIn31Days.toLocalDate()));
        }
        if (document.getExecutionDate().isBefore(document.getDate().toLocalDate().atStartOfDay())) {
            throw new DocumentExecutionDateException(DATE_IS_NOT_BEFORE);
        }
    }
}
