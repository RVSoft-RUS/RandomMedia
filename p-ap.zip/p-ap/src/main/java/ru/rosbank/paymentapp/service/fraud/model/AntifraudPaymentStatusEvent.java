package ru.rosbank.paymentapp.service.fraud.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
@JsonInclude()
public class AntifraudPaymentStatusEvent extends AntifraudRequest {
    private static final String REQUEST_PAYMENT_STATUS_TYPE = "status";

    public AntifraudPaymentStatusEvent() {
        super(REQUEST_PAYMENT_STATUS_TYPE);
    }

    private String id;
    @JsonAlias("StatusCodeT1")
    private Integer statusCodeT1;
    @JsonAlias("StatusCodeT2")
    private Integer statusCodeT2;
    private String status;

}
