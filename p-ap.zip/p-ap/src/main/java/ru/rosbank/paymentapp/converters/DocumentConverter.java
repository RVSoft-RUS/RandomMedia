package ru.rosbank.paymentapp.converters;

import com.google.gson.GsonBuilder;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;
import ru.rosbank.paymentapp.entity.CurrencyControlEntity;
import ru.rosbank.paymentapp.entity.FileInfoEntity;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.esb.model.account.AccountNumberTypeEsb;
import ru.rosbank.platform.esb.model.common.MoneyAmountTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.DocumentIndicatorTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.PaymentOrderTypeEsb;
import ru.rosbank.platform.esb.model.paymentorder.RequisiteTypeEsb;
import ru.rosbank.platform.server.paymentapp.model.BankInfo;
import ru.rosbank.platform.server.paymentapp.model.BisId;
import ru.rosbank.platform.server.paymentapp.model.CurrencyControl;
import ru.rosbank.platform.server.paymentapp.model.Document;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;
import ru.rosbank.platform.server.paymentapp.model.FileInfo;
import ru.rosbank.platform.server.paymentapp.model.Requisite;

@Component
public class DocumentConverter {

    private static final String CURRENCY_RUB = "RUB";
    private static final String DOCUMENT_TYPE_SIEBEL = "01";
    private static final String INPUT_SYSTEM_SIEBEL = "C";
    private static final String CONTROL_USER_SIEBEL = "DBO";

    public Document toDTO(PaymentEntity entity) {

        Document dto = new Document();
        dto.setId(entity.getId().intValue());
        dto.setBisId(new BisId().id(entity.getOrganizationBisId()).branch(entity.getOrganizationBisBranch()));
        dto.setBisRefference(entity.getBisDocumentId());
        dto.setNumber(entity.getNumber());
        dto.setCrmId(entity.getOrganizationCrmId());
        ZoneOffset zoneOffset = OffsetDateTime.now().getOffset();
        dto.setDate(entity.getDate().atOffset(zoneOffset));
        if (entity.getExecutionDate() != null) {
            dto.setExecutionDate(entity.getExecutionDate().atOffset(zoneOffset));
        }
        Optional.ofNullable(entity.getSignDate()).ifPresent(signDate -> dto.setSignDate(signDate.atOffset(zoneOffset)));
        if (entity.getStatus() != null) {
            dto.setStatus(DocumentStatus.fromValue(entity.getStatus()));
        }
        dto.setShowError(entity.isShowError());
        dto.setStatusMessage(entity.getStatusMessage());
        if (entity.getDoctype() != null) {
            dto.setType(Document.TypeEnum.fromValue(entity.getDoctype()));
        }
        dto.setPurpose(entity.getPurpose());
        Optional.ofNullable(entity.getAmount()).map(String::valueOf).ifPresent(dto::setAmount);
        dto.setPaymentPriority(entity.getPaypriority());
        dto.setPayerStatus(entity.getPayerStatus());
        dto.setPaymentBasis(entity.getPaymentBasis());
        dto.setBasisDocumentNumber(entity.getBasisDocumentNumber());
        dto.setBasisDocumentCreated(entity.getBasisDocumentCreated());
        dto.setTaxPeriod(entity.getTaxPeriod());
        dto.setUin(entity.getUin());
        dto.setKbk(entity.getKbk());
        dto.setOktmo(entity.getOktmo());

        dto.setPayer(getPayer(entity));
        dto.setPayee(getPayee(entity));
        dto.setClientId(entity.getClientId());
        String codeTypeIncome = Optional.ofNullable(entity.getCodeTypeIncome()).map(String::valueOf).orElse(null);
        dto.setCodeTypeIncome(codeTypeIncome);
        if (entity.getTypeTaxPayment() != null) {
            dto.setTypeTaxPayment(String.valueOf(entity.getTypeTaxPayment()));
        }

        if (entity.getCurrencyControlEntity() != null) {
            CurrencyControl currencyControl = new CurrencyControl();
            currencyControl.setComment(entity.getCurrencyControlEntity().getComment());
            currencyControl.setFullName(entity.getCurrencyControlEntity().getFullName());
            currencyControl.setIsSumContractLess200(entity.getCurrencyControlEntity().getIsSumContractLess200());
            currencyControl.setPhone(entity.getCurrencyControlEntity().getPhone());
            List<FileInfo> fileInfoList = entity.getCurrencyControlEntity().getFileInfoEntityList()
                    .stream()
                    .map(fileInfoEntity -> new FileInfo().id(fileInfoEntity.getFileId()))
                    .collect(Collectors.toList());
            currencyControl.setFileInfo(fileInfoList);
            dto.setCurrencyControl(currencyControl);
        }
        dto.setOrgShortName(entity.getOrganizationShortName());
        if (entity.getEnrollmentDate() != null) {
            dto.setEnrollmentDate(entity.getEnrollmentDate().atOffset(zoneOffset));
        }
        return dto;
    }

    public PaymentOrderTypeEsb toEsbPayment(PaymentEntity paymentEntity) {
        var orderEsb = new PaymentOrderTypeEsb();
        if (DocumentStatus.REJECTED.getValue().equals(paymentEntity.getStatus())) {
            orderEsb.setCancellationsReason(paymentEntity.getStatusMessage());
        }
        if (DocumentStatus.WAIT.getValue().equals(paymentEntity.getStatus())
                && paymentEntity.getExecutionDate() != null) {
            orderEsb.setCancellationsReason(paymentEntity.getExecutionDate().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        }

        return orderEsb.withRegistrationDate(Date.from(paymentEntity.getDate()
                .atZone(ZoneId.systemDefault())
                .toInstant()))
                .withStatus(paymentEntity.getStatus())
                .withDocumentType(DOCUMENT_TYPE_SIEBEL)
                .withOrderNumber(paymentEntity.getNumber())
                .withAmount(new MoneyAmountTypeEsb()
                        .withAmount(paymentEntity.getAmount())
                        .withCurrencyCode(CURRENCY_RUB))
                .withPayee(new RequisiteTypeEsb()
                        .withPayerName(paymentEntity.getPayeeName())
                        .withNumber(new AccountNumberTypeEsb()
                                .withAccountNumber20Digit(paymentEntity.getPayeeAccount())))
                .withPurpose(paymentEntity.getPurpose())
                .withPayer(new RequisiteTypeEsb()
                        .withNumber(new AccountNumberTypeEsb()
                                .withAccountNumber20Digit(paymentEntity.getPayerAccount())))
                .withDocumentIndicator(new DocumentIndicatorTypeEsb()
                        .withInputSystem(INPUT_SYSTEM_SIEBEL))
                .withControlUser(CONTROL_USER_SIEBEL)
                .withDocumentDate(Date.from(paymentEntity.getDate()
                        .atZone(ZoneId.systemDefault()).toInstant()));
    }

    public PaymentEntity fromDTO(DocumentDTO dto) {

        PaymentEntity entity = new PaymentEntity();
        entity.setClientId(dto.getClientId());
        entity.setNumber(dto.getNumber());
        entity.setOrganizationCrmId(dto.getCrmId());
        entity.setDate(dto.getDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
        if (dto.getExecutionDate() != null) {
            entity.setExecutionDate(dto.getExecutionDate().toLocalDateTime().withHour(0));
        }
        entity.setStatus(dto.getStatus().getValue());
        Optional.ofNullable(dto.getShowError()).ifPresent(entity::setShowError);
        entity.setStatusMessage(dto.getStatusMessage());
        Optional.ofNullable(dto.getType()).map(DocumentDTO.TypeEnum::getValue).ifPresent(entity::setDoctype);
        entity.setPurpose(dto.getPurpose());
        Optional.ofNullable(dto.getAmount()).map(BigDecimal::new).ifPresent(entity::setAmount);
        entity.setPaypriority(dto.getPaymentPriority());
        entity.setPayerStatus(dto.getPayerStatus());
        entity.setPaymentBasis(dto.getPaymentBasis());
        entity.setBasisDocumentNumber(dto.getBasisDocumentNumber());
        entity.setBasisDocumentCreated(dto.getBasisDocumentCreated());
        entity.setTaxPeriod(dto.getTaxPeriod());
        entity.setUin(dto.getUin());
        entity.setKbk(dto.getKbk());
        entity.setOktmo(dto.getOktmo());
        entity.setOrganizationShortName(dto.getOrgShortName());
        if (dto.getPayer() != null) {
            entity.setPayerAccount(dto.getPayer().getAccount());
            entity.setPayerName(dto.getPayer().getName());
            entity.setPayerInn(dto.getPayer().getInn());
            entity.setPayerKpp(dto.getPayer().getKpp());
            if (dto.getPayer().getBank() != null) {
                entity.setPayerBankBic(dto.getPayer().getBank().getBic());
                entity.setPayerBankName(dto.getPayer().getBank().getName());
                entity.setPayerBankCorrespondentAccount(dto.getPayer().getBank().getCorrespondentAccount());
            }
        }
        if (dto.getPayee() != null) {
            entity.setPayeeAccount(dto.getPayee().getAccount());
            entity.setPayeeName(dto.getPayee().getName());
            entity.setPayeeInn(dto.getPayee().getInn());
            entity.setPayeeKpp(dto.getPayee().getKpp());
            if (dto.getPayee().getBank() != null) {
                entity.setPayeeBankBic(dto.getPayee().getBank().getBic());
                entity.setPayeeBankName(dto.getPayee().getBank().getName());
                entity.setPayeeBankCorrespondentAccount(dto.getPayee().getBank().getCorrespondentAccount());
            }
        }
        Short codeTypeIncome = Optional.ofNullable(dto.getCodeTypeIncome()).map(Short::parseShort).orElse(null);

        entity.setCodeTypeIncome(codeTypeIncome);
        if (dto.getTypeTaxPayment() != null) {
            entity.setTypeTaxPayment(Boolean.parseBoolean(dto.getTypeTaxPayment()));
        }
        if (dto.getBisId() != null) {
            entity.setOrganizationBisBranch(dto.getBisId().getBranch());
            entity.setOrganizationBisId(dto.getBisId().getId());
        }

        if (dto.getCurrencyControl() != null) {
            CurrencyControlEntity currencyControlEntity = new CurrencyControlEntity();
            currencyControlEntity.setComment(dto.getCurrencyControl().getComment());
            currencyControlEntity.setFullName(dto.getCurrencyControl().getFullName());
            currencyControlEntity.setPhone(dto.getCurrencyControl().getPhone());
            currencyControlEntity.setIsSumContractLess200(dto.getCurrencyControl().getIsSumContractLess200());
            List<FileInfoEntity> fileInfoEntities = dto.getCurrencyControl().getFileInfo()
                    .stream()
                    .map(fileInfoDTO -> {
                        FileInfoEntity fileInfoEntity = new FileInfoEntity();
                        fileInfoEntity.setFileId(fileInfoDTO.getId());
                        fileInfoEntity.setCurrencyControlEntity(currencyControlEntity);
                        return fileInfoEntity;
                    })
                    .collect(Collectors.toList());
            currencyControlEntity.setFileInfoEntityList(fileInfoEntities);
            entity.setCurrencyControlEntity(currencyControlEntity);
        }
        Optional.ofNullable(dto.getSignDate()).ifPresent(date -> entity.setSignDate(
                date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime()));
        entity.setReferenceId(dto.getReferenceId());
        entity.setReferenceType(dto.getReferenceType());
        if (dto.getEnrollmentDate() != null) {
            entity.setEnrollmentDate(dto.getEnrollmentDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime());
        }
        return entity;
    }

    public String toJson(PaymentEntity entity) {

        String json = new GsonBuilder().create().toJson(toDTO(entity));
        return Base64.getEncoder().encodeToString(json.getBytes());

    }

    private Requisite getPayer(PaymentEntity entity) {
        Requisite payer = new Requisite();
        payer.setAccount(entity.getPayerAccount());
        payer.setName(entity.getPayerName());
        payer.setInn(entity.getPayerInn());
        payer.setKpp(entity.getPayerKpp());

        BankInfo bank = new BankInfo();
        bank.setBic(entity.getPayerBankBic());
        bank.setName(entity.getPayerBankName());
        bank.setCorrespondentAccount(entity.getPayerBankCorrespondentAccount());
        payer.setBank(bank);

        return payer;
    }

    private Requisite getPayee(PaymentEntity entity) {
        Requisite payee = new Requisite();
        payee.setAccount(entity.getPayeeAccount());
        payee.setName(entity.getPayeeName());
        payee.setInn(entity.getPayeeInn());
        payee.setKpp(entity.getPayeeKpp());

        BankInfo bank = new BankInfo();
        bank.setBic(entity.getPayeeBankBic());
        bank.setName(entity.getPayeeBankName());
        bank.setCorrespondentAccount(entity.getPayeeBankCorrespondentAccount());
        payee.setBank(bank);

        return payee;
    }


}
