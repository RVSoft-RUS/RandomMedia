package ru.rosbank.paymentapp.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
public class CbBicAccount implements Serializable {

    @Id
    @Column(name = "BIC")
    @EqualsAndHashCode.Include
    private String bic;

    @Column(name = "ACCOUNT")
    private String account;

    @Column(name = "REGULATIONACCOUNTTYPE")
    private String regulationtype;
}
