package ru.rosbank.paymentapp.dto.pricing;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PayeeDTO {
    private String accountNumber;
    private String bic;
    private String name;
    private String inn;
    private String correspondentAccount;
}
