package ru.rosbank.paymentapp.service.exceptions;


public class GetAccountBalanceException extends Exception {

    public GetAccountBalanceException(String message) {
        super(message);
    }

}
