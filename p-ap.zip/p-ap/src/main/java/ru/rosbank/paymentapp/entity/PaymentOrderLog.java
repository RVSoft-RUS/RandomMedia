package ru.rosbank.paymentapp.entity;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

@Setter
@Entity(name = "payment_order_log")
public class PaymentOrderLog {

    @Id
    private Long documentId;
    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime date;
}
