package ru.rosbank.paymentapp.service;

import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.TemplateEntity;
import ru.rosbank.paymentapp.repository.TemplateRepository;
import ru.rosbank.paymentapp.template.TemplateNameValidator;
import ru.rosbank.paymentapp.template.converters.TemplateDtoToTemplateConverter;
import ru.rosbank.paymentapp.template.converters.TemplateToTemplateDtoConverter;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.paymentapp.model.Template;

/**
 * Summary.
 * @author rb068774
 */
@Service
public class TemplateService {

    public static final int MAX_COUNT = 10000;

    @Autowired
    private TemplateToTemplateDtoConverter templateToTemplateDtoConverter;

    @Autowired
    private TemplateRepository templateRepository;

    @Autowired
    private TemplateDtoToTemplateConverter templateDtoToTemplateConverter;

    @Autowired
    private TemplateNameValidator templateNameValidator;


    public List<Template> getTemplateList(String dboProId, String count, String offset, List<String> accounts) {

        List<TemplateEntity> templates;

        if (accounts == null || accounts.isEmpty()) {
            templates = templateRepository.findByDboProIdAndStatus(dboProId, TemplateEntity.Status.ACTIVE.value());
        } else {
            templates = templateRepository.findAllByDboProIdAndStatusAndPayerAccountIn(dboProId,
                TemplateEntity.Status.ACTIVE.value(), accounts);
        }

        sortByName(templates);

        List<Template> templatesDto = templates.stream().map(templateToTemplateDtoConverter::convert)
            .collect(Collectors.toList());

        return getPage(templatesDto, count, offset);
    }

    private void sortByName(List<TemplateEntity> templates) {
        templates.sort(Comparator.comparing(TemplateEntity::getName, String.CASE_INSENSITIVE_ORDER));
    }

    private List<Template> getPage(List<Template> templates, String count, String offset) {
        int countInt = StringUtils.isNumeric(count) ? Integer.parseInt(count) : MAX_COUNT;
        int offsetInt = StringUtils.isNumeric(offset) ? Integer.parseInt(offset) : 0;
        if (templates.size() <= offsetInt) {
            return new LinkedList<>();
        }
        return templates.subList(offsetInt, Math.min(offsetInt + countInt, templates.size()));
    }

    public Template createTemplateFromDocument(TemplateDTO templateDto,
                                                  String name, String dboProId) {
        templateNameValidator.validateNewTemplateName(name, dboProId);
        TemplateEntity template = templateDtoToTemplateConverter.convert(templateDto);
        template.setId(null);
        template.setDboProId(dboProId);
        template.setName(name);
        template.setDateCreated(new Date());
        template.setLastModifiedDate(new Date());
        template.setCount(0L);
        template.setAmount(template.getAmount().abs());
        template = templateRepository.save(template);

        return templateToTemplateDtoConverter.convert(template);
    }

    public Template saveTemplate(TemplateDTO templateDTO) throws Exception {
        TemplateEntity template = templateDtoToTemplateConverter.convert(templateDTO);
        templateNameValidator.validateExistingTemplateName(template);
        Optional<TemplateEntity> templateOld = templateRepository.findByIdAndDboProIdAndStatus(Long.valueOf(templateDTO.getId()),
                templateDTO.getDboProId(), TemplateEntity.Status.ACTIVE.value());
        if (!templateOld.isPresent()) {
            throw new Exception("Шаблон платежа не найден, требуется создать шаблон из документа.");
        }
        template.setDateCreated(templateOld.get().getDateCreated());
        template.setLastModifiedDate(new Date());
        template.setCount(templateOld.get().getCount());
        template.setAmount(template.getAmount().abs());
        template = templateRepository.save(template);
        return templateToTemplateDtoConverter.convert(template);
    }

    public void deleteTemplate(Long templateId, String dboProId) {
        Optional<TemplateEntity> templateOptional = templateRepository.findByIdAndDboProIdAndStatus(templateId, dboProId,
            TemplateEntity.Status.ACTIVE.value());
        if (templateOptional.isPresent()) {
            TemplateEntity template = templateOptional.get();
            template.setStatus(TemplateEntity.Status.INACTIVE.value());
            templateRepository.save(template);
        }
    }

    public List<Template> search(String dboProId, String query, List<String> accounts) {

        List<TemplateEntity> templates;
        if (accounts == null || accounts.isEmpty()) {
            templates = templateRepository.findByDboProIdAndStatus(dboProId, TemplateEntity.Status.ACTIVE.value());
        } else {
            templates = templateRepository.findAllByDboProIdAndStatusAndPayerAccountIn(dboProId,
                    TemplateEntity.Status.ACTIVE.value(), accounts);
        }

        if (StringUtils.isNotBlank(query)) {
            templates = templates.stream().filter(t -> filterSearch(t, query)).collect(Collectors.toList());
        }

        sortByName(templates);

        return templates.stream()
                .map(templateToTemplateDtoConverter::convert)
                .collect(Collectors.toList());
    }

    private boolean filterSearch(TemplateEntity template, String query) {
        return Optional.ofNullable(template.getName()).map(n -> n.toLowerCase().contains(query.toLowerCase())).orElse(false)
                || Optional.ofNullable(template.getPayeeInn()).map(n -> n.contains(query)).orElse(false)
                || Optional.ofNullable(template.getPayeeName()).map(n -> n.toLowerCase().contains(query.toLowerCase()))
                .orElse(false)
                || Optional.ofNullable(template.getPayerName()).map(n -> n.toLowerCase().contains(query.toLowerCase()))
                .orElse(false);
    }

    public void increment(Long templateId) {
        Optional<TemplateEntity> templateOptional = templateRepository.findById(templateId);
        if (templateOptional.isPresent()) {
            TemplateEntity template = templateOptional.get();
            template.setCount(template.getCount() + 1);
            templateRepository.save(template);
        }
    }

    public Template getTemplate(Long id, String dboProId) throws Exception {
        Optional<TemplateEntity> templateOptional = templateRepository.findByIdAndDboProIdAndStatus(id, dboProId,
                TemplateEntity.Status.ACTIVE.value());
        if (templateOptional.isPresent()) {
            return templateToTemplateDtoConverter.convert(templateOptional.get());
        } else {
            throw new Exception("Template NotFound");
        }
    }
}
