package ru.rosbank.paymentapp.service.fraud;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.service.fraud.model.DboEvent;
import ru.rosbank.paymentapp.service.fraud.model.Entity;
import ru.rosbank.paymentapp.service.fraud.model.Parameters;
import ru.rosbank.paymentapp.service.fraud.model.constant.DboActionType;
import ru.rosbank.paymentapp.service.fraud.model.constant.EventType;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@Service
public class DboEventBlockOperationsService extends AbstractUserEventService {

    @Value("${anti-fraud.user.event.topic.name}")
    private String userEventTopicName;

    @Async("antifraud_executor")
    public void sendBlockActiveOperationsEvent(ClientDTO client) {
        sendDboEvent(client, DboActionType.ACTIVE_OPERATIONS_BLOCKED);
    }

    @Async("antifraud_executor")
    public void sendUnblockActiveOperationsTimeoutEvent(ClientDTO client) {
        sendDboEvent(client, DboActionType.ACTIVE_OPERATIONS_UNBLOCKED_TIMEOUT);
    }

    private void sendDboEvent(ClientDTO client, DboActionType actionType) {
        if (!respectUserEvent) {
            return;
        }
        fraudSenderService.sendMessage(userEventTopicName, createEvent(client, actionType));
    }

    private DboEvent createEvent(ClientDTO client, DboActionType actionType) {

        DboEvent event = new DboEvent();

        event.setAction(actionType.toString());

        event.setCustomer(createCustomer(client));
        event.setRequest(createRequest());
        event.setEntity(new Entity());
        event.setParameters(createParameters());

        return event;
    }

    private Parameters createParameters() {
        Parameters parameters = new Parameters();
        parameters.setSystemId(PARAMETER_SYSTEM_ID_PRO_ONLINE);
        parameters.setTypeCode(EventType.DBO_EVENT.toString());
        return parameters;
    }

}
