package ru.rosbank.paymentapp.service;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapp.entity.DeliveringResource;
import ru.rosbank.paymentapp.repository.DeliveringResourceRepository;
import ru.rosbank.paymentapp.service.sms.SendSmsService;
import ru.rosbank.platform.client.paymentapp.model.FileResourceDTO;
import ru.rosbank.platform.esb.model.smsmessage.TemplateParameterListTypeEsb;
import ru.rosbank.platform.esb.model.smsmessage.TemplateParameterTypeEsb;

//Imported from bs-app
@Service
@RequiredArgsConstructor
public class DeliveringResourceService {
    private static final String DOCUMENT_DETAILS_SMS_PREFIX = "Детали платёжного документа: ";
    public static final String DELIVERING_RESOURCE_NOTIFICATION_TYPE = "dbopro_transaction";

    @Value("${email.msg.ib.link}")
    private String ibLink;

    private final DeliveringResourceRepository deliveringResourceRepository;
    private final SendSmsService sendSmsService;

    public FileResourceDTO getDeliveringResource(String id) {
        Optional<DeliveringResource> ores = deliveringResourceRepository
                .getDeliveringResourceByReference(id);
        if (ores.isPresent()) {
            FileResourceDTO fileResource = new FileResourceDTO();
            DeliveringResource deliveringResource = ores.get();
            fileResource.setId(deliveringResource.getResourceId());
            fileResource.setContentType(FileResourceDTO.ContentTypeEnum.fromValue(deliveringResource.getResourceContentType()));
            fileResource.setContent(new String(deliveringResource.getResourceContent(), StandardCharsets.UTF_8));
            fileResource.setName(deliveringResource.getResourceName());
            deliveringResource.setAttempts(deliveringResource.getAttempts() + 1);
            deliveringResourceRepository.save(deliveringResource);
            return fileResource;
        } else {
            return new FileResourceDTO();
        }
    }

    void deliverReferenceBySms(String phone, String referenceId) {
        sendSmsService.sendSMS(phone,
                referenceDelivered(referenceId, DOCUMENT_DETAILS_SMS_PREFIX),
                DELIVERING_RESOURCE_NOTIFICATION_TYPE);

    }

    public String buildReference(String referenceId) {
        return ibLink + "/#/resource?version=48&guid=" + referenceId;
    }

    public DeliveringResource save(DeliveringResource deliveringResource) {
        return deliveringResourceRepository.save(deliveringResource);
    }

    private TemplateParameterListTypeEsb referenceDelivered(String reference, String prefix) {
        TemplateParameterListTypeEsb templateParameterList = new TemplateParameterListTypeEsb();
        List<TemplateParameterTypeEsb> templateList = templateParameterList.getTemplateParameter();
        templateList.add(new TemplateParameterTypeEsb("text", prefix + reference));

        return templateParameterList;
    }
}
