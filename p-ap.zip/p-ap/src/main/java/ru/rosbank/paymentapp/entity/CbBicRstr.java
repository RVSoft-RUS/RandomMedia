package ru.rosbank.paymentapp.entity;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
public class CbBicRstr implements Serializable {

    @Id
    @EqualsAndHashCode.Include
    private String bic;

    private String rstr;

    private LocalDate rstrdate;

    public CbBicRstr(String bic, String rstr, LocalDate rstrdate) {
        this.bic = bic;
        this.rstr = rstr;
        this.rstrdate = rstrdate;
    }
}
