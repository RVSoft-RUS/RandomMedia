package ru.rosbank.paymentapp.repository;

import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.rosbank.paymentapp.entity.StatusTranslationEntity;

/**
 * Summary.
 * @author rb197115
 * @since 05.03.2024
 */
@Repository
public interface StatusTranslationRepository extends CrudRepository<StatusTranslationEntity, String> {

    Optional<StatusTranslationEntity> findByStatusComment(String key);

}
