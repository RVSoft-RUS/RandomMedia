package ru.rosbank.paymentapp.schedule;

import static ru.rosbank.paymentapp.entity.PaymentEntity.PROCESSING_STATUS;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.service.PropertyService;
import ru.rosbank.paymentapp.service.dfm.DfmPaymentService;

@Slf4j
@Component
@ConditionalOnProperty("dfm.payment.scheduled.enable")
public class PaymentProcessCheckJob extends CronScheduledJob {

    public static LocalDateTime startDateTime;

    @Autowired
    private DocumentProcessor documentProcessor;
    @Autowired
    private DfmPaymentService dfmPaymentService;
    @Autowired
    private PaymentEntityRepository paymentEntityRepository;
    @Autowired
    private PropertyService propertyService;

    public PaymentProcessCheckJob(@Value("${dfm.payment.scheduled.enable}") Boolean enable,
                                  @Value("${dfm.payment.scheduled.cron}") String cronExp) {
        super(enable, cronExp);
    }

    @Override
    public void run() {
        startDateTime = LocalDateTime.now();
        if (propertyService.getBoolean(PropertyService.IS_DISABLED_PROCESSING_DOCS).orElse(false)) {
            log.info("PaymentProcessCheckJob is disabled");
            return;
        }
        dfmPaymentService.deleteOutdatedCompleted();
        List<Long> documentIds = paymentEntityRepository.findAllIdsByStatusIn(PROCESSING_STATUS);
        List<CompletableFuture<Long>> features = new ArrayList<>(documentIds.size());

        for (Long documentId : documentIds) {
            try {
                features.add(documentProcessor.process(documentId));
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        CompletableFuture.allOf(features.toArray(CompletableFuture[]::new)).join();
        startDateTime = null;
    }

}
