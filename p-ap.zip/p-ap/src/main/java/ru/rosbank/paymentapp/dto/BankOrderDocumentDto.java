package ru.rosbank.paymentapp.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 *                 Банковский ордер
 *
 *              <p>paymentPriority - Очередность платежа
 *                 processedBy - Филиал банка, который обрабатывал документ
 *
 * <p>Java class for BankOrderDocument complex type.
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BankOrderDocumentDto extends AbstractDocumentDto {

    protected String paymentPriority;
    protected BankInfoDto processedBy;
}
