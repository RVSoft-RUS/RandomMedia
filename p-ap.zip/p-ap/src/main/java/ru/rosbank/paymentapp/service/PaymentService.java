package ru.rosbank.paymentapp.service;

import static ru.rosbank.paymentapp.entity.PaymentEntity.REVERTIBLE_STATUS;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.Year;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusFinal;
import ru.diasoft.micro.rosbank.ph.request.data.avro.DocumentStatusMiddle;
import ru.rosbank.paymentapp.converters.DocumentConverter;
import ru.rosbank.paymentapp.converters.DocumentDtoConverter;
import ru.rosbank.paymentapp.converters.PaymentDTOToAbstractDocumentDtoConverter;
import ru.rosbank.paymentapp.dto.AbstractDocumentDto;
import ru.rosbank.paymentapp.dto.ResourceContentTypeDto;
import ru.rosbank.paymentapp.dto.phub.DocumentStatusMessageDto;
import ru.rosbank.paymentapp.entity.DeliveringResource;
import ru.rosbank.paymentapp.entity.LastPaymentNumberEntity;
import ru.rosbank.paymentapp.entity.NumberYearKey;
import ru.rosbank.paymentapp.entity.PaymentEntity;
import ru.rosbank.paymentapp.repository.ImportedDocumentRepository;
import ru.rosbank.paymentapp.repository.LastPaymentNumberEntityRepository;
import ru.rosbank.paymentapp.repository.PaymentEntityRepository;
import ru.rosbank.paymentapp.repository.StatusTranslationRepository;
import ru.rosbank.paymentapp.service.audit.AuditService;
import ru.rosbank.paymentapp.service.audit.ThreadLocalAuditContext;
import ru.rosbank.paymentapp.service.bs.BsService;
import ru.rosbank.paymentapp.service.dfm.ToYourselfPaymentService;
import ru.rosbank.paymentapp.service.email.LocalEmailSender;
import ru.rosbank.paymentapp.service.exceptions.BackendException;
import ru.rosbank.paymentapp.service.exceptions.DocumentLockException;
import ru.rosbank.paymentapp.service.exceptions.DocumentRecallRetryException;
import ru.rosbank.paymentapp.service.exceptions.PaymentNotFoundException;
import ru.rosbank.paymentapp.service.exceptions.PaymentNotRevertibleException;
import ru.rosbank.paymentapp.service.fraud.DboEventRegisterPaymentService;
import ru.rosbank.paymentapp.service.fraud.PaymentEventService;
import ru.rosbank.paymentapp.service.validators.PaymentSignedValidator;
import ru.rosbank.paymentapp.service.validators.UniqDocumentNumberValidator;
import ru.rosbank.paymentapp.util.DocumentUtils;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.MetaDataDTO;
import ru.rosbank.platform.server.paymentapp.model.Document;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;
import ru.rosbank.platform.server.paymentapp.model.NextDocumentInfo;

@Slf4j
@RequiredArgsConstructor
@Service
public class PaymentService {

    @Value("${payment.recall.timeout}")
    private int recallTimeout;
    @Value("${document.creation.date}")
    private String defaultDocumentCreationDate;

    private final DocumentConverter documentConverter;
    private final PropertyService propertyService;
    private final BsService bsService;
    private final DocumentRecallService documentRecallService;
    private final PaymentEntityRepository paymentEntityRepository;
    private final ImportedDocumentRepository importedDocumentRepository;
    private final ToYourselfPaymentService toYourselfPaymentService;
    private final LastPaymentNumberEntityRepository lastPaymentNumberEntityRepository;
    private final StatusTranslationRepository statusTranslationRepository;
    private final UniqDocumentNumberValidator uniqDocumentNumberValidator;
    private final PaymentSignedValidator paymentSignedValidator;
    private final PaymentEventService paymentEventService;
    private final DboEventRegisterPaymentService dboEventRegisterPaymentService;
    private final RejectedPaymentStatusProcessor rejectedPaymentStatusProcessor;
    private final UserService userService;
    private final StatementService statementService;
    private final PaymentDTOToAbstractDocumentDtoConverter paymentDTOConverter;
    private final OrganizationService organizationService;
    private final AccountService accountService;
    private final DocumentDtoConverter documentDtoConverter;
    private final DeliveringResourceService deliveringResourceService;
    private final LocalEmailSender localEmailSender;
    private final PrintFormGenerator printFormGenerator;
    private final AuditService auditService;

    public static final String PROPERTY_KEY_BIS_DOCUMENT_DATE = "document.creation.date";
    // дополнительный период времени для предотвращения отправки в БИС отмененного платежа
    private static final int REVERT_TIME_INCREMENT = 10;
    private static final List<String> SYSTEMS_POSSIBLE_VALUES = List.of("C", "q");
    private static final String STATUS_PHUB_DOCUMENT_ACCEPTED = "DocumentAccepted";
    private static final String STATUS_PHUB_DOCUMENT_REJECTED = "DocumentRejected";
    private static final String STANDARD_REJECTED_COMMENT = "Платёж отклонён Банком";
    public static final Collection<String> STATUSES_AFTER_SIGNING = Collections.unmodifiableCollection(
            Arrays.asList("SIGNED", "PROCESSING", "COMPLETED", "PLANNED")
    );

    public List<Document> getDocumentList(List<String> payerAccounts, LocalDateTime dateFrom, LocalDateTime dateTo,
                                          String bisReference, List<DocumentStatusDTO> statuses, long limit, int offset,
                                          List<String> documentTypes) {

        List<PaymentEntity> paymentList = paymentEntityRepository
                .findByPayerAccountInAndDateBetween(payerAccounts, dateFrom, dateTo);
        Long clientId = paymentList.stream().filter(p -> p.getClientId() != null).findFirst()
                .map(PaymentEntity::getClientId).orElse(null);
        if (clientId != null && (CollectionUtils.isEmpty(statuses) || !List.of(DocumentStatusDTO.CREATED).equals(statuses))) {
            rejectedPaymentStatusProcessor.updateRejectedPaymentStatus(paymentList,
                    userService.getClientById(clientId).orElse(null));
        }
        return paymentList
                .stream()
                .filter(d -> filterByStatus(d, statuses))
                .filter(d -> filterByBisReference(d, bisReference))
                .filter(d -> filterByType(d, documentTypes))
                .sorted(Comparator.comparing(PaymentEntity::getDate).reversed())
                .skip(offset)
                .limit(limit)
                .map(documentConverter::toDTO)
                .collect(Collectors.toList());
    }

    public List<Document> getImportedDocumentList(String batchId, String dboProId) {
        Long clientId = bsService.getClient(dboProId).getLegacyId();
        List<String> documentIdList = importedDocumentRepository
                .findByClientIdAndBatchAndDocumentIsNotNull(clientId, batchId)
                .stream().map(importedDocument -> String.valueOf(importedDocument.getDocument().getId()))
                .collect(Collectors.toList());
        return getDocumentsByIdList(documentIdList)
                .stream()
                .map(documentConverter::toDTO)
                .collect(Collectors.toList());
    }

    List<PaymentEntity> getDocumentsByIdList(List<String> documentIds) {
        return paymentEntityRepository.findByIdInOrderByIdDesc(documentIds.stream()
                .mapToLong(Long::parseLong)
                .boxed()
                .collect(Collectors.toList()));
    }

    public Document createDocument(DocumentDTO dto) {
        PaymentEntity document = documentConverter.fromDTO(dto);
        return documentConverter.toDTO(createDocument(document));
    }

    public PaymentEntity createDocument(PaymentEntity document) {

        uniqDocumentNumberValidator.validatePerDey(document, LocalDateTime.ofInstant(getDocumentCreationDate().toInstant(),
                ZoneId.systemDefault()));
        PaymentEntity saved = paymentEntityRepository
                .save(document);
        updateLastNumber(saved.getPayerAccount(), Long.parseLong(saved.getNumber()));
        dboEventRegisterPaymentService.sendRegisterPaymentEvent(document, ThreadLocalAuditContext.get());
        return saved;
    }

    public Document getDocument(Long id) {
        return paymentEntityRepository
                .findById(id)
                .map(documentConverter::toDTO)
                .orElseThrow(() -> new PaymentNotFoundException(id));
    }


    public String getContent(Long id) {
        return paymentEntityRepository
                .findById(id)
                .map(documentConverter::toJson)
                .orElseThrow(() -> new PaymentNotFoundException(id));
    }


    public Document updateDocument(Long id, DocumentDTO dto) {

        PaymentEntity documentOld = paymentEntityRepository
                .findById(id)
                .orElseThrow(() -> new PaymentNotFoundException(id));
        if (!documentOld.getStatus().equals(DocumentStatus.CREATED.name())) {
            throw new BackendException("Изменение документа невозможно. Статус документа = " + documentOld.getStatus());
        }
        PaymentEntity document = documentConverter.fromDTO(dto);
        document.setId(id);
        //если апдейт вызван после подписания - то не создаем новый CurrencyControl
        if (dto.getSignDate() != null) {
            document.setCurrencyControlEntity(documentOld.getCurrencyControlEntity());
        }

        uniqDocumentNumberValidator.validatePerDey(document, LocalDateTime.ofInstant(getDocumentCreationDate().toInstant(),
            ZoneId.systemDefault()));
        PaymentEntity saved = paymentEntityRepository.save(document);
        updateLastNumber(saved.getPayerAccount(), Long.parseLong(saved.getNumber()));
        return documentConverter
                .toDTO(saved);
    }


    public void deleteDocument(Long id) {
        paymentEntityRepository
                .findById(id)
                .filter(e -> DocumentStatus.CREATED.name().equals(e.getStatus()))
                .ifPresent(e -> {
                    e.setStatus(DocumentStatus.ARCHIVE.name());
                    paymentEventService.sendDocumentStatus(e);
                    paymentEntityRepository.save(e);
                });
    }


    public Document getDocumentByReference(String bisId) {
        return paymentEntityRepository
                .findByBisDocumentId(DocumentUtils.toPaymentBisId(bisId))
                .map(documentConverter::toDTO)
                .orElseThrow(() -> new PaymentNotFoundException(bisId));
    }


    public void setSigned(Long id, MetaDataDTO metaData) {

        PaymentEntity document = paymentEntityRepository
                .findById(id)
                .orElseThrow(() -> new PaymentNotFoundException(id));

        paymentSignedValidator.validate(document);
        if (document.getExecutionDate() != null
                && document.getExecutionDate().isAfter(LocalDateTime.now())) {
            document.setStatus(DocumentStatus.PLANNED.name());
        } else {
            document.setStatus(DocumentStatus.SIGNED.name());
        }

        document.setSignDate(Optional.ofNullable(metaData.getDateSignature())
                .map(OffsetDateTime::toLocalDateTime).orElse(LocalDateTime.now()));
        document.setOrganizationBisId(Optional.ofNullable(document.getOrganizationBisId()).orElse(
                Optional.ofNullable(metaData).map(MetaDataDTO::getBisId).map(BisIdDTO::getId)
                        .orElseThrow(() -> new RuntimeException("Не заполнено поле BisId в документе:" + id))));
        document.setOrganizationBisBranch(Optional.ofNullable(document.getOrganizationBisBranch()).orElse(
                Optional.ofNullable(metaData).map(MetaDataDTO::getBisId).map(BisIdDTO::getBranch)
                        .orElseThrow(() -> new RuntimeException("Не заполнено поле BisBranch в документе:" + id))));
        document.setOrganizationCrmId(Optional.ofNullable(document.getOrganizationCrmId()).orElse(
                Optional.ofNullable(metaData).map(MetaDataDTO::getCrmId)
                        .orElseThrow(() -> new RuntimeException("Не заполнено поле CrmId в документе:" + id))));
        document.setOrganizationShortName(Optional.ofNullable(document.getOrganizationShortName()).orElse(
                Optional.ofNullable(metaData).map(MetaDataDTO::getShortNameOrg)
                        .orElse("")));

        paymentEntityRepository.save(document);
        String dboProId = Optional.ofNullable(metaData).map(MetaDataDTO::getDboProId).orElse("");
        auditService.sendEvent(new EventDTO().dboProId(dboProId).initiator("DBOPRO")
                .stage("Отправка события CHANGE_DOC_STATUS в SAS antifraud")
                .reference(dboProId).referenceType("CLIENT"));
        paymentEventService.sendDocumentStatus(document);
    }


    public Double getSum(String account, List<String> statuses) {
        return paymentEntityRepository
                .getByPayerAccountAndStatusIn(account, statuses)
                .stream()
                .map(PaymentEntity::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .doubleValue();
    }


    public void setCompleteByReference(String bisId) {
        PaymentEntity document = paymentEntityRepository
                .findByBisDocumentId(bisId)
                .orElseThrow(() -> new PaymentNotFoundException(bisId));

        document.setStatus(DocumentStatus.COMPLETED.name());
        paymentEntityRepository.save(document);

    }

    public void setCompleteByReferenceList(List<String> bisDocumentIds) {

        for (int i = 0; i < bisDocumentIds.size(); i++) {
            String bisId = bisDocumentIds.get(i);
            if (bisId.startsWith("Y01")) {
                String changedBisId = bisId.replace("Y01", "PP");
                changedBisId = changedBisId.substring(0, 8) + '-' + changedBisId.substring(8);
                bisDocumentIds.set(i, changedBisId);
            }
        }

        var payments = paymentEntityRepository
                .findAllByBisDocumentIdInAndStatusNot(bisDocumentIds, DocumentStatus.COMPLETED.getValue());
        for (PaymentEntity payment : payments) {
            payment.setStatus(DocumentStatus.COMPLETED.getValue());
            paymentEntityRepository.save(payment);
        }

    }


    public NextDocumentInfo getNextInfo(List<String> payerAccounts) {

        Long number = payerAccounts.stream().map(account -> {
            NumberYearKey key = new NumberYearKey();
            key.setNumber20(account);
            key.setYear(Year.now().getValue());
            Optional<LastPaymentNumberEntity> lastNumber = lastPaymentNumberEntityRepository.findById(key);
            return  lastNumber.map(LastPaymentNumberEntity::getNumber).orElse(0L);
        }).max(Long::compare).orElse(0L);

        NextDocumentInfo documentInfo = new NextDocumentInfo();

        Date created = getDocumentCreationDate();
        documentInfo.setCreated(OffsetDateTime.ofInstant(created.toInstant(), ZoneId.systemDefault()));
        documentInfo.setNumber(String.valueOf(number + 1));

        return documentInfo;

    }

    public void recall(Long id) {
        PaymentEntity document = paymentEntityRepository
                .findById(id)
                .orElseThrow(() -> new PaymentNotFoundException(id));

        if (!isRevertible(document)) {
            throw new PaymentNotRevertibleException("Документ нельзя отозвать");
        }

        document.setStatus(DocumentStatus.RECALLED.name());
        paymentEventService.sendDocumentStatus(document);
        document.setShowError(true);
        document.setStatusMessage("Отозвано пользователем "
                + new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(new Date()));

        paymentEntityRepository.save(document);
    }

    public void recall(Long id, boolean signed) {

        var recallEntity = documentRecallService.initiate(id);
        if (signed) {
            recallEntity = documentRecallService.setSigned(recallEntity);
        }
        try {
            documentRecallService.process(recallEntity);
        } catch (DocumentLockException e) {
            recallEntity = documentRecallService.setRetry(recallEntity);
            throw new DocumentRecallRetryException("Превышено число попыток"
                    + " блокировки документа на отзыв id=" + recallEntity.getId());
        }
    }

    public boolean isRevertible(PaymentEntity document) {
        if (DocumentStatus.PLANNED.name().equals(document.getStatus())) {
            return document.getExecutionDate().isAfter(LocalDateTime.now());
        } else {
            if (toYourselfPaymentService.isNotRevertible(document)) {
                return false;
            }
            return document.getSignDate() != null && document.getSignDate()
                    .plusSeconds(recallTimeout)
                    .plusSeconds(REVERT_TIME_INCREMENT)
                    .isAfter(LocalDateTime.now()) && REVERTIBLE_STATUS.contains(document.getStatus());
        }
    }

    public Date getDocumentCreationDate() {
        try {
            String dateFormat = "yyyy-MM-dd";
            Date dateFromConfig = new java.text.SimpleDateFormat(dateFormat).parse(defaultDocumentCreationDate);
            Date dateFromProperty = propertyService.getDate(PROPERTY_KEY_BIS_DOCUMENT_DATE, dateFormat);
            return dateFromProperty == null ? dateFromConfig : dateFromProperty;
        } catch (ParseException e) {
            return new Date();
        }
    }

    @Transactional
    public void processDocumentStatusMessage(DocumentStatusMessageDto message) {
        log.debug("DocumentStatusMessageDto message from PHUB = {}.", message);

        String bisDocumentId = message.getBisId();
        Optional<PaymentEntity> document = paymentEntityRepository.findByBisDocumentId(bisDocumentId);
        if (document.isEmpty()) {
            log.info("Документ с bisDocumentId = {} не найден.", bisDocumentId);
        } else {
            PaymentEntity paymentEntity = document.get();
            paymentEntity.setStatusDateTime(message.getStatusDateTime());
            String statusCode = message.getStatusCode() != null ? message.getStatusCode().toString() : "";
            paymentEntity.setStatusCode(statusCode);
            paymentEntity.setStatusComment(message.getStatusComment());
            paymentEntity.setStatusSysName(message.getStatusSysName());

            if (STATUS_PHUB_DOCUMENT_ACCEPTED.equals(message.getStatusSysName())) {
                paymentEntity.setStatus(DocumentStatus.COMPLETED.getValue());
            } else if (STATUS_PHUB_DOCUMENT_REJECTED.equals(message.getStatusSysName())
                    && !DocumentStatus.RECALLED.getValue().equals(paymentEntity.getStatus())) {
                paymentEntity.setStatus(DocumentStatus.REJECTED.getValue());
                paymentEntity.setStatusMessage(makeStatusMessage(message.getStatusComment()));
                paymentEntity.setShowError(true);
            }

            paymentEntityRepository.save(paymentEntity);
            log.debug("document saved {}", paymentEntity);
        }
    }

    public boolean isValidInputSystem(DocumentStatusMiddle message) {
        return SYSTEMS_POSSIBLE_VALUES.contains(message.getInputSystem());
    }

    public boolean isValidInputSystem(DocumentStatusFinal message) {
        return SYSTEMS_POSSIBLE_VALUES.contains(message.getInputSystem());
    }

    private String makeStatusMessage(String statusComment) {
        var statusTranslationOpt = statusTranslationRepository.findByStatusComment(statusComment);
        if (statusTranslationOpt.isPresent()) {
            log.debug("Find match for statusComment: {}", statusComment);
            return statusTranslationOpt.get().getTranslation();
        } else {
            return STANDARD_REJECTED_COMMENT;
        }
    }

    private boolean filterByStatus(PaymentEntity entity, List<DocumentStatusDTO> statuses) {
        if (statuses == null || statuses.isEmpty()) {
            return !DocumentStatusDTO.ARCHIVE.name().equals(entity.getStatus());
        } else {
            return enrichProcessingStatuses(statuses).contains(DocumentStatusDTO.fromValue(entity.getStatus()));
        }
    }

    private static List<DocumentStatusDTO> enrichProcessingStatuses(List<DocumentStatusDTO> dtoList) {
        if (dtoList.contains(DocumentStatusDTO.PROCESSING)) {
            dtoList.add(DocumentStatusDTO.DFM_PROCESSING);
            dtoList.add(DocumentStatusDTO.SENT_TO_BIS);
            dtoList.add(DocumentStatusDTO.SIGNED);
            dtoList.add(DocumentStatusDTO.PLANNED);
            dtoList.add(DocumentStatusDTO.ERROR);
            dtoList.add(DocumentStatusDTO.REVIEW);
        }
        return dtoList;
    }

    private boolean filterByBisReference(PaymentEntity entity, String bisReference) {
        if (bisReference == null) {
            return true;
        } else {
            return bisReference.equals(entity.getBisDocumentId());
        }
    }

    private boolean filterByType(PaymentEntity entity, List<String> type) {
        if (CollectionUtils.isEmpty(type)) {
            return true;
        } else {
            return type.contains(entity.getDoctype());
        }
    }

    private void updateLastNumber(String account, Long number) {
        NumberYearKey key = new NumberYearKey();
        key.setNumber20(account);
        key.setYear(Year.now().getValue());
        LastPaymentNumberEntity lastNumber = lastPaymentNumberEntityRepository.findById(key)
                .orElse(new LastPaymentNumberEntity(key, 1L));
        if (lastNumber.getNumber() < number) {
            lastNumber.setNumber(number);
        }
        lastPaymentNumberEntityRepository.save(lastNumber);
    }

    public Integer getSignedDocumentCount(List<Long> documentIds) {
        return Math.toIntExact(paymentEntityRepository.findByIdInOrderByIdDesc(documentIds).stream()
                .filter(document -> STATUSES_AFTER_SIGNING.contains(document.getStatus()))
                .count());
    }

    public void sendDocument(String id, String phone, String email, String dboProId) {
        AbstractDocumentDto documentDto = getDocumentForSending(dboProId, id);
        DeliveringResource deliveringResource = DeliveringResource.builder().phone(phone).email(email).created(LocalDate.now())
                .resourceId(documentDto.getNumber()).resourceName("document.html").reference(UUID.randomUUID().toString())
                .resourceContentType(ResourceContentTypeDto.HTML.value()).attempts(0).build();

        String fullReference = deliveringResourceService.buildReference(deliveringResource.getReference());
        try {
            deliveringResource.setResourceContent(
                    printFormGenerator.generatePaymentHtml(documentDto).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            log.error("Exception while generating new html for document {}", id, e);
            throw new BackendException("Cannot generate html for document.");
        }
        deliveringResource = deliveringResourceService.save(deliveringResource);

        if (deliveringResource.isPhoneDelivering()) {
            deliveringResourceService.deliverReferenceBySms(deliveringResource.getPhone(), fullReference);
        }

        if (deliveringResource.isEmailDelivering()) {
            try {
                localEmailSender.sendMimeEmailAudited(email,
                        printFormGenerator.buildEmailMessage(documentDto, fullReference),
                        printFormGenerator.buildEmailPlainTextMessage(documentDto, fullReference),
                        printFormGenerator.getTitle(documentDto) + documentDto.getNumber(),
                        printFormGenerator.createEmailInlineResources(),
                        new ArrayList<>());
            } catch (Exception e) {
                log.error("Exception while generating new html for document {} in email part", id, e);
                throw new BackendException("Cannot generate html for document.");
            }
        }
    }

    private AbstractDocumentDto getDocumentForSending(String dboProId, String documentId) {
        //todo по-хорошему надо это переделать чтобы все хождения в APP были в payment-api
        var paymentDTOOpt = statementService.getPayment(dboProId, documentId);
        if (paymentDTOOpt.isPresent()) {
            return paymentDTOConverter.convert(paymentDTOOpt.get());
        } else {
            // Документ не из выписки
            List<OrganizationDTO> organizations = organizationService.rootGet(dboProId);
            List<String> accounts = organizations.stream()
                    .map(org -> accountService.getAccountList(org.getCrmId(), org.getBisIds()))
                    .flatMap(Collection::stream)
                    .map(AccountDTO::getNumber)
                    .collect(Collectors.toList());
            Document document = getDocumentByReference(documentId);
            if (accounts.contains(document.getPayer().getAccount())) {
                return documentDtoConverter.convert(document);
            }
            throw new PaymentNotFoundException("Document not found in cache");
        }
    }
}
