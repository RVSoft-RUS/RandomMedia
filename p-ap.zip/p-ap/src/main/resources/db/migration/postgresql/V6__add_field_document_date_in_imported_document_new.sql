ALTER TABLE imported_document_new
    ADD COLUMN IF NOT EXISTS document_date timestamp;