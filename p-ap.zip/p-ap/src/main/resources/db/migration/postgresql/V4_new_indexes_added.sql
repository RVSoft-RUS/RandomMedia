CREATE OR REPLACE VIEW convert_dfm_reason AS
SELECT id,
    doc_date,
    reason::character varying(256) AS reason,
    doc_sum,
    name::character varying(256) AS name,
    payeracccode,
    payerinn,
    payerbank::character varying(256) AS payerbank,
    payerbik,
    benefname::character varying(256) AS benefname,
    benefacccode,
    benefinn,
    benefbank::character varying(256) AS benefbank,
    benefbik,
    benefbankacc,
    i_date,
    cli_code,
    flag,
    inf,
    status,
    doc_number,
    doc_serial,
    doc_type
   FROM dfm_payment;

create index if not exists document_old_id_idx on document_old(id);

create index if not exists document_recall_document_id_idx on document_recall(document_id);

create index if not exists imported_document_new_document_id_idx on imported_document_new(document_id);

create index if not exists document_processing_status_idx on document(status) where status in ('SIGNED', 'DFM_PROCESSING', 'PLANNED', 'REVIEW', 'SENT_TO_BIS');

create index if not exists antifraud_resolution_request_id_idx on antifraud_resolution(request_id);

create index if not exists imported_document_document_id_idx on imported_document(document_id);

create index if not exists document_vk_info_id_idx on document(vk_info_id);

create index if not exists document_rectification_new_document_id_idx on document_rectification_new(document_id);

create index if not exists document_payer_inn_idx on document(payer_inn);

create index if not exists dfm_payment_flag_idx on dfm_payment(flag);

create index if not exists document_number_idx on document(number);

create index if not exists dfm_payment_i_date_idx on dfm_payment(i_date);

DROP INDEX document_status_completed_bis_id_idx;

create index if not exists document_status_completed_bis_id_idx
    on document (bis_document_id)
    where status <> 'COMPLETED';