create table if not exists cb_bic
(
    bic               varchar(9),
    namep             varchar(1000),
    englname          varchar(1000),
    regn              varchar(1000),
    cntrcd            varchar(1000),
    rgn               varchar(1000),
    ind               varchar(1000),
    tnp               varchar(1000),
    nnp               varchar(1000),
    adr               varchar(1000),
    prntbic           varchar(1000),
    datein            date,
    dateout           date,
    pttype            varchar(1000),
    srvcs             varchar(1000),
    xchtype           varchar(1000),
    c1                varchar(1000),
    npsparticipant    varchar(1000),
    tonpsdate         date,
    participantstatus varchar(1000),
    directbic         varchar(1000),
    directaccount     varchar(1000)
);

create table if not exists cb_bic_account
(
    bic                   varchar(9),
    account               varchar(20),
    regulationaccounttype varchar(1000),
    ck                    varchar(1000),
    accountcbrbic         varchar(1000),
    datein                date,
    dateout               date,
    accountstatus         varchar(1000)
);

create table if not exists cb_bic_rstr
(
    bic      varchar(1000),
    rstr     varchar(1000),
    rstrdate date
);

create table if not exists dfm_payment
(
    id           bigserial primary key,
    doc_date     timestamp,
    reason       varchar(210),
    doc_sum      decimal(19, 2),
    name         varchar(160),
    payeracccode varchar(255),
    payerinn     varchar(255),
    payerbank    varchar(255),
    payerbik     varchar(255),
    benefname    varchar(160),
    benefacccode varchar(255),
    benefinn     varchar(255),
    benefbank    varchar(255),
    benefbik     varchar(255),
    benefbankacc varchar(255),
    i_date       timestamp,
    cli_code     varchar(20),
    flag         int,
    inf          varchar(255),
    status       varchar(20),
    doc_number   varchar(255),
    doc_serial   bigint,
    doc_type     varchar(2)
);


create table if not exists antifraud_block
(
    id        bigserial
        constraint antifraud_block_p_pk primary key,
    client_id bigint    not null,
    created   timestamp not null,
    released  timestamp,
    constraint antifraud_block_idx
        unique (client_id, released)
);

create table if not exists antifraud_client
(
    id             bigserial primary key,
    client_id      bigint       not null,
    resolution_id  varchar(36),
    status         varchar(100) not null,
    crm_id_natural varchar(30),
    crm_id_legal   varchar(30),
    created        timestamp    not null
);

create table if not exists antifraud_resolution
(
    id          bigserial primary key,
    request_id  varchar(36) not null,
    client_id   bigint      not null,
    document_id bigint      not null,
    status      varchar(30),
    created     timestamp   not null
);


create table if not exists currency
(
    code            varchar(8) not null primary key,
    numeric         smallint,
    description     varchar(255),
    currency_symbol varchar(8)
);

create table if not exists document_old
(
    bis_document_id                  varchar(50),
    number                           varchar(255),
    date                             timestamp,
    status                           varchar(20),
    status_message                   varchar(260),
    doctype                          varchar(2),
    purpose                          varchar(210),
    amount                           numeric(19, 2),
    paypriority                      varchar(2),
    urgent                           boolean,
    payer_status                     varchar(255),
    payment_basis                    varchar(255),
    basis_document_number            varchar(255),
    basis_document_created           varchar(255),
    tax_period                       varchar(255),
    uin                              varchar(255),
    kbk                              varchar(255),
    oktmo                            varchar(255),
    payer_name                       varchar(160),
    payer_account                    varchar(255),
    payer_inn                        varchar(255),
    payer_kpp                        varchar(255),
    payer_bank_name                  varchar(255),
    payer_bank_bic                   varchar(255),
    payer_bank_correspondent_account varchar(255),
    payee_name                       varchar(160),
    payee_account                    varchar(255),
    payee_inn                        varchar(255),
    payee_kpp                        varchar(255),
    payee_bank_name                  varchar(255),
    payee_bank_bic                   varchar(255),
    payee_bank_correspondent_account varchar(255),
    rem_ip                           varchar(50),
    rem_mac                          varchar(25),
    dbo_pro_id                       varchar(255),
    show_error                       boolean default false not null,
    client_id                        bigint,
    code_type_income                 varchar,
    type_tax_payment                 boolean,
    execution_date                   timestamp,
    organization_bis_id              varchar(15),
    organization_bis_branch          varchar(15),
    organization_crm_id              varchar(15),
    organization_short_name          varchar(255),
    sign_date                        timestamp,
    vk_info_id                       int,
    id                               bigint,
    reference_id                     varchar(255),
    reference_type                   varchar(255)
);

create table if not exists document_rectification_new
(
    id                     bigserial
        constraint document_rectification_new_pk
            primary key,
    dbo_pro_id             varchar(255),
    payer_account          varchar(20),
    document_id            varchar(50),
    status                 varchar(20),
    description            varchar(255),
    created                timestamp,
    purpose                varchar(255),
    payee_name             varchar(160),
    payee_account          varchar(20),
    payee_inn              varchar(12),
    payee_kpp              varchar(9),
    payment_basis          varchar(255),
    basis_document_number  varchar(15),
    basis_document_created varchar(10),
    tax_period             varchar(10),
    uin                    varchar(255),
    kbk                    varchar(20),
    oktmo                  varchar(8)
);

create table if not exists last_payment_number
(
    number20 varchar(20),
    year     bigint,
    number   bigint
);

create table if not exists organization_limit
(
    id              bigserial
        constraint organization_limit_pk primary key,
    status          varchar(25),
    type            varchar(25),
    organization_id varchar(15),
    limit_sum       numeric(19, 2),
    limit_period    int,
    payment_type    varchar(25),
    currency        varchar(10)
);



create table if not exists payment_order_log
(
    document_id bigint    not null
        primary key,
    date        timestamp not null
);

create table if not exists payment_vk_info
(
    id                       bigserial
        primary key,
    comment                  varchar(1000),
    full_name                varchar(255),
    phone                    varchar(255),
    is_sum_contract_less_200 boolean,
    is_sent_to_pro_portal    boolean default false,
    attempts_sent_pro_portal int default 0
);

create table if not exists document
(
    id                               bigserial primary key,
    bis_document_id                  varchar(50),
    number                           varchar(255),
    date                             timestamp,
    status                           varchar(20),
    status_message                   varchar(1020),
    doctype                          varchar(2),
    purpose                          varchar(210),
    amount                           numeric(19, 2),
    paypriority                      varchar(2),
    urgent                           boolean,
    payer_status                     varchar(255),
    payment_basis                    varchar(255),
    basis_document_number            varchar(255),
    basis_document_created           varchar(255),
    tax_period                       varchar(255),
    uin                              varchar(255),
    kbk                              varchar(255),
    oktmo                            varchar(255),
    payer_name                       varchar(160),
    payer_account                    varchar(255),
    payer_inn                        varchar(255),
    payer_kpp                        varchar(255),
    payer_bank_name                  varchar(255),
    payer_bank_bic                   varchar(255),
    payer_bank_correspondent_account varchar(255),
    payee_name                       varchar(160),
    payee_account                    varchar(255),
    payee_inn                        varchar(255),
    payee_kpp                        varchar(255),
    payee_bank_name                  varchar(255),
    payee_bank_bic                   varchar(255),
    payee_bank_correspondent_account varchar(255),
    rem_ip                           varchar(50),
    rem_mac                          varchar(25),
    dbo_pro_id                       varchar(255),
    show_error                       boolean not null,
    client_id                        bigint,
    code_type_income                 varchar,
    type_tax_payment                 boolean,
    execution_date                   timestamp,
    sign_date                        timestamp,
    organization_bis_id              varchar(15),
    organization_bis_branch          varchar(15),
    organization_crm_id              varchar(15),
    organization_short_name          varchar(255),
    vk_info_id                       bigint references payment_vk_info,
    reference_id                     varchar(255),
    reference_type                   varchar(255)
);



create table if not exists imported_document
(
    id                               bigint not null primary key,
    batch                            varchar(255),
    created                          timestamp,
    client_id                        bigint,
    status                           varchar(20),
    doc_type                         varchar(2),
    purpose                          varchar(210),
    amount                           numeric(19, 2),
    pay_priority                     varchar(2),
    urgent                           boolean,
    payer_status                     varchar(255),
    payment_basis                    varchar(255),
    basis_document_number            varchar(255),
    basis_document_created           varchar(255),
    tax_period                       varchar(255),
    uin                              varchar(255),
    kbk                              varchar(255),
    oktmo                            varchar(255),
    payer_name                       varchar(160),
    payer_account                    varchar(255),
    payer_inn                        varchar(255),
    payer_kpp                        varchar(255),
    payer_bank_name                  varchar(255),
    payer_bank_bic                   varchar(255),
    payer_bank_correspondent_account varchar(255),
    payee_name                       varchar(400),
    payee_account                    varchar(255),
    payee_inn                        varchar(255),
    payee_kpp                        varchar(255),
    payee_bank_name                  varchar(255),
    payee_bank_bic                   varchar(255),
    payee_bank_correspondent_account varchar(255),
    document_id                      bigint
        constraint imported_document_fk references document,
    code_type_income                 varchar,
    type_tax_payment                 boolean,
    number                           varchar(255)
);

create table if not exists imported_document_new
(
    id                               bigserial primary key,
    batch                            varchar(255),
    created                          timestamp,
    client_id                        bigint,
    status                           varchar(20),
    number                           varchar(100),
    doc_type                         varchar(2),
    purpose                          varchar(1000),
    amount                           numeric(19, 2),
    pay_priority                     varchar(2),
    urgent                           boolean,
    payer_status                     varchar(255),
    payment_basis                    varchar(255),
    basis_document_number            varchar(255),
    basis_document_created           varchar(255),
    tax_period                       varchar(255),
    uin                              varchar(255),
    kbk                              varchar(255),
    oktmo                            varchar(255),
    payer_name                       varchar(400),
    payer_account                    varchar(255),
    payer_inn                        varchar(255),
    payer_kpp                        varchar(255),
    payer_bank_name                  varchar(255),
    payer_bank_bic                   varchar(255),
    payer_bank_correspondent_account varchar(255),
    payee_name                       varchar(400),
    payee_account                    varchar(255),
    payee_inn                        varchar(255),
    payee_kpp                        varchar(255),
    payee_bank_name                  varchar(255),
    payee_bank_bic                   varchar(255),
    payee_bank_correspondent_account varchar(255),
    document_id                      bigint
        constraint imported_document_new_fk references document,
    code_type_income                 varchar,
    type_tax_payment                 boolean,
    error_message                    varchar(255)
);

create table if not exists payment_file
(
    id            bigserial primary key,
    file_id       varchar(255),
    payment_vk_id bigint references payment_vk_info
);

create table if not exists template_new
(
    id                               bigserial primary key,
    dbo_pro_id                       varchar(255) not null,
    name                             varchar(255),
    date_created                     timestamp,
    last_modified_date               timestamp,
    status                           varchar(20),
    doc_type                         varchar(2),
    purpose                          varchar(210),
    amount                           numeric(19, 2),
    pay_priority                     varchar(2),
    urgent                           boolean,
    payer_status                     varchar(255),
    payment_basis                    varchar(255),
    basis_document_number            varchar(255),
    basis_document_created           varchar(255),
    tax_period                       varchar(255),
    uin                              varchar(255),
    kbk                              varchar(255),
    oktmo                            varchar(255),
    payer_name                       varchar(160),
    payer_account                    varchar(255),
    payer_inn                        varchar(255),
    payer_kpp                        varchar(255),
    payer_bank_name                  varchar(255),
    payer_bank_bic                   varchar(255),
    payer_bank_correspondent_account varchar(255),
    payee_name                       varchar(160),
    payee_account                    varchar(255),
    payee_inn                        varchar(255),
    payee_kpp                        varchar(255),
    payee_bank_name                  varchar(255),
    payee_bank_bic                   varchar(255),
    payee_bank_correspondent_account varchar(255),
    code_type_income                 varchar,
    type_tax_payment                 boolean,
    count                            bigint
);

--update 04 07 2023 Sviridenko start
create table if not exists delivering_resource
(
	id bigserial primary key,
	created timestamp,
	attempts bigint,
	phone varchar(255),
	email varchar(255),
	reference varchar(255),
	resource_id varchar(255),
	resource_name varchar(255),
	resource_content bytea,
	resource_content_type varchar(255)
);

--update 02 08 2023 Sviridenko start
create table if not exists property
(
    id           bigserial       not null,
    property_key varchar(50) not null,
    value        varchar(2048),
    description  varchar(255),
    constraint property_pk primary key (id),
    constraint c_property_key_unique unique(property_key)
);

create table if not exists document_recall (
    id bigserial not null,
    created timestamp not null,
    document_id bigint,
    status varchar(20),
    info varchar(255),
    primary key (id),
    foreign key (document_id) references document(id)
);
--update 02 08 2023 Sviridenko end

--update 19 07 2023 Sviridenko start
create sequence if not exists hibernate_sequence start with 1 increment by 1;
--update 19 07 2023 Sviridenko end

create index if not exists delivering_resource_idx1 ON delivering_resource (resource_id);
--update 04 07 2023 Sviridenko end

create unique index if not exists dfm_payment_doc_serial_unique on dfm_payment (doc_serial);


create unique index if not exists idx_antifraud_reso_doc_id on antifraud_resolution (document_id);


create index if not exists organization_limit_organzation_id_status_idx
    on organization_limit (organization_id, status);

create index if not exists template_new_dbo_pro_id_idx
    on template_new (dbo_pro_id);

create index if not exists last_payment_number_number_year_idx
    on last_payment_number (number20, year);

create index if not exists document_payer_account_idx
    on document (payer_account);

create index if not exists document_date_idx
    on document (date);

create index if not exists document_status_completed_bis_id_idx
    on document (bis_document_id)
    where status <> 'completed';