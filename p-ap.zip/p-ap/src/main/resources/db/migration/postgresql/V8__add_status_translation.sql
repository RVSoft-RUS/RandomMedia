CREATE TABLE IF NOT EXISTS status_translation
(
    status_comment VARCHAR(255) ,
    translation    VARCHAR(255),
    primary key (status_comment)
);

COMMENT ON COLUMN status_translation.status_comment IS 'Комментарий к статусу от payment hub';
COMMENT ON COLUMN status_translation.translation IS 'Преобразованный комментарий, показываем клиенту';

INSERT INTO status_translation (status_comment, translation)
VALUES ('Не указан адрес в наименовании плательщика для платежа ФЛ или ИП в бюджет.. Не указан адрес в наименовании плательщика для платежа ФЛ или ИП в бюджет.',
        'Не указан адрес в наименовании плательщика для платежа ФЛ или ИП в бюджет');