ALTER TABLE document
    ADD COLUMN IF NOT EXISTS enrollment_date timestamp;

ALTER TABLE document_old
    ADD COLUMN IF NOT EXISTS enrollment_date timestamp;

COMMENT ON COLUMN document.enrollment_date
    IS 'Дата зачисления на публичный депозитный счет  (Платежка для Нотариуса)';
COMMENT ON COLUMN document_old.enrollment_date
    IS 'Дата зачисления на публичный депозитный счет  (Платежка для Нотариуса)';