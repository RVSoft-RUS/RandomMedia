ALTER TABLE document
    ADD COLUMN IF NOT EXISTS uuid uuid,
    ADD COLUMN IF NOT EXISTS status_date_time timestamp,
    ADD COLUMN IF NOT EXISTS status_comment VARCHAR(255),
    ADD COLUMN IF NOT EXISTS status_code VARCHAR(100),
    ADD COLUMN IF NOT EXISTS status_sys_name VARCHAR(100);

ALTER TABLE document_old
    ADD COLUMN IF NOT EXISTS uuid uuid,
    ADD COLUMN IF NOT EXISTS status_date_time timestamp,
    ADD COLUMN IF NOT EXISTS status_comment VARCHAR(255),
    ADD COLUMN IF NOT EXISTS status_code VARCHAR(100),
    ADD COLUMN IF NOT EXISTS status_sys_name VARCHAR(100);
