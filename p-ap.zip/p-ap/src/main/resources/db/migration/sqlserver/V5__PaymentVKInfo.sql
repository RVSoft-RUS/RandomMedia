CREATE TABLE payment_vk_info (
	id bigint identity (1,1) not null,
	comment varchar(255),
	full_name varchar(255),
	phone varchar(255),
	is_sum_contract_less_200 bit,
    primary key (id)
);




