alter table imported_document_new alter column purpose varchar(1000);
