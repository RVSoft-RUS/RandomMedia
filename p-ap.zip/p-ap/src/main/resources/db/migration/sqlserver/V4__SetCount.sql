update template_new set count = 0;
