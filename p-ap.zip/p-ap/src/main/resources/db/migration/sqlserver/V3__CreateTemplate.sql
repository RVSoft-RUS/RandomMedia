
CREATE TABLE template_new (
	id bigint identity (1,1) not null,
	dbo_pro_id varchar(255)  not null,
	name varchar(255),
	date_created datetime,
	last_modified_date datetime,

	status varchar(20),

	doc_type varchar(2),
	purpose varchar(210),
	amount numeric(19, 2),
	pay_priority varchar(2),
	urgent varchar(1),
	payer_status varchar(255),
	payment_basis varchar(255),
	basis_document_number varchar(255),
	basis_document_created varchar(255),
	tax_period varchar(255),
	uin varchar(255),
	kbk varchar(255),
	oktmo varchar(255),
	payer_name varchar(160),
	payer_account varchar(255),
	payer_inn varchar(255),
	payer_kpp varchar(255),
	payer_bank_name varchar(255),
	payer_bank_bic varchar(255),
	payer_bank_correspondent_account varchar(255),
	payee_name varchar(160),
	payee_account varchar(255),
	payee_inn varchar(255),
	payee_kpp varchar(255),
	payee_bank_name varchar(255),
	payee_bank_bic varchar(255),
	payee_bank_correspondent_account varchar(255),
    code_type_income varchar(1),
    type_tax_payment smallint,
    count bigint,
    primary key (id)
);

CREATE INDEX template_dbo_pro_id_index ON template_new (dbo_pro_id);


