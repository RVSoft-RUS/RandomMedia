CREATE TABLE payment_file (
	id bigint identity (1,1) not null,
	file_id varchar(255),
    primary key (id),
    payment_vk_id bigint,
    foreign key (payment_vk_id) references payment_vk_info(id)
);



