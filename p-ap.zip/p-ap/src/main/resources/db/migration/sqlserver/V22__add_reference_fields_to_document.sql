alter table document add reference_id varchar(255) null;
alter table document add reference_type varchar(255) null;

alter table document_old add reference_id varchar(255) null;
alter table document_old add reference_type varchar(255) null;