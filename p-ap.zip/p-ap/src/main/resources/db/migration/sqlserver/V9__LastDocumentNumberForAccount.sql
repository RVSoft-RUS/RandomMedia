CREATE TABLE last_payment_number (
	number20 varchar(20),
	year bigint,
	number bigint
);
CREATE INDEX number_year ON last_payment_number (number20, year);



