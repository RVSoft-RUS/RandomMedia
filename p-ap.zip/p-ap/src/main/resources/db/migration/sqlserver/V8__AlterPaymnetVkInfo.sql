ALTER TABLE payment_vk_info ALTER COLUMN comment varchar(1000);



