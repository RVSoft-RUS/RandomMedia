INSERT INTO template_new
(dbo_pro_id, name, date_created, last_modified_date, status, doc_type, purpose, pay_priority, payment_basis,
 basis_document_number, basis_document_created, tax_period, uin, kbk, oktmo, payee_name, payee_account, payee_inn,
 payee_kpp, payee_bank_name, payee_bank_bic, payee_bank_correspondent_account)
VALUES ('ENP', 'Единый налоговый платеж', '2023-01-18 15:42:01.927', '2023-01-18 15:42:01.927', 'ACTIVE', 'DE',
        'Единый налоговый платеж', '05', '0', '0', '0', '0', '0', '18201061201010000510', '0',
        'МИ ФНС РОССИИ ПО УПРАВЛЕНИЮ ДОЛГОМ', '03100643000000018500', '7727406020', '770801001',
        'УФК по Тульской области', '017003983', '40102810445370000059');