ALTER TABLE document add vk_info_id bigint;
alter table document add foreign key (vk_info_id) references payment_vk_info(id);



