create table document_rectification_new
(
    id                     bigint  identity (1,1)  not null,
    dbo_pro_id             varchar(255),
    payer_account          varchar(20),
    document_id            varchar(50),
    status                 varchar(20),
    description            varchar(255),
    created                datetime,
    purpose                varchar(255),
    payee_name             varchar(160),
    payee_account          varchar(20),
    payee_inn              varchar(12),
    payee_kpp              varchar(9),
    payment_basis          varchar(255),
    basis_document_number  varchar(15),
    basis_document_created varchar(10),
    tax_period             varchar(10),
    uin                    varchar(255),
    kbk                    varchar(20),
    oktmo                  varchar(8),
    constraint document_rectification_new_pk primary key (id)
);