UPDATE document_old SET id_new = id;
ALTER TABLE document_old DROP CONSTRAINT if exists PK__document__3213E83FD5D5B094;
ALTER TABLE document_old DROP CONSTRAINT if exists PK__document__3213E83F549E6598;
ALTER TABLE document_old DROP CONSTRAINT if exists PK__document_old

ALTER TABLE document_old DROP COLUMN id;

EXEC SP_RENAME  'document_old.id_new' , 'id', 'COLUMN';
