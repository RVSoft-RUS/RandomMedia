CREATE TABLE document_recall (
	id bigint identity (1,1) not null,
    created datetime not null,
	document_id bigint,
	status varchar(20),
	info varchar(255),
    primary key (id),
    foreign key (document_id) references document(id)
);



