ALTER TABLE payment_vk_info ADD is_sent_to_pro_portal bit default 'false';
ALTER TABLE payment_vk_info ADD attempts_sent_pro_portal int default 0;



