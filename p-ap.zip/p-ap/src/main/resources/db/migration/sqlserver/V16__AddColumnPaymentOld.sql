ALTER TABLE document_old  ADD id_new bigint;
