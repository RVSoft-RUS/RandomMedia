create table organization_limit
(
    id                     bigint  identity (1,1)  not null,
    status                 varchar(25),
    type                   varchar(25),
    organization_id        varchar(15),
    limit_sum              numeric(19, 2),
    limit_period           int,
    payment_type           varchar(25),
    currency               varchar(10),
    constraint organization_limit_pk primary key (id)
);

CREATE INDEX organization_id_limit_index ON organization_limit (organization_id, status);