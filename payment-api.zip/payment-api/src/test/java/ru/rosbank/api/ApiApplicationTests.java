package ru.rosbank.api;

import ru.rosbank.BaseTest;



class ApiApplicationTests extends BaseTest {



}
