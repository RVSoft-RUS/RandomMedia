package ru.rosbank;

import feign.Request;
import feign.RequestTemplate;
import java.util.HashMap;
import java.util.List;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;

/**
 * Mocks for tests.
 *
 * @author rb064742
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
@ActiveProfiles("unit_test")
public abstract class BaseTest {
    @MockBean
    protected ReferenceAppApiClient referenceAppApi;

    protected void initBranches() {
        Mockito.when(referenceAppApi.branchGet(null)).thenReturn(new ResponseEntity<>(List.of(
                new BranchDTO().correspondentAccount("01").inn("1").code("R01").bik("11"),
                new BranchDTO().correspondentAccount("02").inn("2").code("R02").bik("22"),
                new BranchDTO().correspondentAccount("03").inn("3").code("R03").bik("33"),
                new BranchDTO().correspondentAccount("04").inn("4").code("R04").bik("44")), HttpStatus.OK));
    }

    protected Request getRequest() {
        return Request.create(Request.HttpMethod.GET, "url",
                new HashMap<>(), null, new RequestTemplate());
    }

}
