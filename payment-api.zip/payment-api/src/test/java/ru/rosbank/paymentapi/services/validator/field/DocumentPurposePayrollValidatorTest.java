package ru.rosbank.paymentapi.services.validator.field;

import java.math.BigDecimal;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class DocumentPurposePayrollValidatorTest  extends BaseTest {

    @Autowired
    private DocumentPurposePayrollValidator documentPurposeValidator;

    @Test
    public void validate() {

        DocumentDTO document = new DocumentDTO();

        document.setPurpose("КОМАНДИРОВОЧН {VOXXXXX}dsgvsadf НДС");

        documentPurposeValidator.validate(document);

        document.setPurpose("asdffg оплата трудa ндс");

        documentPurposeValidator.validate(document);

        document.setPurpose("компенсация нДс");
        documentPurposeValidator.validate(document);
    }

    @Test
    public void validateExceptionEmptyPurpose() {
        DocumentDTO document = new DocumentDTO();

        Assertions.assertThrows(ValidationPaymentException.class, () -> documentPurposeValidator.validate(document));
    }

    @Test
    public void testExceptionCodeWord() {
        DocumentDTO document = new DocumentDTO();

        document.setPurpose("test");

        Assertions.assertThrows(ValidationPaymentException.class, () -> documentPurposeValidator.validate(document));
    }

    @Test
    public void testOutOfRangePurposeLength() {

        DocumentDTO document = new DocumentDTO();
        document.setAmount(BigDecimal.ONE.toString());
        document.setPurpose("1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"
                + "1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"
                + "11111");
        Assertions.assertThrows(ValidationPaymentException.class, () -> documentPurposeValidator.validate(document));
    }
}