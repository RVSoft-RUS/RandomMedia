package ru.rosbank.paymentapi.services.validator;

import java.math.BigDecimal;
import java.util.Arrays;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

class DocumentBalanceValidatorTest {

    @Test
    void validateBalance() {
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setRestAmount(BigDecimal.TEN.toString());


        Assertions.assertThat(DocumentBalanceValidator.validateBalance(
                Arrays.asList(new DocumentDTO().amount(BigDecimal.ONE.toString()),
                new DocumentDTO().amount(BigDecimal.ONE.toString())), accountDTO)).isTrue();
        Assertions.assertThat(DocumentBalanceValidator.validateBalance(
                Arrays.asList(new DocumentDTO().amount(BigDecimal.ONE.toString()),
                new DocumentDTO().amount(BigDecimal.TEN.toString())), accountDTO)).isFalse();
        Assertions.assertThat(DocumentBalanceValidator.validateBalance(
                Arrays.asList(new DocumentDTO().amount(BigDecimal.ONE.toString()),
                new DocumentDTO().amount(BigDecimal.TEN.toString())), accountDTO.restAmount(null))).isFalse();
        Assertions.assertThat(DocumentBalanceValidator.validateBalance(
                Arrays.asList(new DocumentDTO().amount(BigDecimal.ONE.toString()),
                new DocumentDTO().amount(BigDecimal.TEN.toString())), null)).isFalse();
    }
}