package ru.rosbank.paymentapi.services.signature;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

class SignerTest extends BaseTest {

    @Autowired
    DocumentRecallSigner documentRecallSigner;
    @Autowired
    RectificationSigner rectificationSigner;

    @MockBean
    CryptoproAppApi cryptoproAppApi;
    @MockBean
    ProductService productService;


    @Test
    void signFailed() {
        Request request = Request
                .create(Request.HttpMethod.GET, "url", new HashMap<>(), null, new RequestTemplate());
        when(cryptoproAppApi.certificateIdSignPost(any(), any()))
                .thenThrow(
                        new FeignException.InternalServerError("message",
                                request,
                                "ERROR".getBytes(StandardCharsets.UTF_8),
                                null)
            );
        when(cryptoproAppApi.userIdCertificateGet(any())).thenReturn(ResponseEntity.ok(Collections.emptyList()));
        when(productService.getOrganizationByAccNumberAndDboProId(any(),any()))
                .thenReturn(Optional.of(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch")))
                        .crmId("crmId")));
        Assertions.assertThrows(ValidationException.class, () -> documentRecallSigner
                .sign(new ClientDTO().id("id").phone("phone"),
                        Collections.singletonList(new DocumentDTO().payer(new RequisiteDTO().account("accNum")))));
    }

    @Test
    void signFailedRectification() {
        Request request = Request
                .create(Request.HttpMethod.GET, "url", new HashMap<>(), null, new RequestTemplate());
        when(cryptoproAppApi.certificateIdSignPost(any(), any()))
                .thenThrow(new FeignException.InternalServerError("message",
                        request,
                        "ERROR".getBytes(StandardCharsets.UTF_8),
                        null));
        when(cryptoproAppApi.userIdCertificateGet(any())).thenReturn(ResponseEntity.ok(Collections.emptyList()));
        when(productService.getOrganizationByAccNumberAndDboProId(any(),any()))
                .thenReturn(Optional.of(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch")))
                        .crmId("crmId")));
        Assertions.assertThrows(ValidationException.class, () -> rectificationSigner
                .sign(new ClientDTO().id("id").phone("phone"),
                        new Rectification(),
                        new Payment().payer(new Requisite().account("accNum"))));
    }
}