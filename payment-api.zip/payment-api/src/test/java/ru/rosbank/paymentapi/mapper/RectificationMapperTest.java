package ru.rosbank.paymentapi.mapper;

import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

class RectificationMapperTest extends BaseTest {

    @Test
    void toDTO() {
        Rectification rectification = new Rectification();
        rectification.setStatus("ACTIVE");
        rectification.setCreated(OffsetDateTime.now());
        RectificationDTO dto = RectificationMapper.INSTANCE.toDTO(rectification);
        Rectification result = RectificationMapper.INSTANCE.fromDTO(dto);

        Assertions.assertEquals(result.getStatus(), rectification.getStatus());
        Assertions.assertEquals(ClarificationMapper.DATE_TIME_FORMATTER.format(result.getCreated()),
                ClarificationMapper.DATE_TIME_FORMATTER.format(rectification.getCreated()));

    }

    @Test
    void getStatus() {
        Rectification rectification = new Rectification();
        rectification.setStatus("ACTIVE");
        RectificationDTO.StatusEnum result = RectificationMapper.INSTANCE.getStatus(rectification);
        Assertions.assertEquals(result, RectificationDTO.StatusEnum.ACTIVE);
        rectification.setStatus("CREATED");
        result = RectificationMapper.INSTANCE.getStatus(rectification);
        Assertions.assertEquals(result, RectificationDTO.StatusEnum.CREATED);
        rectification.setStatus("NEW");
        result = RectificationMapper.INSTANCE.getStatus(rectification);
        Assertions.assertEquals(result, RectificationDTO.StatusEnum.CREATED);
    }
}