package ru.rosbank.paymentapi.services.reporting;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;

class StatementFormServiceTest {

    @Test
    void getPaymentName() {
        PaymentDTO paymentDTO = new PaymentDTO();
        paymentDTO.setNumber("123");
        paymentDTO.setCompleted(OffsetDateTime.of(2024, 2, 6, 0, 0, 0,0, ZoneOffset.of("+03:00")));
        paymentDTO.setAmount(new AmountDTO().sum(BigDecimal.valueOf(123.01)));
        String name = StatementFormService.getPaymentName(paymentDTO);
        Assertions.assertThat(name).isEqualTo("123 06-02-2024 123,01");
    }
}