package ru.rosbank.paymentapi.services.integration;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;

class ProductServiceTest extends BaseTest {

    @Autowired
    ProductService productService;

    @MockBean
    OrganizationService organizationService;
    @MockBean
    AccountService accountService;

    @BeforeEach
    void init() {
        var orgList = Collections.singletonList(new OrganizationDTO()
                .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch"))));
        when(organizationService.getOrganizations(any())).thenReturn(orgList);
        when(accountService.getAccountList(any(), any(List.class))).thenReturn(Collections.singletonList(new AccountDTO()));
        when(accountService.getAccount(any())).thenReturn(new AccountDTO().restAmount("1000.00"));
    }

    @Test
    void getOrganization() {
        when(accountService.getMapCrmIdAndAccountsAsync(any(List.class))).thenReturn(Collections.singletonMap("123",
                Collections.singletonList(new AccountDTO()
                .number("40802810597880000207")
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                        .id("123")
                        .branch("R19")))));
        when(accountService.getAccountList(eq("321"), any(List.class))).thenReturn(Collections.emptyList());

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("321"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("123"));

        when(organizationService.getOrganizations(anyString()))
                .thenReturn(orgList);

        OrganizationDTO org = productService.getOrganizationByAccNumberAndDboProId("40802810597880000207",
                "35563c07-82b2-43a8-a3b2-c9a11c696b4e").get();
        Assertions.assertEquals(org.getCrmId(), orgList.get(1).getCrmId());
    }

    @Test
    void getOrganizationByAccAndDboProId() {
        when(accountService.getAccountList(eq("123"), any(List.class))).thenReturn(Collections.singletonList(new AccountDTO()
                .number("40802810597880000207")
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                        .id("123")
                        .branch("R19"))));
        when(accountService.getAccountList(eq("321"), any(List.class))).thenReturn(Collections.emptyList());

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("321"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("123"));

        when(organizationService.getOrganizations(anyString()))
                .thenReturn(orgList);

        Optional<OrganizationDTO> orgOpt = productService.getOrganizationByAccAndDboProId("40802810597880000207",
                new AccountDTO().bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("321")));
        Assertions.assertEquals(orgOpt.get().getCrmId(), "321");
    }

    @Test
    void getOrganizationByAccAndDboProIdEmpty() {
        when(accountService.getAccountList(eq("123"), any(List.class))).thenReturn(Collections.singletonList(new AccountDTO()
                .number("40802810597880000207")
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                        .id("123")
                        .branch("R19"))));
        when(accountService.getAccountList(eq("321"), any(List.class))).thenReturn(Collections.emptyList());

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("321"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("123"));

        when(organizationService.getOrganizations(anyString()))
                .thenReturn(orgList);

        Optional<OrganizationDTO> orgOpt = productService.getOrganizationByAccAndDboProId("40802810597880000207",
                new AccountDTO().bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("333")));
        Assertions.assertFalse(orgOpt.isPresent());
    }

    @Test
    void getAccountBalance() {

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("321"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("123"));
        when(accountService.getAccountsAsync(orgList)).thenReturn(Arrays.asList(new AccountDTO()
                .number("40802810597880000207")
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                        .id("123")
                        .branch("R19")).restAmount("500"),
                new AccountDTO()
                        .number("40802810597880000209")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("123")
                                .branch("R19")).restAmount("100")));
        when(organizationService.getOrganizations(anyString()))
                .thenReturn(orgList);

        BigDecimal balance = productService.getAccountBalance("40802810597880000207", "dboProId");
        Assertions.assertEquals(balance, BigDecimal.valueOf(500));
    }

    @Test
    void getAccount() {

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("321"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("123"));
        when(accountService.getAccountsAsync(orgList)).thenReturn(Arrays.asList(new AccountDTO()
                        .number("40802810597880000207")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("123")
                                .branch("R19")).restAmount("500"),
                new AccountDTO()
                        .number("40802810597880000209")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("123")
                                .branch("R19")).restAmount("100")));
        when(organizationService.getOrganizations(anyString()))
                .thenReturn(orgList);

        AccountDTO accountDTO = productService.getAccount("40802810597880000207", "dboProId");
        Assertions.assertEquals(accountDTO.getRestAmount(), "500");
    }

    @Test
    void getAccountThrow() {

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("321"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("123"));
        when(accountService.getAccountsAsync(orgList)).thenReturn(Arrays.asList(new AccountDTO()
                        .number("40802810597880000207")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("123")
                                .branch("R19")).restAmount("500"),
                new AccountDTO()
                        .number("40802810597880000209")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("123")
                                .branch("R19")).restAmount("100")));
        when(organizationService.getOrganizations(anyString()))
                .thenThrow(RuntimeException.class);

        Assertions.assertThrows(RuntimeException.class, () -> productService.getAccount("40802810597880000207", "dboProId"));
    }

    @Test
    void getAccountThrow2() {

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("321"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("123"));
        when(accountService.getAccountsAsync(orgList)).thenReturn(Arrays.asList(new AccountDTO()
                        .number("40802810597880000207")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("123")
                                .branch("R19")).restAmount("500"),
                new AccountDTO()
                        .number("40802810597880000209")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                                .id("123")
                                .branch("R19")).restAmount("100")));
        when(organizationService.getOrganizations(anyString()))
                .thenReturn(orgList);

        Assertions.assertThrows(BankInfoException.class, () -> productService.getAccount("test", "dboProId"));
    }

    @Test
    void getAccountThrow3() {

        Assertions.assertThrows(BankInfoException.class, () -> productService.getAccount("", "dboProId"));
    }
}