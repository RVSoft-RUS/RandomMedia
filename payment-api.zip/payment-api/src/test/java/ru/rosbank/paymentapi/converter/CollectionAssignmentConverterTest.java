package ru.rosbank.paymentapi.converter;


import org.junit.Assert;
import org.junit.jupiter.api.Test;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

class CollectionAssignmentConverterTest {

    @Test
    void convert() {
        PaymentDTO paymentDTO = new PaymentDTO().uin("uin");
        Payment payment = CollectionAssignmentConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getUin(), payment.getUin());
    }
}