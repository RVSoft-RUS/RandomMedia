package ru.rosbank.paymentapi.api;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.DuplicateTemplateNameException;
import ru.rosbank.platform.server.paymentapi.model.Error;

class RestExceptionHandlerTest extends BaseTest {

    @Autowired
    private RestExceptionHandler restExceptionHandler;

    @Test
    void duplicateTemplateNameExceptionTest() {
        Error error = new Error();
        error.setType(Error.TypeEnum.VALIDATION_ERROR);
        error.setMessage("test");

        ResponseEntity<Object> response = restExceptionHandler.handleException(new DuplicateTemplateNameException("test"));
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        Assertions.assertEquals(error, response.getBody());
    }
}
