package ru.rosbank.paymentapi.services.validator;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ConfirmationRequiredException;
import ru.rosbank.paymentapi.exception.ValidationDocumentOrgLimitException;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.ErrorDTO;
import ru.rosbank.platform.client.paymentapp.model.LimitResponseDTO;


class DocumentOrganizationLimitValidatorTest extends BaseTest {

    @Autowired
    DocumentOrganizationLimitValidator validator;
    @MockBean
    PaymentAppApiClient paymentAppApi;

    @Test
    void validate() {
        Mockito.when(paymentAppApi.limitOrganizationIdPost(any(), any())).thenReturn(
                new ResponseEntity<>(new LimitResponseDTO(), HttpStatus.OK));
        OrganizationDTO org = new OrganizationDTO();
        org.setCrmId("CrmId");
        validator.validate(org, Collections.singletonList(new DocumentDTO().id(1)));
        Mockito.verify(paymentAppApi, times(1)).limitOrganizationIdPost(eq("CrmId"), any());
    }

    @Test
    void validateOrgLimitException() throws IOException {


        ErrorDTO errorDTO = new ErrorDTO();
        errorDTO.setType(ErrorDTO.TypeEnum.VALIDATION_ERROR);
        errorDTO.setMessage("message VALIDATION_ERROR");
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        new ObjectMapper().writeValue(stream, errorDTO);
        Request request = Request.create(Request.HttpMethod.GET, "url", new HashMap<>(), null, new RequestTemplate());
        when(paymentAppApi.limitOrganizationIdPost(any(), any())).thenThrow(
                new FeignException.InternalServerError("message", request, stream.toByteArray(), null)
        );
        OrganizationDTO org = new OrganizationDTO();
        org.setCrmId("CrmId");
        Assertions.assertThrows(ValidationDocumentOrgLimitException.class, () ->
                validator.validate(org, Collections.singletonList(new DocumentDTO().id(1))));

    }

    @Test
    void validateException() throws IOException {

        OrganizationDTO org = new OrganizationDTO();
        org.setCrmId("CrmId");
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        new ObjectMapper().writeValue(stream, org);
        Request request = Request.create(Request.HttpMethod.GET, "url", new HashMap<>(), null, new RequestTemplate());
        when(paymentAppApi.limitOrganizationIdPost(any(), any())).thenThrow(
                new FeignException.InternalServerError("message", request, stream.toByteArray(), null)
        );
        Assertions.assertThrows(FeignException.class, () ->
                validator.validate(org, Collections.singletonList(new DocumentDTO().id(1))));

    }

    @Test
    void validateException2() {

        Request request = Request.create(Request.HttpMethod.GET, "url",
                new HashMap<>(), null, new RequestTemplate());

        when(paymentAppApi.limitOrganizationIdPost(any(), any())).thenThrow(
                new FeignException.InternalServerError("message", request, null, null)
        );
        OrganizationDTO org = new OrganizationDTO();
        org.setCrmId("CrmId");
        Assertions.assertThrows(FeignException.class, () ->
                validator.validate(org, Collections.singletonList(new DocumentDTO().id(1))));

    }
}