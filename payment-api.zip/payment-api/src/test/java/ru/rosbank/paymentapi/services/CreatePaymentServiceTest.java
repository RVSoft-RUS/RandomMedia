package ru.rosbank.paymentapi.services;


import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.DocumentValidator;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.AccountsCachedResponseDTO;
import ru.rosbank.platform.client.notificationapp.api.NotificationAppApiClient;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApiClient;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApiClient;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.userapp.api.UserAppApiClient;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

class CreatePaymentServiceTest extends BaseTest {

    @Autowired
    private CreatePaymentService createPaymentService;
    @MockBean
    private AccountAppApiClient accountAppApiClient;
    @MockBean
    private OrganizationAppApiClient organizationAppApiClient;
    @MockBean
    private RolesAppApiClient rolesAppApiClient;
    @MockBean
    private DocumentValidator validator;
    @MockBean
    private UserAppApiClient userAppApiClient;
    @MockBean
    private NotificationAppApiClient notificationAppApi;

    @Test
    void upsert() {
        Mockito.when(notificationAppApi.dfmblockGet(any(), any())).thenReturn(new ResponseEntity<>(false, HttpStatus.OK));
        Mockito.when(referenceAppApi.bankGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(
                        new BankDTO().correspondentAccount("corAcc").name("name")), HttpStatus.OK));
        Mockito.when(userAppApiClient.userGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new ClientDTO(), HttpStatus.OK));

        Mockito.when(rolesAppApiClient.idGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new IndividualDTO()
                        .accessGroup(IndividualDTO.AccessGroupEnum.ALL_RIGHTS)
                .dboProId("123")), HttpStatus.OK));

        Mockito.when(organizationAppApiClient.rootGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new OrganizationDTO().crmId("crmId")
                .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19")))), HttpStatus.OK));

        Mockito.when(accountAppApiClient.idGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getAccount(), HttpStatus.OK));
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new AccountsCachedResponseDTO().accounts(getAccountDTOList()), HttpStatus.OK));

        DocumentDTO documentDTO = createPaymentService.upsert(new Payment()
                .payee(new Requisite().bank(new BankInfo().bic("bic").correspondentAccount("corAcc")))
                .payer(new Requisite().account("accountNumber20"))
                .type(Payment.TypeEnum.CD), "123");
        Assert.assertEquals("accountNumber20", documentDTO.getPayer().getAccount());
    }

    @Test
    void setPayerKppFromOrganizationInn10() {
        DocumentDTO doc = new DocumentDTO().payer(new RequisiteDTO().inn("0123456789"))
                .payerStatus("01");
        createPaymentService.setPayerKppFromOrganization(doc, new OrganizationDTO().kpp("OrganizationKpp"));
        assertThat(doc.getPayer().getKpp()).isEqualTo("OrganizationKpp");
    }

    @Test
    void setPayerKppFromOrganizationInn5() {
        DocumentDTO doc = new DocumentDTO().payer(new RequisiteDTO().inn("01234"))
                .payerStatus("01");
        createPaymentService.setPayerKppFromOrganization(doc, new OrganizationDTO().kpp("OrganizationKpp"));
        assertThat(doc.getPayer().getKpp()).isEqualTo("OrganizationKpp");
    }

    @Test
    void setPayerKppFromOrganizationInn12() {
        DocumentDTO doc = new DocumentDTO().payer(new RequisiteDTO().inn("012345678912"))
                .payerStatus("01");
        createPaymentService.setPayerKppFromOrganization(doc, new OrganizationDTO().kpp("OrganizationKpp"));
        assertThat(doc.getPayer().getKpp()).isEqualTo("0");
    }

    private List<AccountDTO> getAccountDTOList() {
        AccountDTO accountDTO1 = new AccountDTO();
        accountDTO1.setNumber("accountNumber20");
        accountDTO1.setAccountType("CA");
        accountDTO1.setCurrency("RUB");
        accountDTO1.setHasRestrictions(true);
        accountDTO1.setOpenDate(LocalDate.now());
        accountDTO1.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        AccountDTO accountDTO2 = new AccountDTO();
        accountDTO2.setNumber("123456890123456891");
        accountDTO2.setAccountType("CD");
        accountDTO2.setCurrency("RUB");
        accountDTO2.setHasRestrictions(true);
        accountDTO2.setOverdraftAmount("0,00");
        accountDTO2.setRestAmount("2536,25");
        accountDTO2.setOpenDate(LocalDate.now());
        accountDTO2.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        AccountDTO accountDTO3 = new AccountDTO();
        accountDTO3.setNumber("123456890123456892");
        accountDTO3.setAccountType("CE");
        accountDTO3.setCurrency("RUB");
        accountDTO3.setHasRestrictions(true);
        accountDTO3.setOpenDate(LocalDate.now());
        accountDTO3.setReserveAmount("");
        accountDTO3.setRestAmount("-15,25");
        accountDTO3.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));
        return Arrays.asList(accountDTO1, accountDTO2, accountDTO3);
    }

    private AccountDTO getAccount() {
        return new AccountDTO()
                .number("accountNumber20")
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("bisId").branch("branch"));
    }
}