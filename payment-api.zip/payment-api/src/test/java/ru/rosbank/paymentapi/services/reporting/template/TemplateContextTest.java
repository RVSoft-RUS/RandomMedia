package ru.rosbank.paymentapi.services.reporting.template;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TemplateContextTest {
    private TemplateContext templateContext;

    @BeforeEach
    public void init() {
        Map<String, String> data = new HashMap<>(1);
        data.put("param1", "p1");
        templateContext = new TemplateContext(data);
    }

    @Test
    void getTest() {
        String param1 = (String) templateContext.get("param1");
        Assertions.assertEquals("p1", param1);
        Assertions.assertThrows(IllegalArgumentException.class, () -> templateContext.get(null));
    }

    @Test
    void putTest() {
        templateContext.put("param2", "p2");
        String param2 = (String) templateContext.get("param2");
        Assertions.assertEquals("p2", param2);
        Assertions.assertThrows(IllegalArgumentException.class, () -> templateContext.put(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> templateContext.put(null, "null"));
    }
}