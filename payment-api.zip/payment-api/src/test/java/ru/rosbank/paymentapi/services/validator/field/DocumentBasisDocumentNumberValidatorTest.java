package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.DocumentPropertyImpl;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentBasisDocumentNumberValidator;


class DocumentBasisDocumentNumberValidatorTest extends BaseTest {
    @Autowired
    DocumentPropertyImpl documentProperty;
    @MockBean
    DocumentTypeCalculatorImpl documentTypeCalculator;

    @Test
    void validate() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setBasisDocumentNumber("01;A");
        document.setPayerStatus("19");
        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        validator.validate(document);
    }

    @Test
    void validateException() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setBasisDocumentNumber("15;A");
        document.setPayerStatus("19");
        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }

    @Test
    void validate31() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setBasisDocumentNumber("0");
        document.setPayerStatus("31");
        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        validator.validate(document);
    }

    @Test
    void validateException31() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setBasisDocumentNumber("01A");
        document.setPayerStatus("31");
        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }

    @Test
    void validate00() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setPaymentBasis("00");
        document.setBasisDocumentNumber("00");
        document.setPayerStatus("06");

        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        validator.validate(document);
    }

    @Test
    void validateException00() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setPaymentBasis("00");
        document.setBasisDocumentNumber("0");
        document.setPayerStatus("17");
        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }

    @Test
    void validate0() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setPaymentBasis("0");
        document.setBasisDocumentNumber("0");
        document.setPayerStatus("06");

        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        validator.validate(document);
    }

    @Test
    void validateException0() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setPaymentBasis("00");
        document.setBasisDocumentNumber("0");
        document.setPayerStatus("17");
        document.setPayer(new RequisiteDTO());
        DocumentBasisDocumentNumberValidator validator =
                new DocumentBasisDocumentNumberValidator(documentTypeCalculator, documentProperty);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }
}