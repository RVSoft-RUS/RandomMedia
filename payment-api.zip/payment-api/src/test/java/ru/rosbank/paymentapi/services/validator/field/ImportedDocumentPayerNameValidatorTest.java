package ru.rosbank.paymentapi.services.validator.field;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

class ImportedDocumentPayerNameValidatorTest extends BaseTest {
    private DocumentDTO document;

    @Autowired
    ImportedDocumentPayerNameValidator payerNameValidator;

    @Test
    void validate() {
        document = new DocumentDTO();
        document.setPayer(new RequisiteDTO());
        document.getPayer().setName("«\" лоыдвлаоыж»длвожолжэолд»");
        payerNameValidator.validate(document);
        Assertions.assertEquals("\" лоыдвлаоыждлвожолжэолд", document.getPayer().getName());
    }
}