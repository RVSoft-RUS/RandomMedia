package ru.rosbank.paymentapi.services;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.exception.ClarificationValidationException;
import ru.rosbank.paymentapi.mapper.ClarificationMapper;
import ru.rosbank.paymentapi.rbsp.client.ClarificationRBSPFeign;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.paymentapi.rbsp.dto.common.Response;
import ru.rosbank.paymentapi.rbsp.dto.common.ResponseMetaData;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

class ClarificationServiceTest extends BaseTest {

    @Autowired
    ClarificationService clarificationService;
    @MockBean
    ClarificationRBSPFeign rbspClient;
    @MockBean
    ClarificationMapper mapper;
    @MockBean
    ProductService productService;

    @Test
    void clarificationPost() {
        Clarification clarification = new Clarification();
        clarification.setClarificationId(1L);
        when(rbspClient.clarificationPost(any()))
                .thenReturn(new Response<>(new ResponseMetaData(), clarification));
        when(mapper.toClarification(any(), any(), any(), any(), any(), any()))
                .thenReturn(clarification);

        Rectification rectification = new Rectification();
        Payment payment = new Payment();
        payment.setCreated(OffsetDateTime.now());
        BisIdDTO bisIdDTO = new BisIdDTO();

        Long id = clarificationService.clarificationPost(rectification, payment, "orgId", bisIdDTO, "inn");
        Assertions.assertEquals(id, 1L);
    }

    @Test
    void clarificationPostException() {
        Clarification clarification = new Clarification();
        clarification.setClarificationId(1L);
        when(rbspClient.clarificationPost(any()))
                .thenThrow(RuntimeException.class);
        when(mapper.toClarification(any(), any(), any(), any(), any(), any()))
                .thenReturn(clarification);

        Rectification rectification = new Rectification();
        Payment payment = new Payment();
        payment.setCreated(OffsetDateTime.now());
        BisIdDTO bisIdDTO = new BisIdDTO();

        Long id = clarificationService.clarificationPost(rectification, payment, "orgId", bisIdDTO, "inn");
        Assertions.assertNull(id);
    }

    @Test
    void clarificationExecute() {
        Rectification rectification = new Rectification();
        rectification.setId(1L);

        clarificationService.clarificationExecute(rectification);
        verify(rbspClient).clarificationExecutePatch(eq(1L), any());
    }

    @Test
    void clarificationGet() {
        Rectification rectification = new Rectification();
        rectification.setId(1L);
        Clarification clarification = new Clarification();
        clarification.setClarificationId(1L);
        when(rbspClient.clarificationGet(any()))
                .thenReturn(new Response<>(new ResponseMetaData(), clarification));

        Clarification clr = clarificationService.clarificationGet(1L);
        Assertions.assertEquals(clr.getClarificationId(), clarification.getClarificationId());
        verify(rbspClient).clarificationGet(eq(1L));
    }

    @Test
    void rectificationGet() {
        Clarification clarification = new Clarification();
        clarification.setClarificationId(1L);
        Rectification rectification = new Rectification();
        rectification.setId(1L);
        when(rbspClient.clarificationGet(any()))
                .thenReturn(new Response<>(new ResponseMetaData(), clarification));
        when(mapper.toRectification(any()))
                .thenReturn(rectification);
        Rectification rec = clarificationService.rectificationGet(1L);
        Assertions.assertEquals(rec.getId(), rectification.getId());

    }

    @Test
    void clarificationFiltered() {
        Clarification clarification = new Clarification();
        clarification.setClarificationId(1L);
        when(rbspClient.clarificationFilteredPost(any()))
                .thenReturn(new Response<>(new ResponseMetaData(), Collections.singletonList(clarification)));

        List<Clarification> clarifications = clarificationService.clarificationFiltered(Collections.singletonList("1"));
        Assertions.assertTrue(clarifications.stream().anyMatch(c -> clarification.getClarificationId()
                .equals(c.getClarificationId())));
        Assertions.assertTrue(clarifications.size() == 1);
        verify(rbspClient).clarificationFilteredPost(any());
    }

    @Test
    void clarificationFilteredError() {
        Clarification clarification = new Clarification();
        clarification.setClarificationId(1L);
        when(rbspClient.clarificationFilteredPost(any()))
                .thenThrow(RuntimeException.class);

        List<Clarification> clarifications = clarificationService.clarificationFiltered(Collections.singletonList("1"));
        Assertions.assertNull(clarifications);
    }

    @Test
    void commissionGet() {
        ResponseMetaData metaData = new ResponseMetaData();
        metaData.setStatus(200);
        when(rbspClient.commissionGet(any(), any()))
                .thenReturn(new Response<>(metaData, BigDecimal.valueOf(500L)));
        when(productService.getAccountBalance(any(), any()))
                .thenReturn(BigDecimal.valueOf(500L));

        BigDecimal resp = clarificationService.commissionGet("organizationId", "operationUid", "payerAccount20", "dboProId");
        Assertions.assertEquals(resp, BigDecimal.valueOf(500L));
    }

    @Test
    void commissionGetNotEnoughMoney() {
        ResponseMetaData metaData = new ResponseMetaData();
        metaData.setStatus(200);
        when(rbspClient.commissionGet(any(), any()))
                .thenReturn(new Response<>(metaData, BigDecimal.valueOf(500L)));
        when(productService.getAccountBalance(any(), any()))
                .thenReturn(BigDecimal.valueOf(499L));

        Assertions.assertThrows(ClarificationValidationException.class,
            () ->  clarificationService.commissionGet("organizationId", "operationUid", "payerAccount20", "dboProId"));
    }

    @Test
    void commissionGetStatusProcessing() {
        ResponseMetaData metaData = new ResponseMetaData();
        metaData.setStatus(200);
        metaData.setMessage("STATUS_PROCESSING");
        when(rbspClient.commissionGet(any(), any()))
                .thenReturn(new Response<>(metaData, BigDecimal.valueOf(500L)));
        when(productService.getAccountBalance(any(), any()))
                .thenReturn(BigDecimal.valueOf(500L));

        Assertions.assertThrows(ClarificationValidationException.class,
            () ->  clarificationService.commissionGet("organizationId", "operationUid", "payerAccount20", "dboProId"));
    }

    @Test
    void commissionGetStatusCommissionProcessing() {
        ResponseMetaData metaData = new ResponseMetaData();
        metaData.setStatus(200);
        metaData.setMessage("STATUS_COMMISSION_PROCESSING");
        when(rbspClient.commissionGet(any(), any()))
                .thenReturn(new Response<>(metaData, BigDecimal.valueOf(500L)));
        when(productService.getAccountBalance(any(), any()))
                .thenReturn(BigDecimal.valueOf(500L));

        Assertions.assertThrows(ClarificationValidationException.class,
            () ->  clarificationService.commissionGet("organizationId", "operationUid", "payerAccount20", "dboProId"));
    }

    @Test
    void commissionGetMaxCount() {
        ResponseMetaData metaData = new ResponseMetaData();
        metaData.setStatus(200);
        metaData.setMessage("MAX_COUNT");
        when(rbspClient.commissionGet(any(), any()))
                .thenReturn(new Response<>(metaData, BigDecimal.valueOf(500L)));
        when(productService.getAccountBalance(any(), any()))
                .thenReturn(BigDecimal.valueOf(500L));

        Assertions.assertThrows(ClarificationValidationException.class,
            () ->  clarificationService.commissionGet("organizationId", "operationUid", "payerAccount20", "dboProId"));
    }

    @Test
    void commissionGetBankInfoException() {
        ResponseMetaData metaData = new ResponseMetaData();
        metaData.setStatus(500);
        when(rbspClient.commissionGet(any(), any()))
                .thenReturn(new Response<>(metaData, BigDecimal.valueOf(500L)));
        when(productService.getAccountBalance(any(), any()))
                .thenReturn(BigDecimal.valueOf(500L));

        Assertions.assertThrows(BankInfoException.class,
            () ->  clarificationService.commissionGet("organizationId", "operationUid", "payerAccount20", "dboProId"));

    }
}