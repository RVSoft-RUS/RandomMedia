package ru.rosbank.paymentapi.services.validator;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.notificationapp.api.NotificationAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class PayrollPaymentValidatorsTest extends BaseTest {

    @Autowired
    private PayrollPaymentValidators payrollPaymentValidators;
    @MockBean
    private AccountAppApiClient accountAppApiClient;
    @MockBean
    private NotificationAppApiClient notificationAppApi;

    @Test
    void validateOk() throws ValidationPaymentException {
        when(accountAppApiClient.idGet(anyString())).thenReturn(ResponseEntity.ok(new AccountDTO().accountType("CE")));
        when(notificationAppApi.dfmblockGet(anyString(), anyString())).thenReturn(ResponseEntity.ok(false));
        var documentDTO = new DocumentDTO()
                .amount("10000")
                .bisId(new BisIdDTO().id("id").branch("R19"))
                .kbk("kbk")
                .oktmo("oktmo")
                .status(DocumentStatusDTO.CREATED)
                .codeTypeIncome("0")
                .taxPeriod("tax")
                .typeTaxPayment("0")
                .type(DocumentDTO.TypeEnum.DA)
                .purpose("заработная плата")
                .number("1")
                .uin("0")
                .paymentPriority("5")
                .payee(new RequisiteDTO().account("account")
                        .inn("6831242360")
                        .kpp("582301383")
                        .name("name")
                        .account("40802810696430000396")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("30101810000000000256")))
                .payer(new RequisiteDTO()
                        .account("12345678900987654321")
                        .inn("6831242360")
                        .kpp("582301383")
                        .name("name")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("30101810000000000256")));

        payrollPaymentValidators.validate(documentDTO);

    }

    @Test
    void validate() {

        DocumentDTO documentDTO = new DocumentDTO();
        documentDTO.setPayer(new RequisiteDTO().name("Плательщик"));

        documentDTO.setPurpose("зп");

        Assertions.assertThrows(ValidationPaymentException.class, () ->
                payrollPaymentValidators.validate(documentDTO));

    }

    @Test
    void validatePurpose() {
        DocumentDTO documentDTO = new DocumentDTO();
        documentDTO.setPayer(new RequisiteDTO());
        documentDTO.setPurpose("зп");

        Assertions.assertThrows(ValidationPaymentException.class, () ->
                payrollPaymentValidators.validate(documentDTO));
    }

    @Test
    void validatePayerName() {
        DocumentDTO documentDTO = new DocumentDTO();
        documentDTO.setPayer(new RequisiteDTO());
        documentDTO.setPurpose("зп");

        Assertions.assertThrows(ValidationPaymentException.class, () ->
                payrollPaymentValidators.validate(documentDTO));
    }

}