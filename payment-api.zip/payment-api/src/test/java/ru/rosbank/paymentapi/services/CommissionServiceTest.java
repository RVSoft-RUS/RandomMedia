package ru.rosbank.paymentapi.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.paymentapi.services.validator.CommissionPaymentValidators;
import ru.rosbank.paymentapi.util.OrganizationAcc;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.TariffDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.AmountDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.CommissionWarning;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.PaymentCommission;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class CommissionServiceTest extends BaseTest {
    @Autowired
    private CommissionService commissionService;
    @MockBean
    private OrganizationService organizationService;
    @MockBean
    private PaymentAppApi paymentAppApi;
    @MockBean
    private CommissionPaymentValidators validators;
    @MockBean
    ProductService productService;

    @Test
    void getPaymentCommission() {
        init();
        when(paymentAppApi.documentCommissionCalculationPost(any())).thenReturn(
                new ResponseEntity<>(getAmountDTO(), HttpStatus.OK));
        commissionService.commissionEnabled = true;
        PaymentCommission paymentCommission = commissionService.getPaymentCommission(getPayment(), "dboProId");
        Assertions.assertEquals(new BigDecimal("1000.00"), paymentCommission.getCommission().getSum());
    }

    @Test
    void getPaymentCommissionWarning() {
        init();
        when(paymentAppApi.documentCommissionCalculationPost(any())).thenReturn(
                new ResponseEntity<>(getAmountDTO(), HttpStatus.OK));
        commissionService.commissionEnabled = true;
        PaymentCommission paymentCommission = commissionService.getPaymentCommission(getPayment(), "dboProId");
        Assertions.assertEquals(new BigDecimal("1000.00"), paymentCommission.getCommission().getSum());
    }

    @Test
    void getPaymentCommissionException() {
        init();
        when(paymentAppApi.documentCommissionCalculationPost(any())).thenThrow(
                new RuntimeException());
        commissionService.commissionEnabled = true;
        PaymentCommission paymentCommission = commissionService.getPaymentCommission(getPayment(), "dboProId");
        Assertions.assertEquals(CommissionWarning.TypeEnum.ERROR, paymentCommission.getWarning().getType());
    }

    @Test
    void getPaymentCommissionExceptionNull() {

        when(productService.getOrganizationAccByAccNumberAndDboProId(any(String.class), any(String.class)))
                .thenReturn(null);
        when(paymentAppApi.documentCommissionCalculationPost(any())).thenThrow(
                new RuntimeException());
        commissionService.commissionEnabled = true;
        Assertions.assertThrows(ValidationPaymentException.class, () -> commissionService.getPaymentCommission(getPayment(),
                "dboProId"));

        when(productService.getOrganizationAccByAccNumberAndDboProId(any(String.class), any(String.class)))
                .thenReturn(new OrganizationAcc());
        Assertions.assertThrows(ValidationPaymentException.class, () -> commissionService.getPaymentCommission(getPayment(),
                "dboProId"));

    }

    @Test
    void getPaymentCommissionDisable() {
        init();
        when(paymentAppApi.documentCommissionCalculationPost(any())).thenThrow(
                new RuntimeException());
        commissionService.commissionEnabled = false;
        PaymentCommission paymentCommission = commissionService.getPaymentCommission(getPayment(), "dboProId");
        Assertions.assertEquals(CommissionWarning.TypeEnum.INFO, paymentCommission.getWarning().getType());
    }

    @Test
    void getPaymentCommissionTariffConstructor() {
        init();
        String bisId = "bisId";
        String bisBranch = "bisBranch";
        String orgId = "orgId";
        Payment payment = getPayment();
        payment.setOrganizationId(orgId);

        when(organizationService.getTariff(bisId, bisBranch, orgId))
                .thenReturn(new TariffDTO()
                        .bisId(new ru.rosbank.platform.client.organizationapp.model.BisIdDTO()
                                .tariff("CR2")));

        PaymentCommission paymentCommission = commissionService.getPaymentCommission(payment, "dboProId");
        org.assertj.core.api.Assertions.assertThat(paymentCommission.getCommission())
                .isNull();
    }

    private Payment getPayment() {
        return new Payment().payer(new Requisite().account("01234567890123456789")).amount(new Amount()
                .sum(new BigDecimal("1000.00")));
    }

    private AmountDTO getAmountDTO() {
        return new AmountDTO()
                .sum(new BigDecimal("1000.00"));

    }

    private void init() {

        AccountDTO accountDTO = new AccountDTO()
                .number("01234567890123456789")
                .restAmount("1000.00")
                .bisId(new BisIdDTO()
                        .id("bisId")
                        .branch("bisBranch"));
        OrganizationAcc orgAcc = new OrganizationAcc();
        orgAcc.setAccounts(Collections.singletonList(accountDTO));
        when(productService.getOrganizationAccByAccNumberAndDboProId(any(String.class), any(String.class)))
                .thenReturn(orgAcc);

    }
}