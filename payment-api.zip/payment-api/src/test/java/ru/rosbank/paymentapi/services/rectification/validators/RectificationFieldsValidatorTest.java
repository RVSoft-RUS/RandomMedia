package ru.rosbank.paymentapi.services.rectification.validators;

import static org.mockito.ArgumentMatchers.any;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.fileapp.api.FileAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.CurrencyControlDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.FileInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

class RectificationFieldsValidatorTest extends BaseTest {

    @Autowired
    RectificationFieldsValidator rectificationFieldsValidator;
    @Autowired
    DocumentToPaymentConverter documentToPaymentConverter;
    @MockBean
    private FileAppApiClient fileAppApiClient;
    @MockBean
    AccountService accountService;
    @MockBean
    ReferenceService referenceService;

    @Test
    void validateException() {
        Mockito.when(fileAppApiClient.fileIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(new ru.rosbank.platform.client.fileapp.model.FileInfoDTO()
                        .size("size"), HttpStatus.OK));
        Mockito.when(accountService.getAccount(any())).thenReturn(getAccountDTO());
        Mockito.when(referenceService.getBranch(any())).thenReturn(Collections.singletonList(getBranchDTO()));
        DocumentDTO documentDTO = getDocumentDTO();
        Rectification rectification = RectificationFieldsValidator.getRectificationFieldFromDocument(documentDTO);
        Assertions.assertThrows(ValidationException.class, () ->
                rectificationFieldsValidator.validate(rectification, documentToPaymentConverter.convert(documentDTO),
                        getAccountDTO()));
    }

    @Test
    void validate() {
        Mockito.when(fileAppApiClient.fileIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(new ru.rosbank.platform.client.fileapp.model.FileInfoDTO()
                        .size("size"), HttpStatus.OK));
        Mockito.when(accountService.getAccount(any())).thenReturn(getAccountDTO());
        Mockito.when(referenceService.getBranch(any())).thenReturn(Collections.singletonList(getBranchDTO()));
        DocumentDTO documentDTO = getDocumentDTO();
        Rectification rectification = RectificationFieldsValidator.getRectificationFieldFromDocument(documentDTO);
        rectification.setPurpose("Purpose new");
        rectificationFieldsValidator.validate(rectification, documentToPaymentConverter.convert(documentDTO), getAccountDTO());
    }

    @Test
    void validateUin() {
        Mockito.when(fileAppApiClient.fileIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(new ru.rosbank.platform.client.fileapp.model.FileInfoDTO()
                        .size("size"), HttpStatus.OK));
        Mockito.when(accountService.getAccount(any())).thenReturn(getAccountDTO());
        Mockito.when(referenceService.getBranch(any())).thenReturn(Collections.singletonList(getBranchDTO()));
        DocumentDTO documentDTO = getDocumentDTO();
        Rectification rectification = RectificationFieldsValidator.getRectificationFieldFromDocument(documentDTO);
        rectification.setUin("Uin new");
        rectificationFieldsValidator.validate(rectification, documentToPaymentConverter.convert(documentDTO), getAccountDTO());
    }

    @Test
    void updateDocumentField() throws Exception {
        DocumentDTO doc = getDocumentDTO();
        RectificationFieldsValidator.updateDocumentField("payeeName", doc, "field");
        RectificationFieldsValidator.updateDocumentField("payeeAccount", doc, "field");
        RectificationFieldsValidator.updateDocumentField("payeeInn", doc, "field");
        RectificationFieldsValidator.updateDocumentField("payeeKpp", doc, "field");
        RectificationFieldsValidator.updateDocumentField("purpose", doc, "field");
        RectificationFieldsValidator.updateDocumentField("kbk", doc, "field");
        RectificationFieldsValidator.updateDocumentField("oktmo", doc, "field");
        RectificationFieldsValidator.updateDocumentField("paymentBasis", doc, "field");
        RectificationFieldsValidator.updateDocumentField("taxPeriod", doc, "field");
        RectificationFieldsValidator.updateDocumentField("basisDocumentNumber", doc, "field");
        RectificationFieldsValidator.updateDocumentField("basisDocumentCreated", doc, "field");

        Assertions.assertEquals("field", doc.getPayee().getName());
        Assertions.assertEquals("field", doc.getPayee().getAccount());
        Assertions.assertEquals("field", doc.getPayee().getInn());
        Assertions.assertEquals("field", doc.getPayee().getKpp());
        Assertions.assertEquals("field", doc.getPurpose());
        Assertions.assertEquals("field", doc.getKbk());
        Assertions.assertEquals("field", doc.getOktmo());
        Assertions.assertEquals("field", doc.getPaymentBasis());
        Assertions.assertEquals("field", doc.getTaxPeriod());
        Assertions.assertEquals("field", doc.getBasisDocumentNumber());
        Assertions.assertEquals("field", doc.getBasisDocumentCreated());
    }

    @Test
    void getRectificationFieldFromDocument() {

        Rectification  rectification = RectificationFieldsValidator.getRectificationFieldFromDocument(getDocumentDTO());
        Assertions.assertEquals("name", rectification.getPayeeName());
        Assertions.assertEquals("account", rectification.getPayeeAccount());
        Assertions.assertEquals("inn", rectification.getPayeeInn());
        Assertions.assertEquals("kpp", rectification.getPayeeKpp());
        Assertions.assertEquals("purpose", rectification.getPurpose());
        Assertions.assertEquals("kbk", rectification.getKbk());
        Assertions.assertEquals("oktmo", rectification.getOktmo());
        Assertions.assertEquals("paymentBasis", rectification.getPaymentBasis());
        Assertions.assertEquals("taxPeriod", rectification.getTaxPeriod());
        Assertions.assertEquals("basisDocumentNumber", rectification.getBasisDocumentNumber());
        Assertions.assertEquals("basisDocumentCreated", rectification.getBasisDocumentCreated());

    }

    BranchDTO getBranchDTO() {
        ru.rosbank.platform.client.referenceapp.model.BranchDTO branchDTO = new BranchDTO();
        branchDTO.setBik("bic");
        branchDTO.setCode("code");
        branchDTO.setName("name");
        branchDTO.setCorrespondentAccount("corrAcc");
        return branchDTO;
    }

    DocumentDTO getDocumentDTO() {
        BankInfoDTO bankInfoDTO = new BankInfoDTO();
        bankInfoDTO.setBic("bic");
        bankInfoDTO.setName("name");
        bankInfoDTO.setCorrespondentAccount("corrAcc");
        DocumentDTO documentDTO = new DocumentDTO()
                .id(1)
                .amount("123")
                .status(DocumentStatusDTO.CREATED)
                .type(DocumentDTO.TypeEnum.CD)
                .showError(true)
                .typeTaxPayment("typeTax")
                .executionDate(OffsetDateTime.now())
                .payer(new RequisiteDTO().bank(bankInfoDTO.bic("bic")).account("account"))
                .payee(new RequisiteDTO().bank(bankInfoDTO.bic("bic")).account("account").name("name").inn("inn")
                        .kpp("kpp"))
                .currencyControl(new CurrencyControlDTO()
                        .fullName("fullName")
                        .addFileInfoItem(new FileInfoDTO()
                                .id("777")))
                .purpose("purpose").kbk("kbk").oktmo("oktmo").paymentBasis("paymentBasis").taxPeriod("taxPeriod")
                .basisDocumentNumber("basisDocumentNumber").basisDocumentCreated("basisDocumentCreated");
        return documentDTO;
    }

    private AccountDTO getAccountDTO() {
        return new AccountDTO()
                .number("40802810597880000207")
                .accountType("CA")
                .currency("RUB")
                .hasRestrictions(true)
                .openDate(LocalDate.now())
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                        .id("123")
                        .branch("R19"))
                .restAmount("5000.00");
    }
}