package ru.rosbank.paymentapi.converter;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.referenceapi.model.BankDTO;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;



public class DocumentToPaymentConverterExceptionTest extends BaseTest {

    @MockBean
    AccountService accountService;
    @MockBean
    ReferenceService referenceService;
    @Autowired
    private DocumentToPaymentConverter documentToPaymentConverter;

    @Test
    void convert() {
        DocumentDTO documentDTO = new DocumentDTO();
        documentDTO.setPayerStatus("01");
        Mockito.when(accountService.getAccount(any())).thenThrow(BankInfoException.class);
        Payment payment = new Payment();
        Requisite requisite = new Requisite();
        requisite.setBank(new BankInfo());
        payment.setPayer(requisite);
        Assertions.assertThrows(BankInfoException.class, () -> {
            documentToPaymentConverter.convertBack(payment, getAccountDTO());
        });
    }

    private AccountDTO getAccountDTO() {
        BankDTO bankDTO = new BankDTO();
        bankDTO.setBic("bic");
        bankDTO.setName("name");
        bankDTO.setCorrespondentAccount("accaunt");
        BisIdDTO bisIdDTO = new BisIdDTO();
        bisIdDTO.setBranch("R19");
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setBisId(bisIdDTO);
        return accountDTO;
    }
}
