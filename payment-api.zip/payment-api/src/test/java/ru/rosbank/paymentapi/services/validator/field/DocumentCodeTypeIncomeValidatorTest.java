package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentCodeTypeIncomeValidator;

public class DocumentCodeTypeIncomeValidatorTest extends BaseTest {
    @Autowired
    DocumentCodeTypeIncomeValidator validator;

    @Test
    void validate() {
        DocumentDTO document = new DocumentDTO();
        document.setCodeTypeIncome("0");
        document.setType(DocumentDTO.TypeEnum.DE);
        validator.validate(document);
        document.setCodeTypeIncome(null);
        document.setType(DocumentDTO.TypeEnum.DE);
        validator.validate(document);
        document.setCodeTypeIncome("1");
        document.setType(DocumentDTO.TypeEnum.DC);
        validator.validate(document);
    }

    @Test
    void validateThrows() {
        DocumentDTO document = new DocumentDTO();
        document.setCodeTypeIncome("1");
        document.setType(DocumentDTO.TypeEnum.DE);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }
}
