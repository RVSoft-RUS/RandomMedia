package ru.rosbank.paymentapi.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.mapper.PaymentEventMapper;
import ru.rosbank.platform.client.auditapp.api.AuditAppApi;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.client.auditapp.model.PaymentEventDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.userapp.api.UserAppApi;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

class AuditServiceTest extends BaseTest {

    @Autowired
    AuditService auditService;

    @MockBean
    AuditAppApi auditAppApi;
    @MockBean
    PaymentEventMapper paymentEventMapper;
    @MockBean
    UserAppApi userAppApi;

    @Test
    void sendEvent() {
        auditService.sendEvent(new EventDTO());
    }

    @Test
    void logPaymentEvent() {
        when(paymentEventMapper.toPaymentEvent(any()))
                .thenReturn(new PaymentEventDTO());
        when(userAppApi.userGetByDboProId(any())).thenReturn(new ResponseEntity<>(new ClientDTO().fio("fio"), HttpStatus.OK));

        auditService.logPaymentEvent(new DocumentDTO(), "dboProId", PaymentEventDTO.EventEnum.SIGN);
        verify(auditAppApi, Mockito.atMostOnce()).paymentEventPost(any());
    }
}