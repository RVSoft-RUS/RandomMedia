package ru.rosbank.paymentapi.services.validator;

import java.math.BigDecimal;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.paymentapi.services.validator.field.DocumentAmountValidator;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

/**
 * Summary.
 *
 * @author rb068774
 */
class DocumentAmountValidatorTest {
    private final DocumentAmountValidator documentAmountValidator = new DocumentAmountValidator();

    @Test
    void validate() {
        DocumentDTO document = new DocumentDTO();
        document.setAmount(String.valueOf(BigDecimal.ONE));
        documentAmountValidator.validate(document);
    }

    @Test
    void validateException() {
        DocumentDTO document = new DocumentDTO();

        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentAmountValidator.validate(document));
    }

}