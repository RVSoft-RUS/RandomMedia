package ru.rosbank.paymentapi.services.documents;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TextFilterTest {

    @Test
    void containsText() {
        Assertions.assertTrue(TextFilter.containsText("asdfghTest", "TEST"));
        Assertions.assertTrue(TextFilter.containsText("0123456789", "01234"));
        Assertions.assertFalse(TextFilter.containsText("asdfghTes", "TEST"));
        Assertions.assertFalse(TextFilter.containsText("0123456789", "061234"));
        Assertions.assertTrue(TextFilter.containsText(null, "01234"));
        Assertions.assertTrue(TextFilter.containsText("01234", null));
    }
}