package ru.rosbank.paymentapi.api;

import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

public class MyRequestFactory {

    public static MockHttpServletRequestBuilder myFactoryRequestPost(String url) {
        return MockMvcRequestBuilders.post(url)
                .header("ip", "10.10.10.10")
                .header("device-id", "device-id")
                .header("os", "OS")
                .header("macaddress", "MAC12345")
                .header("session-id", "session12345")
                .header("User-Agent", "Mozilla")
                .header("app-version", "app12345");
    }

}
