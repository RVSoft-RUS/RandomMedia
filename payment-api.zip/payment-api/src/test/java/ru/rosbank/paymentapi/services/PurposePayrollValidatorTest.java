package ru.rosbank.paymentapi.services;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.field.PurposePayrollValidator;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class PurposePayrollValidatorTest extends BaseTest {

    @Autowired
    private PurposePayrollValidator purposePayrollValidator;

    @Test
    void isPayrollPurpose() throws ValidationPaymentException {

        purposePayrollValidator.validate(new DocumentDTO().purpose("Перечисление зп"));
        purposePayrollValidator.validate(new DocumentDTO().purpose("Перечисление ЗП"));

    }

    @Test
    void isNotPayrollPurpose() {

        Assertions.assertThrows(ValidationPaymentException.class,
            () -> purposePayrollValidator.validate(new DocumentDTO().purpose("Тест")));

    }

}
