package ru.rosbank.paymentapi.services.validator;

import static org.mockito.ArgumentMatchers.any;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.field.DfmBlockValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.notificationapp.api.NotificationAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class DfmBlockValidatorTest extends BaseTest {

    @Autowired
    private DfmBlockValidator dfmBlockValidator;
    @MockBean
    private NotificationAppApiClient notificationAppApi;


    @Before
    public void setUp() {
        Mockito.when(notificationAppApi.dfmblockGet(any(), any())).thenReturn(new ResponseEntity<>(true, HttpStatus.OK));
    }

    @Test
    void validateDE() {
        DocumentDTO document = new DocumentDTO()
                .bisId(new BisIdDTO().id("1").branch("R19"))
                .type(DocumentDTO.TypeEnum.DE)
                .payee(new RequisiteDTO()
                        .inn("12345")
                        .account("123456"))
                .payer(new RequisiteDTO()
                        .inn("54321")
                        .account("654321"));
        AccountDTO accountDTO = new AccountDTO().number("654321").accountType("TEST");

        dfmBlockValidator.validate(document, Collections.singletonMap("654321", accountDTO));
    }

    @Test
    void validateYourselfCA() {
        AccountDTO accountDTO = new AccountDTO().number("123457").accountType("CA");

        dfmBlockValidator.validate(getYourselfDocument(), Collections.singletonMap("123457", accountDTO));
    }

    @Test
    void validateYourselfC5() {
        AccountDTO accountDTO = new AccountDTO().number("123457").accountType("C5");

        dfmBlockValidator.validate(getYourselfDocument(), Collections.singletonMap("123457", accountDTO));
    }

    @Test
    void validateYourselfC6() {
        AccountDTO accountDTO = new AccountDTO().number("123457").accountType("C6");

        dfmBlockValidator.validate(getYourselfDocument(), Collections.singletonMap("123457", accountDTO));
    }

    @Test
    void validateYourselfC1() {
        AccountDTO accountDTO = new AccountDTO().number("123457").accountType("C1");

        dfmBlockValidator.validate(getYourselfDocument(), Collections.singletonMap("123457", accountDTO));
    }

    @Test
    void validateFail() {
        DocumentDTO document = new DocumentDTO()
                .bisId(new BisIdDTO().id("1").branch("R19"))
                .type(DocumentDTO.TypeEnum.CE)
                .payee(new RequisiteDTO()
                        .inn("12345")
                        .account("123456"))
                .payer(new RequisiteDTO()
                        .inn("54321")
                        .account("654321"));

        AccountDTO accountDTO = new AccountDTO().number("654321").accountType("C6");


        Assertions.assertThrows(ValidationPaymentException.class, () -> dfmBlockValidator.validate(document,
                Collections.singletonMap("654321", accountDTO)));

    }

    private DocumentDTO getYourselfDocument() {
        return new DocumentDTO()
                .bisId(new BisIdDTO().id("1").branch("R19"))
                .type(DocumentDTO.TypeEnum.CE)
                .payee(new RequisiteDTO()
                        .inn("12345")
                        .account("123456"))
                .payer(new RequisiteDTO()
                        .inn("12345")
                        .account("123457"));
    }

    @Test
    void validate() {
        dfmBlockValidator.validate(getDocuments(), Collections.singletonMap("01234567890123456789", new AccountDTO()
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("BisId").branch("R19"))
                .accountType("CA").number("01234567890123456789")));
    }

    @Test
    void testValidate() {

        dfmBlockValidator.validate(getDocuments(), Collections.singletonMap("01234567890123456789", new AccountDTO()
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("BisId").branch("R19"))
                .number("01234567890123456789")));
    }

    List<DocumentDTO> getDocuments() {
        DocumentDTO document = new DocumentDTO();
        document.setBisId(new BisIdDTO().id("BisId").branch("R19"));
        document.setType(DocumentDTO.TypeEnum.DE);
        document.setBasisDocumentNumber("0");
        document.setPayerStatus("31");
        document.setPayer(new RequisiteDTO().account("01234567890123456789"));
        document.setPayee(new RequisiteDTO().account("01234567890123456789"));
        DocumentDTO document2 = new DocumentDTO();
        document2.setBisId(new BisIdDTO().id("BisId2").branch("R19"));
        document2.setType(DocumentDTO.TypeEnum.DE);
        document2.setBasisDocumentNumber("0");
        document2.setPayerStatus("31");
        document2.setPayer(new RequisiteDTO().account("01234567890123456789"));
        document2.setPayee(new RequisiteDTO().account("01234567890123456789"));
        return Arrays.asList(document, document, document, document2);
    }
}