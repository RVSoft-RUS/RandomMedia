package ru.rosbank.paymentapi.services;

import freemarker.template.TemplateException;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.reporting.PaymentFormService;
import ru.rosbank.paymentapi.services.reporting.StatementFormService;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;

public class FormsServicesTest extends BaseTest {

    @Autowired
    PaymentFormService paymentFormService;
    @Autowired
    StatementFormService statementFormService;

    @Test
    public void testPayment() throws IOException, TemplateException {
        DocumentDTO documentDTO = new DocumentDTO()
                .amount("10000")
                .kbk("kbk")
                .status(DocumentStatusDTO.COMPLETED)
                .payee(new RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .payer(new RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")));
        paymentFormService.generatePdfForm(documentDTO,  "paymentAssignment.html.ftl");
        paymentFormService.generatePdfForm(documentDTO,  "paymentAssignmentWithComment.html.ftl");
    }

    @Test
    public void testStatement() throws IOException, TemplateException {
        PaymentDTO paymentDTO = new PaymentDTO()
                .amount(new AmountDTO().sum(BigDecimal.ONE))
                .kbk("kbk")
                .completed(OffsetDateTime.now())
                .payee(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .payer(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .processedBy(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO().correspondentAccount("coraccount")
                        .bic("bic")
                        .name("name"));
        statementFormService.generatePdfForm(paymentDTO,  "paymentAssignment.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "paymentOrder.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "paymentRequestCredit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "paymentRequestDebit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "bankingOrder.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "cardOperation.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "collectionOrderCredit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "collectionOrderDebit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "memorialOrder.html.ftl");
    }

    @Test
    public void testStatementProcessedByNull() throws IOException, TemplateException {
        PaymentDTO paymentDTO = new PaymentDTO()
                .amount(new AmountDTO().sum(BigDecimal.ONE))
                .kbk("kbk")
                .completed(OffsetDateTime.now())
                .payee(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .payer(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .processedBy(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO());
        statementFormService.generatePdfForm(paymentDTO,  "paymentAssignment.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "paymentOrder.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "paymentRequestCredit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "paymentRequestDebit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "bankingOrder.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "cardOperation.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "collectionOrderCredit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "collectionOrderDebit.html.ftl");
        statementFormService.generatePdfForm(paymentDTO,  "memorialOrder.html.ftl");
    }
}
