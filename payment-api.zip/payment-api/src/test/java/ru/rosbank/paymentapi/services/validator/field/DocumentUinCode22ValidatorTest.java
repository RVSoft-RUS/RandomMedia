package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentUinCode22Validator;

class DocumentUinCode22ValidatorTest   extends BaseTest {

    @MockBean
    DocumentTypeCalculatorImpl documentTypeCalculator;

    @Test
    void validateException() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setUin("0");
        document.setPayee(new RequisiteDTO());
        document.getPayee().setAccount("03212012340123456789");
        DocumentUinCode22Validator validator = new DocumentUinCode22Validator(documentTypeCalculator);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }

    @Test
    void validate() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setUin("0");
        document.setPayee(new RequisiteDTO());
        document.getPayee().setAccount("03213012340123456789");
        DocumentUinCode22Validator validator = new DocumentUinCode22Validator(documentTypeCalculator);
        validator.validate(document);
    }
}