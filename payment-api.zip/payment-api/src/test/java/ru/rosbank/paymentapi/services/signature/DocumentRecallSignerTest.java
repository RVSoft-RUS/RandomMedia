package ru.rosbank.paymentapi.services.signature;

import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

class DocumentRecallSignerTest extends BaseTest {

    @Autowired
    DocumentRecallSigner documentRecallSigner;

    @Test
    void buildSubject() {
        var result = documentRecallSigner.buildSubjects(Collections.singletonList(new DocumentDTO().id(1).amount("100")));
        Assertions.assertNotNull(result);
    }
}