package ru.rosbank.paymentapi.services.signature;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SubjectDTO;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

class RectificationSignerTest extends BaseTest {
    @Autowired
    RectificationSigner rectificationSigner;
    @MockBean
    CryptoproAppApi cryptoproAppApi;

    @Test
    void buildSubject() {
        rectificationSigner.rbspEnabled = false;
        SubjectDTO subjectDTO = rectificationSigner.buildSubject(new Rectification().id(1L));
        Assertions.assertEquals(subjectDTO.getReference().getType(), "DOCUMENT_RECTIFICATION");
    }

    @Test
    void buildSubjectClr() {
        rectificationSigner.rbspEnabled = true;
        SubjectDTO subjectDTO = rectificationSigner.buildSubject(new Rectification().id(1L));
        Assertions.assertEquals(subjectDTO.getReference().getType(), "DOCUMENT_CLARIFICATION");
    }

    @Test
    void isRectificationRequestSigned() {
        when(cryptoproAppApi.signatureGet(any(), any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new SignatureDTO().confirmed(true)),
                        HttpStatus.OK));
        Assertions.assertTrue(rectificationSigner.isRectificationRequestSigned("1"));
    }
}