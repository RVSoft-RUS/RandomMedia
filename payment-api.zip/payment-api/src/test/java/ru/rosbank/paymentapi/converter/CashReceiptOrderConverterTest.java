package ru.rosbank.paymentapi.converter;


import org.junit.Assert;
import org.junit.jupiter.api.Test;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

class CashReceiptOrderConverterTest {

    @Test
    void convert() {
        PaymentDTO paymentDTO = new PaymentDTO().content("content");
        Payment payment = CashReceiptOrderConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getContent(), payment.getContent());
    }
}