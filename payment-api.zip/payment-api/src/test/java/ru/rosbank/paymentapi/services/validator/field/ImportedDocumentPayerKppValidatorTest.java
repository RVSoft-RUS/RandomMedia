package ru.rosbank.paymentapi.services.validator.field;

import static org.mockito.ArgumentMatchers.any;

import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;


class ImportedDocumentPayerKppValidatorTest  extends BaseTest {

    @Autowired
    private ImportedDocumentPayerKppValidator documentPayerKppValidator;
    @MockBean
    OrganizationService organizationService;
    private DocumentDTO document;

    @Test
    public void getKpp() {
        document = new DocumentDTO();
        document.setPayer(new RequisiteDTO());
        document.getPayer().setInn("1234567890");
        document.getPayer().setKpp("123456789");
        OrganizationDTO org = new OrganizationDTO().crmId("1");
        org.setInn(document.getPayer().getInn());
        org.setKpp(document.getPayer().getKpp());
        org.addBisIdsItem(new BisIdDTO().id("892363").branch("R19"));
        Mockito.when(organizationService.getOrganizations(any())).thenReturn(Collections.singletonList(org));

        String kpp = documentPayerKppValidator.getKpp(document.getPayer().getInn(), "client");
        Assertions.assertEquals(document.getPayer().getKpp(), kpp);
    }



    @Test
    public void getKpException() {
        document = new DocumentDTO();
        document.setPayer(new RequisiteDTO());
        document.getPayer().setKpp("123456789");
        OrganizationDTO org = new OrganizationDTO().crmId("1");
        org.setInn(document.getPayer().getInn());
        org.setKpp(document.getPayer().getKpp());
        org.addBisIdsItem(new BisIdDTO().id("892363").branch("R19"));

        Assertions.assertThrows(ValidationException.class,
            () -> documentPayerKppValidator.getKpp(document.getPayer().getInn(), "client"));

    }

    @Test
    public void testSuccessImportedDoc() {
        document = new DocumentDTO();
        document.setPayer(new RequisiteDTO());
        document.getPayer().setInn("1234567890");
        OrganizationDTO org = new OrganizationDTO().crmId("1");
        org.setInn(document.getPayer().getInn());
        org.setKpp("123456789");
        org.addBisIdsItem(new BisIdDTO().id("892363").branch("R19"));
        Mockito.when(organizationService.getOrganizations(any())).thenReturn(Collections.singletonList(org));

        documentPayerKppValidator.validate(document, "client");
    }

    @Test
    public void testSuccessImportedDoc2() {
        document = new DocumentDTO();
        document.setPayer(new RequisiteDTO());
        document.getPayer().setInn("1234567890");
        document.getPayer().setKpp("123456789");
        OrganizationDTO org = new OrganizationDTO().crmId("1");
        org.setInn(document.getPayer().getInn());
        org.setKpp(document.getPayer().getKpp());
        org.addBisIdsItem(new BisIdDTO().id("892363").branch("R19"));
        Mockito.when(organizationService.getOrganizations(any())).thenReturn(Collections.singletonList(org));

        Mockito.when(organizationService.getOrganizations(any())).thenReturn(Collections.singletonList(org));

        documentPayerKppValidator.validate(document, "client");
    }

    @Test
    public void testSuccess3() {
        document = new DocumentDTO();
        document.setPayer(new RequisiteDTO());
        document.getPayer().setInn("123456789012");
        document.getPayer().setKpp("0");

        documentPayerKppValidator.validate(document, "client");
    }

}