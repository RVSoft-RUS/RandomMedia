package ru.rosbank.paymentapi.converter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.referenceapi.model.BankDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

class DocumentToPaymentConverterTest extends BaseTest {

    @Autowired
    private DocumentToPaymentConverter documentToPaymentConverter;

    @Test
    void convert() {

        var documentDTO = new DocumentDTO();
        documentDTO.setPayerStatus("01");
        Payment payment = documentToPaymentConverter.convert(documentDTO);
        Assertions.assertEquals(documentDTO.getPayerStatus(), payment.getPayerStatus());

    }

    @Test
    void  convertBack() {
        DocumentDTO documentDTO = new DocumentDTO();
        documentDTO.setPayerStatus("01");
        Payment payment = documentToPaymentConverter.convert(documentDTO);
        documentToPaymentConverter.convertBack(payment, getAccountDTO());

    }

    private AccountDTO getAccountDTO() {
        BankDTO bankDTO = new BankDTO();
        bankDTO.setBic("bic");
        bankDTO.setName("name");
        bankDTO.setCorrespondentAccount("accaunt");
        BisIdDTO bisIdDTO = new BisIdDTO();
        bisIdDTO.setBranch("R19");
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setBisId(bisIdDTO);
        return accountDTO;
    }
}
