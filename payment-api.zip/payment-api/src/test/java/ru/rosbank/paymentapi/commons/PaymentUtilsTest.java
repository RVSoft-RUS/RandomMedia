package ru.rosbank.paymentapi.commons;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

class PaymentUtilsTest {

    @Test
    void getPayeeAccount() {
        String account = PaymentUtils.getPayeeAccount(new DocumentDTO()
                .payee(new RequisiteDTO()
                        .account("account")));
        Assert.assertEquals(account, "account");
    }

    @Test
    void testGetPayeeAccount() {
        String account = PaymentUtils.getPayeeAccount(new Payment()
                .payee(new Requisite()
                        .account("account")));
        Assert.assertEquals(account, "account");
    }

    @Test
    void getPayeeBankBic() {
        String bic = PaymentUtils.getPayeeBankBic(new DocumentDTO()
                .payee(new RequisiteDTO()
                        .bank(new BankInfoDTO()
                                .bic("bic"))));
        Assert.assertEquals(bic, "bic");
    }

    @Test
    void testGetPayeeBankBic() {
        String bic = PaymentUtils.getPayeeBankBic(new Payment()
                .payee(new Requisite()
                        .bank(new BankInfo()
                                .bic("bic"))));
        Assert.assertEquals(bic, "bic");
    }

    @Test
    void getPayeeBankCorrespondentAccount() {
        String corr = PaymentUtils.getPayeeBankCorrespondentAccount(new DocumentDTO()
                .payee(new RequisiteDTO()
                        .bank(new BankInfoDTO()
                                .correspondentAccount("corr"))));
        Assert.assertEquals(corr, "corr");
    }

    @Test
    void formatPaymentPriority() {
        String formatPaymentPriority = PaymentUtils.formatPaymentPriority("00001");
        Assert.assertEquals(formatPaymentPriority, "1");
    }

    @Test
    void isBudgetAccount() {
        Assert.assertTrue(PaymentUtils.isBudgetAccount("40503000000004000000"));

    }

    @Test
    void isBudgetBic() {
        Assert.assertTrue(PaymentUtils.isBudgetBic("001", "40204000000000000000"));
    }

    @Test
    void isDebitForType() {
        Assertions.assertFalse(PaymentUtils.isDebitForType(null));
        Assertions.assertFalse(PaymentUtils.isDebitForType(Payment.TypeEnum.CD));
        Assert.assertTrue(PaymentUtils.isDebitForType(Payment.TypeEnum.DA));
    }

    @Test
    void isDebit() {
        Assert.assertTrue(PaymentUtils.isDebit("DP"));
        Assert.assertTrue(PaymentUtils.isDebit(new PaymentDTO().type(PaymentDTO.TypeEnum.DA)));
        Assert.assertFalse(PaymentUtils.isDebit("CP"));
        Assert.assertFalse(PaymentUtils.isDebit(new PaymentDTO().type(PaymentDTO.TypeEnum.CD)));
    }
}