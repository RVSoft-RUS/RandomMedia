package ru.rosbank.paymentapi.services.validator;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.field.DocumentAmountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentExecutionDateValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankBicValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankCorrAccountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentTypeTaxPaymentValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.validators.DocumentBasisDocumentNumberValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentCodeTypeIncomeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentKbkValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentOktmoValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayPriorityValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeInnValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerAccountValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerStatusValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisCreatedValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentTaxPeriodValidator;

class CommissionPaymentValidatorsTest extends BaseTest {
    @Autowired
    private CommissionPaymentValidators commissionPaymentValidators;
    @MockBean
    private DocumentPayeeBankBicValidator documentPayeeBankBicValidator;
    @MockBean
    private DocumentPayerAccountValidator documentPayerAccountValidator;
    @MockBean
    private DocumentPaymentBasisValidator documentPaymentBasisValidator;
    @MockBean
    private DocumentPayeeBankCorrAccountValidator documentPayeeBankCorrAccountValidator;
    @MockBean
    private DocumentPayPriorityValidator documentPayPriorityValidator;
    @MockBean
    private DocumentPayeeInnValidator documentPayeeInnValidator;
    @MockBean
    private DocumentPayeeKppValidator documentPayeeKppValidator;
    @MockBean
    private DocumentAmountValidator documentAmountValidator;
    @MockBean
    private DocumentKbkValidator documentKbkValidator;
    @MockBean
    private DocumentOktmoValidator documentOktmoValidator;
    @MockBean
    private DocumentPayeeAccountValidator documentPayeeAccountValidator;
    @MockBean
    private DocumentBasisDocumentNumberValidator documentBasisDocumentNumberValidator;
    @MockBean
    private DocumentPayerStatusValidator documentPayerStatusValidator;
    @MockBean
    private DocumentTaxPeriodValidator documentTaxPeriodValidator;
    @MockBean
    private DocumentPaymentBasisCreatedValidator documentPaymentBasisCreatedValidator;
    @MockBean
    private DocumentCodeTypeIncomeValidator documentCodeTypeIncomeValidator;
    @MockBean
    private DocumentTypeTaxPaymentValidator documentTypeTaxPaymentValidator;
    @MockBean
    private DocumentExecutionDateValidator documentExecutionDateValidator;
    @MockBean
    private DocumentPackageValidator documentPackageValidator;

    @Test
    void validate() {
        DocumentDTO document = new DocumentDTO();
        document.setExecutionDate(OffsetDateTime.now().plusDays(5));
        document.setPayer(new RequisiteDTO());
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        accountsMap.put("42606810512232454567", new AccountDTO().number("42606810512232454567"));
        accountsMap.put("40108810696430000397", new AccountDTO().number("40108810696430000397").accountType("CD"));
        commissionPaymentValidators.validate(document, accountsMap);
    }

}