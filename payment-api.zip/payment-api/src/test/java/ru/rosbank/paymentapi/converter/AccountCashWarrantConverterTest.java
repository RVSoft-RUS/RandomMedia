package ru.rosbank.paymentapi.converter;


import java.math.BigDecimal;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

class AccountCashWarrantConverterTest {

    @Test
    void accountCashWarrantConverterTest() {
        PaymentDTO paymentDTO = new PaymentDTO().amount(new AmountDTO().sum(new BigDecimal("555")));
        Payment payment = AccountCashWarrantConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getAmount().getSum(), payment.getAmount().getSum());
    }

}