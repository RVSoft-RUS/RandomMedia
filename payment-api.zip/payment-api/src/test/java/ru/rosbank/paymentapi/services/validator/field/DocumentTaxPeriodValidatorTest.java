package ru.rosbank.paymentapi.services.validator.field;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentTaxPeriodValidator;

public class DocumentTaxPeriodValidatorTest extends BaseTest {

    private static final String ERROR_8_DIGITS = "При КБК = '153...' поле 'Дата налогового периода' должно содержать 8 "
            + "цифр (код таможенного органа)";

    @MockBean
    DocumentTypeCalculatorImpl typeCalculator;

    @Test
    void validateWhenKbkStartsWith153() {
        Mockito.when(typeCalculator.isBudget(Mockito.any())).thenReturn(true);
        var taxPeriodValidator = new DocumentTaxPeriodValidator(typeCalculator);
        var doc = new DocumentDTO().taxPeriod("1234567").kbk("153");
        Assertions.assertThatThrownBy(() -> taxPeriodValidator.validate(doc))
                .isInstanceOf(ValidationPaymentException.class)
                .hasMessage(ERROR_8_DIGITS);
    }
}
