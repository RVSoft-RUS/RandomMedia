package ru.rosbank.paymentapi.services;

import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApiClient;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApiClient;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

class DuplicatesServiceTest extends BaseTest {

    @Autowired
    DuplicatesService duplicatesService;

    @MockBean
    private AccountAppApiClient accountAppApiClient;
    @MockBean
    private OrganizationAppApiClient organizationAppApiClient;
    @MockBean
    private RolesAppApiClient rolesAppApiClient;
    @MockBean
    private PaymentAppApiClient paymentAppApiClient;

    @Test
    void getDuplicatesList() {
        Mockito.when(rolesAppApiClient.idGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new IndividualDTO()
                        .accessGroup(IndividualDTO.AccessGroupEnum.ALL_RIGHTS)
                        .dboProId("123")), HttpStatus.OK));

        Mockito.when(organizationAppApiClient.rootGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("bisId").branch("branch")))), HttpStatus.OK));

        Mockito.when(paymentAppApiClient.documentGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getPaymentList(), HttpStatus.OK));
        Mockito.when(paymentAppApiClient.documentIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getDocument(), HttpStatus.OK));
        Mockito.when(paymentAppApiClient.documentDublicatesPost(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getPaymentList(), HttpStatus.OK));

        List<Payment> response = duplicatesService.getDuplicatesList(Collections.singletonList("1"), "dboproId");

        Assert.assertEquals(Payment.StatusEnum.PROCESSING, response.get(0).getStatus());
    }

    private List<AccountDTO> getAccounts() {
        return Collections.singletonList(new AccountDTO()
                .number("number")
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("bisId").branch("branch")));
    }

    private List<DocumentDTO> getPaymentList() {
        return Collections.singletonList(getDocument());
    }

    private DocumentDTO getDocument() {
        return new DocumentDTO()
                .id(1)
                .amount("123")
                .status(DocumentStatusDTO.DFM_PROCESSING)
                .type(DocumentDTO.TypeEnum.CD)
                .showError(true)
                .typeTaxPayment("typeTax")
                .executionDate(OffsetDateTime.now())
                .payer(new RequisiteDTO().bank(new BankInfoDTO()).account("account"))
                .payee(new RequisiteDTO().bank(new BankInfoDTO().bic("bic")));
    }
}