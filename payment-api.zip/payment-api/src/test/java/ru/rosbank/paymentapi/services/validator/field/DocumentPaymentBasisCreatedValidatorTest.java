package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisCreatedValidator;

public class DocumentPaymentBasisCreatedValidatorTest  extends BaseTest {

    @MockBean
    DocumentTypeCalculatorImpl documentTypeCalculator;

    @Test
    void validate00() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setPaymentBasis("00");
        document.setBasisDocumentCreated("00");

        document.setPayerStatus("06");

        document.setPayer(new RequisiteDTO());
        DocumentPaymentBasisCreatedValidator validator =
                new DocumentPaymentBasisCreatedValidator(documentTypeCalculator);
        validator.validate(document);
    }

    @Test
    void validateException00() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setPaymentBasis("00");
        document.setBasisDocumentCreated("0");
        document.setPayerStatus("17");
        document.setPayer(new RequisiteDTO());
        DocumentPaymentBasisCreatedValidator validator =
                new DocumentPaymentBasisCreatedValidator(documentTypeCalculator);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }

    @Test
    void validate0() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setPaymentBasis("00");
        document.setBasisDocumentCreated("0");
        document.setPayerStatus("30");
        document.setPayer(new RequisiteDTO());
        DocumentPaymentBasisCreatedValidator validator =
                new DocumentPaymentBasisCreatedValidator(documentTypeCalculator);
        validator.validate(document);
    }
}
