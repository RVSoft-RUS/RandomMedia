package ru.rosbank.paymentapi.services.integration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApi;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;

class RolesServiceTest  extends BaseTest {
    @Autowired
    RolesService rolesService;
    @MockBean
    RolesAppApi rolesAppApi;

    @Test
    void isActiveIndividual() {
        when(rolesAppApi.idGet(any(), any()))
                .thenReturn(new ResponseEntity<>(Arrays.asList(
                        getIndividualDTO(IndividualDTO.AccessGroupEnum.ALL_RIGHTS),
                        getIndividualDTO(IndividualDTO.AccessGroupEnum.BLOCK),
                        getIndividualDTO(null)), HttpStatus.OK));
        Assertions.assertTrue(rolesService.isActiveIndividual(null, null));
        Assertions.assertEquals(1, rolesService.getActiveIndividuals(null, null).size());
    }

    @Test
    void isActiveIndividual2() {
        when(rolesAppApi.idGet(any(), any()))
                .thenReturn(new ResponseEntity<>(Arrays.asList(
                        getIndividualDTO(IndividualDTO.AccessGroupEnum.ALL_RIGHTS).accessDate(LocalDate.now())
                                .accessValidPeriod(LocalDate.now()),
                        getIndividualDTO(IndividualDTO.AccessGroupEnum.BLOCK).accessDate(LocalDate.now())),
                        HttpStatus.OK));
        Assertions.assertTrue(rolesService.isActiveIndividual(null, null));
        Assertions.assertEquals(1, rolesService.getActiveIndividuals(null, null).size());
    }

    @Test
    void isBlockIndividual() {
        when(rolesAppApi.idGet(any(), any()))
                .thenReturn(new ResponseEntity<>(Arrays.asList(
                        getIndividualDTO(IndividualDTO.AccessGroupEnum.BLOCK)), HttpStatus.OK));
        Assertions.assertFalse(rolesService.isActiveIndividual(null, null));
        Assertions.assertEquals(0, rolesService.getActiveIndividuals(null, null).size());
    }

    @Test
    void isNotActiveIndividual() {
        when(rolesAppApi.idGet(any(), any()))
                .thenReturn(new ResponseEntity<>(Arrays.asList(
                        getIndividualDTO(IndividualDTO.AccessGroupEnum.ALL_RIGHTS)
                                .accessValidPeriod(LocalDate.now().minusDays(1)),
                        getIndividualDTO(IndividualDTO.AccessGroupEnum.ALL_RIGHTS)
                                .accessDate(LocalDate.now().plusDays(1))), HttpStatus.OK));
        Assertions.assertFalse(rolesService.isActiveIndividual(null, null));
        Assertions.assertEquals(0, rolesService.getActiveIndividuals(null, null).size());
    }

    @Test
    void individualException() {
        Mockito.when(rolesAppApi.idGet(any(), any())).thenThrow(RuntimeException.class);
        Assertions.assertFalse(rolesService.isActiveIndividual(null, null));
        Assertions.assertEquals(0, rolesService.getActiveIndividuals(null, null).size());
    }

    @Test
    void isAccountManagerOrRepresentativeReturnsTrueWhenIndividualRelationTypeAccountManagerOrRepresentative() {
        var representativeIndividual = new IndividualDTO().relationType("Representative");
        var result = rolesService.isAccountManagerOrRepresentative(representativeIndividual);
        assertThat(result).isTrue();

        var accountManagerIndividual = new IndividualDTO().relationType("Account Management");
        result = rolesService.isAccountManagerOrRepresentative(accountManagerIndividual);
        assertThat(result).isTrue();
    }

    @Test
    void isAccountManagerOrRepresentativeReturnsFalseWhenNotIndividualRelationTypeAccountManagerOrRepresentative() {
        var representativeIndividual = new IndividualDTO().relationType("Somebody");
        var result = rolesService.isAccountManagerOrRepresentative(representativeIndividual);
        assertThat(result).isFalse();
    }

    private IndividualDTO getIndividualDTO(IndividualDTO.AccessGroupEnum accessGroup) {
        return new IndividualDTO().accessGroup(accessGroup).accessDate(LocalDate.now().minusDays(1));
    }
}