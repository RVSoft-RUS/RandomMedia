package ru.rosbank.paymentapi.services.validator;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerKppValidator;


/**
 * Summary.
 *
 * @author rb067368
 */
public class DocumentPayerKppValidatorTests extends BaseTest {
    @Autowired
    DocumentPropertyImpl documentProperty;

    private DocumentPayerKppValidator documentPayerKppValidator = new DocumentPayerKppValidator(documentProperty);

    @Test
    public void mustBe9SymbolsNegative() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("123");
        assertThrows(ValidationPaymentException.class, () -> documentPayerKppValidator.validate(document));
    }

    @Test
    public void mustNotToStartWith2ZerosNegative() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("001234567");
        assertThrows(ValidationPaymentException.class, () -> documentPayerKppValidator.validate(document));
    }

    @Test
    public void mustNotBeAllZerosNegative() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("000000000");
        assertThrows(ValidationPaymentException.class, () -> documentPayerKppValidator.validate(document));
    }

    @Test
    public void check56SymbolsNegative() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("1234mn789");
        assertThrows(ValidationPaymentException.class, () -> documentPayerKppValidator.validate(document));
    }

    @Test
    public void test56SymbolsSuccess() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("1234MN789");
        documentPayerKppValidator.validate(document);
    }

    @Test
    public void testAllDigitsSuccess03100() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("123456789");
        document.getPayer().setAccount("031001234501234563789");
        document.setPayerStatus("01");
        documentPayerKppValidator.validate(document);
    }

    @Test
    public void testZeroSuccess03100() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("0");
        document.getPayer().setAccount("031001234501234563789");
        document.setPayerStatus("01");
        documentPayerKppValidator.validate(document);
    }

    @Test
    public void mustBe9Symbols03100() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("1234567890"));
        document.getPayer().setKpp("1234MN789");
        document.getPayer().setAccount("031001234501234563789");
        document.setPayerStatus("01");
        documentPayerKppValidator.validate(document);
    }

    @Test
    public void mustBe9SymbolsNegativeInn12() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("123456789012"));
        document.getPayer().setKpp("123");
        assertThrows(ValidationPaymentException.class, () -> documentPayerKppValidator.validate(document));
    }

    @Test
    public void test0SuccessInn12() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("123456789012"));
        document.getPayer().setKpp("0");
        documentPayerKppValidator.validate(document);
    }

    @Test
    public void testBlankSuccessInn12() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("123456789012"));
        documentPayerKppValidator.validate(document);
    }

    @Test
    public void test0SuccessInn0() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("0"));
        document.getPayer().setKpp("0");
        documentPayerKppValidator.validate(document);
    }

    @Test
    public void test0SuccessInn0Negative() {
        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().inn("0"));
        document.getPayer().setKpp("123456789");
        assertThrows(ValidationPaymentException.class, () -> documentPayerKppValidator.validate(document));
    }
}
