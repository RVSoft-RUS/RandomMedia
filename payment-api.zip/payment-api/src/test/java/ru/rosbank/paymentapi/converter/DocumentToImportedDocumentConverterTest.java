package ru.rosbank.paymentapi.converter;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.mapper.ImportedDocumentMapper;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.CurrencyControlDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.FileInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapi.model.BankDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;


class DocumentToImportedDocumentConverterTest extends BaseTest {
    @Autowired
    DocumentToImportedDocumentConverter converter;
    @MockBean
    AccountService accountService;
    @MockBean
    ReferenceService referenceService;

    @Test
    void convert() {
        ru.rosbank.platform.client.referenceapp.model.BranchDTO branchDTO = new BranchDTO();
        branchDTO.setBik("bic");
        branchDTO.setCode("code");
        branchDTO.setName("name");
        branchDTO.setCorrespondentAccount("corrAcc");
        List<ru.rosbank.platform.client.referenceapp.model.BranchDTO> branchDTOList = new ArrayList<>();
        branchDTOList.add(branchDTO);
        AccountDTO accountDTO = getAccountDTO();

        when(accountService.getAccount(any())).thenReturn(accountDTO);
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(accountDTO));
        when(referenceService.getBranch(any())).thenReturn(Collections.singletonList(branchDTO));
        BankInfoDTO bankInfoDTO = new BankInfoDTO();
        bankInfoDTO.setBic("bic");
        bankInfoDTO.setName("name");
        bankInfoDTO.setCorrespondentAccount("corrAcc");
        DocumentDTO documentDTO = new DocumentDTO()
                .id(1)
                .amount("123")
                .status(DocumentStatusDTO.CREATED)
                .type(DocumentDTO.TypeEnum.CD)
                .showError(true)
                .typeTaxPayment("typeTax")
                .executionDate(OffsetDateTime.now())
                .payer(new RequisiteDTO().bank(bankInfoDTO.bic("bic")).account("account"))
                .payee(new RequisiteDTO().bank(bankInfoDTO.bic("bic")))
                .currencyControl(new CurrencyControlDTO()
                        .fullName("fullName")
                        .addFileInfoItem(new FileInfoDTO()
                                .id("777")));
        ImportedDocumentDTO imported = converter.convert(documentDTO, accountDTO);
        DocumentDTO documentResult = converter.convertBack(ImportedDocumentMapper.INSTANCE.fromDTO(imported));
        Assertions.assertEquals(documentDTO.getPayer().getBank().getBic(), documentResult.getPayer().getBank().getBic());
    }

    @Test
    void convertException() {

        BankInfoDTO bankInfoDTO = new BankInfoDTO();
        DocumentDTO documentDTO = new DocumentDTO()
                .id(1)
                .amount("123")
                .status(DocumentStatusDTO.CREATED)
                .type(DocumentDTO.TypeEnum.CD)
                .showError(true)
                .typeTaxPayment("typeTax")
                .executionDate(OffsetDateTime.now())
                .payer(new RequisiteDTO().bank(bankInfoDTO.bic("bic")).account("account"))
                .payee(new RequisiteDTO().bank(bankInfoDTO.bic("bic")))
                .currencyControl(new CurrencyControlDTO()
                        .fullName("fullName")
                        .addFileInfoItem(new FileInfoDTO()
                                .id("777")));
        Assertions.assertThrows(BankInfoException.class, () -> {
            converter.convert(documentDTO, getAccountDTO());
        });


    }

    private AccountDTO getAccountDTO() {
        BankDTO bankDTO = new BankDTO();
        bankDTO.setBic("bic");
        bankDTO.setName("name");
        bankDTO.setCorrespondentAccount("accaunt");
        BisIdDTO bisIdDTO = new BisIdDTO();
        bisIdDTO.setBranch("R19");
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setBisId(bisIdDTO);
        return accountDTO;
    }
}