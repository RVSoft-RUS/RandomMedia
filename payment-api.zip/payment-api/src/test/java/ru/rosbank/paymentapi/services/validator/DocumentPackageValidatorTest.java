package ru.rosbank.paymentapi.services.validator;

import static org.mockito.ArgumentMatchers.any;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.validator.field.DfmBlockValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.userapp.api.UserAppApi;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class DocumentPackageValidatorTest extends BaseTest {

    @Autowired
    DocumentPackageValidator documentPackageValidator;

    @MockBean
    AccountService accountService;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    DfmBlockValidator dfmBlockValidator;
    @MockBean
    UserAppApi userAppApi;
    @MockBean
    DocumentValidator documentValidator;

    @BeforeEach
    void initMocks() {
        Mockito.when(organizationService.getOrganizations(any()))
                .thenReturn(Arrays.asList(new OrganizationDTO()
                                .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))),
                        new OrganizationDTO()
                                .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19")))
                ));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        Mockito.when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(getAccountDTOList());
        Mockito.when(accountService.getAccount(any()))
                .thenReturn(getAccountDTO());
    }

    @Test
    void validateSuccessful() {
        Mockito.when(userAppApi.antifraudBlockGet(any()))
                .thenReturn(new ResponseEntity<>(false, HttpStatus.OK));
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        getAccountDTOList().forEach(a -> accountsMap.put(a.getNumber(), a));
        documentPackageValidator.validate(getDocuments(),
                new ClientDTO().id("35563c07-82b2-43a8-a3b2-c9a11c696b4e").dbId("1"), new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))), accountsMap);
    }

    @Test
    void validateFailed() {
        Mockito.when(userAppApi.antifraudBlockGet(any()))
                .thenReturn(new ResponseEntity<>(true, HttpStatus.OK));
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        getAccountDTOList().forEach(a -> accountsMap.put(a.getNumber(), a));
        Assertions.assertThrows(ValidationPaymentException.class, () ->
            documentPackageValidator.validate(getDocuments(),
                    new ClientDTO().id("35563c07-82b2-43a8-a3b2-c9a11c696b4e").dbId("1"),
                    new OrganizationDTO()
                            .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))), accountsMap
        ));
    }

    @Test
    void filterValidDocuments() {
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        getAccountDTOList().forEach(a -> accountsMap.put(a.getNumber(), a));
        var validDocs = documentPackageValidator.filterValidDocuments(getDocuments(), accountsMap);
        Assertions.assertNotNull(validDocs);
        Assertions.assertEquals(1, validDocs.stream().findFirst().get().getId());
    }

    private List<DocumentDTO> getDocuments() {
        var doc1 = new DocumentDTO()
                .id(1)
                .clientId(1L)
                .amount("1000.00")
                .status(DocumentStatusDTO.CREATED)
                .date(OffsetDateTime.now())
                .payer(new RequisiteDTO()
                        .account("40802810597880000207")
                );
        var doc2 = new DocumentDTO()
                .id(2)
                .amount("2000.00")
                .executionDate(OffsetDateTime.now())
                .payer(new RequisiteDTO()
                        .account("40802810597880000207")
                );
        return Arrays.asList(doc1, doc2);
    }

    private List<AccountDTO> getAccountDTOList() {
        AccountDTO accountDTO1 = new AccountDTO();
        accountDTO1.setNumber("40802810597880000207");
        accountDTO1.setAccountType("CA");
        accountDTO1.setCurrency("RUB");
        accountDTO1.setHasRestrictions(true);
        accountDTO1.setOpenDate(LocalDate.now());
        accountDTO1.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        AccountDTO accountDTO2 = new AccountDTO();
        accountDTO2.setNumber("123456890123456891");
        accountDTO2.setAccountType("CD");
        accountDTO2.setCurrency("RUB");
        accountDTO2.setHasRestrictions(true);
        accountDTO2.setOverdraftAmount("0,00");
        accountDTO2.setRestAmount("2536,25");
        accountDTO2.setOpenDate(LocalDate.now());
        accountDTO2.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        AccountDTO accountDTO3 = new AccountDTO();
        accountDTO3.setNumber("123456890123456892");
        accountDTO3.setAccountType("CE");
        accountDTO3.setCurrency("RUB");
        accountDTO3.setHasRestrictions(true);
        accountDTO3.setOpenDate(LocalDate.now());
        accountDTO3.setReserveAmount("");
        accountDTO3.setRestAmount("-15,25");
        accountDTO3.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));
        return Arrays.asList(accountDTO1, accountDTO2, accountDTO3);
    }

    private AccountDTO getAccountDTO() {
        return new AccountDTO()
                .number("40802810597880000207")
                .accountType("CA")
                .currency("RUB")
                .hasRestrictions(true)
                .openDate(LocalDate.now())
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                        .id("123")
                        .branch("R19"))
                .restAmount("5000.00");
    }
}