package ru.rosbank.paymentapi.services.validator;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class DocumentValidatorTest extends BaseTest {
    @Autowired
    DocumentValidator documentValidator;
    @MockBean
    DocumentPayerAccountChecker documentPayerAccountChecker;
    @MockBean
    ProductService productService;
    @MockBean
    DocumentOrganizationLimitValidator documentOrganizationLimitValidator;
    @MockBean
    DefaultPaymentValidators defaultPaymentValidators;
    @MockBean
    PayrollPaymentValidators payrollPaymentValidators;
    @MockBean
    ImportedPaymentValidators importedPaymentValidators;
    @MockBean
    ImportedPayrollPaymentValidators importedPayrollPaymentValidators;
    @MockBean
    DocumentPayeeAccountValidator documentPayeeAccountValidator;

    private static final int MIN_DAYS_BEFORE = 11;
    private static final int MAX_DAYS_AFTER = 30;


    @Test
    void validatePayerAccountAndOrgLimit() {

        documentValidator.validatePayerAccountAndOrgLimit("dboPro",
                Collections.singletonList(new DocumentDTO()), new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))));
    }

    @Test
    void validate() {

        Map<String, AccountDTO> accountsMap = new HashMap<>();
        accountsMap.put("42606810512232454567", new AccountDTO().number("42606810512232454567"));
        accountsMap.put("40108810696430000397", new AccountDTO().number("40108810696430000397").accountType("CD"));
        documentValidator.validate(new DocumentDTO().type(DocumentDTO.TypeEnum.DE), accountsMap);
        var doc = new DocumentDTO()
                .payee(new RequisiteDTO()
                        .account("42606810512232454567")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("40102810696430000396")))
                .payer(new RequisiteDTO()
                        .account("40108810696430000397")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("40102810696430000396")));
        doc.setType(DocumentDTO.TypeEnum.DP);
        documentValidator.validate(doc, accountsMap);
    }

    @Test
    void validateImportedDoc() {

        Map<String, AccountDTO> accountsMap = new HashMap<>();
        accountsMap.put("42606810512232454567", new AccountDTO().number("42606810512232454567"));
        accountsMap.put("40108810696430000397", new AccountDTO().number("40108810696430000397").accountType("CD"));
        var doc = new DocumentDTO()
                .date(OffsetDateTime.now())
                .payee(new RequisiteDTO()
                        .account("42606810512232454567")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("40102810696430000396")))
                .payer(new RequisiteDTO()
                        .account("40108810696430000397")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("40102810696430000396")));
        Assertions.assertDoesNotThrow(() -> documentValidator.validateImportedDoc(doc, "dboProId", accountsMap));

        doc.setType(DocumentDTO.TypeEnum.DP);
        Assertions.assertDoesNotThrow(() -> documentValidator.validateImportedDoc(doc, "dboProId", accountsMap));

        doc.setDate(OffsetDateTime.now().minusDays(MIN_DAYS_BEFORE - 1));
        Assertions.assertDoesNotThrow(() -> documentValidator.validateImportedDoc(doc, "dboProId", accountsMap));
        doc.setDate(OffsetDateTime.now().minusDays(MIN_DAYS_BEFORE + 1));
        Assertions.assertThrows(
            ValidationPaymentException.class,
            () -> documentValidator.validateImportedDoc(doc, "dboProId", accountsMap)
        );

        doc.setDate(OffsetDateTime.now().plusDays(MAX_DAYS_AFTER));
        Assertions.assertDoesNotThrow(() -> documentValidator.validateImportedDoc(doc, "dboProId", accountsMap));
        doc.setDate(OffsetDateTime.now().plusDays(MAX_DAYS_AFTER + 1));
        Assertions.assertThrows(
            ValidationPaymentException.class,
            () -> documentValidator.validateImportedDoc(doc, "dboProId", accountsMap)
        );
    }
}