package ru.rosbank.paymentapi.services;

import com.netflix.hystrix.HystrixInvokable;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.rectification.DocumentRectificationService;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.AccountsCachedResponseDTO;
import ru.rosbank.platform.client.cardapp.api.CardAppApiClient;
import ru.rosbank.platform.client.cardapp.model.CardDTO;
import ru.rosbank.platform.client.fileapp.api.FileAppApiClient;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApiClient;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.CurrencyControlDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.FileInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.statementapp.api.StatementAppApiClient;
import ru.rosbank.platform.client.statementapp.model.AccountStatementDTO;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.AccountStatementError;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.DocumentCriteria;
import ru.rosbank.platform.server.paymentapi.model.DocumentsResponse;
import ru.rosbank.platform.server.paymentapi.model.Page;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

class DocumentListServiceTest extends BaseTest {
    @Autowired
    private DocumentListService documentListService;
    @Autowired
    private OrganizationService organizationService;

    @MockBean
    private OrganizationAppApiClient organizationAppApiClient;
    @MockBean
    private AccountAppApiClient accountAppApiClient;
    @MockBean
    private StatementAppApiClient statementAppApiClient;
    @MockBean
    private PaymentAppApiClient paymentAppApiClient;
    @MockBean
    private CardAppApiClient cardAppApiClient;
    @MockBean
    private FileAppApiClient fileAppApiClient;
    @MockBean
    private DocumentRectificationService rectificationService;
    @MockBean
    private OpfConverterService opfConverterService;

    @BeforeEach
    void setUp() {
        Mockito.when(fileAppApiClient.fileIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(new ru.rosbank.platform.client.fileapp.model.FileInfoDTO().size("size"),
                        HttpStatus.OK));
        Mockito.when(paymentAppApiClient.documentGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getPaymentList(), HttpStatus.OK));
        Mockito.when(statementAppApiClient.accountStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new AccountStatementDTO().operations(getOperations()), HttpStatus.OK));
        Mockito.when(organizationAppApiClient.rootGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getOrganizationList(), HttpStatus.OK));

        Mockito.when(rectificationService.getActiveDocumentRectificationsByDocumentsId(Mockito.any()))
                .thenReturn(getRectificationMap());
        Mockito.when(rectificationService.getRectificationByRectifications(Mockito.any()))
                .thenReturn(new Rectification().documentId("documentId"));
        Mockito.when(rectificationService.getRectificationsByPaymentId(Mockito.any(), Mockito.any()))
                .thenReturn(Collections.singletonList(new Rectification().documentId("documentId")));
    }



    @Test
    void getDocumentListWithoutAccountsCriteria() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");
        DocumentsResponse documentsResponse = documentListService.getDocumentList(new DocumentCriteria(),
                "123", orgIds).get();
        Assertions.assertEquals(3, documentsResponse.getPayments().size());
        checkCurrencyControl(documentsResponse.getPayments());
    }

    @Test
    void getDocumentListWithAccountsCriteria() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");
        DocumentsResponse documentsResponse = documentListService.getDocumentList(getCriteriaWithAccounts(),
                "123", orgIds).get();
        Assertions.assertEquals(2, documentsResponse.getPayments().size());
        checkCurrencyControl(documentsResponse.getPayments());
    }

    @Test
    void getDocumentListWithAccountsCriteriaWithHystrixException() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(statementAppApiClient.accountStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(),
                        Mockito.any(), Mockito.any(), Mockito.any()))
                .thenThrow(new HystrixRuntimeException(HystrixRuntimeException.FailureType.TIMEOUT,
                        HystrixInvokable.class, "", null, null));
        var orgIds = organizationService.getOrganizations("123");
        DocumentsResponse documentsResponse = documentListService
                .getDocumentList(getCriteriaWithAccounts(), "123", orgIds).get();

        Assertions.assertEquals(1, documentsResponse.getPayments().size());
        Assertions.assertEquals(1, documentsResponse.getAccStatementErrors().size());
        Assertions.assertEquals(
                AccountStatementError.TypeEnum.UNEXPECTED,
                documentsResponse.getAccStatementErrors().get(0).getType()
        );
        Assertions.assertTrue(documentsResponse.getAccStatementErrors().get(0).getErrorMsg()
                .startsWith("Не удалось получить информацию"));
        checkCurrencyControl(documentsResponse.getPayments());
    }

    @Test
    void getDocumentListWithAccountsCriteriaWithFeignException() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(statementAppApiClient.accountStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(),
                        Mockito.any(), Mockito.any(), Mockito.any()))
                .thenThrow(new FeignException.BadRequest("", getRequest(), null, null));
        var orgIds = organizationService.getOrganizations("123");
        DocumentsResponse documentsResponse = documentListService.getDocumentList(getCriteriaWithAccounts(),
                "123", orgIds).get();
        Assertions.assertEquals(1, documentsResponse.getPayments().size());
        Assertions.assertEquals(1, documentsResponse.getAccStatementErrors().size());
        Assertions.assertEquals(
                AccountStatementError.TypeEnum.UNEXPECTED,
                documentsResponse.getAccStatementErrors().get(0).getType()
        );
        Assertions.assertTrue(documentsResponse.getAccStatementErrors().get(0).getErrorMsg()
                .startsWith("Не удалось получить документы"));
        checkCurrencyControl(documentsResponse.getPayments());
    }

    @Test
    void getDocumentListWithBadDatesCriteria() throws ExecutionException, InterruptedException {
        var orgIds = organizationService.getOrganizations("123");
        DocumentsResponse documentsResponse = documentListService
                .getDocumentList(new DocumentCriteria()
                        .startDate(OffsetDateTime.now()).endDate(OffsetDateTime.MIN), "123", orgIds).get();
        Assertions.assertEquals(0, documentsResponse.getPayments().size());
    }

    @Test
    void getCardListWithCardsCriteria() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(statementAppApiClient.cardStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCardTransactions(), HttpStatus.OK));
        Mockito.when(cardAppApiClient.rootGetFromBd(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCards(), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");
        List<Payment> cardList = documentListService.getCardList(getCriteriaWithCards(), "123", orgIds).get();
        Assertions.assertEquals(2, cardList.size());
    }

    @Test
    void getCardListWithCardsCriteriaWithFeignException() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(statementAppApiClient.cardStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenThrow(new FeignException.BadRequest("", getRequest(), null, null));
        Mockito.when(cardAppApiClient.rootGetFromBd(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCards(), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");
        List<Payment> cardList = documentListService.getCardList(getCriteriaWithCards(), "123", orgIds).get();
        Assertions.assertEquals(0, cardList.size());
    }

    @Test
    void getPaymentListWithCardsCriteria() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(accountAppApiClient.idGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getAccountDTO(), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");

        DocumentsResponse documentsResponse = documentListService.getDocumentList(getCriteriaWithAccountsAndCards(),
                "123", orgIds).get();

        Assertions.assertEquals(2, documentsResponse.getPayments().size());
    }

    @Test
    void getPaymentListError() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(accountAppApiClient.idGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getAccountDTO(), HttpStatus.OK));

        Mockito.when(opfConverterService.convert(Mockito.any())).thenThrow(RuntimeException.class);
        var orgIds = organizationService.getOrganizations("123");

        DocumentsResponse documentsResponse = documentListService.getDocumentList(getCriteriaWithAccountsAndCards(),
                "123", orgIds).get();

        Assertions.assertEquals(2, documentsResponse.getPayments().size());
    }

    @Test
    void getCardListStatementFailed() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Request request = Request.create(Request.HttpMethod.GET, "url",
                new HashMap<>(), null, new RequestTemplate());
        Mockito.when(statementAppApiClient.cardStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenThrow(new FeignException.BadRequest("", request, null, null));
        var orgIds = organizationService.getOrganizations("123");
        List<Payment> cardList = documentListService.getCardList(getCriteriaWithCards(), "123", orgIds).get();
        Assertions.assertEquals(0, cardList.size());
    }

    @Test
    void getCardListWithEmptyCardsCriteria() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(cardAppApiClient.rootGetFromBd(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCards(), HttpStatus.OK));
        Mockito.when(statementAppApiClient.cardStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCardTransactions(), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");
        List<Payment> cardList = documentListService
                .getCardList(new DocumentCriteria().accounts(Collections.singletonList("number")), "123", orgIds).get();
        Assertions.assertEquals(2, cardList.size());
        cardList = documentListService
                .getCardList(new DocumentCriteria()
                        .cards(new ArrayList<>())
                        .accounts(Collections.singletonList("number")), "123", orgIds).get();
        Assertions.assertEquals(2, cardList.size());
    }

    @Test
    void getCardListWithEmptyCardsCriteriaAndWithCardType() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(cardAppApiClient.rootGetFromBd(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCards(), HttpStatus.OK));
        Mockito.when(statementAppApiClient.cardStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCardTransactions(), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");
        List<Payment> cardList = documentListService
                .getCardList(new DocumentCriteria()
                        .types(Collections.singletonList(DocumentCriteria.TypesEnum.DT))
                        .cards(new ArrayList<>())
                        .accounts(Collections.singletonList("number")), "123", orgIds).get();
        Assertions.assertEquals(2, cardList.size());
    }

    @Test
    void getCardListWithEmptyCardsCriteriaAndWithoutCardType() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(cardAppApiClient.rootGetFromBd(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getCards(), HttpStatus.OK));
        var orgIds = organizationService.getOrganizations("123");
        List<Payment> cardList = documentListService
                .getCardList(new DocumentCriteria()
                        .types(Collections.singletonList(DocumentCriteria.TypesEnum.DP))
                        .cards(new ArrayList<>())
                        .accounts(Collections.singletonList("number")), "123", orgIds).get();
        Assertions.assertEquals(0, cardList.size());
    }

    @Test
    void getCardListError() throws ExecutionException, InterruptedException {
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(getAccountDTO())), HttpStatus.OK));
        Mockito.when(cardAppApiClient.rootGetFromBd(Mockito.any(), Mockito.any()))
                .thenThrow(RuntimeException.class);
        var orgIds = organizationService.getOrganizations("123");
        List<Payment> cardList = documentListService
                .getCardList(new DocumentCriteria()
                        .types(Collections.singletonList(DocumentCriteria.TypesEnum.DP))
                        .cards(new ArrayList<>())
                        .accounts(Collections.singletonList("number")), "123", orgIds).get();
        Assertions.assertEquals(0, cardList.size());
    }

    private List<DocumentDTO> getPaymentList() {
        return List.of(new DocumentDTO()
                .id(1)
                .bisRefference("PP220727-013086201")
                .amount("123")
                .status(DocumentStatusDTO.CREATED)
                .type(DocumentDTO.TypeEnum.CD)
                .showError(true)
                .typeTaxPayment("typeTax")
                .executionDate(OffsetDateTime.now())
                .payer(new RequisiteDTO().bank(new BankInfoDTO()).account("account"))
                .payee(new RequisiteDTO().bank(new BankInfoDTO().bic("bic")).account("account"))
                .currencyControl(new CurrencyControlDTO()
                        .fullName("fullName")
                        .addFileInfoItem(new FileInfoDTO()
                                .id("777"))));
    }

    private List<PaymentDTO> getOperations() {
        return List.of(new PaymentDTO()
                .id("Y01220727013086201")
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT)
                .type(PaymentDTO.TypeEnum.CD)
                .cardPan("1231234")
                .created(OffsetDateTime.now())
                .payer(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account"))
                .payee(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")),
                new PaymentDTO()
                        .id("Y01220727013086202")
                        .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT)
                        .type(PaymentDTO.TypeEnum.DH)
                        .cardPan("1231234")
                        .merchantName("Merchant Name")
                        .created(OffsetDateTime.now())
                        .payer(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account"))
                        .payee(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("accountDH")));
    }


    private List<CardDTO> getCards() {
        return Arrays.asList(new CardDTO().number("1231234").accountNumber13("number13").status(CardDTO.StatusEnum.ACTIVE),
                new CardDTO().number("1235678"),
                new CardDTO().number("1237891"));
    }

    private List<PaymentDTO> getCardTransactions() {
        return Arrays.asList(new PaymentDTO()
                    .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT)
                    .type(PaymentDTO.TypeEnum.DT)
                    .status("PROCESSING")
                    .transDateTime(OffsetDateTime.now().minusHours(1))
                    .amount(new AmountDTO().sum(new BigDecimal("1000.10")))
                    .accountNumber13("accountNumber13"),
                new PaymentDTO()
                        .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT)
                        .type(PaymentDTO.TypeEnum.DT)
                        .status("CREATED")
                        .transDateTime(OffsetDateTime.now())
                        .amount(new AmountDTO().sum(new BigDecimal("2000.10")))
                        .accountNumber13("accountNumber13")
        );
    }

    private AccountDTO getAccountDTO() {
        return new AccountDTO()
                .number("number")
                .number13("number13")
                .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().branch("branch").id("id"));
    }

    private List<OrganizationDTO> getOrganizationList() {
        OrganizationDTO organizationDTO = new OrganizationDTO();
        organizationDTO.setCrmId("crmId");
        organizationDTO.setBisIds(Collections.singletonList(new BisIdDTO().branch("branch").id("id")));

        return Collections.singletonList(organizationDTO);
    }

    private DocumentCriteria getCriteriaWithAccounts() {
        DocumentCriteria documentCriteria = new DocumentCriteria();
        documentCriteria.setAccounts(Collections.singletonList("number"));
        documentCriteria.setTypes(Collections.singletonList(DocumentCriteria.TypesEnum.CD));
        return documentCriteria;
    }

    private DocumentCriteria getCriteriaWithCards() {
        return new DocumentCriteria()
                .accounts(Collections.singletonList("account"))
                .cards(Arrays.asList("***1234", "***5678"))
                .statuses(Arrays.asList(DocumentCriteria.StatusesEnum.PROCESSING, DocumentCriteria.StatusesEnum.REJECTED));
    }

    private DocumentCriteria getCriteriaWithAccountsAndCards() {
        return new DocumentCriteria()
                .accounts(Collections.singletonList("number"))
                .cards(Arrays.asList("***1234", "***5678"))
                .statuses(Arrays.asList(DocumentCriteria.StatusesEnum.PROCESSING, DocumentCriteria.StatusesEnum.COMPLETED));
    }

    private void checkCurrencyControl(List<Payment> documentList) {
        Assert.assertEquals(documentList
                .stream()
                .filter(payment -> payment.getCurrencyControl() != null)
                .findFirst()
                .get()
                .getCurrencyControl().getFileInfo()
                .stream()
                .findFirst()
                .get()
                .getSize(), "size");
    }

    @Test
    void getLastPage() {
        ArrayList<Payment> payments = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            payments.add(new Payment());
        }

        Page page = new Page().count(20).offset(0);
        Long result = DocumentListService.getLastPage(payments, page);
        Assertions.assertEquals(2, result);
    }

    @Test
    void isFiltersCA() {
        DocumentCriteria criteria = new DocumentCriteria();
        criteria.contragentInn("012345").contragentName("тест").bank("12345").docNumber("123")
                .sumFrom(BigDecimal.valueOf(10)).sumTo(BigDecimal.valueOf(100));
        Payment document = new Payment();
        document.setType(Payment.TypeEnum.CA);
        document.setPayer(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        document.setNumber("12345");
        document.setAmount(new Amount().sum(BigDecimal.valueOf(-50)));
        Assertions.assertTrue(DocumentListService.isFilters(document, criteria));

    }

    @Test
    void isFiltersDA() {
        DocumentCriteria criteria = new DocumentCriteria();
        criteria.contragentInn("012345").contragentName("тест").bank("123456").docNumber("123")
                .sumFrom(BigDecimal.valueOf(10)).sumTo(BigDecimal.valueOf(100));
        Payment document = new Payment();
        document.setType(Payment.TypeEnum.DA);
        document.setPayee(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        document.setNumber("12345");
        document.setAmount(new Amount().sum(BigDecimal.valueOf(-10)));
        Assertions.assertTrue(DocumentListService.isFilters(document, criteria));
        document.setAmount(new Amount().sum(BigDecimal.valueOf(100)));
        Assertions.assertTrue(DocumentListService.isFilters(document, criteria));
        document.setAmount(new Amount().sum(null));
        Assertions.assertTrue(DocumentListService.isFilters(document, criteria));
        document.setAmount(new Amount().sum(BigDecimal.valueOf(100)));
        criteria.sumFrom(null).sumTo(null);
        Assertions.assertTrue(DocumentListService.isFilters(document, criteria));
    }

    @Test
    void getPage() {
        List<Payment> documents = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            documents.add(new Payment().id(Integer.valueOf(i).toString()));
        }
        Page page = new Page();
        page.setOffset(0);
        page.setCount(10);
        List<Payment>  list1 = DocumentListService.getPage(documents, page);
        Assertions.assertEquals(list1.size(), 10);
        page.setOffset(10);
        List<Payment>  list2 = DocumentListService.getPage(documents, page);
        Assertions.assertEquals(list2.size(), 10);
        page.setOffset(10 + 10);
        List<Payment>  list3 = DocumentListService.getPage(documents, page);
        Assertions.assertEquals(list3.size(), 10);
        page.setOffset(10 + 10 + 10);
        List<Payment>  list4 = DocumentListService.getPage(documents, page);
        Assertions.assertEquals(list4.size(), 10);
        page.setOffset(10 + 10 + 10 + 10);
        List<Payment>  list5 = DocumentListService.getPage(documents, page);
        Assertions.assertEquals(list5.size(), 10);
        page.setOffset(10 + 10 + 10 + 10 + 10);
        List<Payment>  list6 = DocumentListService.getPage(documents, page);
        Assertions.assertEquals(list6.size(), 0);

    }

    Map<String, List<Rectification>> getRectificationMap() {
        Rectification rectification = new Rectification();
        rectification.setDocumentId("Y01220727013086201");
        rectification.setId(1L);
        rectification.setStatus("SIGNED");
        List<Rectification> rectificationList = new ArrayList<>();
        rectificationList.add(rectification);
        Map<String, List<Rectification>> rectificationMap = new HashMap<>();
        rectificationMap.put(rectification.getDocumentId(), rectificationList);
        return rectificationMap;
    }
}