package ru.rosbank.paymentapi.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpSession;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ConfirmationRequiredException;
import ru.rosbank.paymentapi.exception.PaymentNotRevertibleException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.UserService;
import ru.rosbank.paymentapi.services.signature.DocumentRecallSigner;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

class RecallServiceTest extends BaseTest {

    @Autowired
    RecallService recallService;

    @MockBean
    PaymentAppApi paymentAppApi;
    @MockBean
    CryptoproAppApi cryptoproAppApi;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    AccountService accountService;
    @MockBean
    UserService userService;
    @MockBean
    OtpService otpService;
    @MockBean
    DocumentRecallSigner documentRecallSigner;

    @Test
    void recallPaymentCompletedNotRevertibleException() {
        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(new DocumentDTO()
                        .status(DocumentStatusDTO.COMPLETED)
                        .bisId(new BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")), HttpStatus.OK));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number("number")));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        Assertions.assertThrows(PaymentNotRevertibleException.class, () -> recallService.recallPayment("id", "dboProId"));
    }

    @Test
    void recallPaymentRejectedNotRevertibleException() {
        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(new DocumentDTO()
                        .status(DocumentStatusDTO.REJECTED)
                        .bisId(new BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")), HttpStatus.OK));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number("number")));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        Assertions.assertThrows(PaymentNotRevertibleException.class, () -> recallService.recallPayment("id", "dboProId"));
    }

    @Test
    void recallPaymentRecalledNotRevertibleException() {
        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(new DocumentDTO()
                        .status(DocumentStatusDTO.RECALLED)
                        .bisId(new BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")), HttpStatus.OK));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number("number")));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        Assertions.assertThrows(PaymentNotRevertibleException.class, () -> recallService.recallPayment("id", "dboProId"));
    }

    @Test
    void recallPaymentErrorNotRevertibleException() {
        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(new DocumentDTO()
                        .status(DocumentStatusDTO.ERROR)
                        .bisId(new BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")), HttpStatus.OK));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number("number")));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        Assertions.assertThrows(PaymentNotRevertibleException.class, () -> recallService.recallPayment("id", "dboProId"));
    }

    @Test
    void recallPaymentFromBisNotSignedSuccessful() {
        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(new DocumentDTO()
                        .id(1)
                        .status(DocumentStatusDTO.SENT_TO_BIS)
                        .bisId(new BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")), HttpStatus.OK));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number("number")));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        when(userService.getUser(any()))
                .thenReturn(new ClientDTO().id("35563c07-82b2-43a8-a3b2-c9a11c696b4e").phone("79411234566"));
        Request request = Request
                .create(Request.HttpMethod.GET, "url", new HashMap<>(), null, new RequestTemplate());
        when(paymentAppApi.documentIdRecallSignedPost(any(), any()))
                .thenThrow(new FeignException.NotAcceptable("message", request, "ERROR".getBytes(StandardCharsets.UTF_8), null));
        when(documentRecallSigner.sign(any(), any()))
                .thenReturn(new OtpDTO().id("id").attempts(0).created(OffsetDateTime.now()));
        when(cryptoproAppApi.signatureGet(any(), any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new SignatureDTO().confirmed(false)), HttpStatus.OK));
        Assertions.assertThrows(ConfirmationRequiredException.class, () -> recallService.recallPayment("id", "dboProId"));
    }
}