package ru.rosbank.paymentapi.services.integration;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import java.time.OffsetDateTime;
import java.util.Arrays;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.contragentapp.api.ContragentAppAutomaticApi;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

class CounteragentServiceTest extends BaseTest {

    @Autowired
    private CounteragentService counteragentService;
    @MockBean
    private ContragentAppAutomaticApi contragentAppAutomaticApi;

    @Test
    void saveOrUpdateCounteragent() {
        DocumentDTO doc = new DocumentDTO();
        doc.date(OffsetDateTime.now()).crmId("crmId").payee(new RequisiteDTO().inn("inn").account("account")
                .bank(new BankInfoDTO().bic("bic")).kpp("kpp").name("name"));
        counteragentService.saveOrUpdateCounteragent(Arrays.asList(doc, doc));
        verify(contragentAppAutomaticApi, Mockito.atMostOnce()).createContragentAutoPost(eq("crmId"), any());
    }
}