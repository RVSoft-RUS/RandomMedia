package ru.rosbank.paymentapi.config;

import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
class PaymentRejectedExecutionHandlerImplTest {

    @Autowired
    @Qualifier("document_executor")
    Executor documentExecutor;

    @Test
    void rejectedExecution() {
        AtomicInteger counter = new AtomicInteger();
        Runnable task = () -> {
            try {
                Thread.sleep(1_000L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                counter.incrementAndGet();
            }
        };
        documentExecutor.execute(task);
        documentExecutor.execute(task);
        documentExecutor.execute(task);
        Assertions.assertEquals(0, counter.get());
    }
}