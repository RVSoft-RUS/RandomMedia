package ru.rosbank.paymentapi.services.signature;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;

public class SignatureServiceTest extends BaseTest {
    @Autowired
    private SignatureService signatureService;

    @MockBean
    private CryptoproAppApi cryptoproAppApi;

    @Test
    void getSignaturesByOtpSuccessTest() {
        when(cryptoproAppApi.packagesignatureIdsignatureGet(anyString()))
                .thenReturn(ResponseEntity.ok(List.of(new SignatureDTO().id("id"))));
        var response = signatureService.getSignaturesByOtp(new OtpDTO().reference("ref"));
        Assertions.assertNotNull(response);
        Assertions.assertEquals(1, response.size());
        Assertions.assertEquals("id", response.stream().findAny().get().getId());
    }

    @Test
    void getSignaturesByOtpExceptionTest() {
        Request request = Request.create(Request.HttpMethod.GET, "url",
                new HashMap<>(), null, new RequestTemplate());
        when(cryptoproAppApi.packagesignatureIdsignatureGet(anyString()))
                .thenThrow(new FeignException.BadRequest("", request, null, null));
        Assertions.assertThrows(BackendException.class, () -> signatureService.getSignaturesByOtp(new OtpDTO().reference("ref")));
    }
}
