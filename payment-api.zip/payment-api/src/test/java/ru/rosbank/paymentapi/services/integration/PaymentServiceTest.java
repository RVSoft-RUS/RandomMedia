package ru.rosbank.paymentapi.services.integration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import feign.Request;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.AuditService;
import ru.rosbank.paymentapi.services.signature.DocumentSigner;
import ru.rosbank.paymentapi.services.validator.DocumentPackageValidator;
import ru.rosbank.paymentapi.util.OrganizationAcc;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.ReferenceDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.otpapp.api.OtpAppApi;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.ErrorDTO;
import ru.rosbank.platform.client.paymentapp.model.FileResourceDTO;
import ru.rosbank.platform.client.paymentapp.model.NextDocumentInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.server.paymentapi.model.DocumentSendRequestApi;
import ru.rosbank.platform.server.paymentapi.model.NextDocumentInfo;
import ru.rosbank.platform.server.paymentapi.model.SignDocumentRequest;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class PaymentServiceTest extends BaseTest {
    private static final String ORG_1_CRM_ID = "org1_crm_id";
    private static final String NEXT_DOC_NUMBER = "next_doc_number";
    private static final OffsetDateTime NEXT_DOC_CREATED = OffsetDateTime.of(
            2022, 12, 5, 0, 0, 0, 12345, ZoneOffset.of("+03:00")
    );
    @Autowired
    PaymentService paymentService;
    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    DocumentPackageValidator documentPackageValidator;
    @MockBean
    DocumentSigner documentSigner;
    @MockBean
    PaymentAppApi paymentAppApi;
    @MockBean
    UserService userService;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    AccountService accountService;
    @MockBean
    ProductService productService;
    @MockBean
    CryptoproAppApi cryptoproAppApi;
    @MockBean
    AuditService auditService;
    @MockBean
    CounteragentService counteragentService;
    @MockBean
    OtpAppApi otpAppApi;


    private final List<AccountDTO> accountDTOS = List.of(
            new AccountDTO().number("acc1_number").bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                    .id("bisId").branch("branch")),
            new AccountDTO().number("acc2_number").bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO()
                    .id("bisId").branch("branch"))
    );

    @Test
    void createPayment() {
        var doc = buildDocument();
        when(paymentAppApi.documentPost(any()))
                .thenReturn(new ResponseEntity<>(doc, HttpStatus.OK));

        var result = paymentService.createPayment(doc);
        Assertions.assertNotNull(result);
    }

    @BeforeEach
    public void init() {
        var user = new ClientDTO().id("35563c07-82b2-43a8-a3b2-c9a11c696b4e").phone("79411234566");
        when(userService.getUser(any())).thenReturn(user);
        List<OrganizationDTO> availableOrganizations = getAvailableOrganizations();
        when(organizationService.getAvailableOrganizationListByClient(any())).thenReturn(availableOrganizations);
        when(organizationService.getOrganizations(any())).thenReturn(availableOrganizations);
        when(accountService.getCustomerAccountListEsb(availableOrganizations.get(0))).thenReturn(accountDTOS.subList(0,1));
        when(accountService.getCustomerAccountListEsb(availableOrganizations.get(1))).thenReturn(accountDTOS.subList(1,2));

        var nextDocResponse = ResponseEntity.ok(new NextDocumentInfoDTO().number(NEXT_DOC_NUMBER).created(NEXT_DOC_CREATED));
        when(paymentAppApi.documentNextInfoGet(any())).thenReturn(nextDocResponse);
        OrganizationAcc orgAcc = new OrganizationAcc();
        orgAcc.setOrg(availableOrganizations.get(0));
        orgAcc.setAccounts(accountDTOS);
        when(productService.getOrganizationAccByAccNumberAndDboProId(any(), any())).thenReturn(orgAcc);

    }

    @Test
    void updatePayment() {
    }

    @Test
    void batchSignTest() {


        var payer = new RequisiteDTO();
        payer.setAccount("acc1_number");
        var doc1 = new DocumentDTO().id(1).payer(payer);
        var doc2 = new DocumentDTO().id(2).payer(payer);
        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(doc1, HttpStatus.OK))
                .thenReturn(new ResponseEntity<>(doc2, HttpStatus.OK));

        when(documentPackageValidator.filterValidDocuments(any(), any())).thenReturn(Collections.singletonList(doc1));


        var otp = new OtpDTO().id("1").attempts(3).created(OffsetDateTime.now());
        when(documentSigner.sign(any(), any())).thenReturn(otp);
        Map<String, List<AccountDTO>> acc = new HashMap<>();
        acc.put(ORG_1_CRM_ID, accountDTOS);

        var request = new SignDocumentRequest()
                .documentIds(Arrays.asList("1", "2"))
                .importedBatchId("");
        var response = paymentService.batchSign(request, "35563c07-82b2-43a8-a3b2-c9a11c696b4e");
        Assertions.assertNotNull(response);
        Assertions.assertEquals("2", response.getRejectedIds().get(0));
    }

    @Test
    void throwValidationException() throws JsonProcessingException {
        assertThrows(ValidationPaymentException.class, () -> paymentService.throwValidationException(
                new FeignException.FeignClientException(1, "message",
                Request.create(Request.HttpMethod.POST, "https://test.ru", new HashMap<>(), "message".getBytes(), null),
                objectMapper.writeValueAsBytes(createErrorDTO()), null)));
    }

    private DocumentDTO buildDocument() {
        return new DocumentDTO()
                .amount("10000")
                .kbk("kbk")
                .status(DocumentStatusDTO.COMPLETED)
                .payee(new RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .payer(new RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")));
    }

    private ErrorDTO createErrorDTO() {
        ErrorDTO errorDTO = new ErrorDTO();
        errorDTO.setType(ErrorDTO.TypeEnum.VALIDATION_ERROR);
        errorDTO.setMessage("message");
        return errorDTO;
    }

    @Test
    void getNextDocumentInfoReturnsDocumentInfoForMatchedOrganizationId() {
        var expectedOrg = getAvailableOrganizations().get(0);

        var nextDocumentInfo = paymentService.getNextDocumentInfo("user_id", ORG_1_CRM_ID);
        verify(accountService, times(1)).getCustomerAccountListEsb(expectedOrg);
        verify(paymentAppApi, times(1)).documentNextInfoGet(Collections.singletonList("acc1_number"));
        NextDocumentInfo expected = new NextDocumentInfo()
                .number(NEXT_DOC_NUMBER)
                .created("2022-12-05T00:00:00+0300");
        assertThat(nextDocumentInfo)
                .isNotNull()
                .isEqualTo(expected);
    }

    @Test
    void getNextDocumentInfoReturnsDocumentInfoForAllOrganizationIfIdNotMatch() {
        var nextDocumentInfo = paymentService.getNextDocumentInfo("user_id", "not_matching_id");
        verify(accountService, times(2)).getCustomerAccountListEsb(any());
        verify(paymentAppApi, times(1)).documentNextInfoGet(List.of("acc1_number", "acc2_number"));
        NextDocumentInfo expected = new NextDocumentInfo()
                .number(NEXT_DOC_NUMBER)
                .created("2022-12-05T00:00:00+0300");
        assertThat(nextDocumentInfo)
                .isNotNull()
                .isEqualTo(expected);
    }

    @Test
    void getDeliveringResourceTest() {
        when(paymentAppApi.deliveringResourceIdGet(anyString()))
                .thenReturn(ResponseEntity.ok(new FileResourceDTO().name("test")));
        var response = paymentService.getDeliveringResource("id");
        assertNotNull(response);
        assertEquals("test", response.getName());
    }

    @Test
    void sendDocumentTest() {
        when(paymentAppApi.documentSendPost(any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        DocumentSendRequestApi request = new DocumentSendRequestApi();
        request.setEmail("mail");
        request.setDocumentId("docid");
        request.setPhone("phone");
        assertAll(() -> paymentService.sendDocument(request, "dboproid"));
    }

    @Test
    void getSignedDocumentCountTest() {
        when(paymentAppApi.documentSignedCountGet(any())).thenReturn(ResponseEntity.ok(6));
        var response = paymentService.getSignedDocumentCount(List.of(123L, 321L));
        assertNotNull(response);
        assertEquals(6, response);
    }

    @Test
    void getSignedDocumentCountEmptyInputListTest() {
        assertEquals(0, paymentService.getSignedDocumentCount(Collections.emptyList()));
    }

    @Test
    void getSignedDocumentCountExceptionTest() {
        when(paymentAppApi.documentSignedCountGet(any())).thenThrow(new RuntimeException("test"));
        assertEquals(0, paymentService.getSignedDocumentCount(List.of(1L, 2L)));
    }

    private List<OrganizationDTO> getAvailableOrganizations() {
        OrganizationDTO org1 = new OrganizationDTO();
        BisIdDTO org1BisIdDTO = new BisIdDTO()
                .branch("org1_bis_branch")
                .id("org1_bis_id");
        org1.setBisIds(Collections.singletonList(org1BisIdDTO));
        org1.setCrmId(ORG_1_CRM_ID);

        OrganizationDTO org2 = new OrganizationDTO();
        BisIdDTO org2BisIdDTO = new BisIdDTO()
                .branch("org2_bis_branch")
                .id("org2_bis_id");
        org2.setBisIds(Collections.singletonList(org2BisIdDTO));
        org2.setCrmId("org2_crm_id");

        return List.of(org1, org2);
    }

    @Test
    void batchSignPackageSignatureIdExecute() {
        when(cryptoproAppApi.packagesignatureIdsignatureGet(anyString()))
                .thenReturn(ResponseEntity.ok(List.of(new SignatureDTO().id("id")
                        .confirmed(true).reference(new ReferenceDTO().id("1")))));
        var payee = new RequisiteDTO();
        payee.setAccount("acc1_number");
        var doc1 = new DocumentDTO().id(1).payer(new RequisiteDTO().account("acc1_number")).payee(payee)
                .amount(BigDecimal.ONE.toString());
        var doc2 = new DocumentDTO().id(2).payer(new RequisiteDTO().account("acc2_number")).payee(payee)
                .amount(BigDecimal.ONE.toString());
        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(doc1, HttpStatus.OK))
                .thenReturn(new ResponseEntity<>(doc2, HttpStatus.OK));
        when(otpAppApi.idGet(any())).thenReturn(new ResponseEntity<>(new OtpDTO().reference("1"), HttpStatus.OK));
        paymentService.batchSignPackageSignatureIdExecute("1", "1");
        verify(paymentAppApi, Mockito.atMostOnce()).documentIdSignPost(eq("1"), any());
    }
}