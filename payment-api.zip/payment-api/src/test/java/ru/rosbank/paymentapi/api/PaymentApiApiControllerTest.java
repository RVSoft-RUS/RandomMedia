package ru.rosbank.paymentapi.api;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static ru.rosbank.platform.client.rolesapp.model.IndividualDTO.AccessGroupEnum.CREATE_DELETE;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import javax.servlet.http.Cookie;
import org.awaitility.Awaitility;
import org.awaitility.Duration;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.util.ResourceUtils;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.feign.QrPaymentApiFeignClient;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.PaymentPayeeDto;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoDto;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoResponse;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.ResultDto;
import ru.rosbank.paymentapi.services.ClarificationService;
import ru.rosbank.paymentapi.services.CommissionService;
import ru.rosbank.paymentapi.services.DocumentListService;
import ru.rosbank.paymentapi.services.TemplateService;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.PaymentService;
import ru.rosbank.paymentapi.services.integration.RolesService;
import ru.rosbank.paymentapi.services.integration.StatementService;
import ru.rosbank.paymentapi.services.reporting.StatementFormService;
import ru.rosbank.paymentapi.services.signature.SignatureService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.auditapp.api.AuditAppApi;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.ReferenceDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApi;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.rolesapp.model.RightsDTO;
import ru.rosbank.platform.client.sessionapp.api.SessionAppApiClient;
import ru.rosbank.platform.client.sessionapp.model.AttributeDTO;
import ru.rosbank.platform.client.sessionapp.model.SessionDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.CreateTemplateRequest;
import ru.rosbank.platform.server.paymentapi.model.DocumentCriteria;
import ru.rosbank.platform.server.paymentapi.model.DocumentListPdfRequest;
import ru.rosbank.platform.server.paymentapi.model.DocumentSendRequestApi;
import ru.rosbank.platform.server.paymentapi.model.DocumentsRequest;
import ru.rosbank.platform.server.paymentapi.model.DocumentsResponse;
import ru.rosbank.platform.server.paymentapi.model.FileResource;
import ru.rosbank.platform.server.paymentapi.model.NextDocumentInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.PaymentCommission;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoRequest;
import ru.rosbank.platform.server.paymentapi.model.SignDocumentRequest;
import ru.rosbank.platform.server.paymentapi.model.SignDocumentResponse;
import ru.rosbank.platform.server.paymentapi.model.Template;

@AutoConfigureMockMvc
class PaymentApiApiControllerTest extends BaseTest {

    private static final String SESSION = "ODI1Nzk5NjktNDg2NC00ZDcwLTljNmUtNzg0M2MwNjM4YTA3";
    private static final String CLIENT_ID = "9044c6e4-3a31-4a35-a661-4a1f726ce805";

    @Autowired
    MockMvc mvc;
    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    SessionAppApiClient sessionAppApi;
    @MockBean
    PaymentService paymentService;
    @MockBean
    DocumentListService documentListService;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    AccountService accountService;
    @MockBean
    StatementService statementService;
    @MockBean
    StatementFormService statementFormService;
    @MockBean
    PaymentAppApi paymentAppApi;
    @MockBean
    CryptoproAppApi cryptoproAppApi;
    @MockBean
    AuditAppApi auditAppApi;
    @MockBean
    TemplateService templateService;
    @MockBean
    RolesService rolesService;
    @MockBean
    OtpService otpService;
    @MockBean
    SignatureService signatureService;
    @MockBean
    QrPaymentApiFeignClient qrPaymentApiFeignClient;
    @MockBean
    RolesAppApi rolesAppApi;
    @MockBean
    ClarificationService clarificationService;
    @MockBean
    CommissionService commissionService;

    @Test
    void apiDocumentIdFormatTypeGet() throws Exception {
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO());
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO().bisIds(Collections.singletonList(
                        new BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number13("number13").number("number")));
        when(statementService.getCardTransaction(any(), any()))
                .thenReturn(new PaymentDTO().accountNumber13("number13"));

        initAuth();
        mvc.perform(get("/api/document/123/html")
                .cookie(sessionCookie()))
                .andExpect(status().isOk());
    }

    @Test
    void apiDocumentListPdfPost() throws Exception {
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO());
        when(statementFormService.generate(any(), any())).thenReturn(new FileResource().content("content"));

        initAuth();
        mvc.perform(post("/api/documentListPdf")
                .cookie(sessionCookie())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(new DocumentListPdfRequest().ids(Collections.singletonList("1")))))
                .andExpect(status().isOk());
    }

    @Test
    void apiDocumentBatchSignPost() throws Exception {

        when(paymentService.batchSign(any(), any())).thenReturn(new SignDocumentResponse().rejectedIds(
                Collections.singletonList("2")));

        initAuth();
        mvc.perform(post("/api/document/batch/sign")
                .cookie(sessionCookie())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(createSignDocumentRequest())))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.rejected_ids[0]").value("2"));
    }

    private SignDocumentRequest createSignDocumentRequest() {
        return new SignDocumentRequest().documentIds(Arrays.asList("1", "2"));
    }

    @Test
    void apiDocumentIdRecallPostSuccessful() throws Exception {

        initAuth();

        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(new DocumentDTO()
                        .id(1)
                        .status(DocumentStatusDTO.SENT_TO_BIS)
                        .bisId(new ru.rosbank.platform.client.paymentapp.model.BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")), HttpStatus.OK));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number("number")));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        when(paymentAppApi.documentIdRecallSignedPost(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(cryptoproAppApi.signatureGet(any(), any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new SignatureDTO().confirmed(true)), HttpStatus.OK));

        mvc.perform(post("/api/document/1/recall")
                .cookie(sessionCookie()))
                .andExpect(status().isOk());
    }

    @Test
    void apiDocumentIdRecallPostNotRevertible() throws Exception {

        initAuth();

        when(paymentAppApi.documentIdGet(any()))
                .thenReturn(new ResponseEntity<>(new DocumentDTO()
                        .status(DocumentStatusDTO.ERROR)
                        .bisId(new ru.rosbank.platform.client.paymentapp.model.BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")), HttpStatus.OK));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch")))));
        when(accountService.getAccountList(any(), any(List.class)))
                .thenReturn(Collections.singletonList(new AccountDTO().number("number")));
        Mockito.when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);

        mvc.perform(post("/api/document/1/recall")
                .cookie(sessionCookie()))
                .andExpect(status().is5xxServerError());
    }

    @Test
    void apiDocumentListPost() throws Exception {

        var accPaymentList = Arrays.asList(
                new Payment().type(Payment.TypeEnum.CE).executionDate(OffsetDateTime.now().minusMinutes(4)),
                new Payment().type(Payment.TypeEnum.CB).completed(OffsetDateTime.now().minusMinutes(2)));

        var cardPaymentList = Arrays.asList(
                new Payment().type(Payment.TypeEnum.DT).transactionDate(OffsetDateTime.now().minusMinutes(1)),
                new Payment().type(Payment.TypeEnum.DT).transactionDate(OffsetDateTime.now().minusMinutes(3)));

        DocumentsResponse documentsResponse = new DocumentsResponse().payments(accPaymentList);

        when(documentListService.getDocumentList(any(), any(), any()))
                .thenReturn(CompletableFuture.completedFuture(documentsResponse));
        when(documentListService.getCardList(any(), any(), any()))
                .thenReturn(CompletableFuture.completedFuture(cardPaymentList));

        initAuth();
        mvc.perform(MyRequestFactory.myFactoryRequestPost("/api/document/list")
                .cookie(sessionCookie())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(createDocumentsRequest())))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.payments.[0].type").value("DT"))
                .andExpect(jsonPath("$.payments.[1].type").value("CB"))
                .andExpect(jsonPath("$.payments.[2].type").value("DT"))
                .andExpect(jsonPath("$.payments[3].type").value("CE"));
    }

    @Test
    void apiDocumentListPostWithGetCardListException() throws Exception {

        var accPaymentList = Arrays.asList(
                new Payment().type(Payment.TypeEnum.CE).executionDate(OffsetDateTime.now().minusMinutes(4)),
                new Payment().type(Payment.TypeEnum.CB).completed(OffsetDateTime.now().minusMinutes(2)));
        DocumentsResponse documentsResponse = new DocumentsResponse().payments(accPaymentList);
        when(documentListService.getDocumentList(any(), any(), any()))
                .thenReturn(CompletableFuture.completedFuture(documentsResponse));
        CompletableFuture<List<Payment>> badFuture = new CompletableFuture<>();
        badFuture.completeExceptionally(new Exception("an error occurred"));
        when(documentListService.getCardList(any(), any(), any())).thenReturn(badFuture);

        initAuth();
        mvc.perform(post("/api/document/list")
                .cookie(sessionCookie())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(createDocumentsRequest())))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.payments.[0].type").value("CB"))
                .andExpect(jsonPath("$.payments.[1].type").value("CE"));
    }

    private DocumentsRequest createDocumentsRequest() {
        return new DocumentsRequest().criteria(new DocumentCriteria());
    }

    private DocumentsRequest createDocumentsRequestWithCard() {
        return new DocumentsRequest().criteria(new DocumentCriteria().cards(Collections.singletonList("***1234")));
    }

    private void initAuth() {
        when(sessionAppApi.idGet(any())).thenReturn(new ResponseEntity<>(authorizedSession(), HttpStatus.OK));
        when(sessionAppApi.rootPost()).thenReturn(new ResponseEntity<>(authorizedSession(), HttpStatus.OK));
    }

    private SessionDTO authorizedSession() {
        List<AttributeDTO> attrs = Arrays.asList(
                new AttributeDTO().name("authorization_level").value("AUTHORIZED"),
                new AttributeDTO().name("CLIENT_ID").value(CLIENT_ID),
                new AttributeDTO().name("phone").value("79411234566")
        );
        SessionDTO session = new SessionDTO();
        session.setId(Arrays.toString(Base64.getDecoder().decode(SESSION)));
        session.setAttributes(attrs);
        return session;
    }

    private Cookie sessionCookie() {
        return new Cookie("SESSION", SESSION);
    }

    @Test
    void getNextDocumentInfo() throws Exception {
        initAuth();

        when(paymentService.getNextDocumentInfo(any(), any()))
                .thenReturn(new NextDocumentInfo().created("2022-11-30T00:00:00+03:00").number("12F"));

        var path = ResourceUtils.getFile("classpath:json/NextDocumentInfoResponse.json").toPath();
        var expectedContent = Files.readString(path);
        mvc.perform(get("/api/document/next"))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedContent, true));
    }

    @Test
    void apiTemplateCreatePost() throws Exception {
        initAuth();

        var template = new Template();
        template.setId("1");
        template.amount("123456");
        template.setDocType(Template.DocTypeEnum.DA);
        template.dboProId("dboProId");
        template.setName("Test");

        when(templateService.createTemplateFromDocument(any(), any(), any())).thenReturn(template);
        var path = ResourceUtils.getFile("classpath:json/TemplateResponse.json").toPath();
        var expectedContent = Files.readString(path);

        mvc.perform(post("/api/template/create")
                        .cookie(sessionCookie())
                        .content(objectMapper.writeValueAsBytes(new CreateTemplateRequest()))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(content().json(expectedContent, true));
    }

    @Test
    void apiTemplateSavePost() throws Exception {
        initAuth();

        var template = new Template();
        template.setId("1");
        template.amount("123456");
        template.setDocType(Template.DocTypeEnum.DA);
        template.dboProId("dboProId");
        template.setName("Test");

        when(templateService.saveTemplate(any(), any())).thenReturn(template);

        var path = ResourceUtils.getFile("classpath:json/TemplateResponse.json").toPath();
        var expectedContent = Files.readString(path);

        mvc.perform(post("/api/template/save")
                        .cookie(sessionCookie())
                        .content(objectMapper.writeValueAsBytes(new Template()))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(content().json(expectedContent, true));
    }

    @Test
    void apiTemplateIdDelete() throws Exception {
        initAuth();

        mvc.perform(delete("/api/template/{id}", "1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    void apiTemplateENPGet() throws Exception {
        initAuth();
        String enpName = "enpName";
        when(templateService.getTemplateENP())
                .thenReturn(new Template().name(enpName));
        mvc.perform(get("/api/template/ENP"))
                .andExpect(jsonPath("$.name").value(enpName));
    }

    @Test
    void apiTemplateFTSGet() throws Exception {
        initAuth();
        String ftsName = "ftsName";
        when(templateService.getTemplateFTS())
                .thenReturn(new Template().name(ftsName));
        mvc.perform(get("/api/template/FTS"))
                .andExpect(jsonPath("$.name").value(ftsName));
    }

    @Test
    void apiTemplateIncrement() throws Exception {
        initAuth();
        mvc.perform(post("/api/template/{id}/increment", "1"))
                .andExpect(status().isOk());
    }

    @Test
    void apiDocumentIdDelete() throws Exception {

        initAuth();

        when(paymentService.getDocument(any()))
                .thenReturn(new DocumentDTO()
                        .id(1)
                        .crmId("crmId")
                        .status(DocumentStatusDTO.CREATED)
                        .bisId(new ru.rosbank.platform.client.paymentapp.model.BisIdDTO().id("id").branch("branch"))
                        .payer(new RequisiteDTO().account("number")));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new ru.rosbank.platform.client.organizationapp.model
                                .BisIdDTO().id("id").branch("branch"))).crmId("crmId")));

        when(rolesService.getIndividual(any(), any()))
                .thenReturn(new IndividualDTO().accessGroup(CREATE_DELETE));

        mvc.perform(delete("/api/document/1")
                .cookie(sessionCookie()))
                .andExpect(status().isOk());
        Mockito.verify(paymentService, times(1)).deleteDocument(
                eq("1"));
        Awaitility.await().atMost(Duration.TEN_SECONDS)
                .untilAsserted(() -> Mockito.verify(auditAppApi, times(1)).rootPost(
                any()));
    }

    @Test
    void apiDeliveringResourceIdGetTest() throws Exception {
        initAuth();
        when(paymentService.getDeliveringResource(anyString())).thenReturn(new FileResource().name("test"));
        mvc.perform(get("/api/delivering-resource/1")
                        .cookie(sessionCookie()))
                .andExpect(status().isOk());
        Mockito.verify(paymentService, times(1)).getDeliveringResource(
                eq("1"));
    }

    @Test
    void apiDocumentIdSendFormatPostTest() throws Exception {
        initAuth();
        doNothing().when(paymentService).sendDocument(any(), anyString());
        mvc.perform(post("/api/document/send")
                        .cookie(sessionCookie())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(new DocumentSendRequestApi().phone("999999999"))))
                .andExpect(status().isOk());
        Mockito.verify(paymentService, times(1)).sendDocument(any(), anyString());
    }

    @Test
    void apiDocumentIdSendFormatPostNullParamTest() throws Exception {
        initAuth();
        doNothing().when(paymentService).sendDocument(any(), anyString());
        mvc.perform(post("/api/document/send")
                        .cookie(sessionCookie())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new DocumentSendRequestApi())))
                .andExpect(status().is4xxClientError());
        Mockito.verify(paymentService, times(0)).sendDocument(any(), anyString());
    }

    @Test
    void apiDocumentIdSendFormatPostEmptyParamTest() throws Exception {
        initAuth();
        doNothing().when(paymentService).sendDocument(any(), anyString());
        mvc.perform(post("/api/document/send")
                        .cookie(sessionCookie())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new DocumentSendRequestApi().phone("").email(""))))
                .andExpect(status().is4xxClientError());
        Mockito.verify(paymentService, times(0)).sendDocument(any(), anyString());
    }

    @Test
    void apiDocumentSignedCountCorrelationIdGetTest() throws Exception {
        initAuth();
        when(otpService.getOtpByUUID("correlationId")).thenReturn(new OtpDTO());
        when(signatureService.getSignaturesByOtp(any(OtpDTO.class))).thenReturn(List.of(
                new SignatureDTO().reference(new ReferenceDTO().id("1")).confirmed(false),
                new SignatureDTO().reference(new ReferenceDTO().id("2")).confirmed(true)
        ));
        when(paymentService.getSignedDocumentCount(any())).thenReturn(999);

        mvc.perform(get("/api/document/signed/count/correlationId")
                        .cookie(sessionCookie()))
                .andExpect(status().isOk());
        Mockito.verify(paymentService, times(1)).getSignedDocumentCount(eq(List.of(2L)));
    }

    @Test
    void createRefundValidateUserRightsException() throws Exception {
        initAuth();
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789011");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345");
        mvc.perform(post("/api/v1/refundsbp")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(sbpRefundInfoRequest))
                        .cookie(sessionCookie()))
                .andExpect(status().isForbidden());
    }

    @Test
    void createRefundValidateUserRightsException2() throws Exception {
        initAuth();
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345");
        mvc.perform(post("/api/v1/refundsbp")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(sbpRefundInfoRequest))
                        .cookie(sessionCookie()))
                .andExpect(status().isForbidden());
    }

    @Test
    void apicommissionGetTest() throws Exception {
        initAuth();
        when(clarificationService.commissionGet(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(BigDecimal.valueOf(500));
        mvc.perform(get("/api/v1/document/rectification/crm-id/1crm-id/document-id/Y1234/account/0123456789/commission")
                .cookie(sessionCookie()))
                .andExpect(status().isOk())
                .andExpect(content().string("500"));
        Mockito.verify(clarificationService, times(1)).commissionGet(
                eq("1crm-id"), eq("Y1234"), eq("0123456789"),
                eq("9044c6e4-3a31-4a35-a661-4a1f726ce805"));
    }

    @Test
    void apiDocumentCommissionCalculationPost() throws Exception {

        when(commissionService.getPaymentCommission(any(), any())).thenReturn(new PaymentCommission());

        initAuth();
        mvc.perform(post("/api/document/commission/calculation")
                .cookie(sessionCookie())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsBytes(new Payment())))
                .andExpect(status().isOk());
    }

    @Test
    void accountCdtBlockGet() throws Exception {

        initAuth();
        mvc.perform(get("/api/v1/accountCdtBlockGet?acc20=12345678901234567890&bic=bic")
                        .cookie(sessionCookie())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}