package ru.rosbank.paymentapi.commons;

import static ru.rosbank.paymentapi.commons.Constants.OS_TYPE_IOS;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.paymentapi.audit.AuditContext;

class ConstantsTest {

    @Test
    void getPlatform() {
        var context = new AuditContext();
        context.setUserAgent("iPhone11Pro 15.4.1");
        var result = Constants.getPlatform(context);
        Assertions.assertEquals(OS_TYPE_IOS, result);
    }
}