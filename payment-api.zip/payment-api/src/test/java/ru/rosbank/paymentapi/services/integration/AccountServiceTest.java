package ru.rosbank.paymentapi.services.integration;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletionException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.AccountsCachedResponseDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;

class AccountServiceTest extends BaseTest {

    @Autowired
    private AccountService accountService;
    @MockBean
    private AccountAppApiClient accountAppApiClient;

    @Test
    void getAccount() {
        when(accountAppApiClient.idGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(new AccountDTO(), HttpStatus.OK));
        AccountDTO account = accountService.getAccount("123");
        Assertions.assertNotNull(account);
    }

    @Test
    void getAccountList() {
        when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(
                        new AccountsCachedResponseDTO().accounts(Collections.singletonList(new AccountDTO())), HttpStatus.OK));
        List<AccountDTO> accountList = accountService.getAccountList("123", List.of(new BisIdDTO().id("123").branch("123")));
        Assertions.assertFalse(accountList.isEmpty());
    }

    @Test
    void getAccountsAsync() {
        Mockito.when(accountAppApiClient.organizationAccountsGet(eq("1-XYZ"), any(), any()))
                .thenReturn(new ResponseEntity<>(getAccountCachedDTOList().isActualData(false).responseDelay(3), HttpStatus.OK));
        AccountDTO accountDTO1 = new AccountDTO();
        accountDTO1.setNumber("123456890123456890");
        accountDTO1.setAccountType("CA");
        accountDTO1.setCurrency("RUB");
        accountDTO1.setHasRestrictions(true);
        accountDTO1.setOpenDate(LocalDate.now());
        accountDTO1.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));
        Mockito.when(accountAppApiClient.organizationAccountsGet(eq("2-XYZ"), any(), any()))
                .thenReturn(new ResponseEntity<>(new AccountsCachedResponseDTO()
                        .isActualData(false).responseDelay(3).accounts(Collections.singletonList(accountDTO1)), HttpStatus.OK));
        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("1-XYZ"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("2-XYZ"));
        List<AccountDTO> accountList = accountService.getAccountsAsync(orgList);
        Assertions.assertFalse(accountList.isEmpty());
        Assertions.assertTrue(accountList.size() == 6);
    }

    @Test
    void getMapCrmIdAndAccountsAsync() {
        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))).crmId("1-XYZ"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))).crmId("2-XYZ"));
        Mockito.when(accountAppApiClient.organizationAccountsGet(eq("2-XYZ"), any(), any()))
                .thenReturn(new ResponseEntity<>(getAccountCachedDTOList(), HttpStatus.OK));
        Mockito.when(accountAppApiClient.organizationAccountsGet(eq("1-XYZ"), any(), any()))
                .thenReturn(new ResponseEntity<>(new AccountsCachedResponseDTO().accounts(
                        Collections.singletonList(new AccountDTO())), HttpStatus.OK));
        var mapCrmIdAndAcc = accountService.getMapCrmIdAndAccountsAsync(orgList);
        Assertions.assertFalse(mapCrmIdAndAcc.isEmpty());
        Assertions.assertEquals(5, mapCrmIdAndAcc.get("2-XYZ").size());
        Assertions.assertEquals(1, mapCrmIdAndAcc.get("1-XYZ").size());
    }

    private AccountsCachedResponseDTO getAccountCachedDTOList() {
        AccountsCachedResponseDTO accountsCachedResponse = new AccountsCachedResponseDTO();
        accountsCachedResponse.setAccounts(getAccountDTOList());
        accountsCachedResponse.setIsActualData(true);
        return accountsCachedResponse;
    }

    private List<AccountDTO> getAccountDTOList() {
        AccountDTO accountDTO1 = new AccountDTO();
        accountDTO1.setNumber("123456890123456890");
        accountDTO1.setAccountType("CA");
        accountDTO1.setCurrency("RUB");
        accountDTO1.setHasRestrictions(true);
        accountDTO1.setOpenDate(LocalDate.now());
        accountDTO1.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        AccountDTO accountDTO2 = new AccountDTO();
        accountDTO2.setNumber("123456890123456891");
        accountDTO2.setAccountType("CD");
        accountDTO2.setCurrency("RUB");
        accountDTO2.setHasRestrictions(true);
        accountDTO2.setOverdraftAmount("0,00");
        accountDTO2.setRestAmount("2536,25");
        accountDTO2.setOpenDate(LocalDate.now());
        accountDTO2.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        AccountDTO accountDTO3 = new AccountDTO();
        accountDTO3.setNumber("123456890123456892");
        accountDTO3.setAccountType("CE");
        accountDTO3.setCurrency("RUB");
        accountDTO3.setHasRestrictions(true);
        accountDTO3.setOpenDate(LocalDate.now());
        accountDTO3.setReserveAmount("");
        accountDTO3.setRestAmount("-15,25");
        accountDTO3.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        // account with foreign currency
        AccountDTO accountDTO4 = new AccountDTO();
        accountDTO4.setNumber("123456890123456893");
        accountDTO4.setAccountType("CA");
        accountDTO4.setCurrency("USD");
        accountDTO4.setHasRestrictions(true);
        accountDTO4.setOpenDate(LocalDate.now());
        accountDTO4.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));

        AccountDTO accountDTO5 = new AccountDTO();
        accountDTO5.setNumber("123456890123456894");
        accountDTO5.setAccountType("CE");
        accountDTO5.setCurrency("USD");
        accountDTO5.setHasRestrictions(true);
        accountDTO5.setOpenDate(LocalDate.now());
        accountDTO5.setBisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("123").branch("R19"));
        return Arrays.asList(accountDTO1, accountDTO2, accountDTO3, accountDTO4, accountDTO5);
    }
}