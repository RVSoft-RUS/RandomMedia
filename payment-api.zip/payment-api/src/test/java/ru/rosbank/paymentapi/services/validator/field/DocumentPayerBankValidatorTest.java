package ru.rosbank.paymentapi.services.validator.field;

import static org.mockito.ArgumentMatchers.any;

import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;

class DocumentPayerBankValidatorTest extends BaseTest {
    @Autowired
    private DocumentPayerBankValidator payerBankValidator;
    @MockBean
    private ReferenceService referenceService;

    @Test
    void validate() {
        Mockito.when(referenceService.getBranch(any())).thenReturn(Collections.singletonList(new BranchDTO()
                .bik("0123456789").correspondentAccount("01234567890123456789").name("name")));
        DocumentDTO document = new DocumentDTO();

        payerBankValidator.validate(document, "branch");
        BankInfoDTO payerBank = document.getPayer().getBank();
        Assertions.assertEquals(payerBank.getBic(), "0123456789");
        Assertions.assertEquals(payerBank.getCorrespondentAccount(), "01234567890123456789");
        Assertions.assertEquals(payerBank.getName(), "name");

        document.setPayer(new RequisiteDTO().bank(new BankInfoDTO().correspondentAccount("456").name("78")));

        payerBankValidator.validate(document, "branch");
        payerBank = document.getPayer().getBank();
        Assertions.assertEquals(payerBank.getBic(), "0123456789");
        Assertions.assertEquals(payerBank.getCorrespondentAccount(), "456");
        Assertions.assertEquals(payerBank.getName(), "78");

        document.setPayer(new RequisiteDTO().bank(new BankInfoDTO().bic("123").correspondentAccount(null).name("78")));

        payerBankValidator.validate(document, "branch");
        payerBank = document.getPayer().getBank();
        Assertions.assertEquals(payerBank.getBic(), "123");
        Assertions.assertEquals(payerBank.getCorrespondentAccount(), "01234567890123456789");
        Assertions.assertEquals(payerBank.getName(), "78");

        document.setPayer(new RequisiteDTO().bank(new BankInfoDTO().bic("123").correspondentAccount("456").name(null)));

        payerBankValidator.validate(document, "branch");
        payerBank = document.getPayer().getBank();
        Assertions.assertEquals(payerBank.getBic(), "123");
        Assertions.assertEquals(payerBank.getCorrespondentAccount(), "456");
        Assertions.assertEquals(payerBank.getName(), "name");
    }

    @Test
    void validate1() {

        DocumentDTO document = new DocumentDTO();
        document.setPayer(new RequisiteDTO().bank(new BankInfoDTO().bic("123").correspondentAccount("456").name("78")));
        payerBankValidator.validate(document, "branch");
        BankInfoDTO payerBank = document.getPayer().getBank();
        Assertions.assertEquals(payerBank.getBic(), "123");
        Assertions.assertEquals(payerBank.getCorrespondentAccount(), "456");
        Assertions.assertEquals(payerBank.getName(), "78");
    }
}