package ru.rosbank.paymentapi.services.validator;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.notificationapp.api.NotificationAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class DefaultPaymentValidatorsTest extends BaseTest {

    @Autowired
    private DefaultPaymentValidators defaultPaymentValidators;
    @MockBean
    private AccountAppApiClient accountAppApiClient;
    @MockBean
    private NotificationAppApiClient notificationAppApi;

    @Test
    void validateOk() throws ValidationPaymentException {
        when(accountAppApiClient.idGet(anyString())).thenReturn(ResponseEntity.ok(new AccountDTO().accountType("CE")
                .bisId(new BisIdDTO().id("id").branch("R19"))));
        when(referenceAppApi.bankGet(anyString())).thenReturn(new ResponseEntity<>(List.of(new BankDTO()
                .correspondentAccount("30101810000000000256")), HttpStatus.OK));
        when(notificationAppApi.dfmblockGet(anyString(), anyString())).thenReturn(ResponseEntity.ok(false));
        var documentDTO = new DocumentDTO()
                .amount("10000")
                .kbk("kbk")
                .bisId(new ru.rosbank.platform.client.paymentapp.model.BisIdDTO().id("id").branch("R19"))
                .oktmo("oktmo")
                .number("1")
                .status(DocumentStatusDTO.CREATED)
                .codeTypeIncome("0")
                .taxPeriod("tax")
                .typeTaxPayment("0")
                .type(DocumentDTO.TypeEnum.DA)
                .purpose("purpose")
                .uin("0")
                .paymentPriority("5")
                .payee(new RequisiteDTO().account("account")
                        .inn("6831242360")
                        .kpp("582301383")
                        .name("name")
                        .account("40802810696430000396")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("30101810000000000256")))
                .payer(new RequisiteDTO()
                        .account("12345678900987654321")
                        .inn("6831242360")
                        .kpp("582301383")
                        .name("name")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount("30101810000000000256")))
                .crmId("1234");

        defaultPaymentValidators.validate(documentDTO);

    }

}