package ru.rosbank.paymentapi.services.validator.field;

import static org.mockito.ArgumentMatchers.any;
import static ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator.FORBIDDEN_PAYEE_ACCOUNT_MSG;
import static ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator.MONEYBOX_ERROR_MESSAGE;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

public class DocumentPayeeAccountValidatorTest extends BaseTest {


    private static final String ERROR_MSG_BIC_UTRA_643 = "Символы с 6 по 8 в номере счета должны быть равны 643";
    private static final String ACCOUNT_40102 = "40102810696430000396";
    private static final String ACCOUNT_UTRA_IS_NOT_643 = "00101644696430000396";
    private static final String ACCOUNT_UTRA_IS_643 = "00101643696430000396";
    private static final String BIC_TYPE_UTRA = "52";
    private static final String BIC_UTRA = "bicUtra";

    @Autowired
    DocumentPayeeAccountValidator validator;
    @MockBean
    ReferenceService referenceService;
    @MockBean
    DocumentTypeCalculatorImpl documentTypeCalculator;

    @Test
    void validateForbiddenAccounts() {
        var doc = new DocumentDTO()
                .payee(new RequisiteDTO()
                        .account(ACCOUNT_40102));
        Assertions.assertThatThrownBy(() -> validator.validate(doc))
                .isInstanceOf(ValidationPaymentException.class)
                .hasMessage(FORBIDDEN_PAYEE_ACCOUNT_MSG);
    }

    @Test
    void validateUtraBicAndAccIsNot643() {
        var doc = new DocumentDTO()
                .payee(new RequisiteDTO()
                        .account(ACCOUNT_UTRA_IS_NOT_643)
                        .bank(new BankInfoDTO()
                                .bic(BIC_UTRA)
                                .correspondentAccount(ACCOUNT_40102)));
        Mockito.when(referenceService.getBankInfo(BIC_UTRA))
                .thenReturn(Collections.singletonList(new BankDTO()
                        .bikType(BIC_TYPE_UTRA)));
        Assertions.assertThatThrownBy(() -> validator.validate(doc))
                .isInstanceOf(ValidationPaymentException.class)
                .hasMessage(ERROR_MSG_BIC_UTRA_643);
    }

    @Test
    void validateUtraBicAndAccIs643() {
        var doc = new DocumentDTO()
                .payee(new RequisiteDTO()
                        .account(ACCOUNT_UTRA_IS_643)
                        .bank(new BankInfoDTO()
                                .bic(BIC_UTRA)
                                .correspondentAccount(ACCOUNT_40102)));
        Mockito.when(referenceService.getBankInfo(BIC_UTRA))
                .thenReturn(Collections.singletonList(new BankDTO()
                        .bikType(BIC_TYPE_UTRA)));
        Assertions.assertThatCode(() -> validator.validate(doc))
                .doesNotThrowAnyException();
    }

    @Test
    void validate() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(false);
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        accountsMap.put("42606810512232454567", new AccountDTO().number("42606810512232454567"));
        accountsMap.put("40108810696430000397", new AccountDTO().number("40108810696430000397").accountType("CD"));

        var doc = new DocumentDTO()
                .payee(new RequisiteDTO()
                        .account("42606810512232454567")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount(ACCOUNT_40102)))
                .payer(new RequisiteDTO()
                        .account("40108810696430000397")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount(ACCOUNT_40102)));
        validator.validate(doc, accountsMap);

        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);
        validator.validate(doc, accountsMap);
    }

    @Test
    void testValidate() {

        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(false);
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        accountsMap.put("42606810512232454568", new AccountDTO().number("42606810512232454568"));
        accountsMap.put("40108810696430000397", new AccountDTO().number("40108810696430000397").accountType("CD"));
        var doc = new DocumentDTO()
                .payee(new RequisiteDTO()
                        .account("42606810512232454567")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount(ACCOUNT_40102)))
                .payer(new RequisiteDTO()
                        .account("40108810696430000397")
                        .bank(new BankInfoDTO()
                                .bic("044525256")
                                .correspondentAccount(ACCOUNT_40102)));
        Assertions.assertThatThrownBy(() -> validator.validate(doc, accountsMap))
                .isInstanceOf(ValidationPaymentException.class)
                .hasMessage(MONEYBOX_ERROR_MESSAGE);
    }
}
