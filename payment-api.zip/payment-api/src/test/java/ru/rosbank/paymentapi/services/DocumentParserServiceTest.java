package ru.rosbank.paymentapi.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ImportDocumentException;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;



/**
 * Summary.
 * @author rb068869
 */

public class DocumentParserServiceTest  extends BaseTest {
    public static final String ENCODING_WINDOWS_1251 = "Cp1251";

    @Autowired
    private DocumentParserService documentParserService;

    @Test
    public void parseDocumentTxt() throws IOException, ImportDocumentException {
        String s = IOUtils.toString(this.getClass().getResourceAsStream("/txt/_1c/document.txt"), StandardCharsets.UTF_8);
        List<DocumentDTO> documentList = documentParserService.parseDocumentsTxt(s.getBytes(ENCODING_WINDOWS_1251));
        DocumentDTO document = documentList.get(0);
        Assert.assertNotNull(document);
        Assert.assertEquals("28462.04", document.getAmount());
        Assert.assertEquals("40702810087870000526", document.getPayer().getAccount());
        Assert.assertEquals("40702810938000050000", document.getPayee().getAccount());
        Assert.assertEquals("7710914000", document.getPayer().getInn());
        Assert.assertEquals("9717052000", document.getPayee().getInn());
        Assert.assertEquals("774500000", document.getPayer().getKpp());
        Assert.assertEquals("771502002", document.getPayee().getKpp());
        Assert.assertEquals("ООО Ромашка", document.getPayer().getName());
        Assert.assertEquals("ООО \"ЦЕНТР\"", document.getPayee().getName());
        Assert.assertEquals("044525555", document.getPayer().getBank().getBic());
        Assert.assertEquals("044525225", document.getPayee().getBank().getBic());
        Assert.assertEquals("Оплата согл. Спецификации №**** от 11.11.2019г. по договору № МККК-188ПМ-2019 "
            + "от 11.11.2019Сумма 28462-04В т.ч. НДС  (20%) 4743-67", document.getPurpose());
        Assert.assertEquals("0", document.getUin());
        Assert.assertEquals("5", document.getPaymentPriority());
    }

    @Test
    public void parseDocumentTxt2() throws IOException, ImportDocumentException {
        String s = IOUtils.toString(this.getClass().getResourceAsStream("/txt/_1c/1с_to_kl.txt"), StandardCharsets.UTF_8);
        List<DocumentDTO> documentList = documentParserService.parseDocumentsTxt(s.getBytes(ENCODING_WINDOWS_1251));
        DocumentDTO document = documentList.get(0);

        Assert.assertNotNull(document);
        Assert.assertEquals("100.00", document.getAmount());
        Assert.assertEquals("40802810696430000396", document.getPayer().getAccount());
        Assert.assertEquals("40702810997880000716", document.getPayee().getAccount());
        Assert.assertEquals("500807892602", document.getPayer().getInn());
        Assert.assertEquals("7729755500", document.getPayee().getInn());
        Assert.assertEquals("Индивидуальный предприниматель Головачев Дмитрий Валерьевич", document.getPayer().getName());
        Assert.assertEquals("ООО \"Бизнесграфик\"", document.getPayee().getName());
        Assert.assertEquals("044525256", document.getPayer().getBank().getBic());
        Assert.assertEquals("044525256", document.getPayee().getBank().getBic());
        Assert.assertEquals("тестовый платеж для 1с Сумма 100-00 В т.ч. НДС  (20%) 16-67", document.getPurpose());
        Assert.assertEquals("5", document.getPaymentPriority());
    }

    @Test
    public void parseDocumentEmpty() throws IOException, ImportDocumentException {
        String s = IOUtils.toString(this.getClass().getResourceAsStream("/txt/_1c/empty.txt"), StandardCharsets.UTF_8);
        Assertions.assertThrows(ImportDocumentException.class,
            () -> documentParserService.parseDocumentsTxt(s.getBytes(ENCODING_WINDOWS_1251)));
    }

    @Test
    public void parseDocumentTxtBudget() throws IOException, ImportDocumentException {
        byte[] content = IOUtils.toString(this.getClass().getResourceAsStream("/txt/_1c/document_budget.txt"),
            StandardCharsets.UTF_8).getBytes(ENCODING_WINDOWS_1251);
        List<DocumentDTO> documentList = documentParserService.parseDocumentsTxt(content);
        DocumentDTO document = documentList.get(0);
        Assert.assertNotNull(document);
        Assert.assertEquals("12294.00", document.getAmount());
        Assert.assertEquals("40702810087870000526", document.getPayer().getAccount());
        Assert.assertEquals("00101810000000010003", document.getPayee().getAccount());
        Assert.assertEquals("7710914000", document.getPayer().getInn());
        Assert.assertEquals("2807010233", document.getPayee().getInn());
        Assert.assertEquals("280745001", document.getPayer().getKpp());
        Assert.assertEquals("280701001", document.getPayee().getKpp());
        Assert.assertEquals("ООО Ромашка", document.getPayer().getName());
        Assert.assertEquals("Межрайонная инспекция ФНС России №5 по Амурской области", document.getPayee().getName());
        Assert.assertEquals("044525555", document.getPayer().getBank().getBic());
        Assert.assertEquals("044525984", document.getPayee().getBank().getBic());
        Assert.assertEquals("Налог на доходы физических лиц за июль 2019 г. КПП 280740000  ОП Север",
            document.getPurpose());
        Assert.assertEquals("0", document.getUin());
        Assert.assertEquals("5", document.getPaymentPriority());
        Assert.assertEquals("18210102010011000110", document.getKbk());
        Assert.assertEquals("10700000", document.getOktmo());
        Assert.assertEquals("ТП", document.getPaymentBasis());
        Assert.assertEquals("0", document.getBasisDocumentCreated());
        Assert.assertEquals("0", document.getBasisDocumentNumber());
        Assert.assertEquals("МС.07.2019", document.getTaxPeriod());
        Assert.assertEquals("02", document.getPayerStatus());
    }

}
