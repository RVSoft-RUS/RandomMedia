package ru.rosbank.paymentapi.converter;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.BankInfoDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.client.statementapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;


public class CurrencyConverterTest extends BaseTest {

    @Test
    void convertCurrencyOther() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.DO);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_OTHER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertCO() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.CO);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_OTHER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }


    @Test
    void convertMemorialOrder() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.DL);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertDN() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.DN);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertCN() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.CN);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertCL() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.CL);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertCM() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.CM);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertDM() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.DM);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertDR() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.DR);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertCR() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.CR);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertDK() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.DK);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_TRANSACTION);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    @Test
    void convertCK() {
        PaymentDTO paymentDTO = getPaymentDTO();
        paymentDTO.setType(PaymentDTO.TypeEnum.CK);
        paymentDTO.setSubtype(PaymentDTO.SubtypeEnum.CURRENCY_TRANSACTION);
        Payment payment = CurrencyConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getCompleted(), payment.getCompleted());
    }

    private PaymentDTO getPaymentDTO() {
        PaymentDTO paymentDTO = new PaymentDTO();
        paymentDTO.setCompleted(OffsetDateTime.now());
        paymentDTO.setPayer(new RequisiteDTO());
        paymentDTO.setPayee(new RequisiteDTO());
        paymentDTO.setAmount(new AmountDTO());
        paymentDTO.getPayee().setBank(new BankInfoDTO());
        paymentDTO.getPayer().setBank(new BankInfoDTO());
        paymentDTO.getAmount().setCurrency("USD");
        paymentDTO.getAmount().setSum(new BigDecimal(1));
        paymentDTO.getAmount().setSumRur(new BigDecimal(60));
        paymentDTO.getPayee().getBank().setSwift("SWIFT");
        paymentDTO.getPayer().getBank().setSwift("SWIFT");
        paymentDTO.getPayee().setName("PayeeName");
        paymentDTO.getPayer().setName("PayerName");
        paymentDTO.setPurpose("Purpose");
        paymentDTO.getPayee().setAccount("PayeeAccount");
        paymentDTO.getPayer().setAccount("PayerAccount");
        paymentDTO.getPayee().getBank().setName("PayeeBankName");
        paymentDTO.getPayer().getBank().setName("PayerBankName");
        paymentDTO.setPaymentOrderDate(OffsetDateTime.now());
        paymentDTO.setPaymentOrderNumber("pOrderNumber");
        return paymentDTO;
    }


}
