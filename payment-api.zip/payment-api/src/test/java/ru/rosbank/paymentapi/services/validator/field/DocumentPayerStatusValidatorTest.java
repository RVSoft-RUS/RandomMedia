package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.DocumentPropertyImpl;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerStatusValidator;

class DocumentPayerStatusValidatorTest  extends BaseTest {
    @Autowired
    DocumentPropertyImpl documentProperty;
    @MockBean
    DocumentTypeCalculatorImpl documentTypeCalculator;

    @Test
    void validate() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setKbk("01qwERенГШ01qwERенГШ");
        document.setPayerStatus("31");
        document.setPayee(new RequisiteDTO());
        document.getPayee().setAccount("03212012340123456789");
        DocumentPayerStatusValidator validator = new DocumentPayerStatusValidator(documentTypeCalculator, documentProperty);
        validator.validate(document);
    }

    @Test
    void validateException() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setKbk("01qwERенГШ01qwERенГ%");
        document.setPayerStatus("31");
        document.setPayee(new RequisiteDTO());
        document.getPayee().setAccount("00000012340123456789");
        DocumentPayerStatusValidator validator = new DocumentPayerStatusValidator(documentTypeCalculator, documentProperty);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }


    @Test
    void validatePayeeAcc03100() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setKbk("01qwERенГШ01qwERенГШ");
        document.setPayerStatus("01");
        document.setPayee(new RequisiteDTO());
        document.getPayee().setAccount("03100012340123456789");
        DocumentPayerStatusValidator validator = new DocumentPayerStatusValidator(documentTypeCalculator, documentProperty);
        validator.validate(document);
    }

    @Test
    void validateExceptionPayeeAcc03100() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setKbk("01qwERенГШ01qwERенГШ");
        document.setPayerStatus("01");
        document.setPayee(new RequisiteDTO());
        document.getPayee().setAccount("03110012340123456789");
        DocumentPayerStatusValidator validator = new DocumentPayerStatusValidator(documentTypeCalculator, documentProperty);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }

    @Test
    void testStatus33() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        //Успешные проверки
        DocumentDTO document = new DocumentDTO();
        document.setPayee(new RequisiteDTO());
        document.getPayee().setAccount("40101810845250010102");
        document.setPayerStatus("33");
        document.setPayer(new RequisiteDTO());
        document.getPayer().setInn("12345");
        document.setBasisDocumentNumber("0");
        DocumentPayerStatusValidator validator = new DocumentPayerStatusValidator(documentTypeCalculator, documentProperty);
        assertDoesNotThrow(() -> validator.validate(document));
        document.getPayer().setInn("1234567890");
        assertDoesNotThrow(() -> validator.validate(document));
        document.getPayer().setInn("123456789012");
        assertDoesNotThrow(() -> validator.validate(document));
        document.getPayer().setInn("0");
        assertDoesNotThrow(() -> validator.validate(document));

        //Ошибка валидации
        document.setBasisDocumentNumber("123456");
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }
}