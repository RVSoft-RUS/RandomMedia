package ru.rosbank.paymentapi.services.validator.field;

import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;


class DocumentDateOnSignValidatorTest extends BaseTest {

    private static final long DAYS_BEFORE_FOR_EXCEPTION = 12;
    private static final long DAYS_AFTER_FOR_EXCEPTION = 32;

    @Test
    void validate() {
        DocumentDTO document = new DocumentDTO();
        document.setDate(OffsetDateTime.now().minusDays(3));

        DocumentDateOnSignValidator validator = new DocumentDateOnSignValidator();

        Assertions.assertDoesNotThrow(() -> validator.validate(document));

        document.setExecutionDate(OffsetDateTime.now().minusDays(3));
        Assertions.assertDoesNotThrow(() -> validator.validate(document));

        document.setExecutionDate(OffsetDateTime.now().minusDays(DAYS_BEFORE_FOR_EXCEPTION));
        Assertions.assertThrows(ValidationPaymentException.class, () -> validator.validate(document));

        document.setExecutionDate(OffsetDateTime.now().plusDays(DAYS_AFTER_FOR_EXCEPTION));
        Assertions.assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }
}