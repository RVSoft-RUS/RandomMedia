package ru.rosbank.paymentapi.services.reporting.template;

import freemarker.template.TemplateException;
import java.io.IOException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import ru.rosbank.paymentapi.services.reporting.template.impl.FreeMarkerTemplateEngine;

class TemplateMergerTest {
    FreeMarkerTemplateEngine engine;
    private TemplateMerger templateMerger;

    @BeforeEach
    public void init() throws TemplateException, IOException {
        FreeMarkerConfigurationFactoryBean configurationFactoryBean = new FreeMarkerConfigurationFactoryBean();
        engine = new FreeMarkerTemplateEngine(configurationFactoryBean.createConfiguration());
        templateMerger = new TemplateMerger(engine);
    }

    @Test
    void parameterTest() {
        templateMerger = templateMerger.parameter("Param1", "string");
        Assertions.assertNotNull(templateMerger);
        Assertions.assertThrows(IllegalArgumentException.class, () -> templateMerger.parameter("Param1", null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> templateMerger.parameter(null, ""));
    }
}