package ru.rosbank.paymentapi.services.reporting.pdfrenderer;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class PdfRendererTest {

    @Test
    void mainTest() {
        String[] args = {"1", "2"};
        Assertions.assertThrows(IllegalArgumentException.class, () -> PdfRenderer.main(args));
    }
}