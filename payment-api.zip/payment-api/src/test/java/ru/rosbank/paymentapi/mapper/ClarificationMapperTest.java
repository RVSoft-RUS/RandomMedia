package ru.rosbank.paymentapi.mapper;

import java.time.OffsetDateTime;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.paymentapi.rbsp.dto.PayeeInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

class ClarificationMapperTest extends BaseTest {
    @Autowired
    ClarificationMapper mapper;

    @Test
    void toRectification() {
        Clarification clr = new Clarification();
        clr.setClarificationId(1L);
        clr.setCreationDate(OffsetDateTime.now());
        clr.setOperationUid("OperationUid");
        clr.setCodeTypeIncome("CodeTypeIncome");
        clr.setTypeTaxPayment("TypeTaxPayment");
        clr.setUin("Uin");
        clr.setTaxPeriod("TaxPeriod");
        clr.setTaxPaymentReason("TaxPaymentReason");
        clr.setTaxOktmo("TaxOktmo");
        clr.setTaxKbk("TaxKbk");
        clr.setTaxDocNumber("TaxDocNumber");
        clr.setTaxDocDate("TaxDocDate");
        clr.setPayerAccNumber("PayerAccNumber");
        clr.setPurpose("\n тест \r\n test \n");
        PayeeInfo payeeInfo = new PayeeInfo();
        payeeInfo.setPayeeAccNumber("PayeeAccNumber");
        payeeInfo.setPayeeInn("PayeeInn");
        payeeInfo.setPayeeKpp("PayeeKpp");
        payeeInfo.setPayeeName("PayeeName");

        clr.setPayeeInfo(payeeInfo);

        Rectification rectification = mapper.toRectification(clr);
        Assertions.assertEquals(rectification.getId(), clr.getClarificationId());
        Assertions.assertEquals(ClarificationMapper.DATE_TIME_FORMATTER.format(rectification.getCreated()),
                ClarificationMapper.DATE_TIME_FORMATTER.format(clr.getCreationDate()));
        Assertions.assertEquals(rectification.getPayerAccount(), clr.getPayerAccNumber());
        Payment payment = new Payment();
        payment.setCreated(OffsetDateTime.now());
        payment.setNumber("number");
        payment.setPayer(new Requisite().account("PayerAccNumber"));
        Clarification clrNew = mapper.toClarification(rectification, payment,
                "orgId", "bisId", "bisBranch", "inn");

        Assertions.assertEquals(clrNew.getOperationUid(), clr.getOperationUid());
        Assertions.assertEquals(clrNew.getCodeTypeIncome(), clr.getCodeTypeIncome());
        Assertions.assertEquals(clrNew.getTypeTaxPayment(), clr.getTypeTaxPayment());
        Assertions.assertEquals(clrNew.getUin(), clr.getUin());
        Assertions.assertEquals(clrNew.getTaxPeriod(), clr.getTaxPeriod());
        Assertions.assertEquals(clrNew.getTaxPaymentReason(), clr.getTaxPaymentReason());
        Assertions.assertEquals(clrNew.getTaxOktmo(), clr.getTaxOktmo());
        Assertions.assertEquals(clrNew.getTaxKbk(), clr.getTaxKbk());
        Assertions.assertEquals(clrNew.getTaxDocNumber(), clr.getTaxDocNumber());
        Assertions.assertEquals(clrNew.getTaxDocDate(), clr.getTaxDocDate());
        Assertions.assertEquals(clrNew.getPayeeInfo().getPayeeAccNumber(), clr.getPayeeInfo().getPayeeAccNumber());
        Assertions.assertEquals(clrNew.getPayeeInfo().getPayeeInn(), clr.getPayeeInfo().getPayeeInn());
        Assertions.assertEquals(clrNew.getPayeeInfo().getPayeeKpp(), clr.getPayeeInfo().getPayeeKpp());
        Assertions.assertEquals(clrNew.getPayeeInfo().getPayeeName(), clr.getPayeeInfo().getPayeeName());
        Assertions.assertEquals(clrNew.getPaymentNumber(), "number");
        Assertions.assertEquals(clrNew.getPayerAccNumber(), clr.getPayerAccNumber());
        Assertions.assertEquals(clrNew.getCliType(), "LE");
        Assertions.assertEquals(clrNew.getPurpose(), "  тест    test  ");

        clrNew = mapper.toClarification(rectification, payment,
                "orgId", "bisId", "bisBranch", "012345678912");
        Assertions.assertEquals(clrNew.getCliType(), "IP");
        payment.setCreated(null);
        rectification.setPurpose(null);
        clrNew = mapper.toClarification(rectification, payment,
                "orgId", "bisId", "bisBranch", "012345678912");
        Assertions.assertNull(clrNew.getPurpose());
        Assertions.assertNull(clrNew.getPaymentDate());
    }
}