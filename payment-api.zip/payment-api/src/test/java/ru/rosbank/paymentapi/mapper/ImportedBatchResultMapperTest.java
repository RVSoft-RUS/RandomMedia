package ru.rosbank.paymentapi.mapper;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.platform.client.paymentapp.model.ImportedBatchResultDTO;
import ru.rosbank.platform.server.paymentapi.model.ImportedBatchResult;

class ImportedBatchResultMapperTest {

    @Test
    void fromDTO() {
        ImportedBatchResultDTO batch = new ImportedBatchResultDTO();
        batch.setId("1");
        ImportedBatchResult result = ImportedBatchResultMapper.INSTANCE.fromDTO(batch);
        Assertions.assertEquals(batch.getId(), result.getId());
    }
}