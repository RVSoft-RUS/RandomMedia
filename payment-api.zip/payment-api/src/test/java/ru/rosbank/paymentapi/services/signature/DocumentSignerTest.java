package ru.rosbank.paymentapi.services.signature;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

class DocumentSignerTest extends BaseTest {

    @Autowired
    DocumentSigner documentSigner;

    @MockBean
    CryptoproAppApi cryptoproAppApi;
    @MockBean
    OtpService otpService;
    @MockBean
    ProductService productService;
    @MockBean
    OrganizationService organizationService;

    @Test
    void sign() {
        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("di").branch("ranch")))
                        .crmId("idCrm"),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch")))
                        .crmId("crmId"));
        when(organizationService.getOrganizations(any())).thenReturn(orgList);
        when(cryptoproAppApi.certificateIdSignPost(any(), any()))
                .thenReturn(new ResponseEntity<>("certID", HttpStatus.OK));
        when(cryptoproAppApi.userIdCertificateGet(any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(new CertificateDTO()
                        .crmId("crmId")
                        .status(CertificateDTO.StatusEnum.ACTIVE)), HttpStatus.OK));
        when(otpService.generatePackageSignatureOtp(any(), any()))
                .thenReturn(new OtpDTO());
        when(productService.getOrganizationByAccNumberAndDboProId(any(),any()))
                .thenReturn(Optional.of(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch")))
                        .crmId("crmId")));
        var client = new ClientDTO();
        var docList =
                Arrays.asList(new DocumentDTO()
                                .id(1)
                                .payer(new RequisiteDTO()
                                        .account("40702810393790000591"))
                                .amount("100.00"),
                        new DocumentDTO()
                                .id(2)
                                .payer(new RequisiteDTO()
                                        .account("40702810393790000591"))
                                .amount("200.00"));
        var result = documentSigner.sign(client, docList);
        Assertions.assertNotNull(result);
    }
}