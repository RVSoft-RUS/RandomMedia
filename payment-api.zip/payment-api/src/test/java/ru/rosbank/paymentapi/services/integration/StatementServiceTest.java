package ru.rosbank.paymentapi.services.integration;

import com.netflix.hystrix.HystrixInvokable;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import feign.FeignException;
import java.time.OffsetDateTime;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.statementapp.api.StatementAppApiClient;
import ru.rosbank.platform.client.statementapp.model.AccountStatementDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;

class StatementServiceTest extends BaseTest {

    @Autowired
    StatementService statementService;

    @MockBean
    private StatementAppApiClient statementAppApiClient;

    @Test
    void getPayment() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new PaymentDTO(), HttpStatus.OK));

        var result = statementService.getPayment("123", "321");
        Assertions.assertNotNull(result);
    }

    @Test
    void getPaymentExceptionNotFound() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenThrow(new FeignException.NotFound("", getRequest(), null, null));

        var result = statementService.getPayment("123", "321");
        Assertions.assertNull(result);
    }

    @Test
    void getPaymentExceptionBadRequest() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenThrow(new FeignException.BadRequest("", getRequest(), null, null));

        var result = statementService.getPayment("123", "321");
        Assertions.assertNull(result);
    }

    @Test
    void getCardTransaction() {
        Mockito.when(statementAppApiClient.cardTransactionsDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new PaymentDTO(), HttpStatus.OK));

        var result = statementService.getCardTransaction("123", "321");
        Assertions.assertNotNull(result);
    }

    @Test
    void getCardTransactionNotFound() {
        Mockito.when(statementAppApiClient.cardTransactionsDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenThrow(new FeignException.NotFound("", getRequest(), null, null));

        var result = statementService.getCardTransaction("123", "321");
        Assertions.assertNull(result);
    }

    @Test
    void getCardTransactionBadRequest() {
        Mockito.when(statementAppApiClient.cardTransactionsDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenThrow(new FeignException.BadRequest("", getRequest(), null, null));

        var result = statementService.getCardTransaction("123", "321");
        Assertions.assertNull(result);
    }

    @Test
    public void testGetStatementList() {
        Mockito.when(statementAppApiClient.accountStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(),
                        Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new AccountStatementDTO().operations(getOperations()), HttpStatus.OK));

        String accountNumber = "accountNumber";
        String branch = "branch";
        OffsetDateTime from = OffsetDateTime.now();
        OffsetDateTime to = OffsetDateTime.now();
        String clientId = "clientId";
        var result = statementService.getStatementList(accountNumber, branch, from, to, clientId);

        Assertions.assertNotNull(result);
        Assertions.assertEquals(2, result.size());
    }

    @Test
    public void testGetStatementListWithCircuitBreaker() {
        Mockito.when(statementAppApiClient.accountStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(),
                        Mockito.any(), Mockito.any(), Mockito.any()))
                .thenAnswer((Answer<ResponseEntity<?>>) invocation -> new ResponseEntity<>(
                        new AccountStatementDTO().operations(getOperations()), HttpStatus.OK));

        String accountNumber = "accountNumber";
        String branch = "branch";
        OffsetDateTime from = OffsetDateTime.now();
        OffsetDateTime to = OffsetDateTime.now();
        String clientId = "clientId";
        var result = statementService.getStatementList(accountNumber, branch, from, to, clientId);

        Assertions.assertNotNull(result);
        Assertions.assertEquals(2, result.size());

        Mockito.when(statementAppApiClient.accountStatementOnlineGet(Mockito.any(), Mockito.any(), Mockito.any(),
                        Mockito.any(), Mockito.any(), Mockito.any()))
                .thenThrow(new HystrixRuntimeException(HystrixRuntimeException.FailureType.COMMAND_EXCEPTION,
                        HystrixInvokable.class, "", null, null));

        Assertions.assertThrows(HystrixRuntimeException.class,
            () ->  statementService.getStatementList(accountNumber, branch, from, to, clientId));
    }

    private List<PaymentDTO> getOperations() {
        return List.of(new PaymentDTO()
                        .id("1")
                        .created(OffsetDateTime.now()),
                new PaymentDTO()
                        .id("2")
                        .created(OffsetDateTime.now()));
    }
}