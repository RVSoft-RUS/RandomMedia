package ru.rosbank.paymentapi.services.integration;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;

class ReferenceServiceTest extends BaseTest {
    @Autowired
    ReferenceService referenceService;

    @Test
    void getBankInfo() {
        when(referenceAppApi.bankGet(anyString())).thenReturn(new ResponseEntity<>(Collections.singletonList(new BankDTO()
                .correspondentAccount("30101810000000000256")), HttpStatus.OK));
        Assertions.assertEquals(0, referenceService.getBankInfo(null).size());
        Assertions.assertEquals("30101810000000000256",
               referenceService.getBankInfo("0123456789").get(0).getCorrespondentAccount());
    }

    @Test
    void getBranch() {
        initBranches();

        Assertions.assertEquals("1", referenceService.getBranch(null).get(0).getInn());
    }

    @Test
    void isRosbankInn() {
        initBranches();

        Assertions.assertTrue(referenceService.isRosbankInn("3"));
        Assertions.assertFalse(referenceService.isRosbankInn("7730060165"));
    }

    @Test
    void branchCashTest() {
        initBranches();

        Assertions.assertEquals("1", referenceService.getBranch(null).get(0).getInn());
        Assertions.assertEquals("2", referenceService.getBranch(null).get(1).getInn());
        Assertions.assertEquals("R03", referenceService.getBranchForBic("33"));
        Assertions.assertEquals("3", referenceService.getBranch(null).get(2).getInn());
        Assertions.assertEquals("R03", referenceService.getBranchForBic("33"));
        Assertions.assertTrue(referenceService.isRosbankInn("4"));

        verify(referenceAppApi, Mockito.atMostOnce()).branchGet(any());
    }
}