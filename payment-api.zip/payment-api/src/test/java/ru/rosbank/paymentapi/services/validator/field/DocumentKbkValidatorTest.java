package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentKbkValidator;

class DocumentKbkValidatorTest  extends BaseTest {

    @MockBean
    DocumentTypeCalculatorImpl documentTypeCalculator;

    @Test
    void validate() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setKbk("01qwERенГШ01qwERенГШ");
        document.setPayerStatus("19");
        document.setPayer(new RequisiteDTO());
        DocumentKbkValidator validator =
                new DocumentKbkValidator(documentTypeCalculator);
        validator.validate(document);
    }

    @Test
    void validateException() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);

        DocumentDTO document = new DocumentDTO();
        document.setKbk("01qwERенГШ01qwERенГ");
        document.setPayerStatus("19");
        document.setPayer(new RequisiteDTO());
        DocumentKbkValidator validator =
                new DocumentKbkValidator(documentTypeCalculator);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }
}