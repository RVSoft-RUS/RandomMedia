package ru.rosbank.paymentapi.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApiClient;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.server.paymentapi.model.Template;

class TemplateServiceTest extends BaseTest {

    @Autowired
    TemplateService templateService;

    @MockBean
    PaymentAppApiClient paymentAppApi;


    @Test
    void search() {
        init();
        List<Template> templateList = templateService.search("test", "test");
        Template template = templateList.get(0);
        Assertions.assertEquals("123456", template.getAmount());
        Assertions.assertEquals("DA", template.getDocType().getValue());
    }

    @Test
    void createTemplateFromDocument() {
        var payment = new Payment();
        payment.setType(Payment.TypeEnum.CA);
        payment.setPayer(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setNumber("12345");
        payment.setAmount(new Amount().sum(BigDecimal.valueOf(50)));
        payment.setPayee(new Requisite().inn("").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setPaymentPriority("1");
        payment.setTaxPaymentType(false);


        var templateDTO = new TemplateDTO();
        templateDTO.setId("1");
        templateDTO.amount("123456");
        templateDTO.setDocType(TemplateDTO.DocTypeEnum.DA);
        templateDTO.dateCreated(LocalDate.now());
        templateDTO.dboProId("dboProId");
        templateDTO.setName("Test");

        var bank = new BankInfoDTO();
        bank.bic("044525256").correspondentAccount("30101810000000000256").name("Московский филиал ПАО \"РОСБАНК\"");
        var payee = new RequisiteDTO();
        payee.account("40702810097370000155").inn("7716859727").kpp("0").name("ООО ТРАНС-ТК").bank(bank);
        templateDTO.setPayee(payee);
        templateDTO.setPayer(payee);

        when(paymentAppApi.templatePost(any())).thenReturn(new ResponseEntity<>(templateDTO, HttpStatus.OK));

        var template = templateService.createTemplateFromDocument(payment, "name", "dboProId");
        Assertions.assertEquals("123456", template.getAmount());
        Assertions.assertEquals("1", template.getId());
        Assertions.assertEquals(Template.DocTypeEnum.DA, template.getDocType());
        Assertions.assertEquals("dboProId", template.getDboProId());
        Assertions.assertEquals("Test", template.getName());
    }

    @Test
    void saveTemplate() {
        var templateDTO = new TemplateDTO();
        templateDTO.setId("1");
        templateDTO.amount("123456");
        templateDTO.setDocType(TemplateDTO.DocTypeEnum.DA);
        templateDTO.dateCreated(LocalDate.now());
        templateDTO.dboProId("dboProId");
        templateDTO.setName("Test");

        var bank = new BankInfoDTO();
        bank.bic("044525256").correspondentAccount("30101810000000000256").name("Московский филиал ПАО \"РОСБАНК\"");
        var payee = new RequisiteDTO();
        payee.account("40702810097370000155").inn("7716859727").kpp("0").name("ООО ТРАНС-ТК").bank(bank);
        templateDTO.setPayee(payee);
        templateDTO.setPayer(payee);

        when(paymentAppApi.templateIdPost(any(), any())).thenReturn(new ResponseEntity<>(templateDTO, HttpStatus.OK));

        var saveTemplate = templateService.saveTemplate(new Template(), "dboProId");
        Assertions.assertEquals("123456", saveTemplate.getAmount());
        Assertions.assertEquals("1", saveTemplate.getId());
        Assertions.assertEquals(Template.DocTypeEnum.DA, saveTemplate.getDocType());
        Assertions.assertEquals("dboProId", saveTemplate.getDboProId());
        Assertions.assertEquals("Test", saveTemplate.getName());

    }

    @Test
    void createTemplateFromDocumentBackendException() {
        var payment = new Payment();
        payment.setType(Payment.TypeEnum.CA);
        payment.setPayer(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setNumber("12345");
        payment.setAmount(new Amount().sum(BigDecimal.valueOf(50)));
        payment.setPayee(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setPaymentPriority("01");
        payment.setTaxPaymentType(true);

        when(paymentAppApi.templatePost(any())).thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        Assertions.assertThrows(BackendException.class, () -> templateService
                .createTemplateFromDocument(payment, "name", "dboProId"));
    }

    @Test
    void createTemplateFromDocumentAnotherBackendException() {
        var payment = new Payment();
        payment.setType(Payment.TypeEnum.CA);
        payment.setPayer(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setNumber("12345");
        payment.setAmount(new Amount().sum(BigDecimal.valueOf(50)));
        payment.setPayee(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setPaymentPriority("01");
        payment.setTaxPaymentType(true);

        when(paymentAppApi.templatePost(any()))
                .thenReturn(new ResponseEntity<>(new TemplateDTO(), HttpStatus.INTERNAL_SERVER_ERROR));
        Assertions.assertThrows(BackendException.class, () -> templateService
                .createTemplateFromDocument(payment, "name", "dboProId"));
    }

    @Test
    void saveTemplateBackendException() {
        when(paymentAppApi.templateIdPost(any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        Assertions.assertThrows(BackendException.class, () -> templateService.saveTemplate(new Template(), "dboProId"));
    }

    @Test
    void saveTemplateAnotherBackendException() {
        when(paymentAppApi.templateIdPost(any(), any()))
                .thenReturn(new ResponseEntity<>(new TemplateDTO(), HttpStatus.INTERNAL_SERVER_ERROR));
        Assertions.assertThrows(BackendException.class, () -> templateService.saveTemplate(new Template(), "dboProId"));
    }

    @Test
    void saveTemplateFeignException() {
        byte[] body = new byte[]{1, 2, 3, 4};
        Request request = Request.create(Request.HttpMethod.GET, "url",
                new HashMap<>(), null, new RequestTemplate());
        when(paymentAppApi.templateIdPost(any(), any()))
                .thenThrow(new FeignException.NotFound("", request, body, null));
        Assertions.assertThrows(BackendException.class, () -> templateService.saveTemplate(new Template(), "dboProId"));
    }

    @Test
    void createTemplateFromDocumentFeignException() {
        var payment = new Payment();
        payment.setType(Payment.TypeEnum.CA);
        payment.setPayer(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setNumber("12345");
        payment.setAmount(new Amount().sum(BigDecimal.valueOf(50)));
        payment.setPayee(new Requisite().inn("0123456789").name("ООО тест").bank(new BankInfo().bic("123456789")));
        payment.setPaymentPriority("02");

        byte[] body = new byte[]{1, 2, 3, 4};
        Request request = Request.create(Request.HttpMethod.GET, "url",
                new HashMap<>(), null, new RequestTemplate());
        when(paymentAppApi.templatePost(any())).thenThrow(new FeignException.NotFound("", request, body, null));
        Assertions.assertThrows(BackendException.class, () -> templateService
                .createTemplateFromDocument(payment, "name", "dboProId"));
    }

    @Test
    void deleteTemplate() {
        when(paymentAppApi.templateIdDelete(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        templateService.deleteTemplate("1", "dboProId");
    }

    private void init() {
        var templateDTO = new TemplateDTO();
        templateDTO.setId("1");
        templateDTO.amount("123456");
        templateDTO.setDocType(TemplateDTO.DocTypeEnum.DA);
        templateDTO.dateCreated(LocalDate.now());
        templateDTO.dboProId("dboProId");
        templateDTO.setName(" Test");

        var bank = new BankInfoDTO();
        bank.bic("044525256").correspondentAccount("30101810000000000256").name("Московский филиал ПАО \"РОСБАНК\"");
        var payee = new RequisiteDTO();
        payee.account("40702810097370000155").inn("7716859727").kpp("0").name("ООО ТРАНС-ТК").bank(bank);
        templateDTO.setPayee(payee);
        templateDTO.setPayer(payee);

        when(paymentAppApi.templateSearchGet(any(), any(), any())).thenReturn(
                new ResponseEntity<>(Collections.singletonList(templateDTO), HttpStatus.OK));
        var organizationDTO = new OrganizationDTO();
        organizationDTO.setCrmId("1-QZ2-99");
        organizationDTO.setShortName("org name");
        organizationDTO.setInn("12345");

        var bisIdDTOS = Collections.singletonList(new BisIdDTO());
        organizationDTO.setBisIds(bisIdDTOS);
        var organizationDTOS = Collections.singletonList(organizationDTO);

    }

    @Test
    void getTemplateENP() {
        String enpName = "enpName";
        when(paymentAppApi.templateGet("ENP", "1", "0", null))
                .thenReturn(ResponseEntity.ok(Collections.singletonList(new TemplateDTO().name(enpName))));
        Template templateENP = templateService.getTemplateENP();
        org.assertj.core.api.Assertions.assertThat(templateENP.getName()).isEqualTo(enpName);
    }

    @Test
    void getTemplateFTS() {
        String ftsName = "ftsName";
        when(paymentAppApi.templateGet("FTS",  "1", "0", null))
                .thenReturn(ResponseEntity.ok(Collections.singletonList(new TemplateDTO().name(ftsName))));
        Template templateFTS = templateService.getTemplateFTS();
        org.assertj.core.api.Assertions.assertThat(templateFTS.getName()).isEqualTo(ftsName);
    }

    @Test
    void apiTemplateIncrement() {

        when(paymentAppApi.templateIdGet(any(), any())).thenReturn(new ResponseEntity<>(
                new ru.rosbank.platform.client.paymentapp.model.TemplateDTO().name("Name"), HttpStatus.OK));
        templateService.apiTemplateIdIncrementPost("1", "2");
        Mockito.verify(paymentAppApi, times(1)).templateIdIncrementPost(eq("1"));
    }

    @Test
    void apiTemplateIncrementException() {

        when(paymentAppApi.templateIdGet(any(), any())).thenReturn(new ResponseEntity<>(
                null, HttpStatus.OK));
        templateService.apiTemplateIdIncrementPost("1", "2");
        Mockito.verify(paymentAppApi, times(0)).templateIdIncrementPost(eq("1"));
    }
}
