package ru.rosbank.paymentapi.services;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ImportDocumentException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.paymentapi.services.validator.DocumentValidator;
import ru.rosbank.paymentapi.util.OrganizationAcc;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;
import ru.rosbank.platform.server.paymentapi.model.ImportedBatchResult;
import ru.rosbank.platform.server.paymentapi.model.ImportedDocument;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

class DocumentImportServiceTest extends BaseTest {
    @Autowired
    DocumentImportService documentImportService;
    @MockBean
    PaymentAppApiClient paymentAppApi;
    @MockBean
    AccountService accountService;
    @MockBean
    ReferenceService referenceService;
    @MockBean
    ProductService productService;
    @MockBean
    DocumentValidator documentValidator;

    @Test
    void createInvalidBatch() throws IOException, ImportDocumentException {
        Mockito.doThrow(new ValidationPaymentException(17, "", ""))
                .when(documentValidator).validateImportedDoc(any(), any(), any());
        ru.rosbank.platform.client.referenceapi.model.BankDTO bankDTO
                = new ru.rosbank.platform.client.referenceapi.model.BankDTO();
        bankDTO.setBic("bic");
        bankDTO.setName("name");
        bankDTO.setCorrespondentAccount("accaunt");
        BisIdDTO bisIdDTO = new BisIdDTO();
        bisIdDTO.setBranch("R19");
        BranchDTO branchDTO = new BranchDTO();
        branchDTO.setBik("bic");
        branchDTO.setCode("code");
        branchDTO.setName("name");
        branchDTO.setCorrespondentAccount("corrAcc");
        List<BranchDTO> branchDTOList = new ArrayList<>();
        branchDTOList.add(branchDTO);
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setBisId(bisIdDTO);
        accountDTO.setNumber("40802810193770000006");

        when(accountService.getAccount(any())).thenReturn(accountDTO);
        when(accountService.getAccountList(any(), any(String.class)))
                .thenReturn(Collections.singletonList(accountDTO));
        Map<String, List<AccountDTO>> crmIdAccountMap = new HashMap<>();
        crmIdAccountMap.put("crmId", Collections.singletonList(accountDTO));
        when(productService.getAccounts(any(String.class)))
                .thenReturn(crmIdAccountMap);
        when(referenceService.getBranch(any())).thenReturn(Collections.singletonList(branchDTO));
        BankInfoDTO bankInfoDTO = new BankInfoDTO();
        bankInfoDTO.setBic("bic");
        bankInfoDTO.setName("name");
        bankInfoDTO.setCorrespondentAccount("corrAcc");


        Mockito.when(paymentAppApi.importedPost(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>("Batch", HttpStatus.OK));
        when(referenceAppApi.bankGet(anyString())).thenReturn(new ResponseEntity<>(Collections.singletonList(new BankDTO()
                .correspondentAccount("30101810000000000256")), HttpStatus.OK));
        File docFile = ResourceUtils.getFile("classpath:txt/1c_test.txt");
        FileInputStream fis2 = new FileInputStream(docFile);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(fis2.readAllBytes());
        ImportedBatchResult result = documentImportService.createBatch(byteArrayOutputStream.toByteArray(), "test");
        Assertions.assertEquals(2, result.getInvalidPaymentsCount());
        Assertions.assertEquals("Batch", result.getId());
    }

    @Test
    void updateImportedDocument() {
        when(paymentAppApi.importedDocumentPost(any(), any())).thenReturn(new ResponseEntity<>(new ImportedDocumentDTO(),
                HttpStatus.OK));

        AccountDTO accountDTO = new AccountDTO();
        BisIdDTO bisIdDTO = new BisIdDTO();
        bisIdDTO.setBranch("R19");
        accountDTO.setBisId(bisIdDTO);
        accountDTO.setNumber("40802810193770000006");
        OrganizationAcc orgAcc = new OrganizationAcc();
        orgAcc.setAccounts(Collections.singletonList(accountDTO));
        when(productService.getOrganizationAccByAccNumberAndDboProId(any(String.class), any(String.class)))
                .thenReturn(orgAcc);
        ImportedDocument importedDocument = new ImportedDocument();
        importedDocument.setPayer(new Requisite().account("40802810193770000006"));

        documentImportService.updateImportedDocument(importedDocument, "dboProId");
    }

    @Test
    void createValidBatch() throws IOException, ImportDocumentException {
        Mockito.doThrow(new ValidationPaymentException(17, "", ""))
                .when(documentValidator).validateImportedDoc(any(), any(), any());
        ru.rosbank.platform.client.referenceapi.model.BankDTO bankDTO
                = new ru.rosbank.platform.client.referenceapi.model.BankDTO();
        bankDTO.setBic("bic");
        bankDTO.setName("name");
        bankDTO.setCorrespondentAccount("accaunt");
        BisIdDTO bisIdDTO = new BisIdDTO();
        bisIdDTO.setBranch("R19");
        BranchDTO branchDTO = new BranchDTO();
        branchDTO.setBik("bic");
        branchDTO.setCode("code");
        branchDTO.setName("name");
        branchDTO.setCorrespondentAccount("corrAcc");
        List<BranchDTO> branchDTOList = new ArrayList<>();
        branchDTOList.add(branchDTO);
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setBisId(bisIdDTO);
        accountDTO.setNumber("40802810193770000006");

        when(accountService.getAccount(any())).thenReturn(accountDTO);
        when(accountService.getAccountList(any(), any(String.class)))
                .thenReturn(Collections.singletonList(accountDTO));
        Map<String, List<AccountDTO>> crmIdAccountMap = new HashMap<>();
        crmIdAccountMap.put("crmId", Collections.singletonList(accountDTO));
        when(productService.getAccounts(any(String.class)))
                .thenReturn(crmIdAccountMap);
        when(referenceService.getBranch(any())).thenReturn(Collections.singletonList(branchDTO));
        BankInfoDTO bankInfoDTO = new BankInfoDTO();
        bankInfoDTO.setBic("bic");
        bankInfoDTO.setName("name");
        bankInfoDTO.setCorrespondentAccount("corrAcc");


        Mockito.when(paymentAppApi.importedPost(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>("Batch", HttpStatus.OK));
        when(referenceAppApi.bankGet(anyString())).thenReturn(new ResponseEntity<>(Collections.singletonList(new BankDTO()
                .correspondentAccount("30101810000000000256")), HttpStatus.OK));
        File docFile = ResourceUtils.getFile("classpath:txt/1c_test_with_date.txt");
        FileInputStream fis2 = new FileInputStream(docFile);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(fis2.readAllBytes());
        ImportedBatchResult result = documentImportService.createBatch(byteArrayOutputStream.toByteArray(), "test");
        Assertions.assertEquals(1, result.getInvalidPaymentsCount());
        Assertions.assertEquals("Batch", result.getId());
    }
}