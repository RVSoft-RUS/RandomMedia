package ru.rosbank.paymentapi.mapper;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.PaymentPayeeDto;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.PaymentQrDto;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoDto;
import ru.rosbank.paymentapi.model.feign.refundapi.CurrencyAmountEnum;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundData;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoRequest;

class RefundDataMapperTest extends BaseTest {

    @Autowired
    RefundDataMapper refundDataMapper;

    @Test
    void convertTest() {
        String expectedQrcIdr = "123";
        String expectedTrxId = "456";
        String expectedAmount = "1000000";
        String expectedAccountLegal = "40817810570000123456";
        String expectedMerchantId = "789";
        String expectedTin = "123456789012";
        String expectedReasonText = "Возврат СБП";
        QrInfoDto qrInfoDto = QrInfoDto.builder()
                .payment(PaymentQrDto.builder().qrId(expectedQrcIdr).id(expectedTrxId).build())
                .payee(PaymentPayeeDto.builder().merchantId(expectedMerchantId).inn(expectedTin).build())
                .build();
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAccount(expectedAccountLegal);
        sbpRefundInfoRequest.setReasonText(expectedReasonText);
        RefundData expectedRefundData = RefundData
                .builder()
                .qrcIdr(expectedQrcIdr)
                .trxId(expectedTrxId)
                .amount(expectedAmount)
                .accountLegal(expectedAccountLegal)
                .currencyAmount(CurrencyAmountEnum.RUB)
                .merchantId(expectedMerchantId)
                .tin(expectedTin)
                .reasonText(expectedReasonText)
                .build();

        RefundData refundData = refundDataMapper.convert(qrInfoDto, sbpRefundInfoRequest, expectedAmount);
        assertThat(refundData).isEqualTo(expectedRefundData);
    }

}