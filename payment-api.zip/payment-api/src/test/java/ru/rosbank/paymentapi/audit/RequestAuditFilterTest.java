package ru.rosbank.paymentapi.audit;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;

class RequestAuditFilterTest extends BaseTest {
    @Autowired
    RequestAuditFilter requestAuditFilter;

    @Test
    void fillFromDevice() {
        String device = "{\"platform\": \"ANDROID\", \"os\":\"28\", \"model\": \"SM-11A\", \"man\":\"Samsung\"}";
        AuditContext auditContext = new AuditContext();
        requestAuditFilter.fillFromDevice(device, auditContext);
        assertEquals(auditContext.os, "28");
        assertEquals(auditContext.model, "SM-11A");
        assertEquals(auditContext.man, "Samsung");
    }

    @Test
    void fillFromDevice2() {
        String device = "{\"platform\": \"ANDROID\", \"os\":\"28\", \"model\": \"SM-11A\"}";
        AuditContext auditContext = new AuditContext();
        requestAuditFilter.fillFromDevice(device, auditContext);
        assertEquals(auditContext.os, "28");
        assertEquals(auditContext.model, "SM-11A");
        assertNull(auditContext.man);
    }

    @Test
    void fillFromDeviceNull() {
        AuditContext auditContext = new AuditContext();
        requestAuditFilter.fillFromDevice(null, auditContext);
        assertNull(auditContext.os);
        assertNull(auditContext.model);
        assertNull(auditContext.man);
    }
}