package ru.rosbank.paymentapi.converter;


import org.junit.Assert;
import org.junit.jupiter.api.Test;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

class BankOrderConverterTest {

    @Test
    void convert() {
        PaymentDTO paymentDTO = new PaymentDTO().number("123");
        Payment payment = BankOrderConverter.convert(paymentDTO);
        Assert.assertEquals(paymentDTO.getNumber(), payment.getNumber());
    }
}