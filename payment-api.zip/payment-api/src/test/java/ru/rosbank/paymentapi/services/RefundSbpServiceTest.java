package ru.rosbank.paymentapi.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.github.fppt.jedismock.RedisServer;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.IncorrectRefundStatusException;
import ru.rosbank.paymentapi.exception.IncorrectResponseException;
import ru.rosbank.paymentapi.exception.InvalidOrganizationException;
import ru.rosbank.paymentapi.exception.NoRightsException;
import ru.rosbank.paymentapi.feign.QrPaymentApiFeignClient;
import ru.rosbank.paymentapi.feign.RefundApiFeignClient;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.PaymentPayeeDto;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoDto;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoResponse;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.ResultDto;
import ru.rosbank.paymentapi.model.feign.refundapi.GetRefundResponse;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundObject;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundStatus;
import ru.rosbank.paymentapi.model.feign.refundapi.ResponseMetadata;
import ru.rosbank.paymentapi.model.feign.refundapi.WebResponseCreateRefundResponse;
import ru.rosbank.paymentapi.model.feign.refundapi.WebResponseGetRefundResponse;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApi;
import ru.rosbank.platform.client.rolesapp.model.RightsDTO;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoRequest;

class RefundSbpServiceTest extends BaseTest {

    private static RedisServer server;
    private static Jedis jedis;

    @Autowired
    RefundSbpService refundSbpService;
    @MockBean
    QrPaymentApiFeignClient qrPaymentApiFeignClient;
    @MockBean
    RolesAppApi rolesAppApi;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    RefundApiFeignClient refundApiFeignClient;
    @MockBean
    JedisPool jedisPool;

    @BeforeAll
     static void setup() throws IOException {
        server = RedisServer
                .newRedisServer(1234, InetAddress.getByName("127.0.0.1"))
                .start();
        jedis = new Jedis(server.getHost(), server.getBindPort());
    }

    @AfterAll
    static void cleanUp() throws IOException {
        server.stop();
    }

    @Test
    void createRefundGetQrInfoException() {
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().result(
                        ResultDto.builder().status(401).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        Assertions.assertThrows(IncorrectResponseException.class,
            () -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
    }

    @Test
    void createRefundValidateUserRightsException() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789011");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        Assertions.assertThrows(InvalidOrganizationException.class,
            () -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
    }

    @Test
    void createRefundValidateUserRightsException2() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        Assertions.assertThrows(NoRightsException.class,
            () -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
    }

    @Test
    void createRefundPostException() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        RightsDTO rights = new RightsDTO();
        rights.setStatus(RightsDTO.StatusEnum.ACCESS);
        rights.setAccessRights(RightsDTO.AccessRightsEnum.ALL);
        list.add(rights);
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        when(refundApiFeignClient.refundPost(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        when(jedisPool.getResource()).thenReturn(jedis);
        Assertions.assertThrows(IncorrectResponseException.class,
            () -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
    }

    @Test
    void createRefundPollException() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        RightsDTO rights = new RightsDTO();
        rights.setStatus(RightsDTO.StatusEnum.ACCESS);
        rights.setAccessRights(RightsDTO.AccessRightsEnum.ALL);
        list.add(rights);
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        when(refundApiFeignClient.refundPost(any(), any())).thenReturn(
                new ResponseEntity<>(
                        WebResponseCreateRefundResponse.builder().data(
                                RefundObject.builder().build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(WebResponseGetRefundResponse.builder().build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        when(jedisPool.getResource()).thenReturn(jedis);
        Assertions.assertThrows(IncorrectResponseException.class,
            () -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
    }

    @Test
    void createRefundPollFailedStatus() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        RightsDTO rights = new RightsDTO();
        rights.setStatus(RightsDTO.StatusEnum.ACCESS);
        rights.setAccessRights(RightsDTO.AccessRightsEnum.ALL);
        list.add(rights);
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        when(refundApiFeignClient.refundPost(any(), any())).thenReturn(
                new ResponseEntity<>(
                        WebResponseCreateRefundResponse.builder().data(
                                RefundObject.builder().build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.FAILED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        when(jedisPool.getResource()).thenReturn(jedis);
        Assertions.assertThrows(IncorrectRefundStatusException.class,
            () -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
    }

    @Test
    void createRefundPollConfirmedStatus() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        RightsDTO rights = new RightsDTO();
        rights.setStatus(RightsDTO.StatusEnum.ACCESS);
        rights.setAccessRights(RightsDTO.AccessRightsEnum.ALL);
        list.add(rights);
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        when(refundApiFeignClient.refundPost(any(), any())).thenReturn(
                new ResponseEntity<>(
                        WebResponseCreateRefundResponse.builder().data(
                                RefundObject.builder().build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.CONFIRMED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        when(jedisPool.getResource()).thenReturn(jedis);
        Assertions.assertDoesNotThrow(() -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
    }

    @Test
    void createRefundNewPaymentRedis() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        RightsDTO rights = new RightsDTO();
        rights.setStatus(RightsDTO.StatusEnum.ACCESS);
        rights.setAccessRights(RightsDTO.AccessRightsEnum.ALL);
        list.add(rights);
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        when(refundApiFeignClient.refundPost(any(), any())).thenReturn(
                new ResponseEntity<>(
                        WebResponseCreateRefundResponse.builder().data(
                                RefundObject.builder().build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.CONFIRMED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345");
        when(jedisPool.getResource()).thenReturn(jedis);
        Assertions.assertDoesNotThrow(() -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
        verify(refundApiFeignClient, times(1)).refundPost(any(UUID.class),any());
    }

    @Test
    void createRefundAlreadyCreatedPaymentRedis() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(qrPaymentApiFeignClient.qrPaymentPaymentBisReferenceGet(any(), any()))
                .thenReturn(new ResponseEntity<>(QrInfoResponse.builder().data(data).result(
                        ResultDto.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        List<RightsDTO> list = new ArrayList<>();
        RightsDTO rights = new RightsDTO();
        rights.setStatus(RightsDTO.StatusEnum.ACCESS);
        rights.setAccessRights(RightsDTO.AccessRightsEnum.ALL);
        list.add(rights);
        when(rolesAppApi.rightsGet(any(), any()))
                .thenReturn(new ResponseEntity<>(list, HttpStatus.OK));
        List<OrganizationDTO> organizations = new ArrayList<>();
        OrganizationDTO org = new OrganizationDTO();
        org.setInn("123456789012");
        organizations.add(org);
        when(organizationService.getOrganizations(any()))
                .thenReturn(organizations);
        when(refundApiFeignClient.refundPost(any(), any())).thenReturn(
                new ResponseEntity<>(
                        WebResponseCreateRefundResponse.builder().data(
                                RefundObject.builder().build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.CONFIRMED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        BigDecimal amountRub = BigDecimal.valueOf(100_000L);
        sbpRefundInfoRequest.setAmount(amountRub);
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        sbpRefundInfoRequest.setPaymentId("12345600");
        when(jedisPool.getResource()).thenReturn(jedis);
        BigDecimal amountKopecks = amountRub.movePointRight(2);
        String uniquePaymentKey = "sbp_refund:" + "123456" + "_" + amountKopecks.toPlainString();
        String idempotenceKey = "84dfdcf2-d7d8-4666-8bf4-5cb6c602c16e";
        jedis.set(uniquePaymentKey, idempotenceKey);
        Assertions.assertDoesNotThrow(() -> refundSbpService.createRefund(sbpRefundInfoRequest, "12345"));
        verify(refundApiFeignClient, times(1))
                .refundPost(eq(UUID.fromString(idempotenceKey)), any());
    }

    @Test
    void executeRefundPollFailedStatus() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(refundApiFeignClient.refundDocumentIdExecutePatch(any())).thenReturn(
                new ResponseEntity<>(
                        WebResponseCreateRefundResponse.builder().data(
                                RefundObject.builder().build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.FAILED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        Assertions.assertThrows(IncorrectRefundStatusException.class,
            () -> refundSbpService.executeRefund(UUID.randomUUID()));
    }

    @Test
    void executeRefundPollCompletedStatus() {
        QrInfoDto data = new QrInfoDto();
        data.setPayee(PaymentPayeeDto.builder().inn("123456789012").build());
        when(refundApiFeignClient.refundDocumentIdExecutePatch(any())).thenReturn(
                new ResponseEntity<>(
                        WebResponseCreateRefundResponse.builder().data(
                                RefundObject.builder().build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.COMPLETED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        Assertions.assertDoesNotThrow(() -> refundSbpService.executeRefund(UUID.randomUUID()));
    }

}