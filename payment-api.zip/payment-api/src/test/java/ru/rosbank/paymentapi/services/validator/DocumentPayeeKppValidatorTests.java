package ru.rosbank.paymentapi.services.validator;

import static org.mockito.ArgumentMatchers.any;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;


/**
 * Summary.
 *
 * @author rb068869
 */
public class DocumentPayeeKppValidatorTests extends BaseTest {

    private final DocumentDTO document = new DocumentDTO().payee(new RequisiteDTO());
    @MockBean
    DocumentTypeCalculatorImpl documentTypeCalculator;

    @Test
    public void testPayeeKppCounterpartyMustBeEmptyInsteadZero() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("760212755949");
        assertValidExceptionIsNotThrown();
    }

    @Test
    public void testPayeeKppCounterpartyMustBeEmptyInn10() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("0123456789");
        assertValidExceptionIsNotThrown();
    }

    @Test
    public void testPayeeKppCounterpartyMustBeEmpty() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("760212755949");
        assertValidExceptionIsNotThrown();
    }

    @Test
    public void testZerosCounterparty() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("0123456789");
        document.getPayee().setKpp("000000000");
        assertValidExceptionIsThrown();

    }

    @Test
    public void testStartZerosCounterparty() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("0123456789");
        document.getPayee().setKpp("001234567");
        assertValidExceptionIsThrown();
    }

    @Test
    public void testNonNineCounterparty() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("0123456789");
        document.getPayee().setKpp("1234567");
        assertValidExceptionIsThrown();
    }

    @Test
    public void testPayeeKppCounterpartyInn5() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("760212");
        document.getPayee().setKpp("123456789");
        assertValidExceptionIsNotThrown();
    }

    @Test
    public void testPayeeKppCounterpartyInn10() throws ValidationPaymentException {
        setDocIsNotBudget();
        document.getPayee().setInn("760212");
        document.getPayee().setKpp("1234AZ789");
        assertValidExceptionIsNotThrown();
    }

    @Test
    public void testPayeeKppBudgetMustBeZero() throws ValidationPaymentException {
        setDocIsBudget();
        document.getPayee().setInn("760212755949");
        document.getPayee().setKpp("0");
        assertValidExceptionIsThrown();
    }

    @Test
    public void testPayeeKppBudgetEmpty() throws ValidationPaymentException {
        setDocIsBudget();
        document.getPayee().setInn("760212755949");
        assertValidExceptionIsThrown();
    }

    @Test
    public void testZerosBudget() throws ValidationPaymentException {
        setDocIsBudget();
        document.getPayee().setKpp("000000000");
        assertValidExceptionIsThrown();
    }

    @Test
    public void testStartZerosBudget() throws ValidationPaymentException {
        setDocIsBudget();
        document.getPayee().setKpp("001234567");
        assertValidExceptionIsThrown();
    }

    @Test
    public void testNonNineBudget() throws ValidationPaymentException {
        setDocIsBudget();
        document.getPayee().setKpp("1234567");
        assertValidExceptionIsThrown();
    }

    @Test
    public void testPayeeKppBudget1() throws ValidationPaymentException {
        setDocIsBudget();
        document.getPayee().setInn("0");
        document.getPayee().setKpp("123456789");
        assertValidExceptionIsNotThrown();
    }

    @Test
    public void testPayeeKppBudget2() throws ValidationPaymentException {
        setDocIsBudget();
        document.getPayee().setInn("760212");
        document.getPayee().setKpp("1234AZ789");
        assertValidExceptionIsNotThrown();
    }

    private void setDocIsNotBudget() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(false);
    }

    private void setDocIsBudget() {
        Mockito.when(documentTypeCalculator.isBudget(any())).thenReturn(true);
    }

    private DocumentPayeeKppValidator getValidator() {
        return new DocumentPayeeKppValidator(documentTypeCalculator);
    }

    private void assertValidExceptionIsThrown() {
        Assertions.assertThatThrownBy(() -> getValidator().validate(document)).isInstanceOf(ValidationPaymentException.class);
    }

    private void assertValidExceptionIsNotThrown() {
        Assertions.assertThatCode(() -> getValidator().validate(document)).doesNotThrowAnyException();
    }
}
