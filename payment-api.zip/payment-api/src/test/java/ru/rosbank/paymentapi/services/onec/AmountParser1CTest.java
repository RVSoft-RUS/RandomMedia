package ru.rosbank.paymentapi.services.onec;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

class AmountParser1CTest {

    @Test
    void parseAndSetValue() {
        AmountParser1C parser1C = new AmountParser1C();
        DocumentDTO doc = new DocumentDTO();
        parser1C.parseAndSetValue("Сумма=100", doc);
        Assertions.assertEquals("100.00", doc.getAmount());
        parser1C.parseAndSetValue("Сумма=-100", doc);
        Assertions.assertEquals("100.00", doc.getAmount());
    }
}