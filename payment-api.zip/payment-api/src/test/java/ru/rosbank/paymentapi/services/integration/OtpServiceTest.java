package ru.rosbank.paymentapi.services.integration;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import feign.FeignException;
import feign.Request;
import feign.RequestTemplate;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.HashMap;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.platform.client.otpapp.api.OtpAppApi;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;

class OtpServiceTest extends BaseTest {

    @Autowired
    OtpService otpService;

    @MockBean
    OtpAppApi otpAppApi;

    @Test
    void generatePackageSignatureOtpSuccessful() {

        var otp = new OtpDTO();
        when(otpAppApi.rootPost(any())).thenReturn(new ResponseEntity<>(otp, HttpStatus.OK));

        var result = otpService
                .generatePackageSignatureOtp("61352529-4667-4e20-a76c-d2a9087aa288", "79521234566");
        Assertions.assertNotNull(result);
    }

    @Test
    void generatePackageSignatureOtpFailed() {

        Request request = Request
                .create(Request.HttpMethod.GET, "url", new HashMap<>(), null, new RequestTemplate());
        when(otpAppApi.rootPost(any())).thenThrow(
                new FeignException.InternalServerError("message", request, "ERROR".getBytes(StandardCharsets.UTF_8), null)
        );
        Exception exception = assertThrows(BackendException.class, () -> {
            otpService.generatePackageSignatureOtp("61352529-4667-4e20-a76c-d2a9087aa288", "79521234566");
        });

        String expectedMessage = "message";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }


    @Test
    void getExpireMilliSeconds() {

        var otp = new OtpDTO().created(OffsetDateTime.now());
        var result = otpService.getExpireMilliSeconds(otp);
        Assertions.assertEquals(180, result);
    }

    @Test
    void getOtpByUUIDSuccessTest() {
        when(otpAppApi.idGet(anyString())).thenReturn(ResponseEntity.ok(new OtpDTO().id("response ID")));
        var result = otpService.getOtpByUUID("test");
        Assertions.assertNotNull(result);
        Assertions.assertEquals("response ID", result.getId());
    }

    @Test
    void getOtpByUUIDExceptionTest() {
        Request request = Request.create(Request.HttpMethod.GET, "url",
                new HashMap<>(), null, new RequestTemplate());
        when(otpAppApi.idGet(anyString())).thenThrow(new FeignException.BadRequest("", request, null, null));
        Assertions.assertThrows(BackendException.class, () -> otpService.getOtpByUUID("test"));
    }
}