package ru.rosbank.paymentapi.services;

import static org.junit.jupiter.api.Assertions.assertThrows;

import freemarker.template.TemplateException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import org.jsoup.Jsoup;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.util.StringUtils;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.AccessForbiddenException;
import ru.rosbank.paymentapi.services.reporting.DocumentFormService;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.AccountsCachedResponseDTO;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApiClient;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApiClient;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.statementapp.api.StatementAppApiClient;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.FileResource;


public class DocumentFormServiceTest extends BaseTest {

    @Autowired
    private DocumentFormService documentFormService;
    @MockBean
    private StatementAppApiClient statementAppApiClient;
    @MockBean
    private PaymentAppApiClient paymentAppApiClient;
    @MockBean
    private OrganizationAppApiClient organizationAppApiClient;
    @MockBean
    private AccountAppApiClient accountAppApiClient;

    @Test
    public void testDocumentForm() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(paymentAppApiClient.documentIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getDocument(), HttpStatus.OK));
        FileResource pdf = documentFormService.getDocumentForm("123", "pdf", "123");
        FileResource html = documentFormService.getDocumentForm("123", "html", "123");
        Assertions.assertTrue(StringUtils.isNotBlank(pdf.getContent()));
        Assertions.assertTrue(StringUtils.isNotBlank(html.getContent()));
        Assertions.assertNotNull(pdf.getName());
        Assertions.assertNotNull(html.getName());
    }

    @Test
    public void testDocumentFormCA() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getStDocumentCA(), HttpStatus.OK));
        FileResource pdf = documentFormService.getDocumentForm("123", "pdf", "123");
        FileResource html = documentFormService.getDocumentForm("123", "html", "123");

        File file = new ClassPathResource("/html/collectionOrderCredit.html").getFile();
        String strActual = new String(Base64.getEncoder().encode(Files.readAllBytes(file.toPath())));

        Assertions.assertEquals(html.getContent(), strActual);
    }

    @Test
    public void testDocumentFormPDSN() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(paymentAppApiClient.refferenceIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getDocument(), HttpStatus.OK));
        //FileResource pdf = documentFormService.getDocumentForm("123", "pdf", "123");
        FileResource html = documentFormService.getDocumentFormPDSN("123", "html", "123");

        String resultHtml = new String(Base64.getDecoder().decode(html.getContent()));

        //OutputStream outputStream = new FileOutputStream("C:\\Users\\rb197115\\Pictures\\qq.html");
        //outputStream.write(resultHtml.getBytes());
        //outputStream.close();

        Assertions.assertTrue(resultHtml.contains(" "));
    }

    @Test
    public void testDocumentFormDA() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getStDocumentDA(), HttpStatus.OK));
        FileResource pdf = documentFormService.getDocumentForm("123", "pdf", "123");
        FileResource html = documentFormService.getDocumentForm("123", "html", "123");

        File file = new ClassPathResource("/html/collectionOrderDebit.html").getFile();
        String strActual = new String(Base64.getEncoder().encode(Files.readAllBytes(file.toPath())));

        Assertions.assertEquals(html.getContent(), strActual);
    }

    @Test
    public void testDocumentStatementForm() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getStDocumentCA(), HttpStatus.OK));
        FileResource htmlCA = documentFormService.getDocumentForm("123", "html", "123");

        Assertions.assertTrue(new String(Base64.getDecoder().decode(htmlCA.getContent()))
                .contains("12345678901234567890123456789012345"));

        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(getStDocumentDA(), HttpStatus.OK));
        FileResource htmlDA = documentFormService.getDocumentForm("123", "html", "123");
        Assertions.assertTrue(new String(Base64.getDecoder().decode(htmlDA.getContent()))
                .contains("123456789012345678901234567890123DA"));

    }

    @Test
    public void testDocumentFormNoMatch() {
        initDocumentForms();
        List<AccountDTO> accountList = getAccountList();
        accountList.get(0).setNumber("-1");
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new AccountsCachedResponseDTO().accounts(accountList), HttpStatus.OK));

        Mockito.when(paymentAppApiClient.documentIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getDocument(), HttpStatus.OK));

        assertThrows(AccessForbiddenException.class, () -> documentFormService.getDocumentForm("123", "pdf", "123"));
        assertThrows(AccessForbiddenException.class, () -> documentFormService.getDocumentForm("123", "html", "123"));
    }

    @Test
    public void testSentToBankDocStamp() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(paymentAppApiClient.documentIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getDocument().status(DocumentStatusDTO.SIGNED), HttpStatus.OK));
        FileResource html = documentFormService.getDocumentForm("123", "html", "123");
        Assertions.assertEquals("НАПРАВЛЕНО", getFirstWordInStamp(html));


    }

    @Test
    public void testReceivedByBankDocStamp() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(paymentAppApiClient.documentIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getDocument().status(DocumentStatusDTO.SENT_TO_BIS), HttpStatus.OK));
        FileResource html = documentFormService.getDocumentForm("123", "html", "123");
        Assertions.assertEquals("ПОЛУЧЕНО", getFirstWordInStamp(html));

    }


    @Test
    public void testPaymentForm() throws IOException, TemplateException {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new PaymentDTO().subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT),
                        HttpStatus.OK));
        FileResource html = documentFormService.getDocumentForm("123", "html", "123");
        Assertions.assertTrue(StringUtils.isNotBlank(html.getContent()));
    }

    private DocumentDTO getDocument() {
        return new DocumentDTO()
                .number("123456789")
                .date(OffsetDateTime.of(2024, 6, 22, 0, 0, 0, 0, ZoneOffset.ofHours(0)))
                .enrollmentDate(OffsetDateTime.of(2024, 6, 22, 0, 0, 0, 0, ZoneOffset.ofHours(0)))
                .purpose("На финансирование терроризма")
                .uin("2")
                .amount("3210504020.01")
                .kbk("kbk")
                .status(DocumentStatusDTO.COMPLETED)
                .payee(new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("ИП Константинопольский Константин Константинович")
                        .bank(new ru.rosbank.platform.client.paymentapp.model.BankInfoDTO()
                                .name("ПАО РОСБАНК")
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .payer(new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("ИП Константинопольский Константин Константович")
                        .bank(new ru.rosbank.platform.client.paymentapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")));
    }

    private PaymentDTO getStDocumentCA() {
        return new PaymentDTO()
                .subtype(PaymentDTO.SubtypeEnum.COLLECTION_ASSIGNMENT)
                .type(PaymentDTO.TypeEnum.CA)
                .uin("2")
                .field23("12345678901234567890123456789012345")
                .amount(new AmountDTO().sum(BigDecimal.ONE))
                .kbk("kbk")
                .status("COMPLETED")
                .payee(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .payer(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")));
    }

    private PaymentDTO getStDocumentDA() {
        return new PaymentDTO()
                .subtype(PaymentDTO.SubtypeEnum.COLLECTION_ASSIGNMENT)
                .type(PaymentDTO.TypeEnum.DA)
                .uin("2")
                .field23("123456789012345678901234567890123DA")
                .amount(new AmountDTO().sum(BigDecimal.ONE))
                .kbk("kbk")
                .status("COMPLETED")
                .payee(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")))
                .payer(new ru.rosbank.platform.client.statementapp.model.RequisiteDTO().account("account")
                        .inn("inn")
                        .kpp("kpp")
                        .name("name")
                        .bank(new ru.rosbank.platform.client.statementapp.model.BankInfoDTO()
                                .bic("bic")
                                .correspondentAccount("coraccount")));
    }

    @Test
    public void testDocumentListPdf() throws IOException, TemplateException {

        initDocumentForms();
        Mockito.when(paymentAppApiClient.documentIdGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getDocument(), HttpStatus.OK));
        FileResource listPdf = documentFormService.getDocumentListPdf(Arrays.asList("1", "2", "3"), "123");
        Assertions.assertTrue(StringUtils.isNotBlank(listPdf.getContent()));
        Assertions.assertEquals("documents", listPdf.getName());
    }

    @Test
    public void testPaymentListPdf() throws IOException, TemplateException {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new PaymentDTO().subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT),
                        HttpStatus.OK));
        FileResource paymentList = documentFormService.getDocumentListPdf(Arrays.asList("1", "2", "3"), "123");
        Assertions.assertNotNull(paymentList.getContent());
        Assertions.assertEquals("documents", paymentList.getName());
    }

    private List<OrganizationDTO> getOrganizationDtoList() {
        return Collections.singletonList(new OrganizationDTO().bisIds(Collections.singletonList(new BisIdDTO())));
    }

    private List<AccountDTO> getAccountList() {
        return Collections.singletonList(new AccountDTO().number("account").currency("RUR"));
    }

    private void initDocumentForms() {
        Mockito.when(statementAppApiClient.documentDboProIdIdGet(Mockito.any(), Mockito.any())).thenReturn(null);

        Mockito.when(organizationAppApiClient.rootGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(getOrganizationDtoList(), HttpStatus.OK));
        Mockito.when(accountAppApiClient.organizationAccountsGet(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(new ResponseEntity<>(new AccountsCachedResponseDTO().accounts(getAccountList()), HttpStatus.OK));
    }

    private String getFirstWordInStamp(FileResource html) {
        String htmlString = new String(Base64.getDecoder().decode(html.getContent()), StandardCharsets.UTF_8);
        String stringInStamp = Jsoup.parse(htmlString).select("div[class=bankNotes__status]")
                .first().childNode(0).toString();
        return Arrays.stream(stringInStamp.trim().split(" ")).findFirst().get();
    }
}
