package ru.rosbank.paymentapi.services.rectification.validators;

import static org.mockito.ArgumentMatchers.any;

import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;


public class UserRoleValidatorTest extends BaseTest {
    @Autowired
    UserRoleValidator userRoleValidator;
    @MockBean
    AccountService accountService;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    ProductService productService;

    @Test
    void userRoleValidatorExceptionTest() {
        Mockito.when(accountService.getAccount(any())).thenReturn(new AccountDTO());
        Assertions.assertThrows(ValidationException.class, () ->
                userRoleValidator.validate("dboPro", new AccountDTO(), null));
    }

    @Test
    void userRoleValidatorExceptionTest2() {
        Mockito.when(accountService.getAccount(any())).thenReturn(new AccountDTO());
        Assertions.assertThrows(ValidationException.class, () ->
                userRoleValidator.validate("dboPro", null, new OrganizationDTO()));
    }

    @Test
    void userRoleValidatorTest() {
        Mockito.when(accountService.getAccount(any())).thenReturn(new AccountDTO());
        Mockito.when(productService.getOrganizationByAccNumberAndDboProId(any(), any()))
                .thenReturn(Optional.of(new OrganizationDTO()));
        Mockito.when(organizationService.applyRole(any(), any())).thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        Assertions.assertDoesNotThrow(() ->
                userRoleValidator.validate("dboPro", new AccountDTO(), new OrganizationDTO()));
    }
}
