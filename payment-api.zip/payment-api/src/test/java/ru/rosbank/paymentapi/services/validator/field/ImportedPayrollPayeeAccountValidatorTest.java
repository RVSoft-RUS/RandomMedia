package ru.rosbank.paymentapi.services.validator.field;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

class ImportedPayrollPayeeAccountValidatorTest extends BaseTest {
    @Autowired
    ImportedPayrollPayeeAccountValidator validator;

    @Test
    void validate() {
        DocumentDTO documentDTO = new DocumentDTO().payee(new RequisiteDTO().account("00000000000000000000"));
        validator.validate(documentDTO);
        Assertions.assertEquals("", documentDTO.getPayee().getAccount());
    }
}