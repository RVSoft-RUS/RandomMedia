package ru.rosbank.paymentapi.services.integration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApi;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.organizationapp.model.TariffDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

class OrganizationServiceTest extends BaseTest {

    @Autowired
    OrganizationService organizationService;

    @MockBean
    OrganizationAppApi organizationAppApi;
    @MockBean
    RolesService rolesService;

    @Test
    void getOrganizations() {
        var orgList = Collections.singletonList(new OrganizationDTO()
                .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch"))));
        when(organizationAppApi.rootGet(anyString()))
                .thenReturn(new ResponseEntity<>(orgList, HttpStatus.OK));

        var result = organizationService.getOrganizations("1");
        Assertions.assertEquals("id", result.get(0).getBisIds().get(0).getId());
    }

    @Test
    void applyRole() {

        when(rolesService.getIndividual(any(), any()))
                .thenReturn(new IndividualDTO().accessGroup(IndividualDTO.AccessGroupEnum.ALL_RIGHTS));
        var result = organizationService
                .applyRole("61352529-4667-4e20-a76c-d2a9087aa288", new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch"))));
        Assertions.assertEquals(IndividualDTO.AccessGroupEnum.ALL_RIGHTS, result);
    }

    @Test
    void getActiveOrganizations() {
        when(rolesService.isActiveIndividual(any(), any()))
                .thenReturn(true);
        var orgList = Collections.singletonList(new OrganizationDTO()
                .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch"))));
        when(organizationAppApi.rootGet(anyString()))
                .thenReturn(new ResponseEntity<>(orgList, HttpStatus.OK));

        var result = organizationService.getActiveOrganizations("1");
        Assertions.assertEquals("id", result.get(0).getBisIds().get(0).getId());
    }

    @Test
    void getNotActiveOrganizations() {
        when(rolesService.isActiveIndividual(any(), any()))
                .thenReturn(false);
        var orgList = Collections.singletonList(new OrganizationDTO()
                .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch"))));
        when(organizationAppApi.rootGet(anyString()))
                .thenReturn(new ResponseEntity<>(orgList, HttpStatus.OK));

        var result = organizationService.getActiveOrganizations("1");
        Assertions.assertEquals(0, result.size());
    }

    @Test
    void getAvailableOrganizationReturnsEmptyListWhenClientRegistrationNotCompleted() {
        var clientDTO = new ClientDTO().registrationCompleted(null);
        var availableOrganizationListByClient = organizationService.getAvailableOrganizationListByClient(clientDTO);
        assertThat(availableOrganizationListByClient).isEmpty();
    }

    @Test
    void getAvailableOrganizationsReturnsOnlyOrganizationWhereClientIsManagerOrRepresentative() {
        OrganizationDTO org = new OrganizationDTO().isProspect(true)
                .crmId("2")
                .bisIds(Collections.singletonList(new BisIdDTO().id("id").branch("branch")));
        var orgList = Collections.singletonList(org);
        when(organizationAppApi.rootGet(anyString()))
                .thenReturn(new ResponseEntity<>(orgList, HttpStatus.OK));

        var individuals = List.of(
                new IndividualDTO().relationType(RolesService.REPRESENTATIVE_TYPE)
        );
        when(rolesService.getActiveIndividuals(anyString(), anyString())).thenReturn(individuals);
        when(rolesService.isAccountManagerOrRepresentative(any())).thenReturn(true);

        var clientDTO = new ClientDTO().id("1").registrationCompleted(OffsetDateTime.now());
        var availableOrganizationListByClient = organizationService.getAvailableOrganizationListByClient(clientDTO);


        assertThat(availableOrganizationListByClient).isNotEmpty().hasSize(1);
        var organizationDTOResult = availableOrganizationListByClient.get(0);
        assertThat(organizationDTOResult).isEqualTo(org);
    }

    @Test
    void getTariffSuccessful() {
        String bisId = "bisId";
        String bisBranch = "bisBranch";
        String crmId = "crmId";
        TariffDTO tariffMock = Mockito.mock(TariffDTO.class);
        when(organizationAppApi.getOrganizationTariff(bisId, bisBranch, crmId))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(tariffMock), HttpStatus.OK));

        TariffDTO result = organizationService.getTariff(bisId, bisBranch, crmId);

        Assertions.assertEquals(tariffMock, result);
    }

    @Test
    void getTariffNegative() {
        String bisId = "bisId";
        String bisBranch = "bisBranch";
        String crmId = "crmId";
        when(organizationAppApi.getOrganizationTariff(bisId, bisBranch, crmId))
                .thenReturn(new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK));

        org.assertj.core.api.Assertions.assertThatThrownBy(() -> organizationService.getTariff(bisId, bisBranch, crmId))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("Unable to find any tariff for bisId: bisId, bisBranch: bisBranch, crmId: crmId");
    }
}