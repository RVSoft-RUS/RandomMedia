package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.OffsetDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;


class DocumentExecutionDateValidatorTest extends BaseTest {

    @Autowired
    DocumentExecutionDateValidator validator;

    @Test
    void validate() {
        DocumentDTO document = new DocumentDTO();
        document.setDate(OffsetDateTime.now());
        document.setExecutionDate(OffsetDateTime.now().plusDays(5));
        validator.validate(document);
    }

    @Test
    void validateThrows() {
        DocumentDTO document = new DocumentDTO();
        document.setDate(OffsetDateTime.now());
        document.setExecutionDate(OffsetDateTime.now().plusDays(50));
        assertThrows(ValidationException.class, () -> validator.validate(document));

        document.setExecutionDate(OffsetDateTime.now().minusDays(5));
        assertThrows(ValidationException.class, () -> validator.validate(document));
    }
}