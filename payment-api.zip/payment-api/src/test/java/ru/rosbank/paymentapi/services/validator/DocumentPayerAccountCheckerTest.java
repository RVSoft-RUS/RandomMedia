package ru.rosbank.paymentapi.services.validator;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;

class DocumentPayerAccountCheckerTest extends BaseTest {

    @Autowired
    DocumentPayerAccountChecker documentPayerAccountChecker;

    @MockBean
    OrganizationService organizationService;


    @Test
    void validate() {

        var orgList = Arrays.asList(new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("321").branch("R70"))),
                new OrganizationDTO()
                        .bisIds(Collections.singletonList(new BisIdDTO().id("123").branch("R19"))));
        Mockito.when(organizationService.applyRole("35563c07-82b2-43a8-a3b2-c9a11c696b4e", orgList.get(1)))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        Mockito.when(organizationService.applyRole("35563c07-82b2-43a8-a3b2-c9a11c696b4e", orgList.get(0)))
                .thenReturn(IndividualDTO.AccessGroupEnum.BLOCK);

        documentPayerAccountChecker
                .validate("35563c07-82b2-43a8-a3b2-c9a11c696b4e", orgList.get(1));
    }
}