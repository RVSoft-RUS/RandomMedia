package ru.rosbank.paymentapi.services.validator;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.services.validator.field.DocumentNumberValidator;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

/**
 * Summary.
 *
 * @author rb068869
 */
class DocumentNumberValidatorTests extends BaseTest {

    @Autowired
    private DocumentNumberValidator documentNumberValidator;

    private DocumentDTO documentDTO;

    @BeforeEach
    void setUp() {
        documentDTO = new DocumentDTO();
    }

    @Test
    void testBlank() {
        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentNumberValidator.validate(documentDTO));
    }

    @Test
    void testSuccess() {
        documentDTO.setNumber("12345");
        documentNumberValidator.validate(documentDTO);
    }

    @Test
    void testDigitsOnly() {
        documentDTO.setNumber("123A");
        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentNumberValidator.validate(documentDTO));
    }

    @Test
    void testZero() {
        documentDTO.setNumber("0");
        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentNumberValidator.validate(documentDTO));
    }

    @Test
    void testEndsWithThreeZeros() {
        documentDTO.setNumber("123000");
        documentNumberValidator.validate(documentDTO);
    }

    @Test
    void testWrongCountOfDigits() {
        documentDTO.setNumber("1234567");
        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentNumberValidator.validate(documentDTO));
    }

    @Test
    void testThreeZeros() {
        documentDTO.setNumber("000");

        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentNumberValidator.validate(documentDTO));
    }

    @Test
    void testTwoZeros() {
        documentDTO.setNumber("00");
        Assertions.assertThrows(ValidationPaymentException.class,
            () -> documentNumberValidator.validate(documentDTO));
    }

}
