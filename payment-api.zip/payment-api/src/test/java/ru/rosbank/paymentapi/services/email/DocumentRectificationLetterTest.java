package ru.rosbank.paymentapi.services.email;


import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

class DocumentRectificationLetterTest extends BaseTest {

    @Autowired
    private DocumentRectificationLetter documentRectificationLetter;

    @Test
    void buildHtmlMessage() {

        Payment documentDto = new Payment();
        documentDto.setNumber("01");
        documentDto.setCreated(OffsetDateTime.now());

        Requisite requisiteDto = new Requisite();
        requisiteDto.setName("test");
        requisiteDto.setInn("123");
        requisiteDto.setAccount("123");
        documentDto.setPayer(requisiteDto);

        documentDto.setExecutionDate(OffsetDateTime.now());

        documentDto.setAmount(new Amount().sum(BigDecimal.ONE));

        Rectification rectification = new Rectification();

        String actualHtml = documentRectificationLetter.buildHtmlMessage(rectification, documentDto);
        assertNotNull(actualHtml);

        String actualTxt = documentRectificationLetter.buildPlainTextMessage(rectification, documentDto);
        assertNotNull(actualTxt);
    }

}