package ru.rosbank.paymentapi.services.validator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;


class DocumentTypeCalculatorImplTest extends BaseTest {
    @Autowired
    private DocumentTypeCalculatorImpl documentTypeCalculator;
    DocumentDTO document;

    @Test
    void calculateForImportedDoc() {
        initBranches();

        document = new DocumentDTO();
        RequisiteDTO requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayee(requisite);
        requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayer(requisite);
        // counterparty
        document.getPayee().setAccount("00000000000000000000");
        document.getPayee().setInn("1");
        document.setPurpose("ывфафып КОМАНДИРОВОЧНные эывжалдыфржд");
        DocumentDTO.TypeEnum typeEnum = documentTypeCalculator.calculateForImportedDoc(document);
        Assertions.assertEquals(DocumentDTO.TypeEnum.DP, typeEnum);

    }

    @Test
    void calculateDG() {
        List<BranchDTO> branchDTO = new ArrayList<>();
        branchDTO.add(new BranchDTO().correspondentAccount("corAcc").name("name").inn("7730060164"));
        Mockito.when(referenceAppApi.branchGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(branchDTO, HttpStatus.OK));
        document = new DocumentDTO();
        RequisiteDTO requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayee(requisite);
        requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayer(requisite);

        document.getPayee().setAccount("00000000000000000000");
        document.getPayee().setInn("7730060164");
        document.getPayer().setInn("7730060164");
        document.setPurpose("ывфафып КОМАНДИРОВОЧНные эывжалдыфржд");
        DocumentDTO.TypeEnum typeEnum = documentTypeCalculator.calculate(document);
        Assertions.assertEquals(DocumentDTO.TypeEnum.DG, typeEnum);

    }

    @Test
    void calculateDC() {
        List<BranchDTO> branchDTO = new ArrayList<>();
        branchDTO.add(new BranchDTO().correspondentAccount("corAcc").name("name").inn("7730060164"));
        Mockito.when(referenceAppApi.branchGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(branchDTO, HttpStatus.OK));
        document = new DocumentDTO();
        RequisiteDTO requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayee(requisite);
        requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayer(requisite);

        document.getPayee().setAccount("42100000000000000000");
        document.getPayee().setInn("7730060164");
        document.getPayer().setInn("7730060164");
        document.setPurpose("ывфафып КОМАНДИРОВОЧНные эывжалдыфржд");
        DocumentDTO.TypeEnum typeEnum = documentTypeCalculator.calculate(document);
        Assertions.assertEquals(DocumentDTO.TypeEnum.DC, typeEnum);

    }

    @Test
    void calculateDE1() {
        List<BranchDTO> branchDTO = new ArrayList<>();
        branchDTO.add(new BranchDTO().correspondentAccount("corAcc").name("name").inn("7730060164"));
        Mockito.when(referenceAppApi.branchGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(branchDTO, HttpStatus.OK));
        document = new DocumentDTO();
        RequisiteDTO requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayee(requisite);
        requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayer(requisite);

        document.getPayee().setAccount("40204000000000000000");
        document.getPayee().setInn("7730060165");
        document.getPayee().getBank().bic("0123456000").correspondentAccount("");
        document.getPayer().setInn("7730060164");
        document.setPurpose("ывфафып КОМАНДИРОВОЧНные эывжалдыфржд");
        DocumentDTO.TypeEnum typeEnum = documentTypeCalculator.calculate(document);
        Assertions.assertEquals(DocumentDTO.TypeEnum.DE, typeEnum);

    }

    @Test
    void calculateDE2() {
        List<BranchDTO> branchDTO = new ArrayList<>();
        branchDTO.add(new BranchDTO().correspondentAccount("corAcc").name("name").inn("7730060164"));
        Mockito.when(referenceAppApi.branchGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(branchDTO, HttpStatus.OK));
        document = new DocumentDTO();
        RequisiteDTO requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayee(requisite);
        requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayer(requisite);

        document.getPayee().setAccount("40503000000004000000");
        document.getPayee().setInn("7730060165");
        document.getPayee().getBank().bic("0123456000").correspondentAccount("");
        document.getPayer().setInn("7730060164");
        document.setPurpose("ывфафып КОМАНДИРОВОЧНные эывжалдыфржд");
        DocumentDTO.TypeEnum typeEnum = documentTypeCalculator.calculate(document);
        Assertions.assertEquals(DocumentDTO.TypeEnum.DE, typeEnum);
    }

    @Test
    void calculateDE3() {
        List<BranchDTO> branchDTO = new ArrayList<>();
        branchDTO.add(new BranchDTO().correspondentAccount("corAcc").name("name").inn("7730060164"));
        Mockito.when(referenceAppApi.branchGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(branchDTO, HttpStatus.OK));

        Mockito.when(referenceAppApi.bankGet(Mockito.any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(
                        new BankDTO().correspondentAccount("40102000000000000000").bikType("51")), HttpStatus.OK));
        document = new DocumentDTO();
        RequisiteDTO requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayee(requisite);
        requisite = new RequisiteDTO();
        requisite.setBank(new BankInfoDTO());
        document.setPayer(requisite);

        document.getPayee().setAccount("00503000000004000000");
        document.getPayee().setInn("7730060165");
        document.getPayee().getBank().bic("0123456000").correspondentAccount("40102000000000000000");
        document.getPayer().setInn("7730060164");
        document.setPurpose("ывфафып КОМАНДИРОВОЧНные эывжалдыфржд");
        DocumentDTO.TypeEnum typeEnum = documentTypeCalculator.calculate(document);
        Assertions.assertEquals(DocumentDTO.TypeEnum.DE, typeEnum);
    }
}