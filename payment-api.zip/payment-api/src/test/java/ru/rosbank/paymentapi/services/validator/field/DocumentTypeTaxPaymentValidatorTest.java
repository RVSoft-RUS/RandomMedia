package ru.rosbank.paymentapi.services.validator.field;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.BaseTest;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

public class DocumentTypeTaxPaymentValidatorTest extends BaseTest {
    @Autowired
    DocumentTypeTaxPaymentValidator validator;

    @Test
    void validate() {
        DocumentDTO document = new DocumentDTO();
        document.setTypeTaxPayment("false");
        document.setType(DocumentDTO.TypeEnum.DE);
        validator.validate(document);
        document.setTypeTaxPayment(null);
        document.setType(DocumentDTO.TypeEnum.DE);
        validator.validate(document);
        document.setTypeTaxPayment("true");
        document.setType(DocumentDTO.TypeEnum.DC);
        validator.validate(document);
    }

    @Test
    void validateThrows() {
        DocumentDTO document = new DocumentDTO();
        document.setTypeTaxPayment("true");
        document.setType(DocumentDTO.TypeEnum.DE);
        assertThrows(ValidationPaymentException.class, () -> validator.validate(document));
    }
}
