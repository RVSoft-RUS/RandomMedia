package ru.rosbank.paymentapi.services.rectification;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.converter.PaymentToPaymentConverter;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.paymentapi.services.AuditService;
import ru.rosbank.paymentapi.services.ClarificationService;
import ru.rosbank.paymentapi.services.email.DocumentRectificationLetter;
import ru.rosbank.paymentapi.services.email.LocalEmailSender;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.StatementService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.client.statementapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;


class DocumentRectificationServiceTest extends BaseTest {
    @Autowired
    DocumentRectificationService rectificationService;
    @MockBean
    PaymentAppApi paymentAppApi;
    @MockBean
    StatementService statementService;
    @MockBean
    PaymentToPaymentConverter paymentToPaymentConverter;
    @MockBean
    DocumentToPaymentConverter documentToPaymentConverter;
    @MockBean
    AuditService auditService;
    @MockBean
    OrganizationService organizationService;
    @MockBean
    AccountService accountService;
    @MockBean
    ClarificationService clarificationService;
    @MockBean
    LocalEmailSender localEmailSender;
    @MockBean
    DocumentRectificationLetter documentRectificationLetter;

    @Test
    void isRectificationRequestAccessible() {
        rectificationService.rbspEnabled = false;
        Rectification rectification = new Rectification();
        rectification.setDocumentId("Y01200122410882501");
        rectificationService.isRectificationRequestAccessible(rectification);
        verify(paymentAppApi).documentRectificationGet(ArgumentMatchers.any(),
                ArgumentMatchers.eq("PP200122-410882501"));
    }

    @Test
    void isRectificationRequestAccessibleRbspEnabled() {
        rectificationService.rbspEnabled = true;
        Rectification rectification = new Rectification();
        rectification.setDocumentId("Y01200122410882501");
        Assertions.assertTrue(rectificationService.isRectificationRequestAccessible(rectification));

    }

    @Test
    void getPaymentStatement() {
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO()
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT));
        when(paymentToPaymentConverter.convert(any())).thenReturn(new Payment());
        rectificationService.getPayment("PP200122-410882501", "dboProId");
        verify(statementService).getPayment(ArgumentMatchers.anyString(), ArgumentMatchers.eq("PP200122-410882501"));
    }

    @Test
    void getPaymentStatement2() {
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO()
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT));
        when(paymentToPaymentConverter.convert(any())).thenReturn(new Payment());
        rectificationService.getPayment("Y01200122410882501", "dboProId");
        verify(statementService).getPayment(ArgumentMatchers.anyString(), ArgumentMatchers.eq("Y01200122410882501"));
    }

    @Test
    void getPayment() {
        when(statementService.getPayment(any(), any())).thenReturn(null);
        when(paymentAppApi.refferenceIdGet(any())).thenReturn(new ResponseEntity<>(new DocumentDTO(), HttpStatus.OK));
        when(documentToPaymentConverter.convert(any())).thenReturn(new Payment());
        rectificationService.getPayment("PP200122-410882501", "dboProId");
        verify(paymentAppApi).refferenceIdGet(ArgumentMatchers.eq("PP200122-410882501"));
    }

    @Test
    void getPayment2() {
        when(statementService.getPayment(any(), any())).thenReturn(null);
        when(paymentAppApi.refferenceIdGet(any())).thenReturn(new ResponseEntity<>(new DocumentDTO(), HttpStatus.OK));
        when(documentToPaymentConverter.convert(any())).thenReturn(new Payment());
        rectificationService.getPayment("Y01200122410882501", "dboProId");
        verify(paymentAppApi).refferenceIdGet(ArgumentMatchers.eq("PP200122-410882501"));
    }

    @Test
    void getActiveDocumentRectificationsByDocumentsIdFromPaymentNotRectification() {
        RectificationDTO rectificationDTO = new RectificationDTO();
        rectificationDTO.setDocumentId("PP200122-410882501");
        rectificationDTO.setStatus(RectificationDTO.StatusEnum.ACTIVE);
        List<RectificationDTO> rectificationList = new ArrayList<>();
        rectificationList.add(rectificationDTO);
        when(paymentAppApi.documentRectificationBatchGet(any()))
                .thenReturn(new ResponseEntity<>(rectificationList, HttpStatus.OK));
        List<String> documentIdList = new ArrayList<>();
        documentIdList.add("PP200122-410882501");
        List<Rectification> rectifications =
                rectificationService
                        .getActiveDocumentRectificationsByDocumentsIdFromPayment(documentIdList);
        Assert.assertNotNull(rectifications);
        Assert.assertTrue(rectifications.stream().anyMatch(r -> "PP200122-410882501".equals(r.getDocumentId())));
    }

    @Test
    void getActiveDocumentRectificationsByDocumentsIdFromPaymentEmtyList() {
        List<String> documentIdList = new ArrayList<>();
        Assert.assertNotNull(rectificationService.getActiveDocumentRectificationsByDocumentsIdFromPayment(documentIdList));
    }

    @Test
    void findRectificationbByPaymentId() {
        Rectification rectification = new Rectification();
        rectification.setDocumentId("PP200122-410882501");
        rectification.setId(1L);
        rectification.setStatus("SIGNED");
        List<Rectification> rectificationList = new ArrayList<>();
        rectificationList.add(rectification);
        Map<String, List<Rectification>> rectificationMap = new HashMap<>();
        rectificationMap.put(rectification.getDocumentId(), rectificationList);
        Payment payment = new Payment();
        payment.setId(rectification.getDocumentId());
        List<Rectification> rectifications = rectificationService.getRectificationsByPaymentId(
                rectificationMap, payment);
        Assert.assertNotNull(rectifications);
        Assert.assertEquals(rectification.getId(), rectifications.get(0).getId());
        Rectification rectificationResult = rectificationService.getRectificationByRectifications(rectifications);
        Assert.assertEquals(rectification.getId(), rectificationResult.getId());
    }

    @Test
    void findRectificationbByPaymentId2() {
        Rectification rectification = new Rectification();
        rectification.setDocumentId("PP200122-410882501");
        rectification.setId(1L);
        rectification.setStatus("SIGNED");
        rectification.setCreated(OffsetDateTime.now().minusHours(1));
        Rectification rectification2 = new Rectification();
        rectification2.setDocumentId("PP200122-410882501");
        rectification2.setId(2L);
        rectification2.setStatus("SIGNED");
        rectification2.setCreated(OffsetDateTime.now());
        List<Rectification> rectificationList = new ArrayList<>();
        rectificationList.add(rectification);
        rectificationList.add(rectification2);
        Map<String, List<Rectification>> rectificationMap = new HashMap<>();
        rectificationMap.put(rectification.getDocumentId(), rectificationList);
        Payment payment = new Payment();
        payment.setId(rectification.getDocumentId());
        List<Rectification> rectifications = rectificationService.getRectificationsByPaymentId(
                rectificationMap, payment);
        Assert.assertTrue(rectifications.size() == 2);
        Assert.assertEquals(rectification2.getId(), rectifications.get(0).getId());
        Rectification rectificationResult = rectificationService.getRectificationByRectifications(rectifications);
        Assert.assertEquals(rectification2.getId(), rectificationResult.getId());
    }

    @Test
    public void testFindRectificationbByPaymentId_WithMatchingPaymentId_ShouldReturnRectification() {
        Rectification rectification1 = new Rectification()
                .id(1L)
                .status("SIGNED")
                .documentId("payment_id_1")
                .created(OffsetDateTime.now())
                .payerAccount("payer_account_1")
                .payeeName("payee_name_1")
                .payeeAccount("payee_account_1")
                .payeeInn("payee_inn_1")
                .payeeKpp("payee_kpp_1")
                .purpose("purpose_1")
                .paymentBasis("payment_basis_1")
                .basisDocumentNumber("basis_document_number_1")
                .basisDocumentCreated("basis_document_created_1")
                .taxPeriod("tax_period_1")
                .uin("uin_1")
                .kbk("kbk_1")
                .oktmo("oktmo_1");

        Rectification rectification2 = new Rectification()
                .id(2L)
                .status("SIGNED")
                .documentId("document_id_2")
                .created(OffsetDateTime.now())
                .payerAccount("payer_account_2")
                .payeeName("payee_name_2")
                .payeeAccount("payee_account_2")
                .payeeInn("payee_inn_2")
                .payeeKpp("payee_kpp_2")
                .purpose("purpose_2")
                .paymentBasis("payment_basis_2")
                .basisDocumentNumber("basis_document_number_2")
                .basisDocumentCreated("basis_document_created_2")
                .taxPeriod("tax_period_2")
                .uin("uin_2")
                .kbk("kbk_2")
                .oktmo("oktmo_2");

        List<Rectification> rectificationList = new ArrayList<>();
        rectificationList.add(rectification1);
        rectificationList.add(rectification2);
        Map<String, List<Rectification>> rectificationMap = new HashMap<>();
        rectificationMap.put(rectification1.getDocumentId(), Collections.singletonList(rectification1));
        rectificationMap.put(rectification2.getDocumentId(), Collections.singletonList(rectification2));
        Payment payment = new Payment();
        payment.setId(rectification1.getDocumentId());
        List<Rectification> rectifications = rectificationService.getRectificationsByPaymentId(
                rectificationMap, payment);
        Assert.assertNotNull(rectifications);
        Assert.assertEquals(rectification1.getId(), rectifications.get(0).getId());
        Rectification rectificationResult = rectificationService.getRectificationByRectifications(rectifications);
        Assert.assertEquals(rectification1.getId(), rectificationResult.getId());

        payment.setId(rectification2.getDocumentId());
        rectifications = rectificationService.getRectificationsByPaymentId(
                rectificationMap, payment);
        Assert.assertNotNull(rectifications);
        Assert.assertEquals(rectification2.getId(), rectifications.get(0).getId());
        rectificationResult = rectificationService.getRectificationByRectifications(rectifications);
        Assert.assertEquals(rectification2.getId(), rectificationResult.getId());
    }

    @Test
    void getActiveDocumentRectificationsByDocumentsException() {
        List<String> documentIdList = new ArrayList<>();
        documentIdList.add("1");
        when(paymentAppApi.documentRectificationBatchGet(documentIdList)).thenThrow(RuntimeException.class);
        Assertions.assertNotNull(rectificationService.getActiveDocumentRectificationsByDocumentsIdFromPayment(documentIdList));
    }

    @Test
    void getActiveDocumentRectificationsByDocumentEmptyBatch() {
        List<String> documentIdList = new ArrayList<>();
        documentIdList.add("1");
        when(paymentAppApi.documentRectificationBatchGet(documentIdList)).thenReturn(ResponseEntity.ok(Collections.emptyList()));
        Assertions.assertNotNull(rectificationService.getActiveDocumentRectificationsByDocumentsIdFromPayment(documentIdList));
    }

    @Test
    void findRectificationbReturnNull() {
        Map<String, List<Rectification>> rectificationMap = new HashMap<>();
        Payment payment = new Payment();
        List<Rectification> rectifications = rectificationService.getRectificationsByPaymentId(
                rectificationMap, payment);

        Rectification rectificationResult = rectificationService.getRectificationByRectifications(rectifications);

        Assert.assertNull(rectifications);
        Assert.assertNull(rectificationResult);
    }

    @Test
    void findRectificationbReturnrectificationDTOS() {
        Map<String, List<Rectification>> rectificationMap = new HashMap<>();
        Payment payment = new Payment();
        List<String> documentIdList = new ArrayList<>();
        documentIdList.add("1");
        when(paymentAppApi.documentRectificationBatchGet(documentIdList)).thenReturn(null);

        List<Rectification> rectifications = rectificationService.getRectificationsByPaymentId(
                rectificationMap, payment);

        Rectification rectificationResult = rectificationService.getRectificationByRectifications(rectifications);

        Assert.assertNull(rectifications);
        Assert.assertNull(rectificationResult);
    }


    @Test
    void register() {

        rectificationService.rbspEnabled = false;
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO().payer(
                new RequisiteDTO().account("01234567890123456789"))
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT));
        when(paymentToPaymentConverter.convert(any())).thenReturn(new Payment().payer(
                new Requisite().account("01234567890123456789")).payee(
                new Requisite().account("01234567890123456789")).status(Payment.StatusEnum.COMPLETED)
                .type(Payment.TypeEnum.DA));
        when(documentToPaymentConverter.convertBackWithoutId(any(), any())).thenReturn(new DocumentDTO().payer(
                new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("01234567890123456789"))
                .payee(new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("01234567890123456789")));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO().bisIds(Collections.singletonList(
                        new BisIdDTO().id("id").branch("branch")))));
        when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        when(accountService.getAccount(any()))
                .thenReturn((new AccountDTO().number13("number13").number("number")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("id"))));
        when(paymentAppApi.documentRectificationPost(any()))
                .thenReturn(new ResponseEntity<>(new RectificationDTO().id(1L), HttpStatus.OK));
        Rectification rectification = getRectification();
        rectification.setType("DA");
        rectificationService.register(rectification, "dboProId");
        verify(paymentAppApi).documentRectificationPost(any());
    }

    @Test
    void registerClr() {
        rectificationService.rbspEnabled = true;
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO().payer(
                new RequisiteDTO().account("01234567890123456789"))
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT));
        when(paymentToPaymentConverter.convert(any())).thenReturn(new Payment().payer(
                new Requisite().account("01234567890123456789")).payee(
                new Requisite().account("01234567890123456789")).status(Payment.StatusEnum.COMPLETED)
                .type(Payment.TypeEnum.DA));
        when(documentToPaymentConverter.convertBackWithoutId(any(), any())).thenReturn(new DocumentDTO().payer(
                new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("01234567890123456789"))
                .payee(new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("01234567890123456789")));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO().bisIds(Collections.singletonList(
                        new BisIdDTO().id("id").branch("branch")))));
        when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        when(accountService.getAccount(any()))
                .thenReturn((new AccountDTO().number13("number13").number("number")
                        .bisId(new ru.rosbank.platform.client.accountapp.model.BisIdDTO().id("id"))));
        when(clarificationService.clarificationPost(any(), any(), any(), any(), any()))
                .thenReturn(1L);
        rectificationService.register(getRectification(), "dboProId");
        verify(clarificationService).clarificationPost(any(), any(), any(), any(), any());
    }

    @Test
    void registerException() {
        rectificationService.rbspEnabled = true;
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO().payer(
                new RequisiteDTO().account("01234567890123456789"))
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT));
        when(paymentToPaymentConverter.convert(any())).thenReturn(new Payment().payer(
                new Requisite().account("01234567890123456789")).payee(
                new Requisite().account("01234567890123456789")).status(Payment.StatusEnum.COMPLETED)
                .type(Payment.TypeEnum.DA));
        when(documentToPaymentConverter.convertBackWithoutId(any(), any())).thenReturn(new DocumentDTO().payer(
                new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("01234567890123456789"))
                .payee(new ru.rosbank.platform.client.paymentapp.model.RequisiteDTO().account("01234567890123456789")));
        when(organizationService.getOrganizations(any()))
                .thenReturn(Collections.singletonList(new OrganizationDTO().bisIds(Collections.singletonList(
                        new BisIdDTO().id("id").branch("branch")))));
        when(organizationService.applyRole(any(), any()))
                .thenReturn(IndividualDTO.AccessGroupEnum.ALL_RIGHTS);
        when(accountService.getAccount(any())).thenThrow(ValidationPaymentException.class);
        when(clarificationService.clarificationPost(any(), any(), any(), any(), any()))
                .thenReturn(1L);
        Assertions.assertThrows(ValidationPaymentException.class, () ->
                rectificationService.register(getRectification(), "dboProId"));
    }

    @Test
    void processDocument() {
        rectificationService.rbspEnabled = false;
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO()
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT));
        when(paymentToPaymentConverter.convert(any())).thenReturn(new Payment().payer(new Requisite().name("name")
                .account("account")));
        when(documentRectificationLetter.buildHtmlMessage(any(), any())).thenReturn("string");
        when(documentRectificationLetter.buildPlainTextMessage(any(), any())).thenReturn("string");
        rectificationService.processDocument(getRectification(), "dboProId");
        verify(paymentAppApi).documentRectificationIdExecutePost(any());
    }

    @Test
    void processDocumentClr() {
        rectificationService.rbspEnabled = true;
        when(statementService.getPayment(any(), any())).thenReturn(new PaymentDTO()
                .subtype(PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT));
        when(paymentToPaymentConverter.convert(any())).thenReturn(new Payment().payer(new Requisite().name("name")
                .account("account")));
        when(documentRectificationLetter.buildHtmlMessage(any(), any())).thenReturn("string");
        when(documentRectificationLetter.buildPlainTextMessage(any(), any())).thenReturn("string");
        rectificationService.processDocument(getRectification(), "dboProId");
        verify(clarificationService).clarificationExecute(any());
    }

    @Test
    void getRegistryRequest() {
        when(paymentAppApi.documentRectificationGet(any(), any()))
                .thenReturn(ResponseEntity.ok(new RectificationDTO()));
        rectificationService.rbspEnabled = false;
        rectificationService.getRegistryRequest(1L);
        verify(paymentAppApi).documentRectificationGet(any(), any());
    }

    @Test
    void getRegistryRequestClr() {
        Rectification rec = new Rectification();
        rec.setId(1L);
        when(clarificationService.rectificationGet(any()))
                .thenReturn(rec);
        rectificationService.rbspEnabled = true;
        rectificationService.getRegistryRequest(1L);
        verify(clarificationService).rectificationGet(any());
    }

    Rectification getRectification() {
        return new Rectification()
                .id(1L)
                .documentId("payment_id_1")
                .created(OffsetDateTime.now())
                .payerAccount("payer_account_1")
                .status("CREATED")
                .payeeName("payee_name_1")
                .payeeAccount("payee_account_1")
                .payeeInn("payee_inn_1")
                .payeeKpp("payee_kpp_1")
                .purpose("purpose_1")
                .paymentBasis("payment_basis_1")
                .basisDocumentNumber("basis_document_number_1")
                .basisDocumentCreated("basis_document_created_1")
                .taxPeriod("tax_period_1")
                .uin("uin_1")
                .kbk("kbk_1")
                .oktmo("oktmo_1");
    }

    @Test
    void getActiveDocumentRectificationsByDocumentsId1() {
        RectificationDTO rectificationDTO = new RectificationDTO();
        rectificationDTO.setDocumentId("PP200122-410882501");
        rectificationDTO.setStatus(RectificationDTO.StatusEnum.ACTIVE);
        when(paymentAppApi.documentRectificationBatchGet(any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(rectificationDTO), HttpStatus.OK));
        List<String> documentIdList = new ArrayList<>();
        documentIdList.add("PP200122-410882501");
        Clarification clarification = new Clarification();
        clarification.setOperationUid("PP200122-410882501");
        when(clarificationService.clarificationFiltered(any()))
                .thenReturn(Collections.singletonList(clarification));


        Map<String, List<Rectification>> rectificationsMap = rectificationService
                .getActiveDocumentRectificationsByDocumentsId(documentIdList);

        Assert.assertNotNull(rectificationsMap);
        Assert.assertTrue(rectificationsMap.get("PP200122-410882501").stream()
                .anyMatch(r -> "PP200122-410882501".equals(r.getDocumentId())));
        Assert.assertTrue(rectificationsMap.get("PP200122-410882501").size() == 1);
    }

    @Test
    void getActiveDocumentRectificationsByDocumentsId2() {
        RectificationDTO rectificationDTO = new RectificationDTO();
        rectificationDTO.setDocumentId("PP200122-410882501");
        rectificationDTO.setStatus(RectificationDTO.StatusEnum.ACTIVE);
        when(paymentAppApi.documentRectificationBatchGet(any()))
                .thenReturn(new ResponseEntity<>(Collections.singletonList(rectificationDTO), HttpStatus.OK));
        List<String> documentIdList = new ArrayList<>();
        documentIdList.add("PP200122-410882501");
        documentIdList.add("PP200122-410882502");
        Clarification clarification = new Clarification();
        clarification.setOperationUid("PP200122-410882502");
        when(clarificationService.clarificationFiltered(any()))
                .thenReturn(Collections.singletonList(clarification));

        Map<String, List<Rectification>> rectificationsMap =
                rectificationService.getActiveDocumentRectificationsByDocumentsId(documentIdList);

        Assert.assertNotNull(rectificationsMap);
        Assert.assertTrue(rectificationsMap.get("PP200122-410882501").stream().anyMatch(r ->
                "PP200122-410882501".equals(r.getDocumentId())));
        Assert.assertTrue(rectificationsMap.get("PP200122-410882502").stream().anyMatch(r ->
                "PP200122-410882502".equals(r.getDocumentId())));
        Assert.assertTrue(rectificationsMap.size() == 2);
    }
}