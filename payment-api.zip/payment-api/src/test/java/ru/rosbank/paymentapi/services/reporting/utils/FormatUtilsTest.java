package ru.rosbank.paymentapi.services.reporting.utils;

import java.math.BigDecimal;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class FormatUtilsTest {

    @Test
    public void testFormatAmountWithDot() {
        Assert.assertEquals("123.00", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123)));
        Assert.assertEquals("123.00", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123.0)));
        Assert.assertEquals("123.46", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123.46)));
        Assert.assertEquals("123.50", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123.50)));
        Assert.assertEquals("123.52", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123.52)));
        Assert.assertEquals("123.80", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123.8)));
        Assert.assertEquals("123.46", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123.455)));
        Assert.assertEquals("123.08", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123.08)));
        Assert.assertEquals("0.00", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(0)));
        Assert.assertEquals("1.00", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(1)));
        Assert.assertEquals("11.00", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(11)));
        Assert.assertEquals("0.40", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(0.4)));
        Assert.assertEquals("123456.20", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(123456.2)));
        Assert.assertEquals("1000.40", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(1000.40)));
        Assert.assertEquals("12052.00", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(12052)));
        Assert.assertEquals("- 12052.00", FormatUtils.formatAmountWithDot(BigDecimal.valueOf(-12052)));
    }

    @Test
    public void testFormatAmount() {
        Assert.assertEquals("123-00", FormatUtils.formatAmount(BigDecimal.valueOf(123)));
        Assert.assertEquals("123-12", FormatUtils.formatAmount(BigDecimal.valueOf(123.12)));
        Assert.assertEquals("123-10", FormatUtils.formatAmount(BigDecimal.valueOf(123.1)));
        Assert.assertEquals("123-01", FormatUtils.formatAmount(BigDecimal.valueOf(123.01)));
        Assert.assertEquals("123-00", FormatUtils.formatAmount(BigDecimal.valueOf(123.0)));
        Assert.assertEquals("123-00", FormatUtils.formatAmount(BigDecimal.valueOf(123.00)));
        Assert.assertEquals("123-05", FormatUtils.formatAmount(BigDecimal.valueOf(-123.05)));
        Assert.assertEquals("123-00", FormatUtils.formatAmount(BigDecimal.valueOf(-123)));
    }

    @Test
    public void testFormatCurrencyToRubleString() {
        Assert.assertEquals("Сто двадцать три рубля", FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(123)));
        Assert.assertEquals("Сто двадцать три рубля 12 копеек",
                FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(123.12)));
        Assert.assertEquals("Сто двадцать три рубля 10 копеек",
                FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(123.1)));
        Assert.assertEquals("Сто двадцать три рубля 1 копейка",
                FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(123.01)));
        Assert.assertEquals("Сто двадцать три рубля", FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(123.0)));
        Assert.assertEquals("Сто двадцать три рубля", FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(123.00)));
        Assert.assertEquals("Сто двадцать три рубля 5 копеек",
                FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(-123.05)));
        Assert.assertEquals("Сто двадцать три рубля", FormatUtils.formatCurrencyToRubleString(BigDecimal.valueOf(-123)));
    }

    @Test
    public void testMaskCardNumber1() {
        Assert.assertEquals("4405 03** **** 6258", FormatUtils.maskCardNumber("4405036162566258"));
    }

    @Test
    public void testMaskCardNumber2() {
        Assert.assertEquals("4405 03** **** 625811", FormatUtils.maskCardNumber("440503616256625811"));
    }

    @Test
    public void testMaskCardNumberNegative1() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> FormatUtils.maskCardNumber("123456789012345"));
    }

    @Test
    public void testMaskCardNumberNegative2() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> FormatUtils.maskCardNumber("1234567890123456789"));
    }

    @Test
    public void testMaskCardNumberNegative3() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> FormatUtils.maskCardNumber("1234 5678 9012 3456"));
    }

    @Test
    public void testParseAmount() {
        Assert.assertEquals(new BigDecimal("123.00"), FormatUtils.parseAmount("123.00"));
        Assert.assertEquals(new BigDecimal("0.00"), FormatUtils.parseAmount("0"));
        Assert.assertEquals(new BigDecimal("0.00"), FormatUtils.parseAmount("00"));
        Assert.assertEquals(new BigDecimal("0.10"), FormatUtils.parseAmount(".10"));
        Assert.assertEquals(new BigDecimal("0.15"), FormatUtils.parseAmount("0.15"));
        Assert.assertEquals(new BigDecimal("0.16"), FormatUtils.parseAmount("0.155"));
        Assert.assertEquals(new BigDecimal("0.14"), FormatUtils.parseAmount("0.144"));
        Assert.assertEquals(new BigDecimal("-100.00"), FormatUtils.parseAmount("-100"));
    }

    @Test
    public void testParseAmountEmpty() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> Assert.assertEquals(BigDecimal.ZERO,
                FormatUtils.parseAmount("")));
    }

    @Test
    public void testParseAmountInvalid() {
        Assert.assertEquals(BigDecimal.ZERO, FormatUtils.parseAmount(null));
    }

    @Test
    public void testFormatCmsOperatingTime() {
        Assert.assertEquals("пн-пт 11:00-19:00;сб 11:00-18:00;вс выходной",
                FormatUtils.formatCmsOperatingTime(" [пн-пт]-[11:00]-[19:00]\n" + " [сб]-[11:00]-[18:00]"));
        Assert.assertEquals("пн-пт 10:00-19:00;сб, вс выходной",
                FormatUtils.formatCmsOperatingTime(" [пн-пт]-[10:00]-[19:00]"));
        Assert.assertEquals("",
                FormatUtils.formatCmsOperatingTime(""));
        Assert.assertEquals("пн-пт 10:00-14:00 15:00-19:00;сб, вс выходной",
                FormatUtils.formatCmsOperatingTime(" [пн-пт]-[10:00]-[14:00] [15:00]-[19:00]"));
        Assert.assertEquals("пн-чт 10:00-17:45;пт 10:00-16:45;сб, вс выходной",
                FormatUtils.formatCmsOperatingTime(" [пн-чт]-[10:00]-[17:45]\n" + " [пт]-[10:00]-[16:45]"));
    }

    @Test
    void formatAccountNumber() {
        String acc = FormatUtils.formatAccountNumber("12345678901234567890");
        Assert.assertEquals("12345 678 9 0123 4567890", acc);
    }

    @Test
    void maskCardNumber() {
        String amount = FormatUtils.maskCardNumber("0123456789012345");
        Assertions.assertEquals("0123 45** **** 2345",
                amount);
    }

    @Test
    void toUrlString() {
        String url = FormatUtils.toUrlString("templates/");
    }

    @Test
    void formatAmount() {
        String amount = FormatUtils.formatAmount(BigDecimal.valueOf(1111111121.50));
        Assertions.assertEquals("1 111 111 121-50",
                amount);
    }

    @Test
    void formatAmountIntegral() {
        String amount = FormatUtils.formatAmountIntegral(BigDecimal.valueOf(1111111121.50));
        Assertions.assertEquals("1 111 111 121.",
                amount);
    }

    @Test
    void formatAmountFraction() {
        String amount = FormatUtils.formatAmountFraction(BigDecimal.valueOf(1111111121.50));
        Assertions.assertEquals("50",
                amount);
    }

    @Test
    void formatAmountWithDot() {
        String amount = FormatUtils.formatAmountWithDot(BigDecimal.valueOf(1111111121.50));
        Assertions.assertEquals("1111111121.50",
                amount);
    }

    @Test
    void formatKbk() {
        String amount = FormatUtils.formatKbk("01234567890123456789");
        Assertions.assertEquals("012 3 45 67890 12 3456 789",
                amount);
    }

    @Test
    void formatOktmo() {
        String oktmo = FormatUtils.formatOktmo("01234567891");
        Assertions.assertEquals("01 234 567 891",
                oktmo);
        oktmo = FormatUtils.formatOktmo("01234567");
        Assertions.assertEquals("01 234 567",
                oktmo);
    }

    @Test
    void formatBoolean() {
        String bool = FormatUtils.formatBoolean(true);
        Assertions.assertEquals("1",
                bool);
    }
}