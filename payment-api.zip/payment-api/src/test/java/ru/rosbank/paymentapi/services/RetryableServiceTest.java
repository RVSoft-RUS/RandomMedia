package ru.rosbank.paymentapi.services;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.rosbank.BaseTest;
import ru.rosbank.paymentapi.feign.RefundApiFeignClient;
import ru.rosbank.paymentapi.model.feign.refundapi.GetRefundResponse;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundStatus;
import ru.rosbank.paymentapi.model.feign.refundapi.ResponseMetadata;
import ru.rosbank.paymentapi.model.feign.refundapi.WebResponseGetRefundResponse;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoRequest;

class RetryableServiceTest extends BaseTest {

    @Autowired
    RetryableService retryableService;
    @MockBean
    RefundApiFeignClient refundApiFeignClient;

    @Test
    void attemptToGetRefundExpectedStatusRetry() {
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.PROCESSING).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        Assertions.assertDoesNotThrow(
            () -> retryableService.attemptToGetRefundExpectedStatus(UUID.randomUUID(), RefundStatus.CONFIRMED));
        verify(refundApiFeignClient, times(5)).refundDocumentIdGet(any());
    }

    @Test
    void attemptToGetRefundExpectedStatusFailedNotRetries() {
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.FAILED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        Assertions.assertDoesNotThrow(
            () -> retryableService.attemptToGetRefundExpectedStatus(UUID.randomUUID(), RefundStatus.CONFIRMED));
        verify(refundApiFeignClient, times(1)).refundDocumentIdGet(any());
    }

    @Test
    void attemptToGetRefundExpectedStatusExpectedNotRetries() {
        when(refundApiFeignClient.refundDocumentIdGet(any()))
                .thenReturn(new ResponseEntity<>(
                        WebResponseGetRefundResponse.builder().data(
                                GetRefundResponse.builder().status(
                                        RefundStatus.CONFIRMED).build()).result(
                                ResponseMetadata.builder().code("123").status(200).build()).build(), HttpStatus.OK));
        SbpRefundInfoRequest sbpRefundInfoRequest = new SbpRefundInfoRequest();
        sbpRefundInfoRequest.setAmount(BigDecimal.valueOf(100_000L));
        sbpRefundInfoRequest.setDate(OffsetDateTime.now());
        Assertions.assertDoesNotThrow(
            () -> retryableService.attemptToGetRefundExpectedStatus(UUID.randomUUID(), RefundStatus.CONFIRMED));
        verify(refundApiFeignClient, times(1)).refundDocumentIdGet(any());
    }

}