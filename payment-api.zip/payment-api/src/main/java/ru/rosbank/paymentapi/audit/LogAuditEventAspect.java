package ru.rosbank.paymentapi.audit;

import static org.apache.commons.lang3.StringUtils.isEmpty;

import java.lang.reflect.Method;
import java.util.Optional;
import javax.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.rosbank.paymentapi.services.AuditService;
import ru.rosbank.platform.client.auditapp.model.EventDTO;

/**
 * LogAuditEventAspect Заполнение таблицы событий.
 */
@Slf4j
@Aspect
@Component
public class LogAuditEventAspect {

    @Autowired
    private AuditService auditService;
    @Autowired
    private HttpSession session;

    @AfterReturning(value = "@annotation(ru.rosbank.paymentapi.audit.LogAuditEvent)", returning = "result")
    public void logEvent(JoinPoint joinPoint, Object result) {
        try {
            EventDTO event = createEvent(joinPoint);
            if (isEmpty(event.getMessage())) {
                event.setMessage(resultToMessage(result));
            }
            auditService.sendEvent(event);
        } catch (Exception e) {
            log.error("Error sending audit message", e);
        }
    }

    @AfterThrowing(value = "@annotation(ru.rosbank.paymentapi.audit.LogAuditEvent)", throwing = "ex")
    public void logAfterThrowing(JoinPoint joinPoint, Exception ex) {
        try {
            EventDTO event = createEvent(joinPoint);
            event.setErrorMessage(Optional.ofNullable(ex.getMessage()).orElse(ex.getClass().getSimpleName()));
            auditService.sendEvent(event);
        } catch (Exception e) {
            log.error("Error sending audit message", e);
        }
    }

    private EventDTO createEvent(JoinPoint joinPoint) throws NoSuchMethodException {
        Class targetClass = joinPoint.getTarget().getClass();
        String methodName = joinPoint.getSignature().getName();
        Class[] parameterTypes = ((MethodSignature)joinPoint.getSignature()).getMethod().getParameterTypes();
        Method method = targetClass.getMethod(methodName, parameterTypes);
        EventDTO event = new EventDTO();
        LogAuditEvent annotation = method.getAnnotation(LogAuditEvent.class);
        event.setDboProId(session.getAttribute("CLIENT_ID").toString());
        event.setStage(annotation.stage());
        event.setMessage(paramToMessage(joinPoint, annotation));
        return event;
    }

    private String paramToMessage(JoinPoint joinPoint, LogAuditEvent annotation) {
        Object[] args = joinPoint.getArgs();
        if (args.length > 0) {
            if (annotation.argNum() > 0) {
                return args[annotation.argNum() - 1].toString();
            }
        }
        return null;
    }

    private String resultToMessage(Object result) {
        return Optional.ofNullable(result).map(Object::toString).orElse("");
    }
}
