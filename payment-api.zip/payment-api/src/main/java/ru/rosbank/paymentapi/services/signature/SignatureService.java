package ru.rosbank.paymentapi.services.signature;

import feign.FeignException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;

@Service
@RequiredArgsConstructor
@Slf4j
public class SignatureService {
    private final CryptoproAppApi cryptoproAppApi;

    public List<SignatureDTO> getSignaturesByOtp(OtpDTO otp) {
        try {
            return cryptoproAppApi.packagesignatureIdsignatureGet(otp.getReference()).getBody();
        } catch (FeignException e) {
            log.error("Ошибка подписей по пакетному идентификатору {} ", otp.getReference(), e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
    }
}
