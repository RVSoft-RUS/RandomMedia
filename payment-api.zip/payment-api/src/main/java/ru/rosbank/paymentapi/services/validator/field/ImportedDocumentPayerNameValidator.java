package ru.rosbank.paymentapi.services.validator.field;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerNameValidator;




@Service
public class ImportedDocumentPayerNameValidator extends DocumentPayerNameValidator {
    private static final String ERROR_MESSAGE_EMPTY = "Поле наименование плательщика должно быть заполнено";
    private static final String ESB_NOT_ACCEPTABLE_SYMBOLS_REGEXP
            = "[^a-zA-Z0-9а-яА-ЯёЁ\\s{}\\.<>()+!&№$*;^\\-/|,%_?`:#@'=\"~\\\\§]*";

    public void validate(DocumentDTO document) throws ValidationPaymentException {
        String payerName = Optional.ofNullable(document.getPayer()).map(RequisiteDTO::getName)
                .orElseThrow(() -> new ValidationPaymentException(8, "payer.name", ERROR_MESSAGE_EMPTY));
        if (StringUtils.isNotBlank(payerName)) {
            document.getPayer().setName(payerName.replaceAll(ESB_NOT_ACCEPTABLE_SYMBOLS_REGEXP, ""));
        }
        super.validate(document);
    }

}
