package ru.rosbank.paymentapi.rbsp.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Запрос на создание уточнения.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Clarification {
    private Long clarificationId;
    private OffsetDateTime creationDate;
    private String status;
    @NotNull
    private String operationUid;
    private String operationUidType;
    private String sourceSubsystem;
    private String statusMessage;
    @NotNull
    private String paymentNumber;
    @NotNull
    private LocalDate paymentDate;
    private PayeeInfo payeeInfo;
    private String purpose;
    private String uin;
    private String taxKbk;
    private String taxOktmo;
    private String taxPaymentReason;
    private String taxPeriod;
    private String taxDocNumber;
    private String taxDocDate;
    private String codeTypeIncome;
    private String typeTaxPayment;
    @NotNull
    private OrganizationInfo organizationInfo;
    @Schema(description = "Поле ТИП клиента LE или IP")
    private String cliType;
    @Schema(description = "Расчетный счет плательщика из уточняемого платежа.")
    private String payerAccNumber;
    private String type;
}
