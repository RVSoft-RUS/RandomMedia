package ru.rosbank.paymentapi.exception;

public class AvaliableBalanceExcessException extends DocumentRejectedException {

    public AvaliableBalanceExcessException(String msg) {
        super(msg);
    }
}
