package ru.rosbank.paymentapi.services;


import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.paymentapi.services.validator.CommissionPaymentValidators;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.AmountDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.CommissionWarning;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.PaymentCommission;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommissionService {
    private static final String ERR_COMMISSION_BALANCE = "На счете недостаточно средств для оплаты комиссии, "
            + "пополните счет в течение суток для исполнения платежа";
    private static final String COMMISSION_DISABLED_MESSAGE = "Не удалось рассчитать комиссию. "
            + "Платеж все равно будет исполнен, если на счету достаточно средств";
    private static final String COMMON_ERR_MESSAGE = "При расчете комиссии произошла ошибка. "
            + "Пожалуйста, попробуйте снова";
    private final ProductService productService;
    private final PaymentAppApi paymentAppApi;
    private final DocumentToPaymentConverter converter;
    private final CommissionPaymentValidators validators;
    private final OrganizationService organizationService;
    @Value("${payment.commission.enabled}")
    protected Boolean commissionEnabled;

    public PaymentCommission getPaymentCommission(Payment doc, String dboProId) {
        PaymentCommission paymentCommission = new PaymentCommission();

        if (!commissionEnabled) {

            CommissionWarning commissionWarning = new CommissionWarning();
            commissionWarning.setType(CommissionWarning.TypeEnum.INFO);
            commissionWarning.setMessage(COMMISSION_DISABLED_MESSAGE);
            paymentCommission.setWarning(commissionWarning);
            return paymentCommission;
        }
        var payerAccount20 = doc.getPayer().getAccount();
        var organizationAcc = productService.getOrganizationAccByAccNumberAndDboProId(payerAccount20, dboProId);

        if (organizationAcc == null || organizationAcc.getAccounts() == null) {
            throw new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен");
        }

        List<AccountDTO> accounts = organizationAcc.getAccounts();
        var accountOpt = accounts.stream().filter(a -> payerAccount20.equals(a.getNumber())).findFirst();
        if (accountOpt.isEmpty()) {
            throw new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен");
        }
        var accountDTO = accountOpt.get();
        BisIdDTO bisId = accountDTO.getBisId();
        //if tariff is "CR1" or "CR2" (tariff-constructor) commission is always null
        String tariffCode = getTariffCode(doc, bisId);
        if ("CR1".equals(tariffCode) || "CR2".equals(tariffCode)) {
            return paymentCommission;
        }

        Amount commission = new Amount();
        DocumentDTO documentDTO = converter.convertBack(doc, accountDTO);
        documentDTO.setBisId(new ru.rosbank.platform.client.paymentapp.model.BisIdDTO()
                .id(bisId.getId())
                .branch(bisId.getBranch()));
        documentDTO.setTariffCode(tariffCode);
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        organizationAcc.getAccounts().forEach(a -> accountsMap.put(a.getNumber(), a));
        validators.validate(documentDTO, accountsMap);
        try {
            AmountDTO dto = paymentAppApi.documentCommissionCalculationPost(documentDTO).getBody();
            commission.sum(dto.getSum()).currency(dto.getCurrency());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            CommissionWarning commissionWarning = new CommissionWarning();
            commissionWarning.setType(CommissionWarning.TypeEnum.ERROR);
            commissionWarning.setMessage(COMMON_ERR_MESSAGE);
            paymentCommission.setWarning(commissionWarning);
            return paymentCommission;
        }
        if (!isEnoughMoneyForCommission(doc, commission, accountDTO)) {
            paymentCommission.setCommission(commission);
            CommissionWarning commissionWarning = new CommissionWarning();
            commissionWarning.setType(CommissionWarning.TypeEnum.WARNING);
            commissionWarning.setMessage(ERR_COMMISSION_BALANCE);
            paymentCommission.setWarning(commissionWarning);
            return paymentCommission;
        }

        paymentCommission.setCommission(commission);
        return paymentCommission;
    }

    private String getTariffCode(Payment doc, BisIdDTO bisIdDTO) {
        try {
            return organizationService.getTariff(bisIdDTO.getId(), bisIdDTO.getBranch(), doc.getOrganizationId())
                    .getBisId()
                    .getTariff();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean isEnoughMoneyForCommission(Payment doc, Amount commission, AccountDTO accountDTO) {
        BigDecimal accountBalance = new BigDecimal(accountDTO.getRestAmount());
        if (accountBalance != null && accountBalance.compareTo(commission.getSum().add(doc.getAmount().getSum())) >= 0) {
            return true;
        }
        return false;
    }
}
