package ru.rosbank.paymentapi.services;

import static ru.rosbank.paymentapi.commons.Constants.NOT_ENOUGH_RIGHTS_ERROR;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.AccessForbiddenException;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

@Slf4j
@Service
@RequiredArgsConstructor
public class PermissionService {

    public void checkCreatePaymentPermissions(IndividualDTO individualDTO) {
        if (!IndividualDTO.AccessGroupEnum.ALL_RIGHTS.equals(individualDTO.getAccessGroup())
                && !IndividualDTO.AccessGroupEnum.CREATE_DELETE.equals(individualDTO.getAccessGroup())) {
            throw new AccessForbiddenException(NOT_ENOUGH_RIGHTS_ERROR);
        }
    }

}
