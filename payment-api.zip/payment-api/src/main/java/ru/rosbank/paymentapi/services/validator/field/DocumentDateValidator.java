package ru.rosbank.paymentapi.services.validator.field;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;


/**
 * Summary.
 * Field 4
 */
@Service
public class DocumentDateValidator implements IDocumentValidator {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final int FIELD_ID = 4;
    private static final int MIN_DAYS_BEFORE = 11;
    private static final int MAX_DAYS_AFTER = 30;
    private static final String FIELD_NAME = "date";
    private static final String ERROR_MESSAGE_INCORRECT_DATE = "Дата документа должна быть в интервале от %s до %s."
            + " Укажите верную дату документа в программе 1С и повтороно загрузите платёж";

    @Override
    public void validate(DocumentDTO document) {
        OffsetDateTime date = document.getDate();
        OffsetDateTime now = OffsetDateTime.now(date.getOffset());

        OffsetDateTime earliestDateTime = now.minusDays(MIN_DAYS_BEFORE);
        OffsetDateTime latestDateTime = now.plusDays(MAX_DAYS_AFTER);

        if (date.isBefore(earliestDateTime) || date.isAfter(latestDateTime)) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME,
                    String.format(ERROR_MESSAGE_INCORRECT_DATE,
                            earliestDateTime.plusDays(1).toLocalDate().format(DATE_FORMATTER),
                            latestDateTime.toLocalDate().format(DATE_FORMATTER)));
        }
    }
}
