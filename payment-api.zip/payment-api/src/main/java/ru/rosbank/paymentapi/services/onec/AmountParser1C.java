package ru.rosbank.paymentapi.services.onec;

import java.math.BigDecimal;
import org.apache.commons.lang3.StringUtils;
import ru.rosbank.paymentapi.services.reporting.utils.FormatUtils;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class AmountParser1C extends AbstractDocumentFieldParser1C {
    private static final String AMOUNT_KEY = "Сумма";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            String value = getValueFromLine(line);
            BigDecimal amount = StringUtils.isBlank(value) ? BigDecimal.ZERO : FormatUtils.parseAmount(value);
            document.setAmount(amount.abs().toString());
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, AMOUNT_KEY);
    }
}
