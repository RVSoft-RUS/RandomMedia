package ru.rosbank.paymentapi.exception;

public class BankInfoException extends RuntimeException {

    public BankInfoException(String msg) {
        super(msg);
    }
}
