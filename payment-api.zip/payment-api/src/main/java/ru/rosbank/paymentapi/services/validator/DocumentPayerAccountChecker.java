package ru.rosbank.paymentapi.services.validator;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.audit.AuditContext;
import ru.rosbank.paymentapi.audit.ThreadLocalAuditContext;
import ru.rosbank.paymentapi.exception.AccessForbiddenException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;

@RequiredArgsConstructor
@Service
public class DocumentPayerAccountChecker {

    private static final List<IndividualDTO.AccessGroupEnum> VALID_ROLES =
            List.of(IndividualDTO.AccessGroupEnum.CREATE_DELETE, IndividualDTO.AccessGroupEnum.ALL_RIGHTS);

    private final OrganizationService organizationService;

    public void validate(String dboProId, OrganizationDTO org) throws ValidationException {

        IndividualDTO.AccessGroupEnum role = organizationService.applyRole(dboProId, org);
        if (VALID_ROLES.contains(role)) {
            return;
        }

        throw new AccessForbiddenException("9: Счёт плательщика запрещён.");
    }


}
