package ru.rosbank.paymentapi.services;

import static ru.rosbank.paymentapi.commons.Constants.OUTCOME_PAYMENT;
import static ru.rosbank.platform.server.paymentapi.model.Payment.StatusEnum.COMPLETED;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.model.AccountTurnover;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Turnover;


/**
 * Summary.
 * @author rb068774
 */
@Service
public class AccountTurnoverService {

    public List<Turnover> getAccountTurnoversForDocumentList(List<Payment> documents) {
        Map<AccountTurnover, AccountTurnover> accountTurnoverMap = new HashMap<>();

        Optional.ofNullable(documents).orElse(new ArrayList<>()).stream().filter(doc -> COMPLETED.equals(doc.getStatus())
            && doc.getCompleted() != null)
            .forEach(doc -> addAccountTurnover(accountTurnoverMap, doc));

        return Optional.ofNullable(accountTurnoverMap.values().stream().map(t -> t.toDto()).collect(Collectors.toList()))
            .orElse(new ArrayList<>());
    }

    private void addAccountTurnover(Map<AccountTurnover, AccountTurnover> accountTurnoverMap,
                                    Payment documentDto) {
        AccountTurnover accountTurnover = new AccountTurnover();
        if (OUTCOME_PAYMENT.contains(documentDto.getType()) || Payment.TypeEnum.DP == documentDto.getType()) {
            accountTurnover.setAccount(documentDto.getPayer().getAccount());
        } else {
            accountTurnover.setAccount(documentDto.getPayee().getAccount());
        }
        accountTurnover.setCurrency(documentDto.getAmount().getCurrency());
        accountTurnover.setDate(documentDto.getCompleted());
        if (accountTurnoverMap.containsKey(accountTurnover)) {
            accountTurnover = accountTurnoverMap.get(accountTurnover);
        } else {
            accountTurnoverMap.put(accountTurnover, accountTurnover);
        }

        if (OUTCOME_PAYMENT.contains(documentDto.getType()) || Payment.TypeEnum.DP == documentDto.getType()) {
            accountTurnover.setAmountOutgoing(accountTurnover.getAmountOutgoing().add(documentDto.getAmount()
                .getSum()));
        } else {
            accountTurnover.setAmountIncoming(accountTurnover.getAmountIncoming().add(documentDto.getAmount()
                .getSum()));
        }
    }

}
