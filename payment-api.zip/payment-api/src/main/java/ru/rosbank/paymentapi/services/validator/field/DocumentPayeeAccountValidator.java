package ru.rosbank.paymentapi.services.validator.field;

import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static ru.rosbank.paymentapi.commons.PaymentUtils.BIC_TUPE_UTRA_ACC;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentTypeCalculator;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

/**
 * Summary.
 * Field 17
 */
@Slf4j
@Service
@Order(-100)
public class DocumentPayeeAccountValidator implements IDocumentValidator {
    public static final String DEFAULT_ERROR_MESSAGE = "17: Заполните поле";
    public static final String MONEYBOX_ERROR_MESSAGE = "17: С бизнес-копилки можно сделать платеж только в бюджет и "
            + "на свой счет в Росбанке";
    private static final String ERROR_MESSAGE_RUB_ONLY =
            "17: Перевод осуществляется только на рублёвые счета (код валюты - 810)";
    private static final String ERROR_MESSAGE_PAYER_AND_PAYEE_ACCOUNTS_EQUALS =
            "17: Номер счёта получателя совпадает с номером счёта плательщика";
    private static final String ERROR_MESSAGE_INVALID_KEY = "17: Указан неверный номер счёта получателя";
    private static final String NONRESIDENT_PURPOSE_ERROR_MESSAGE = "24: Выбран счёт нерезидента. "
            + "Укажите код валютной операции в поле \"Назначение платежа\"";
    private static final List<String> OUTDATED_NON_RESIDENT_ACCOUNTS = Collections
            .unmodifiableList(Arrays.asList("40803", "40804", "40805", "40806", "40809", "40813", "40814", "40815"));
    private static final List<Integer> WEIGHTS_ACCOUNT_BIC
            = Collections.unmodifiableList(Arrays.asList(7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1));
    private static final short APPROPRIATE_CODE_CURRENCY = 810;
    private static final short APPROPRIATE_CODE_CURRENCY_BIC_UTRA = 643;
    private static final String PREFIX_COR_ACCOUNT_UTRA = "40102";
    public static final String PAYEE_ACCOUNT_FIELD = "payee.account";
    public static final String FORBIDDEN_PAYEE_ACCOUNT_MSG = "В качестве счёта получателя выбран недопустимый счёт";
    private static final String ERROR_MSG_BIC_UTRA_643 = "Символы с 6 по 8 в номере счета должны быть равны 643";

    @Autowired
    private AccountService accountService;
    @Autowired
    private ReferenceService referenceService;
    @Autowired
    private DocumentTypeCalculator documentTypeCalculator;

    @Override
    public void validate(DocumentDTO document) throws ValidationPaymentException {
        validatePayeeAccount(document, null);
    }


    public void validate(DocumentDTO document, Map<String, AccountDTO> clientAccounts) throws ValidationPaymentException {
        validatePayeeAccount(document, clientAccounts);
    }

    void validatePayeeAccount(DocumentDTO document, Map<String, AccountDTO> clientAccounts) {
        String payeeAccount = document.getPayee().getAccount();

        if (isBlank(payeeAccount) || payeeAccount.length() != 20) {
            throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, DEFAULT_ERROR_MESSAGE);
        }

        if (payeeAccount.startsWith("30101") || payeeAccount.startsWith("40102")) {
            throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, FORBIDDEN_PAYEE_ACCOUNT_MSG);
        }

        if (isBicTypeUtra(document.getPayee().getBank().getBic())
                && document.getPayee().getBank().getCorrespondentAccount().startsWith(PREFIX_COR_ACCOUNT_UTRA)) {
            if (!payeeAccount.startsWith("0")) {
                throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, ERROR_MESSAGE_INVALID_KEY);
            }
            if (Short.parseShort(payeeAccount.substring(5, 8)) != APPROPRIATE_CODE_CURRENCY_BIC_UTRA) {
                throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, ERROR_MSG_BIC_UTRA_643);
            }

            return;
        }

        if (Short.parseShort(payeeAccount.substring(5, 8)) != APPROPRIATE_CODE_CURRENCY) {
            throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, ERROR_MESSAGE_RUB_ONLY);
        }

        if (payeeAccount.equals(document.getPayer().getAccount())) {
            throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, ERROR_MESSAGE_PAYER_AND_PAYEE_ACCOUNTS_EQUALS);
        }

        if (isFalse(isAccountValidByBic(payeeAccount, document.getPayee().getBank().getBic()))) {
            throw new ValidationPaymentException(17, "payee.bank.bic", ERROR_MESSAGE_INVALID_KEY);
        }

        if (isNonresident(payeeAccount)) {
            checkNonresidentPurpose(document.getPurpose());
        }

        if (OUTDATED_NON_RESIDENT_ACCOUNTS.stream().anyMatch(payeeAccount::startsWith)) {
            throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD,
                    "Устаревший номер счёта, на который не могут быть зачислены денежные средства. "
                            + "Введите другой номер счёта");
        }

        if (clientAccounts == null) {
            checkMoneyBox(document);
        } else {
            checkMoneyBox(document, clientAccounts);
        }
    }


    public boolean isBicTypeUtra(String bic) {
        return referenceService.getBankInfo(bic).stream().findFirst().map(bank -> BIC_TUPE_UTRA_ACC.contains(bank.getBikType()))
                .orElse(false);
    }

    private boolean isNonresident(String account) {
        return account.startsWith("40807") || account.startsWith("30111") || account.startsWith("40820")
                || account.startsWith("425");
    }

    private static void checkNonresidentPurpose(String purpose) throws ValidationPaymentException {
        if (isBlank(purpose)) {
            throw new ValidationPaymentException(24, "purpose", NONRESIDENT_PURPOSE_ERROR_MESSAGE);
        }

        Pattern pattern = Pattern.compile("\\{VO.{5}}");
        Matcher matcher = pattern.matcher(purpose);
        if (isFalse(matcher.find())) {
            throw new ValidationPaymentException(24, "purpose", NONRESIDENT_PURPOSE_ERROR_MESSAGE);
        }
    }

    public boolean isAccountValidByBic(String account, String bic) {
        int number = Integer.parseInt(bic.substring(6));
        final String extendedAccount;
        if (number < 50) {
            // cash center
            extendedAccount = "0" + bic.substring(4, 6) + account;
        } else {
            // credit organization
            extendedAccount = bic.substring(6, 9) + account;
        }

        int checksum = IntStream.range(0, extendedAccount.length())
                .map(i -> (WEIGHTS_ACCOUNT_BIC.get(i) * Integer.parseInt("" + extendedAccount.charAt(i))) % 10).sum();
        return checksum % 10 == 0;

    }

    void checkMoneyBox(DocumentDTO document) throws ValidationPaymentException {
        var payerAccountDTO = accountService.getAccount(document.getPayer().getAccount());
        log.info("checkMoneyBox for document payer account {} and document payee account {} result is {}",
                document.getPayer().getAccount(),
                document.getPayee().getAccount(), "CD".equals(Optional.ofNullable(payerAccountDTO)
                        .orElseThrow(() -> new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен"))
                        .getAccountType()));
        log.info("checkMoneyBox for document payer account {} and document payee account {} result isBudget {}",
                document.getPayer().getAccount(),
                document.getPayee().getAccount(), documentTypeCalculator.isBudget(document));
        boolean isToOwnAccount = isToOwnAccount(document);
        log.info("checkMoneyBox for document payer account {} and document payee account {} result isToOwnAccount {}",
                document.getPayer().getAccount(),
                document.getPayee().getAccount(), isToOwnAccount);
        if ("CD".equals(Optional.of(payerAccountDTO)
                .orElseThrow(() -> new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен"))
                .getAccountType())
                && !(documentTypeCalculator.isBudget(document) || isToOwnAccount)) {
            throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, MONEYBOX_ERROR_MESSAGE);
        }
    }

    void checkMoneyBox(DocumentDTO document, Map<String, AccountDTO> clientAccounts) throws ValidationPaymentException {
        var payerAccount = Optional.ofNullable(document).map(DocumentDTO::getPayer).map(RequisiteDTO::getAccount)
                .orElseThrow(() -> new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен"));
        var payeeAccount = Optional.ofNullable(document).map(DocumentDTO::getPayee).map(RequisiteDTO::getAccount)
                .orElseThrow(() -> new ValidationPaymentException(17, "payee_account", "Сервис платежей недоступен"));
        var payerAccountDTO = clientAccounts.get(payerAccount);
        log.info("checkMoneyBox for document payer account {} and document payee account {} result is {}",
                payerAccount,
                payeeAccount, "CD".equals(Optional.ofNullable(payerAccountDTO)
                        .orElseThrow(() -> new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен"))
                        .getAccountType()));
        log.info("checkMoneyBox for document payer account {} and document payee account {} result isBudget {}",
                payerAccount,
                payeeAccount, documentTypeCalculator.isBudget(document));
        boolean isToOwnAccount = isToOwnAccount(document, clientAccounts);
        log.info("checkMoneyBox for document payer account {} and document payee account {} result isToOwnAccount {}",
                payerAccount,
                payeeAccount, isToOwnAccount);
        if ("CD".equals(Optional.of(payerAccountDTO)
                .orElseThrow(() -> new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен"))
                .getAccountType())
                && !(documentTypeCalculator.isBudget(document) || isToOwnAccount)) {
            throw new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, MONEYBOX_ERROR_MESSAGE);
        }
    }

    boolean isToOwnAccount(DocumentDTO document, Map<String, AccountDTO> clientAccounts) {
        String payeeAccount = document.getPayee().getAccount();
        return clientAccounts.containsKey(payeeAccount);
    }

    boolean isToOwnAccount(DocumentDTO document) {
        BisIdDTO bisIdPayerOrg = Optional.ofNullable(accountService.getAccount(document.getPayer().getAccount()))
                .map(AccountDTO::getBisId)
                .orElseThrow(() -> new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен"));

        List<AccountDTO> accounts;
        if (document.getCrmId() != null) {
            accounts = accountService.getAccountList(document.getCrmId(),
                    List.of(new ru.rosbank.platform.client.organizationapp.model.BisIdDTO().branch(bisIdPayerOrg.getBranch())
                            .id(bisIdPayerOrg.getId())));
        } else {
            accounts = accountService.getAccountList(bisIdPayerOrg.getId(), bisIdPayerOrg.getBranch());
        }
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        accounts.forEach(a -> accountsMap.put(a.getNumber(), a));
        return isToOwnAccount(document, accountsMap);
    }

}
