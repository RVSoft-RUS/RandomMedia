package ru.rosbank.paymentapi.util;

import java.util.List;
import lombok.Data;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;

@Data
public class OrganizationAcc {
    OrganizationDTO org;
    List<AccountDTO> accounts;
}
