package ru.rosbank.paymentapi.services.onec.budget;


import ru.rosbank.paymentapi.services.onec.AbstractDocumentFieldParser1C;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class PaymentBasisParser1C extends AbstractDocumentFieldParser1C {
    private static final String PAYMENT_BASIS_KEY = "ПоказательОснования";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.setPaymentBasis(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, PAYMENT_BASIS_KEY);
    }
}
