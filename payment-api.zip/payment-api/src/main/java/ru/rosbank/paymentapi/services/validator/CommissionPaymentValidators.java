package ru.rosbank.paymentapi.services.validator;

import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.validator.field.DocumentAmountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentExecutionDateValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankBicValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankCorrAccountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentTypeTaxPaymentValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentBasisDocumentNumberValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentCodeTypeIncomeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentKbkValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentOktmoValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayPriorityValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeInnValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerAccountValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerStatusValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisCreatedValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentTaxPeriodValidator;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommissionPaymentValidators {

    private final List<IDocumentValidator> validators;

    DocumentExecutionDateValidator documentExecutionDateValidator;
    DocumentPayeeAccountValidator documentPayeeAccountValidator;

    @Autowired
    CommissionPaymentValidators(
            DocumentPayeeBankBicValidator documentPayeeBankBicValidator,
            DocumentPayerAccountValidator documentPayerAccountValidator,
            DocumentPaymentBasisValidator documentPaymentBasisValidator,
            DocumentPayeeBankCorrAccountValidator documentPayeeBankCorrAccountValidator,
            DocumentPayPriorityValidator documentPayPriorityValidator,
            DocumentPayeeInnValidator documentPayeeInnValidator,
            DocumentPayeeKppValidator documentPayeeKppValidator,
            DocumentAmountValidator documentAmountValidator,
            DocumentKbkValidator documentKbkValidator,
            DocumentOktmoValidator documentOktmoValidator,
            DocumentPayeeAccountValidator documentPayeeAccountValidator,
            DocumentBasisDocumentNumberValidator documentBasisDocumentNumberValidator,
            DocumentPayerStatusValidator documentPayerStatusValidator,
            DocumentTaxPeriodValidator documentTaxPeriodValidator,
            DocumentPaymentBasisCreatedValidator documentPaymentBasisCreatedValidator,
            DocumentCodeTypeIncomeValidator documentCodeTypeIncomeValidator,
            DocumentTypeTaxPaymentValidator documentTypeTaxPaymentValidator,
            DocumentExecutionDateValidator documentExecutionDateValidator
    ) {
        validators = List.of(
                documentPayerAccountValidator,
                documentPayeeBankBicValidator,
                documentBasisDocumentNumberValidator,
                documentPaymentBasisValidator,
                documentPaymentBasisCreatedValidator,
                documentPayPriorityValidator,
                documentTaxPeriodValidator,
                documentKbkValidator,
                documentOktmoValidator,
                documentPayeeInnValidator,
                documentPayeeKppValidator,
                documentPayerStatusValidator,
                documentPayeeBankCorrAccountValidator,
                documentCodeTypeIncomeValidator,
                documentTypeTaxPaymentValidator,
                documentAmountValidator
        );
        this.documentExecutionDateValidator = documentExecutionDateValidator;
        this.documentPayeeAccountValidator = documentPayeeAccountValidator;
    }

    public void validate(DocumentDTO documentDTO, Map<String, AccountDTO> clientAccounts)
            throws ValidationPaymentException {

        if (documentDTO.getExecutionDate() != null) {
            documentExecutionDateValidator.validate(documentDTO);
        }
        for (IDocumentValidator validator : validators) {
            validator.validate(documentDTO);
        }
        documentPayeeAccountValidator.validate(documentDTO, clientAccounts);
    }
}
