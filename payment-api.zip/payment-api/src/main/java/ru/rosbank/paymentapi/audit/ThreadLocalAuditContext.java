package ru.rosbank.paymentapi.audit;

import org.springframework.util.Assert;

/**
 * ThreadLocal обертка для {@link AuditContext}.
 *
 * <p>По умолчанию и после сброса значения инициализируется {@code new AuditContext()}. Автоинициализация позволяет не
 * заботиться о контексте там где он не нужен (тесты, фоновые задачи и т.п.)</p>
 *
 * @author Q-APE
 */
public class ThreadLocalAuditContext {

    private static final ThreadLocal<AuditContext> threadLocal = new ThreadLocal<AuditContext>() {

        @Override
        protected AuditContext initialValue() {
            return new AuditContext();
        }

    };

    /**
     * Возвращает thread local экземпляр контекста клиента {@link AuditContext}.
     *
     * @return AuditContext контекст клиента (non-null).
     */
    public static AuditContext get() {
        return threadLocal.get();
    }

    /**
     * Сохраняет {@link AuditContext} в thread local.
     *
     * @param auditContext AuditContext контекст клиента (non-null).
     */
    public static void set(AuditContext auditContext) {
        Assert.notNull(auditContext, "auditContext must not be null!");
        threadLocal.set(auditContext);
    }

    /**
     * Сбрасывает состояние ThreadLocal.
     */
    public static void clear() {
        threadLocal.remove();
    }
}
