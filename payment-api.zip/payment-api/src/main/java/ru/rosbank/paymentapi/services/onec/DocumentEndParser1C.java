package ru.rosbank.paymentapi.services.onec;


import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class DocumentEndParser1C extends AbstractDocumentFieldParser1C {

    private static final String DOCUMENT_END_KEY = "КонецДокумента";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        // nothing to do
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, DOCUMENT_END_KEY);
    }

    public static String getDocumentEndKey() {
        return DOCUMENT_END_KEY;
    }
}
