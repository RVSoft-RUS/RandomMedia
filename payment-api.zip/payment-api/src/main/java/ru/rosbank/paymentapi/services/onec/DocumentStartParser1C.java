package ru.rosbank.paymentapi.services.onec;

import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class DocumentStartParser1C extends AbstractDocumentFieldParser1C {
    private static final String DOCUMENT_START_KEY = "СекцияДокумент";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        // nothing to do
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, DOCUMENT_START_KEY);
    }

    public static String getKey() {
        return DOCUMENT_START_KEY;
    }

}
