package ru.rosbank.paymentapi.services.integration;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApiClient;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReferenceAppService {
    private final ReferenceAppApiClient referenceAppApi;

    public List<BankDTO> getBankInfo(String query) {
        log.info("Вызов referenceAppApi.bankGet для query = {}", query);
        return referenceAppApi.bankGet(query).getBody();
    }

    @Cacheable(value = "branches", sync = true)
    public List<BranchDTO> getBranch(String code) {
        log.info("Вызов referenceAppApi.branchGet для code = {}", code);
        return referenceAppApi.branchGet(code).getBody();
    }
}
