package ru.rosbank.paymentapi.model.feign.refundapi;

import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * Метадата ответа.
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResponseMetadata {

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime timestamp;
    private UUID id;
    private Integer status;
    private String code;
    private String message;
    private String debugInfo;

    public boolean isSuccess() {
        if (status != null) {
            return status >= 200 && status < 300;
        }
        return false;
    }

}

