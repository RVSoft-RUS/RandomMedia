package ru.rosbank.paymentapi.services.reporting;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;


/**
 * Summary.
 *
 * @author rb068774
 * @since 08.07.2021
 */
@Slf4j
public class StatementPdfMerger {

    public StatementPdfMerger() {
    }

    List<InputStream> fullPdf = new ArrayList<>();


    public void add(ByteArrayOutputStream extendedDocument) throws IOException {
        var reportInput = new ByteArrayInputStream(extendedDocument.toByteArray());
        try (reportInput) {
            fullPdf.add(reportInput);
        }
    }

    public ByteArrayOutputStream process() {
        ByteArrayOutputStream reportFull = new ByteArrayOutputStream();
        try {
            mergePdfFiles(fullPdf, reportFull);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return reportFull;
    }


    private static void mergePdfFiles(List<InputStream> inputPdfList, OutputStream outputStream) throws Exception {
        //Create document and pdfReader objects.
        Document document = new Document();
        List<PdfReader> readers = new ArrayList<>();
        int totalPages = 0;

        //Create pdf Iterator object using inputPdfList.

        // Create reader list for the input pdf files.
        for (InputStream pdf : inputPdfList) {
            try (pdf) {
                var pdfReader = new PdfReader(pdf);
                readers.add(pdfReader);
                totalPages = totalPages + pdfReader.getNumberOfPages();
            }
        }

        // Create writer for the outputStream
        var writer = PdfWriter.getInstance(document, outputStream);

        //Open document.
        document.open();

        //Contain the pdf data.
        PdfContentByte pageContentByte = writer.getDirectContent();

        PdfImportedPage pdfImportedPage;
        int currentPdfReaderPage = 1;

        // Iterate and process the reader list.
        for (PdfReader pdfReader : readers) {
            //Create page and add content.
            while (currentPdfReaderPage <= pdfReader.getNumberOfPages()) {
                document.newPage();
                pdfImportedPage = writer.getImportedPage(pdfReader, currentPdfReaderPage);
                pageContentByte.addTemplate(pdfImportedPage, 0, 0);
                currentPdfReaderPage++;
            }
            currentPdfReaderPage = 1;
        }

        //Close document and outputStream.
        outputStream.flush();
        document.close();
        outputStream.close();
        writer.close();
        log.debug("Pdf files merged successfully.");
    }
}
