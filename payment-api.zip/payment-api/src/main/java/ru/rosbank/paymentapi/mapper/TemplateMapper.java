package ru.rosbank.paymentapi.mapper;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Template;

@Mapper(componentModel = "spring")
public abstract class TemplateMapper {

    @Autowired
    private DocumentTypeCalculatorImpl documentTypeCalculator;

    @Mapping(target = "payer.inn", qualifiedByName = "inn")
    @Mapping(target = "payee.inn", qualifiedByName = "inn")
    public abstract Template fromDTO(TemplateDTO templateDTO);

    @InheritInverseConfiguration
    public abstract TemplateDTO toDTO(Template template);

    @Mapping(target = "payer.inn", qualifiedByName = "inn")
    @Mapping(target = "payee.inn", qualifiedByName = "inn")
    @Mapping(target = "amount", source = "amount.sum")
    @Mapping(target = "docType", source = "payment", qualifiedByName = "calculator")
    @Mapping(target = "dateCreated", ignore = true)
    @Mapping(target = "lastModifiedDate", ignore = true)
    @Mapping(target = "payPriority", source = "payment.paymentPriority", qualifiedByName = "payPriority")
    @Mapping(target = "typeTaxPayment", source = "payment.taxPaymentType", qualifiedByName = "typeTaxPayment")
    public abstract TemplateDTO paymentToTemplateDTO(Payment payment);

    @Named("inn")
    public String inn(String inn) {
        return StringUtils.isBlank(inn) ? "0" : inn;
    }

    @Named("calculator")
    public String calculator(Payment payment) {
        return documentTypeCalculator.calculate(payment).getValue();
    }

    @Named("payPriority")
    public String payPriority(String payPriority) {
        return payPriority.length() == 1 ? "_0" + payPriority : "_" + payPriority;
    }

    @Named("typeTaxPayment")
    public String typeTaxPayment(Boolean typeTaxPayment) {
        return Optional.ofNullable(typeTaxPayment).map(t -> t ? "1" : "0").orElse(null);
    }
}
