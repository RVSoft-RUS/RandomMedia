package ru.rosbank.paymentapi.services;


import static ru.rosbank.paymentapi.commons.Constants.OUTCOME_PAYMENT;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.referenceapp.api.ReferenceAppApi;
import ru.rosbank.platform.server.paymentapi.model.Payment;


/**
 * Summary.
 * @author rb068774
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OpfConverterService {

    private final ReferenceAppApi referenceAppApi;

    public Payment convert(Payment payment) {
        try {
            if (OUTCOME_PAYMENT.contains(payment.getType())) {
                payment.getPayee().setName(referenceAppApi.opfGet(payment.getPayee().getName()).getBody());
            } else {
                payment.getPayer().setName(referenceAppApi.opfGet(payment.getPayer().getName()).getBody());
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return payment;
    }


}
