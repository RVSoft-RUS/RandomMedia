package ru.rosbank.paymentapi.services;

import static ru.rosbank.paymentapi.services.signature.DocumentRecallSigner.DOCUMENTRECALL;
import static ru.rosbank.paymentapi.util.FormatUtils.masqueradePhoneNumber;

import feign.FeignException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.audit.LogAuditEvent;
import ru.rosbank.paymentapi.exception.ConfirmationRequiredException;
import ru.rosbank.paymentapi.exception.DocumentSignException;
import ru.rosbank.paymentapi.exception.PaymentNotRevertibleException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.UserService;
import ru.rosbank.paymentapi.services.signature.DocumentRecallSigner;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.server.paymentapi.model.Confirmation;
import ru.rosbank.platform.server.paymentapp.model.DocumentStatus;

@Slf4j
@Service
@RequiredArgsConstructor
public class RecallService {

    private final PaymentAppApi paymentAppApi;
    private final CryptoproAppApi cryptoproAppApi;
    private final OrganizationService organizationService;
    private final AccountService accountService;
    private final UserService userService;
    private final OtpService otpService;
    private final DocumentRecallSigner documentRecallSigner;

    static final List<String> NON_REVERTIBLE_STATUS
            = List.of(DocumentStatus.COMPLETED.name(), DocumentStatus.REJECTED.name(),
            DocumentStatus.RECALLED.name(), DocumentStatus.ERROR.name());

    @LogAuditEvent(stage = "Создание запроса на отзыв платежа", argNum = 1)
    public void recallPayment(String id, String dboProId) {
        var orgList = organizationService.getOrganizations(dboProId);
        var accountList = orgList.stream()
                .map(orgDTO -> accountService.getAccountList(orgDTO.getCrmId(), orgDTO.getBisIds()))
                .flatMap(List::stream)
                .map(AccountDTO::getNumber)
                .collect(Collectors.toList());
        var document = paymentAppApi.documentIdGet(id).getBody();
        assert document != null;
        if (!accountList.contains(document.getPayer().getAccount())) {
            throw new ValidationException("Счет списания не доступен пользователю.");
        }
        var organization = orgList.stream()
                .filter(org -> org.getBisIds().stream()
                        .anyMatch(bis -> bis.getId().equals(document.getBisId().getId())))
                .findFirst().orElse(null);
        assert organization != null;
        if (!organizationService.applyRole(dboProId, organization)
                .equals(IndividualDTO.AccessGroupEnum.ALL_RIGHTS)) {
            throw new ValidationException("Не достаточно прав у пользователя.");
        }
        if (NON_REVERTIBLE_STATUS.contains(document.getStatus().toString())) {
            throw new PaymentNotRevertibleException(getRecallErrorMsg(document.getStatus()));
        } else if (DocumentStatusDTO.SENT_TO_BIS.equals(document.getStatus())) {
            recallFromBis(document, dboProId);
        } else {
            paymentAppApi.documentIdRecallSignedPost(id, false);
        }

    }

    private String getRecallErrorMsg(DocumentStatusDTO status) {
        switch (status) {
            case COMPLETED:
                return "Платёж уже исполнен, для возврата средств обратитесь к получателю";
            case REJECTED:
                return "Платёж отклонён, отзывать не нужно";
            case RECALLED:
                return "Вы уже отозвали этот платёж";
            case ERROR:
                return "Технический сбой, попробуйте позже";
            default:
                return null;
        }
    }

    private void recallFromBis(DocumentDTO document, String dboProId) {

        var documentId = document.getId().toString();
        if (!isRecallRequestSigned(documentId)) {
            try {
                paymentAppApi.documentIdRecallSignedPost(documentId, false);
            } catch (FeignException e) {
                if (e.status() == 406) {
                    var user = userService.getUser(dboProId);
                    var otp = documentRecallSigner.sign(user, List.of(document));
                    if (otp == null) {
                        throw new DocumentSignException("Не удалось подписать документ");
                    }
                    var confirmation = new Confirmation()
                            .id(otp.getId())
                            .type(Confirmation.TypeEnum.SMS)
                            .attempts(otp.getAttempts())
                            .message(masqueradePhoneNumber(user.getPhone()))
                            .expiresIn(otpService.getExpireMilliSeconds(otp).intValue());
                    throw new ConfirmationRequiredException(confirmation);
                } else {
                    throw e;
                }
            }
        } else {
            paymentAppApi.documentIdRecallSignedPost(documentId, true);
        }
    }

    private boolean isRecallRequestSigned(String id) {
        return Objects.requireNonNull(cryptoproAppApi
                .signatureGet(id, DOCUMENTRECALL)
                .getBody())
                .stream()
                .anyMatch(SignatureDTO::getConfirmed);
    }
}
