package ru.rosbank.paymentapi.services.rectification.validators;


import static ru.rosbank.platform.server.paymentapi.model.Payment.TypeEnum.DA;
import static ru.rosbank.platform.server.paymentapi.model.Payment.TypeEnum.DB;
import static ru.rosbank.platform.server.paymentapi.model.Payment.TypeEnum.DC;
import static ru.rosbank.platform.server.paymentapi.model.Payment.TypeEnum.DE;
import static ru.rosbank.platform.server.paymentapi.model.Payment.TypeEnum.DF;
import static ru.rosbank.platform.server.paymentapi.model.Payment.TypeEnum.DG;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Payment.TypeEnum;


/**
 * Summary.
 * @author rb066284
 */
@Service
public class DocumentTypeValidator {

    public static final Collection<TypeEnum> DOCUMENT_TYPES_ALLOWED = Collections.unmodifiableCollection(
        Arrays.asList(DA, DB, DC, DE, DG, DF)
    );

    public void validate(Payment payment) {
        if (DOCUMENT_TYPES_ALLOWED.stream()
            .noneMatch(dt -> dt.equals(payment.getType()))) {

            throw new ValidationException("Уточнение не доступно для документа с типом " + payment.getType() + ".");
        }
    }

}
