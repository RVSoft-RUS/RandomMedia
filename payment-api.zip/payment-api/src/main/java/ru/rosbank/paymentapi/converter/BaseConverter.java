package ru.rosbank.paymentapi.converter;

import org.apache.commons.lang3.StringUtils;
import ru.rosbank.paymentapi.mapper.AmountMapper;
import ru.rosbank.paymentapi.mapper.BankInfoMapper;
import ru.rosbank.paymentapi.mapper.PaymentOutputModeMapper;
import ru.rosbank.paymentapi.mapper.PaymentTypeMapper;
import ru.rosbank.paymentapi.mapper.RequisiteMapper;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class BaseConverter {
    public static Payment convert(Payment payment, PaymentDTO input) {

        payment.setId(input.getId());
        payment.setStatus(Payment.StatusEnum.COMPLETED);
        if (input.getType() != null) {
            payment.setType(Payment.TypeEnum.fromValue(input.getType().getValue()));
        }

        // Вид платежа
        if (input.getPaymentOutputMode() != null) {
            payment.setPaymentOutputMode(PaymentOutputModeMapper.INSTANCE.fromDTO(input.getPaymentOutputMode()));
        }

        payment.setCompleted(input.getCompleted());

        // Номер документа
        payment.setNumber(input.getNumber());
        // Дата создания документа
        payment.setCreated(input.getCreated());
        // Сумма
        payment.setAmount(AmountMapper.INSTANCE.fromDTO(input.getAmount()));
        // Сумма прописью
        payment.setAmountString(input.getAmountString());

        if (input.getPayee() != null) {
            payment.setPayee(RequisiteMapper.INSTANCE.fromDTO(input.getPayee()));
            if (Payment.TypeEnum.DH.equals(payment.getType()) && !StringUtils.isBlank(input.getMerchantName())) {
                payment.getPayee().setName(input.getMerchantName());
            }
        }
        if (input.getPayer() != null) {
            payment.setPayer(RequisiteMapper.INSTANCE.fromDTO(input.getPayer()));
        }

        payment.setPurpose(input.getPurpose());

        // Отметка об исполнении
        payment.setProcessedBy(BankInfoMapper.INSTANCE.fromDTO(input.getProcessedBy()));

        return payment;
    }

}
