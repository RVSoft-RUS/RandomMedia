package ru.rosbank.paymentapi.model;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Date;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import ru.rosbank.platform.server.paymentapi.model.Turnover;


@Getter
@Setter
public class AccountTurnover {

    protected String account;
    protected OffsetDateTime date;
    protected String currency;
    protected BigDecimal amountIncoming = new BigDecimal(0);
    protected BigDecimal amountOutgoing = new BigDecimal(0);

    public Turnover toDto() {
        Turnover accountTurnoverDto = new Turnover();
        accountTurnoverDto.setAccount(getAccount());
        accountTurnoverDto.setCurrency(getCurrency());
        accountTurnoverDto.setDate(getDate());
        accountTurnoverDto.setIncome(getAmountIncoming());
        accountTurnoverDto.setOutcome(getAmountOutgoing());
        return accountTurnoverDto;
    }

    @Override
    public boolean equals(Object object) {
        AccountTurnover accountTurnover = (AccountTurnover) object;
        return this.account.equals(accountTurnover.account) && this.date.equals(accountTurnover.date)
                && this.currency.equals(accountTurnover.currency);
    }

    @Override
    public int hashCode() {
        if (account != null && date != null) {
            return Objects.hash(account.hashCode(), date.hashCode(), currency.hashCode());
        }
        return super.hashCode();
    }
}
