package ru.rosbank.paymentapi.exception;


public class DocumentRejectedException extends RuntimeException {

    public DocumentRejectedException(String msg) {
        super(msg);
    }

}
