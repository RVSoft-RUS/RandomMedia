package ru.rosbank.paymentapi.services.onec;


import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068774
 */
public class DocumentNumberParser1C extends AbstractDocumentFieldParser1C {
    private static final String PAYEE_ACCOUNT_KEY = "Номер";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.setNumber(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, PAYEE_ACCOUNT_KEY);
    }

}
