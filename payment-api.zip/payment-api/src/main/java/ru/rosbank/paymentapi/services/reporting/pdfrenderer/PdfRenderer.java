package ru.rosbank.paymentapi.services.reporting.pdfrenderer;

import static ru.rosbank.paymentapi.util.FormatUtils.checkTrue;

import com.google.common.base.Charsets;
import com.google.common.io.Files;
import com.itextpdf.text.DocumentException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xhtmlrenderer.pdf.ITextRenderer;
import org.xhtmlrenderer.pdf.ITextUserAgent;
import ru.rosbank.paymentapi.services.reporting.ReportException;

/**
 * Формирует pdf файлы из строки, представляющей xhtml.
 *
 * @author Q-GMA
 */
public class PdfRenderer {

    private static final Logger LOGGER = LoggerFactory.getLogger(PdfRenderer.class);

    /**
     * Конвертирует xhtml документ в pdf.
     * Сконвертированный pdf записывается в переданный {@code outputStream}
     *
     * @param xhtmlReport  строка, содержащая xhtm документ
     * @param baseUrl      String URL папки относительно которой xhtml документ и стили адресуют ресурсы (стили, картинки и т.п.)
     * @param outputStream OutputStream стрим для записи результата
     */
    public static void xhtmlToPdf(String xhtmlReport, String baseUrl, OutputStream outputStream) {
        ITextRenderer renderer = new ITextRenderer();

        ITextUserAgentMod userAgentCallback = new ITextUserAgentMod(renderer);
        renderer.getSharedContext().setUserAgentCallback(userAgentCallback);

        try {
            renderer.setDocumentFromString(xhtmlReport, baseUrl);
            renderer.layout();
            renderer.createPDF(outputStream);
        } catch (DocumentException e) {
            LOGGER.error("Error while generating PDF report", e);
            throw new ReportException("Error while generating PDF report", e);
        } catch (IOException e) {
            LOGGER.error("Error while generating PDF report", e);
            throw new ReportException("Error while generating PDF report", e);
        } finally {
            IOUtils.closeQuietly(outputStream);
        }
    }


    /**
     * Main метод для запуска из скрипта.
     */
    public static void main(String[] args) throws IOException {
        checkTrue(args.length >= 3, "Expected arguments: <html file> <styles dir> <output file>");
        String htmlFile = args[0];
        String stylesDir = args[1];
        String outputFile = args[2];

        String htmlContent = Files.toString(new File(htmlFile), Charsets.UTF_8);

        xhtmlToPdf(htmlContent, stylesDir, new FileOutputStream(outputFile));
    }


    private static class ITextUserAgentMod extends ITextUserAgent {

        public ITextUserAgentMod(ITextRenderer renderer) {
            super(renderer.getOutputDevice());
            setSharedContext(renderer.getSharedContext());
        }

        @Override
        protected InputStream resolveAndOpenStream(String uri) {
            return super.resolveAndOpenStream(normalize(uri));
        }

        private String normalize(String uriString) {
            try {
                URI uri = new URI(uriString);

                URI normalized;

                if (uri.isOpaque()) {
                    URI schemeSpecific = unwrapScheme(uri).normalize();
                    normalized = wrapScheme(uri.getScheme(), schemeSpecific);
                } else {
                    normalized = uri.normalize();
                }

                return normalized.toString();
            } catch (URISyntaxException e) {
                throw new IllegalStateException(String.format("Can not normalize URI '%s'", uriString), e);
            }
        }

        private URI unwrapScheme(URI uri) throws URISyntaxException {
            return new URI(uri.getSchemeSpecificPart());
        }

        private URI wrapScheme(String scheme, URI uri) throws URISyntaxException {
            return new URI(scheme + ":" + uri.toString());
        }
    }
}
