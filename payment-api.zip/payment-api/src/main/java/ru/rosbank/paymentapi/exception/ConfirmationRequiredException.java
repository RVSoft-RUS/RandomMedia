package ru.rosbank.paymentapi.exception;


import ru.rosbank.platform.server.paymentapi.model.Confirmation;

public class ConfirmationRequiredException extends RuntimeException {

    private final Confirmation confirmation;

    public ConfirmationRequiredException(Confirmation confirmation) {
        this.confirmation = confirmation;
    }

    public Confirmation getConfirmation() {
        return confirmation;
    }
}
