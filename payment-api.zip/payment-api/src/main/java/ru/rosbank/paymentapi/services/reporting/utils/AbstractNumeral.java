package ru.rosbank.paymentapi.services.reporting.utils;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Базовый класс для классов преобразующих числа и денежные суммы в текстовое представление.
 *
 * @author Q-YAA
 */
public abstract class AbstractNumeral {

    /**
     * Максимально поддерживаемое целое число для перевода в текстовое представление (10^33).
     */
    public static final BigInteger MAX_SUPPORTED_NUMBER = new BigInteger("1000000000000000000000000000000000000");

    /**
     * Переводит целое число в текстовое представление.
     *
     * @param number целое число
     * @return String целое число в текстовом представлении
     */
    public abstract String spellNumber(BigInteger number);

    /**
     * Переводит денежную сумму в текстовое представление.
     *
     * @param number   значение денежной суммы
     * @param currency трёхсимвольный код валюты денежной суммы (RUR, USD и т.п.)
     * @return String денежная сумма в текстовом представлении
     */
    public abstract String spellAmount(BigDecimal number, String currency);

    protected void checkNumberSupported(BigInteger number) {
        if (number.abs().compareTo(MAX_SUPPORTED_NUMBER) > 0) {
            throw new IllegalArgumentException(String.format("Max supported number is: '%s'", MAX_SUPPORTED_NUMBER));
        }
    }
}
