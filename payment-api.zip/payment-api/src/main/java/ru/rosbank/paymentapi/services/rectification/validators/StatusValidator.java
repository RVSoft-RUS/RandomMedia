package ru.rosbank.paymentapi.services.rectification.validators;

import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

/**
 * Summary.
 * @author rb066284
 */
@Service
public class StatusValidator {

    public void validate(Payment payment) {
        if (!Payment.StatusEnum.COMPLETED.equals(payment.getStatus())) {
            throw new ValidationException("Уточнение доступно только для исходящего исполненного платежа.");
        }
    }

}
