package ru.rosbank.paymentapi.exception;


public class DuplicateTemplateNameException extends ValidationException {

    public DuplicateTemplateNameException(String msg) {
        super(msg);
    }

}
