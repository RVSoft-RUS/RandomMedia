package ru.rosbank.paymentapi.feign;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.util.UUID;
import javax.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundData;
import ru.rosbank.paymentapi.model.feign.refundapi.WebResponseCreateRefundResponse;
import ru.rosbank.paymentapi.model.feign.refundapi.WebResponseGetRefundResponse;


@FeignClient(name = "RefundApi", url = "${fastpayle.url}")
public interface RefundApiFeignClient {

    @GetMapping(value = "/refund/v0/refund/{documentId}", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<WebResponseGetRefundResponse> refundDocumentIdGet(@PathVariable("documentId") UUID documentId);

    @PostMapping(value = "/refund/v0/refund/", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<WebResponseCreateRefundResponse> refundPost(
            @RequestHeader(value = "Idempotence-Key", required = true) UUID idempotenceKey,
            @Valid @RequestBody RefundData refundData);

    @PatchMapping(value = "/refund/v0/refund/{documentId}/execute", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<WebResponseCreateRefundResponse> refundDocumentIdExecutePatch(@PathVariable("documentId") UUID documentId);

}
