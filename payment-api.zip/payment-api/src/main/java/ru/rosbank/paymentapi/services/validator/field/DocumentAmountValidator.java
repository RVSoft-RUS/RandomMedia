package ru.rosbank.paymentapi.services.validator.field;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.math.BigDecimal;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

/**
 * Summary.
 * Поле 7
 */
@Service
public class DocumentAmountValidator implements IDocumentValidator {

    public void validate(DocumentDTO document) {
        if (isBlank(document.getAmount())
                || BigDecimal.ZERO.equals(BigDecimal.valueOf(Double.parseDouble(document.getAmount())))) {
            throw new ValidationPaymentException(7, "amount", "Заполните поле сумма");
        }
    }

}
