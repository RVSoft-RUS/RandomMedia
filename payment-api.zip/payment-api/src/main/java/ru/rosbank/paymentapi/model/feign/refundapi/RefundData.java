package ru.rosbank.paymentapi.model.feign.refundapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefundData {

    private String qrcIdr;
    private String trxId;
    private String amount;
    private CurrencyAmountEnum currencyAmount;
    private String accountLegal;
    private String legalId;
    private String merchantId;
    private String tin;
    private String reasonText;
    private CustomerDto customer;

}

