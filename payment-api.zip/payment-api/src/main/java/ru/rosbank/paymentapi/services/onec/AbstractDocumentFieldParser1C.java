package ru.rosbank.paymentapi.services.onec;


import ru.rosbank.paymentapi.exception.ImportDocumentException;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public abstract class AbstractDocumentFieldParser1C {
    private static final String FIELD_SEPARATOR = "=";

    protected boolean containsWithSeparator(String line, String substring) {
        return line.indexOf(substring + FIELD_SEPARATOR) == 0;
    }

    protected String getValueFromLine(String currentLine) {
        return currentLine.substring(currentLine.indexOf(FIELD_SEPARATOR) + 1).trim();
    }

    public abstract void parseAndSetValue(String line, DocumentDTO document) throws ImportDocumentException;

    public abstract boolean isMatch(String line);

}
