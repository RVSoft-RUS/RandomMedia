package ru.rosbank.paymentapi.services.validator.field;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentUtils;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

/**
 * Summary.
 * Field 17
 */
@Slf4j
@Service
public class DocumentPurposePayrollValidator implements IDocumentValidator {
    private static final String ERR_PURPOSE_EMPTY = "Заполните поле назначение платежа";
    private static final int PURPOSE_MAX_LENGTH = 210;
    private static final String ERR_PURPOSE_MAX_LENGTH = "Совокупное количество символов вместе с информацией об НДС не должно "
            + "превышать 210 символов - скорректируйте текст в поле назначение платежа";
    private static final String ERR_PURPOSE_WRONG_SYMBOLS = "Введены некорректные символы в назначении платежа: ";
    private static final String ERR_PURPOSE_CODE_WORD = "Укажите корректное назначение платежа, например: заработная "
            + "плата, аванс, премия: ";
    @Value("${payroll.code-words}")
    private String[] payrollCodeWords;
    private static List<String> PAYROLL_CODE_WORDS = null;

    public void validate(DocumentDTO document) throws ValidationPaymentException {
        String purpose = Optional.ofNullable(document)
                .map(DocumentDTO::getPurpose).orElse("");
        if (PAYROLL_CODE_WORDS == null) {
            PAYROLL_CODE_WORDS = Arrays.asList(payrollCodeWords);
        }
        if (StringUtils.isBlank(purpose)) {
            throw new ValidationPaymentException(24, "purpose", ERR_PURPOSE_EMPTY);
        } else if (purpose.length() > PURPOSE_MAX_LENGTH) {
            throw new ValidationPaymentException(24, "purpose", ERR_PURPOSE_MAX_LENGTH);
        } else {
            try {
                DocumentUtils.validateInput4AcceptableSymbols(document.getPurpose(), ERR_PURPOSE_WRONG_SYMBOLS);
            } catch (ValidationPaymentException var6) {
                var6.setErrorCode(24);
                var6.setErrorField("purpose");
                throw var6;
            }

            if (!PAYROLL_CODE_WORDS.stream().anyMatch(i -> purpose.toUpperCase().contains(i))) {
                throw new ValidationPaymentException(24, "purpose", ERR_PURPOSE_CODE_WORD);
            }
        }
    }

}
