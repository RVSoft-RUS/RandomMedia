package ru.rosbank.paymentapi.mapper;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Optional;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

@Mapper(componentModel = "spring")
public interface ClarificationMapper extends OffsetDateTimeMapper {

    @Mapping(target = "status", ignore = true)
    @Mapping(target = "operationUid", source = "rectification.documentId")
    @Mapping(target = "sourceSubsystem", constant = "PRO")
    @Mapping(target = "paymentNumber", source = "payment.number")
    @Mapping(target = "paymentDate", source = "payment.created", qualifiedByName = "toLocalDate")
    @Mapping(target = "taxKbk", source = "rectification.kbk")
    @Mapping(target = "taxOktmo", source = "rectification.oktmo")
    @Mapping(target = "taxPaymentReason", source = "rectification.paymentBasis")
    @Mapping(target = "taxDocNumber", source = "rectification.basisDocumentNumber")
    @Mapping(target = "taxDocDate", source = "rectification.basisDocumentCreated")
    @Mapping(target = "organizationInfo.organizationId", source = "orgId")
    @Mapping(target = "organizationInfo.bisId", source = "bisId")
    @Mapping(target = "organizationInfo.bisBranch", source = "bisBranch")
    @Mapping(target = "payeeInfo.payeeName", source = "rectification.payeeName")
    @Mapping(target = "payeeInfo.payeeAccNumber", source = "rectification.payeeAccount")
    @Mapping(target = "payeeInfo.payeeInn", source = "rectification.payeeInn")
    @Mapping(target = "payeeInfo.payeeKpp", source = "rectification.payeeKpp")
    @Mapping(target = "payerAccNumber", source = "payment.payer.account")
    @Mapping(target = "cliType", source = "payerInn", qualifiedByName = "getCliType")
    @Mapping(target = "purpose", source = "rectification.purpose", qualifiedByName = "validateText")
    @Mapping(target = "uin", source = "rectification.uin")
    @Mapping(target = "taxPeriod", source = "rectification.taxPeriod")
    @Mapping(target = "codeTypeIncome", source = "rectification.codeTypeIncome")
    @Mapping(target = "typeTaxPayment", source = "rectification.typeTaxPayment")
    @Mapping(target = "statusMessage", source = "rectification.statusMessage")
    @Mapping(target = "type", source = "rectification.type")

    Clarification toClarification(Rectification rectification, Payment payment, String orgId,
                                  String bisId, String bisBranch, String payerInn);

    @Mapping(target = "id", source = "clarificationId")
    @Mapping(target = "documentId", source = "operationUid")
    @Mapping(target = "kbk", source = "taxKbk")
    @Mapping(target = "oktmo", source = "taxOktmo")
    @Mapping(target = "paymentBasis", source = "taxPaymentReason")
    @Mapping(target = "basisDocumentNumber", source = "taxDocNumber")
    @Mapping(target = "basisDocumentCreated", source = "taxDocDate")
    @Mapping(target = "payeeName", source = "payeeInfo.payeeName")
    @Mapping(target = "payeeAccount", source = "payeeInfo.payeeAccNumber")
    @Mapping(target = "payeeInn", source = "payeeInfo.payeeInn")
    @Mapping(target = "payeeKpp", source = "payeeInfo.payeeKpp")
    @Mapping(target = "created", source = "creationDate", qualifiedByName = "toDate")
    @Mapping(target = "payerAccount", source = "payerAccNumber")
    Rectification toRectification(Clarification clarification);

    @Named("toLocalDate")
    default LocalDate toLocalDate(OffsetDateTime  date) {
        if (date == null) {
            return null;
        }
        return date.atZoneSameInstant(ZoneId.systemDefault()).toLocalDate();
    }

    @Named("getCliType")
    default String getCliType(String inn) {

        return Optional.ofNullable(inn).map(String::trim).map(String::length).orElse(0) == 12 ? "IP" : "LE";
    }

    @Named("validateText")
    default String validateText(String txt) {
        if (txt == null) {
            return null;
        }
        return txt.replace("\n", " ").replace("\r", " ");
    }
}
