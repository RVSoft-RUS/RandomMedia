package ru.rosbank.paymentapi.services.signature;

import static org.apache.commons.lang3.ObjectUtils.isNotEmpty;
import static ru.rosbank.paymentapi.commons.Constants.getPlatform;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import feign.FeignException;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ru.rosbank.paymentapi.audit.ThreadLocalAuditContext;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.paymentapi.exception.DocumentSignException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateDTO;
import ru.rosbank.platform.client.cryptoproapp.model.MetaDataDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SubjectDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@Slf4j
@RequiredArgsConstructor
public abstract class Signer {

    private final ProductService productService;
    private final OrganizationService organizationService;
    private final OtpService otpService;
    private final CryptoproAppApi cryptoproAppApi;

    protected static final String DOCUMENT_UNCONFIRMED_CERTIFICATE_ERROR = "9: Ваш сертификат на подписи у руководителя.";
    protected static final String UNCONFIRMED_CERTIFICATE_ERROR = "Ваш сертификат на подписи у руководителя.";

    abstract List<SubjectDTO> buildSubjects(List<DocumentDTO> items);

    public OtpDTO sign(ClientDTO user, List<DocumentDTO> items) {
        var certificate = getSignerCertificate(user.getId(), items);
        List<SubjectDTO> subjects = buildSubjects(items);
        String packageSignatureId;
        try {
            packageSignatureId = cryptoproAppApi.certificateIdSignPost(certificate.getId(), subjects).getBody();
        } catch (FeignException e) {
            log.error("Ошибка создания транзакции подписи {} ", user.getId(), e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        if (packageSignatureId != null) {
            return otpService.generatePackageSignatureOtp(packageSignatureId, user.getPhone());
        }
        return null;
    }

    private CertificateDTO getSignerCertificate(String dboProId, List<DocumentDTO> subjects) {
        Optional<DocumentDTO> osignable = subjects.stream().findFirst();
        if (osignable.isPresent()) {
            var doc = osignable.get();
            var organizationDTO = productService.getOrganizationByAccNumberAndDboProId(doc.getPayer().getAccount(), dboProId)
                    .orElseThrow(() -> new DocumentSignException("Организация не найдена"));
            List<CertificateDTO> certificates;
            try {
                certificates = cryptoproAppApi.userIdCertificateGet(dboProId).getBody();
            } catch (FeignException e) {
                log.error("Ошибка получения сертификатов пользователя {} ", dboProId, e);
                throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
            }
            Optional<CertificateDTO> ocertificate = certificates.stream()
                    .filter(cert -> organizationDTO.getCrmId().equals(cert.getCrmId()))
                    .filter(cert -> CertificateDTO.StatusEnum.ACTIVE.equals(cert.getStatus()))
                    .findFirst();
            if (ocertificate.isPresent()) {
                return ocertificate.get();
            }
        }
        if (isNotEmpty(subjects) && subjects.size() == 1) {
            throw new ValidationException(DOCUMENT_UNCONFIRMED_CERTIFICATE_ERROR);
        } else {
            throw new ValidationException(UNCONFIRMED_CERTIFICATE_ERROR);
        }
    }

    String documentToString(DocumentDTO doc) throws JsonProcessingException {
        var mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        String json = mapper.writeValueAsString(doc);
        return new String(Base64.getEncoder().encode(json.getBytes()));
    }

    MetaDataDTO buildMetaData() {
        var context = ThreadLocalAuditContext.get();
        return new MetaDataDTO()
                .platform(getPlatform(context))
                .appVersion(context.getApplicationVersion())
                .ip(context.getIp())
                .sessionId(context.getSessionId())
                .deviceId(context.getDeviceId())
                .os(context.getOs())
                .model(context.getModel())
                .man(context.getMan());
    }
}
