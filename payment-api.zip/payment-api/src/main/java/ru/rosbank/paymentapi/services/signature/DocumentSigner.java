package ru.rosbank.paymentapi.services.signature;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.FileResourceDTO;
import ru.rosbank.platform.client.cryptoproapp.model.MetaDataDTO;
import ru.rosbank.platform.client.cryptoproapp.model.ReferenceDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SubjectDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

@Slf4j
@Service
public class DocumentSigner extends Signer {

    @Value("${cryptopro.template-sms.document.single}")
    private String smsTemplateSingle;
    @Value("${cryptopro.template-sms.document.package}")
    private String smsTemplatePackage;

    public static final String DOCUMENT = "DOCUMENT";
    public static final Collection<String> USER_AGENT_WEB = Collections.singletonList("Mozilla");
    public static final Collection<String> USER_AGENT_ANDROID = Collections.singletonList("Dalvik");
    public static final Collection<String> USER_AGENT_IOS = Collections.unmodifiableCollection(
            Arrays.asList("CFNetwork", "iphone")
    );
    public static final String OS_TYPE_WEB = "WEB";
    public static final String OS_TYPE_ANDROID = "ANDROID";
    public static final String OS_TYPE_IOS = "IOS";

    public DocumentSigner(ProductService productService, OrganizationService organizationService,
                          OtpService otpService, CryptoproAppApi cryptoproAppApi) {
        super(productService, organizationService, otpService, cryptoproAppApi);
    }

    @Override
    protected List<SubjectDTO> buildSubjects(List<DocumentDTO> items) {
        BigDecimal total = items.stream()
                .map(DocumentDTO::getAmount)
                .map(BigDecimal::new).reduce(BigDecimal.ZERO, BigDecimal::add);
        String documentInfo = (items.size() > 1)
                ? String.format(smsTemplatePackage, items.size(), total)
                : String.format(smsTemplateSingle, total);

        List<SubjectDTO> subjects = createSubjectList(items);
        subjects.forEach(s -> s.setDocumentInfo(documentInfo));
        return subjects;
    }

    private List<SubjectDTO> createSubjectList(List<DocumentDTO> items) {
        return items.stream().map(element -> {
            SubjectDTO subject = buildSubject(element);
            subject.setMetaData(buildMetaData());
            return subject;
        }).collect(Collectors.toList());
    }

    private SubjectDTO buildSubject(DocumentDTO signable) {
        SubjectDTO subject = new SubjectDTO();
        subject.setReference(
            new ReferenceDTO()
                .id(signable.getId().toString())
                .type(DOCUMENT)
        );
        try {
            subject.setResource(
                new FileResourceDTO().id(UUID.randomUUID().toString())
                    .content(documentToString(signable))
                    .contentType(FileResourceDTO.ContentTypeEnum.TXT)
                    .name("document.json")
            );
        } catch (JsonProcessingException e) {
            log.error(e.getMessage());
        }
        return subject;
    }
}
