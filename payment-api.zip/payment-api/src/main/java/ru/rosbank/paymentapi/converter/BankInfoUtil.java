package ru.rosbank.paymentapi.converter;

import java.util.List;
import lombok.extern.slf4j.Slf4j;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;

@Slf4j
public  class BankInfoUtil {
    private static final String BANK_INFO_ERROR = "Произошла техническая ошибка. Не удалось создать платёж. Попробуйте позже.";

    static void setBankInfo(RequisiteDTO payer,  String accountStr, AccountService accountService,
                            ReferenceService referenceService, AccountDTO accountDto) {
        try {
            AccountDTO account = accountDto;
            if (accountDto == null) {
                account = accountService.getAccount(accountStr);
            }
            String branch = account.getBisId().getBranch();
            List<BranchDTO> branchDto = referenceService.getBranch(branch);
            BankInfoDTO bankInfoDTO = new BankInfoDTO();
            bankInfoDTO.setBic(branchDto.get(0).getBik());
            bankInfoDTO.setCorrespondentAccount(branchDto.get(0).getCorrespondentAccount());
            bankInfoDTO.setName(branchDto.get(0).getName());
            payer.setBank(bankInfoDTO);
        } catch (Exception e) {
            log.error("Error to convert {} ", e.getMessage());
            throw new BankInfoException(BANK_INFO_ERROR);
        }
    }
}
