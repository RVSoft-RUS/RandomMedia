package ru.rosbank.paymentapi.services.validator.field;

import static org.apache.commons.lang3.StringUtils.containsIgnoreCase;
import static ru.rosbank.platform.utils.payment.validators.DocumentUtils.validateInput4AcceptableSymbols;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Slf4j
@Service
@RequiredArgsConstructor
public class PurposePayrollValidator implements IDocumentValidator {
    private static final int FIELD_ID = 24;
    private static final String FIELD_NAME = "purpose";
    private static final String ERR_PURPOSE_EMPTY = "Заполните поле";
    public static final int PURPOSE_MAX_LENGTH = 210;
    private static final String ERR_PURPOSE_MAX_LENGTH = "Совокупное количество символов вместе с информацией об НДС"
            + " не должно превышать 210 символов - скорректируйте текст";
    private static final String ERR_PURPOSE_WRONG_SYMBOLS = "Введены некорректные символы: ";

    public static final Collection<String> PAYROLL_PAYMENT_PURPOSE_KEYWORDS = Collections.unmodifiableCollection(Arrays.asList(
            "КОМАНДИРОВОЧН", "БОЛЬНИЧН", "МАССИВ", "REGISTER", "КОМПЕНСАЦ", "ПРЕМИ", "ОТПУСК", "ДИВИДЕНД", "ОПЛАТА ТРУД",
            "ОПЛАТЫ ТРУД", "ОПЛАТЕ ТРУД", "ОПЛ.ТР", "ОТПУСК", "ПЕНСИ", "ПОДОТЧЕТ", "РАСЧЕТ", "ПОД ОТЧЕТ", "В СВЯЗИ С РОЖДЕН",
            "ВЕДОМОСТ", "УВОЛЬНЕН", "ПОСОБ", ".ПОСОБ", "КОМАНДИРОВОЧ", "БОЛЬНИЧН", "ПОСОБИ", "ПО ВЕД.", "ПОДОТЧЁТ", "Р-РУ",
            "РАБОТНИКАМ", "ПОД ОТЧЕТ", "РАСЧЕТ ПРИ УВОЛ", "СОТРУДНИК", "СУТОЧНЫЕ", "ХОЗНУЖДЫ", "ПРЕМИИ", "ПРЕМ", "ВЫПЛАТ",
            "ЗАРАБОТ", "ЗАРАБ. ПЛАТ", "ЗАР. ПЛАТ", "З/П", "АРЕНД", "КОМПЕНСАЦИЯ", "ЗАРАБ.ПЛАТ", "ЗАР.ПЛАТ", "З\\ПЛ",
            "ЗАР. ПЛ", "ЗАРАБОТНАЯ ПЛАТА", "ЗАРПЛ", "АВАНС", "РЕЕСТР", "ЗП", "З/П", "ЗАР.ПЛАТА", "ЗАР. ПЛАТА", "З\\П",
            "\\ПРИЛОЖЕНИЕ\\", "//ПРИЛОЖЕНИЕ//", "ЗАРАБОТ. ПЛАТА")
    );

    @Override
    public void validate(DocumentDTO documentDTO) {
        String purpose = documentDTO.getPurpose();
        if (StringUtils.isBlank(purpose)) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, ERR_PURPOSE_EMPTY);
        }

        if (purpose.length() > PURPOSE_MAX_LENGTH) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, ERR_PURPOSE_MAX_LENGTH);
        }

        if (PAYROLL_PAYMENT_PURPOSE_KEYWORDS.stream().noneMatch(key -> containsIgnoreCase(documentDTO.getPurpose(), key))) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME,
                    "Укажите корректное назначение платежа, например: заработная плата, аванс, премия.");
        }

        try {
            validateInput4AcceptableSymbols(documentDTO.getPurpose(), ERR_PURPOSE_WRONG_SYMBOLS);
        } catch (ValidationPaymentException e) {
            e.setErrorField(FIELD_NAME);
            e.setErrorCode(FIELD_ID);
            throw e;
        }
    }

}
