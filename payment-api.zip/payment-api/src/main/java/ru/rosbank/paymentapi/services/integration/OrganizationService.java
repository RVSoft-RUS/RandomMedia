package ru.rosbank.paymentapi.services.integration;

import feign.FeignException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApi;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.organizationapp.model.TariffDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationService {

    private final OrganizationAppApi organizationAppApi;
    private final RolesService rolesService;

    public List<OrganizationDTO> getOrganizations(String clientId) {
        try {
            return organizationAppApi.rootGet(clientId).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения списка организаций {}", clientId, e);
            return Collections.emptyList();
        }
    }

    public TariffDTO getTariff(String bisId, String bisBranch, String crmId) {
        String noTariffError = "Unable to find any tariff for bisId: %s, bisBranch: %s, crmId: %s";
        return Optional.ofNullable(organizationAppApi.getOrganizationTariff(bisId, bisBranch, crmId).getBody())
                .orElseThrow(() -> new RuntimeException(String.format(noTariffError, bisId, bisBranch, crmId)))
                .stream()
                .findAny()
                .orElseThrow(() -> new RuntimeException(String.format(noTariffError, bisId, bisBranch, crmId)));
    }

    public List<OrganizationDTO> getActiveOrganizations(String clientId) {
        return getOrganizations(clientId).stream()
                .filter(org -> rolesService.isActiveIndividual(org.getCrmId(), clientId))
                .collect(Collectors.toList());
    }

    public IndividualDTO.AccessGroupEnum applyRole(String dboProId, OrganizationDTO organization) {
        var individual = rolesService.getIndividual(organization.getCrmId(), dboProId);
        return individual.getAccessGroup();
    }

    /**
     * Организации, к которым у пользователя есть доступ.
     * Есть полномочия, срок действия по которым не истёк.
     * Полномочия пользователя - отличны от BLOCK
     */
    public List<OrganizationDTO> getAvailableOrganizationListByClient(ClientDTO client) {
        if (client.getRegistrationCompleted() != null) {
            try {
                List<OrganizationDTO> organizations = Optional.ofNullable(getOrganizations(client.getId()))
                        .orElse(new ArrayList<>());

                return organizations.stream()
                        .filter(OrganizationDTO::getIsProspect)
                        .filter(organization -> isActiveEmpowermentPresent(client, organization))
                        .collect(Collectors.toList());
            } catch (FeignException e) {
                log.error(e.getMessage());
            }
        }
        return new ArrayList<>();
    }

    private boolean isActiveEmpowermentPresent(ClientDTO client, OrganizationDTO organization) {
        var individualList = chooseDboMatrixIndividuals(client, organization);
        return !individualList.isEmpty();
    }

    public List<IndividualDTO> chooseDboMatrixIndividuals(ClientDTO client, OrganizationDTO organization) {

        var individualList = rolesService.getActiveIndividuals(organization.getCrmId(), client.getId());
        // Если /RelationType = "Representative" или/RelationType = "Account Management" ,
        // то осуществляется проверка /AccessValidPeriod по найденному /RelationType,
        // остальные /RelationType по пользователю игнорируются.
        var managers = individualList.stream()
                .filter(rolesService::isAccountManagerOrRepresentative)
                .collect(Collectors.toList());
        if (!managers.isEmpty()) {
            individualList = managers;
        }
        return individualList;
    }
}
