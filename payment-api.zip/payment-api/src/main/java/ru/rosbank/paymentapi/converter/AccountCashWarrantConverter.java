package ru.rosbank.paymentapi.converter;

import ru.rosbank.paymentapi.mapper.BankInfoMapper;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class AccountCashWarrantConverter {
    public static Payment convert(PaymentDTO input) {
        Payment document = new Payment();
        document.setSubtype(Payment.SubtypeEnum.ACCOUNT_CASH_WARRANT);
        BaseConverter.convert(document, input);

        document.setNumber(input.getNumber());

        // TODO remove useless

        // Дата создания документа
        document.setCreated(input.getCreated());
        // Дата исполнения
        document.setCompleted(input.getCompleted());
        // Дата валютирования
        document.setValueDate(input.getValueDate());
        // Составитель (не заполняется ?)
        /*
        if (po.getOrderStamp() != null && po.getOrderStamp().getSignerList() != null &&
                po.getOrderStamp().getSignerList().getSigner() != null) {
            document
                    .setOrderStampSinger(po.getOrderStamp().getSignerList().getSigner().getPosition());
        }
        */

        // Отметка об исполнении
        document.setProcessedBy(BankInfoMapper.INSTANCE.fromDTO(input.getProcessedBy()));

        // Содержание
        document.setContent(input.getContent());

        document.setOrderStampSinger(input.getOrderStampSinger());

        document.setItmTransId(input.getItmTransId());

        return document;
    }

}
