package ru.rosbank.paymentapi.services.integration;

import feign.FeignException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.cardapp.api.CardAppApi;
import ru.rosbank.platform.client.cardapp.model.CardDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class CardService {

    private final CardAppApi cardAppApi;

    public List<CardDTO> getCardList(String bisId, String branch) {
        try {
            return Optional.ofNullable(cardAppApi.rootGetFromBd(bisId, branch))
                    .map(ResponseEntity::getBody)
                    .orElse(Collections.emptyList());
        } catch (FeignException e) {
            log.error("Ошибка получения списка карт card-app для bisId {}", bisId, e);
            return Collections.emptyList();
        }
    }
}
