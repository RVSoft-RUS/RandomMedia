package ru.rosbank.paymentapi.converter;


import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.time.OffsetDateTime;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.ImportedDocument;


@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentToImportedDocumentConverter {

    private final DocumentTypeCalculatorImpl documentTypeCalculatorImpl;
    private final ReferenceService referenceService;
    private final AccountService accountService;
    private static final String BANK_INFO_ERROR = "Произошла техническая ошибка. Не удалось создать платёж. Попробуйте позже.";

    public ImportedDocumentDTO convert(DocumentDTO documentDTO, AccountDTO accountDto) {
        var document = new ImportedDocumentDTO();
        Optional.ofNullable(documentDTO.getId()).map(String::valueOf).ifPresent(document::setId);

        document.setNumber(documentDTO.getNumber());

        document.setPayPriority(documentDTO.getPaymentPriority());
        document.setPayerStatus(documentDTO.getPayerStatus());
        document.setPaymentBasis(documentDTO.getPaymentBasis());
        document.setBasisDocumentNumber(documentDTO.getBasisDocumentNumber());
        document.setBasisDocumentCreated(documentDTO.getBasisDocumentCreated());
        document.setDocumentDate(documentDTO.getDate());
        document.setTaxPeriod(documentDTO.getTaxPeriod());
        document.setUin(documentDTO.getUin());
        document.setKbk(documentDTO.getKbk());
        document.setOktmo(documentDTO.getOktmo());

        document.setPurpose(documentDTO.getPurpose());

        // TODO rectification

        document.setAmount(documentDTO.getAmount());


        if (documentDTO.getType() != null) {
            document.setDocType(ImportedDocumentDTO.DocTypeEnum.fromValue(documentDTO.getType().name()));
        } else {
            document.setDocType(ImportedDocumentDTO.DocTypeEnum.fromValue(
                    documentTypeCalculatorImpl.calculate(documentDTO).getValue()));
        }

        document.setCodeTypeIncome(documentDTO.getCodeTypeIncome());

        document.setTypeTaxPayment(documentDTO.getTypeTaxPayment());

        var payer = new RequisiteDTO();
        if (documentDTO.getPayer() != null) {
            payer.setAccount(documentDTO.getPayer().getAccount());
            payer.setName(documentDTO.getPayer().getName());
            payer.setInn(documentDTO.getPayer().getInn());
            payer.setKpp(documentDTO.getPayer().getKpp());
            if (documentDTO.getPayer().getBank() != null) {
                BankInfoUtil.setBankInfo(payer,documentDTO.getPayer().getAccount(), accountService, referenceService,
                        accountDto);
            }
        }
        document.setPayer(payer);

        var payee = new RequisiteDTO();
        if (documentDTO.getPayee() != null) {
            payee.setAccount(documentDTO.getPayee().getAccount());
            payee.setName(documentDTO.getPayee().getName());
            payee.setInn(documentDTO.getPayee().getInn());
            payee.setKpp(documentDTO.getPayee().getKpp());
            if (documentDTO.getPayee().getBank() != null) {
                payee.setBank(documentDTO.getPayee().getBank());
            }
        }
        document.setPayee(payee);

        return document;
    }


    public DocumentDTO convertBack(ImportedDocument document) {
        var documentDTO = new DocumentDTO();

        if (isNotBlank(document.getId())) {
            documentDTO.setId(Integer.parseInt(document.getId()));
        }

        if (document.getDocType() != null) {
            documentDTO.setType(DocumentDTO.TypeEnum.fromValue(document.getDocType().getValue()));
        }
        documentDTO.setPaymentPriority(document.getPayPriority());
        documentDTO.setStatus(DocumentStatusDTO.CREATED);
        documentDTO.setNumber(document.getNumber());
        documentDTO.setBasisDocumentNumber(document.getBasisDocumentNumber());
        documentDTO.setBasisDocumentCreated(document.getBasisDocumentCreated());
        documentDTO.setTaxPeriod(document.getTaxPeriod());
        documentDTO.setUin(document.getUin());
        documentDTO.setKbk(document.getKbk());
        documentDTO.setOktmo(document.getOktmo());
        documentDTO.setPurpose(document.getPurpose());
        documentDTO.setCodeTypeIncome(document.getCodeTypeIncome());
        documentDTO.setTypeTaxPayment(document.getTypeTaxPayment());
        documentDTO.setPaymentBasis(document.getPaymentBasis());
        documentDTO.setPayerStatus(document.getPayerStatus());
        documentDTO.setAmount(document.getAmount());


        documentDTO.setDate(OffsetDateTime.now());

        // TODO
        //        document.setUrgent(PaymentOutputModeDto.URGENT.equals((documentDto.getPaymentOutputMode())));
        var payer = new RequisiteDTO();
        if (document.getPayer() != null) {
            payer.setAccount(document.getPayer().getAccount());
            payer.setInn(document.getPayer().getInn());
            payer.setKpp(document.getPayer().getKpp());
            payer.setName(document.getPayer().getName());

            if (document.getPayer().getBank() != null) {
                payer.setBank(fillBankInfo(document.getPayer().getBank()));
            }
        }
        documentDTO.setPayer(payer);

        var payee = new RequisiteDTO();
        if (document.getPayee() != null) {
            payee.setAccount(document.getPayee().getAccount());
            payee.setInn(document.getPayee().getInn());
            payee.setKpp(document.getPayee().getKpp());
            payee.setName(document.getPayee().getName());

            if (document.getPayee().getBank() != null) {
                payee.setBank(fillBankInfo(document.getPayee().getBank()));

                // Заполняем данные банка на основании БИК из справочника
                referenceService.getBankInfo(payee.getBank().getBic()).stream()
                        .filter(bb -> StringUtils.isBlank(payee.getBank().getCorrespondentAccount())
                                || payee.getBank().getCorrespondentAccount().equals(bb.getCorrespondentAccount()))
                        .findFirst()
                        .ifPresent(bankDTO -> {
                            payee.getBank().setCorrespondentAccount(bankDTO.getCorrespondentAccount());
                            payee.getBank().setName(bankDTO.getName());
                        });
            }
        }

        documentDTO.setPayee(payee);

        return documentDTO;
    }

    private BankInfoDTO fillBankInfo(BankInfo input) {
        var bankInfo = new BankInfoDTO();
        bankInfo.setBic(input.getBic());
        bankInfo.setCorrespondentAccount(input.getCorrespondentAccount());
        bankInfo.setName(input.getName());
        return bankInfo;
    }

}
