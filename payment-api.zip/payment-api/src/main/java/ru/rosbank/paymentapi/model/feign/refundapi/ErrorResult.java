package ru.rosbank.paymentapi.model.feign.refundapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Неудачный результат запроса.
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResult {

    private ResponseMetadata result;

}

