package ru.rosbank.paymentapi.services;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.IncorrectRefundStatusException;
import ru.rosbank.paymentapi.feign.RefundApiFeignClient;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundStatus;

@Slf4j
@Service
@RequiredArgsConstructor
@EnableRetry
public class RetryableService {

    private final RefundApiFeignClient refundApiFeignClient;

    @Retryable(maxAttemptsExpression = "#{${sbpRefund.status.attempts}}", value = Exception.class,
            backoff = @Backoff(delayExpression = "#{${sbpRefund.status.delay}}"))
    public RefundStatus attemptToGetRefundExpectedStatus(UUID documentId, RefundStatus expectedStatus) {
        RefundStatus status = refundApiFeignClient.refundDocumentIdGet(documentId).getBody().getData().getStatus();
        if (!expectedStatus.equals(status) && !RefundStatus.FAILED.equals(status)) {
            log.warn("Current refund status is '{}', expected: '{}'. Retrying...", status, expectedStatus);
            throw new IncorrectRefundStatusException(status.getValue());
        }
        return status;
    }

    @Recover
    public RefundStatus recover(Exception exception) {
        return RefundStatus.valueOf(exception.getMessage());
    }

}
