package ru.rosbank.paymentapi.services;

import static org.springframework.util.CollectionUtils.isEmpty;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import feign.FeignException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.commons.PaymentUtils;
import ru.rosbank.paymentapi.converter.CardTransactionToPaymentConverter;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.converter.PaymentToPaymentConverter;
import ru.rosbank.paymentapi.services.documents.TextFilter;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.CardService;
import ru.rosbank.paymentapi.services.integration.PaymentService;
import ru.rosbank.paymentapi.services.integration.StatementService;
import ru.rosbank.paymentapi.services.rectification.DocumentRectificationService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.cardapp.model.CardDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.statementapp.model.ErrorDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.AccountStatementError;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.DocumentCriteria;
import ru.rosbank.platform.server.paymentapi.model.DocumentsResponse;
import ru.rosbank.platform.server.paymentapi.model.Page;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentListService {
    private static final Integer DEFAULT_OFFSET = 0;
    private static final Integer DEFAULT_COUNT = 10;
    public static final String BIS_END_OF_DAY_ERROR_MESSAGE = "Идёт закрытие операционного дня. "
            + "Чтобы посмотреть Ленту операций или сформировать выписку, зайдите позже. "
            + "Новые платежи можно создавать и подписывать прямо сейчас.";
    public static final String STATEMENT_APP_API_MESSAGE = "Не удалось получить информацию об операциях. "
            + "Чтобы посмотреть Ленту операций или сформировать выписку, зайдите позже. "
            + "Новые платежи можно создавать и подписывать прямо сейчас.";

    public static final String GET_DOCUMENT_LIST_MESSAGE =
            "Дата начала периода: %tD. Дата конца периода: %tD. Количество операций в ответе: %d";
    public static final String USER_INITIATOR = "USER";
    public static final String USER_GET_DOCUMENT_LIST = "Запрос списка документов";

    private static final List<String> CARD_COMPLETED_TYPE_LIST = Arrays.asList("PROCESSING", "REJECTED");

    @Value("${document.list.defaultPeriod}")
    private Integer defaultDocumentListPeriod;

    @Value("${document.list.futurePeriod}")
    private Integer futureDocumentListPeriod;

    @Value("${document.list.includeCardTransactions}")
    private boolean includeCardTransactions;

    private final StatementService statementService;
    private final PaymentService paymentService;
    private final AccountService accountService;
    private final CardService cardService;
    private final DocumentToPaymentConverter documentToPaymentConverter;
    private final PaymentToPaymentConverter paymentToPaymentConverter;
    private final CardTransactionToPaymentConverter cardTransactionToPaymentConverter;
    private final DocumentRectificationService documentRectificationService;
    private final OpfConverterService opfConverterService;


    @Async("document_executor")
    public CompletableFuture<List<Payment>> getCardList(DocumentCriteria criteria,
                                                        String clientId, List<OrganizationDTO> orgDTOList) {
        try {
            if (!includeCardTransactions) {
                return CompletableFuture.completedFuture(Collections.emptyList());
            }

            var orgAccounts = orgDTOList.stream()
                    .map(orgDTO -> accountService.getAccountList(orgDTO.getCrmId(), orgDTO.getBisIds()))
                    .flatMap(List::stream)
                    .collect(Collectors.toList());

            var cardListStream = orgDTOList.stream()
                    .map(orgDTO -> orgDTO.getBisIds().stream()
                            .map(bisIdDTO -> cardService.getCardList(bisIdDTO.getId(), bisIdDTO.getBranch()))
                            .flatMap(List::stream)
                            .collect(Collectors.toList()))
                    .flatMap(List::stream);

            List<CardDTO> cardList;
            if (criteria.getCards() != null && !criteria.getCards().isEmpty()) {
                cardList = cardListStream
                        .filter(card -> criteria.getCards().stream()
                                .anyMatch(mask -> mask.substring(mask.length() - 4)
                                        .equals(card.getNumber().substring(card.getNumber().length() - 4))))
                        .collect(Collectors.toList());
            } else {
                cardList = cardListStream
                        .filter(card -> criteria.getTypes() == null || criteria.getTypes().isEmpty()
                                || criteria.getTypes().contains(DocumentCriteria.TypesEnum.DT))
                        .filter(card -> orgAccounts.stream()
                                .filter(acc -> criteria.getAccounts().stream()
                                        .anyMatch(num -> num.equals(acc.getNumber())))
                                .anyMatch(dto -> dto.getNumber13().equals(card.getAccountNumber13())))
                        .filter(card -> CardDTO.StatusEnum.ACTIVE.equals(card.getStatus()))
                        .collect(Collectors.toList());
            }

            var paymentList = cardList.stream()
                    .map(CardDTO::getNumber)
                    .map(card -> statementService
                            .getCardStatementList(card, criteria.getStartDate(), criteria.getEndDate(), clientId))
                    .flatMap(List::stream)
                    .filter(p -> filterCardTransactionsByStatuses(criteria, p))
                    .map(cardTransactionToPaymentConverter::convert)
                    .collect(Collectors.toList());
            if (!isEmpty(paymentList)) {
                paymentList.stream().map(Payment::getPayer)
                        .forEach(p -> orgAccounts.stream()
                                .filter(a -> a.getNumber13().equals(p.getAccount()))
                                .findFirst().ifPresent(a -> p.setAccount(a.getNumber())));
            }
            return CompletableFuture.completedFuture(paymentList);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return CompletableFuture.completedFuture(Collections.emptyList());
        }
    }

    private boolean filterCardTransactionsByStatuses(DocumentCriteria criteria, PaymentDTO payment) {
        if (isEmpty(criteria.getStatuses())) {
            return true;
        } else {
            boolean result = false;
            if (criteria.getStatuses().contains(DocumentCriteria.StatusesEnum.COMPLETED)) {
                result = CARD_COMPLETED_TYPE_LIST.contains(payment.getStatus());
            } else {
                if (criteria.getStatuses().contains(DocumentCriteria.StatusesEnum.PROCESSING)) {
                    result = DocumentCriteria.StatusesEnum.PROCESSING.getValue().equals(payment.getStatus());
                }
                if (criteria.getStatuses().contains(DocumentCriteria.StatusesEnum.REJECTED)) {
                    result = result || DocumentCriteria.StatusesEnum.REJECTED.getValue().equals(payment.getStatus());
                }
            }
            return result;
        }
    }

    @Async("document_executor")
    public CompletableFuture<DocumentsResponse> getDocumentList(DocumentCriteria criteria,
                                                                String clientId,
                                                                List<OrganizationDTO> orgIds) {
        try {
            if (isEmpty(orgIds)) {
                return CompletableFuture.completedFuture(new DocumentsResponse().payments(Collections.emptyList()));
            }
            OffsetDateTime operDate = paymentService.getDocumentTestOperDateGet();
            if (criteria.getStartDate() == null || criteria.getEndDate() == null) {
                criteria.setStartDate(operDate
                        .minusDays(defaultDocumentListPeriod));
                criteria.setEndDate(operDate.plusDays(futureDocumentListPeriod));
            } else if (criteria.getStartDate().isAfter(criteria.getEndDate())) {
                log.error("Wrong criteria dates: {} {}", criteria.getStartDate(), criteria.getEndDate());
                return CompletableFuture.completedFuture(new DocumentsResponse().payments(Collections.emptyList()));
            }

            List<AccountDTO> accountDTOS = null;
            Map<String, String> accountOrgId = new ConcurrentHashMap<>();

            accountDTOS = orgIds.stream()
                    .map(orgInfo -> {
                        List<AccountDTO> accounts = accountService
                                .getAccountList(orgInfo.getCrmId(), orgInfo.getBisIds());
                        accounts.forEach(it -> accountOrgId.put(it.getNumber(),
                                orgInfo.getCrmId()));
                        return accounts;
                    })
                    .flatMap(List::stream)
                    .filter(accountDTO -> isEmpty(criteria.getAccounts())
                            || criteria.getAccounts().contains(accountDTO.getNumber()))
                    .collect(Collectors.toList());

            if (isEmpty(accountDTOS)) {
                log.error("Нет доступных счетов, client id = {}", clientId);
                return CompletableFuture.completedFuture(new DocumentsResponse().payments(Collections.emptyList()));
            }

            List<Payment> payments = new LinkedList<>();
            List<DocumentCriteria.StatusesEnum> statuses = criteria.getStatuses();
            List<AccountStatementError> accStatementErrors = new ArrayList<>();
            if (isEmpty(statuses) || statuses.contains(DocumentCriteria.StatusesEnum.COMPLETED)) {
                // statement-app
                List<PaymentDTO> paymentDTOS = accountDTOS.stream().map(accountDTO -> {
                    try {
                        return statementService.getStatementList(accountDTO.getNumber(),
                                accountDTO.getBisId().getBranch(),
                                criteria.getStartDate(), criteria.getEndDate(), clientId);
                    } catch (FeignException e) {
                        log.error("Ошибка получения документов из statement-app: ", e);
                        String message = "Не удалось получить документы";
                        AccountStatementError.TypeEnum typeEnum = AccountStatementError.TypeEnum.UNEXPECTED;
                        if (e.responseBody().isPresent()) {
                            String error = new String(e.responseBody().get().array(), StandardCharsets.UTF_8);
                            try {
                                ErrorDTO errorDTO = new ObjectMapper().readValue(error, ErrorDTO.class);
                                if (ErrorDTO.TypeEnum.EOD.equals(errorDTO.getType())) {
                                    message = BIS_END_OF_DAY_ERROR_MESSAGE;
                                    typeEnum = AccountStatementError.TypeEnum.END_OF_DAY;
                                }
                            } catch (JsonProcessingException jsonProcessingException) {
                                log.error(e.getMessage(), e);
                            }

                        }
                        accStatementErrors.add(new AccountStatementError().account(
                                accountDTO.getNumber()).errorMsg(message).type(typeEnum));
                        return new LinkedList<PaymentDTO>();
                    } catch (HystrixRuntimeException e) {
                        log.error("Ошибка получения документов из statement-app: ", e);
                        AccountStatementError.TypeEnum typeEnum = AccountStatementError.TypeEnum.UNEXPECTED;
                        accStatementErrors.add(new AccountStatementError().account(
                                accountDTO.getNumber()).errorMsg(STATEMENT_APP_API_MESSAGE).type(typeEnum));
                        return new LinkedList<PaymentDTO>();
                    }
                }).flatMap(List::stream).collect(Collectors.toList());
                // устанавливаем уточнение платежа, если было
                List<String> paymentIdList = paymentDTOS.stream()
                        .map(PaymentDTO::getId)
                        .collect(Collectors.toList());

                Map<String, List<Rectification>> activeDocumentRectificationsByDocumentsId =
                        documentRectificationService
                                .getActiveDocumentRectificationsByDocumentsId(paymentIdList);

                paymentDTOS.stream()
                        .map(paymentToPaymentConverter::convert)
                        .peek(p -> {
                            p.status(Payment.StatusEnum.COMPLETED);
                            List<Rectification> rectifications = documentRectificationService.getRectificationsByPaymentId(
                                    activeDocumentRectificationsByDocumentsId, p);
                            p.setRectifications(rectifications);
                            p.setRectification(documentRectificationService.getRectificationByRectifications(rectifications));
                        })
                        .forEach(payments::add);
                //Обновляем статус COMPLETED платежей
                paymentService.markDocumentsAsCompleted(payments.stream()
                        .map(Payment::getId).collect(Collectors.toList()));
            }
            if (isEmpty(statuses) || !(statuses.size() == 1 && statuses.contains(DocumentCriteria.StatusesEnum.COMPLETED))) {
                // payment-app
                List<DocumentDTO> documentDTOS = paymentService.getPaymentList(
                        accountDTOS
                                .stream()
                                .map(AccountDTO::getNumber)
                                .collect(Collectors.toList()),
                        criteria.getStartDate(),
                        criteria.getEndDate(),
                        Optional.ofNullable(criteria.getStatuses())
                                .orElse(new ArrayList<>())
                                .stream()
                                .filter(s -> !s.equals(DocumentCriteria.StatusesEnum.COMPLETED))
                                .map(DocumentCriteria.StatusesEnum::name)
                                .map(DocumentStatusDTO::fromValue)
                                .collect(Collectors.toList())
                );

                documentDTOS.stream()
                        .filter(d -> !DocumentStatusDTO.COMPLETED.equals(d.getStatus()))
                        .forEach(doc -> payments.add(documentToPaymentConverter.convert(doc)));
            }

            Stream<Payment> paymentsStream;
            if (criteria.getTypes() != null && !criteria.getTypes().isEmpty()) {
                paymentsStream = payments.stream().filter(it -> {
                    var criteriaTypes = criteria.getTypes().stream()
                            .map(DocumentCriteria.TypesEnum::getValue)
                            .collect(Collectors.toList());
                    return criteriaTypes.contains(it.getType().getValue());
                });
            } else if (!isEmpty(criteria.getCards())) {
                paymentsStream = payments.stream()
                        .filter(it -> it.getCardPan() != null)
                        .filter(it -> criteria.getCards().stream()
                                .anyMatch(mask -> mask.substring(mask.length() - 4)
                                        .equals(it.getCardPan().substring(it.getCardPan().length() - 4))));
            } else {
                paymentsStream = payments.stream();
            }

            return CompletableFuture.completedFuture(new DocumentsResponse().payments(paymentsStream
                    .filter(p -> TextFilter.documentContainsText(p, criteria.getFilter()))
                    .filter(p -> isFilters(p, criteria))
                    .peek(it -> {
                        try {
                            String organizationId = null;
                            if (PaymentUtils.isDebit(it.getType().getValue())) {
                                organizationId = accountOrgId.get(it.getPayer().getAccount());
                            } else {
                                organizationId = accountOrgId.get(it.getPayee().getAccount());
                            }

                            it.setOrganizationId(organizationId);
                            opfConverterService.convert(it);
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    })
                    .collect(Collectors.toList())).accStatementErrors(accStatementErrors));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return CompletableFuture.completedFuture(new DocumentsResponse().payments(Collections.emptyList()));
        }
    }

    public static List<Payment> getPage(List<Payment> documents, Page page) {
        if (page == null) {
            page = new Page().offset(DEFAULT_OFFSET).count(DEFAULT_COUNT);
        }
        if (documents.size() <= page.getOffset()) {
            return new LinkedList<>();
        }
        return documents.subList(page.getOffset(), Math.min(page.getOffset() + page.getCount(), documents.size()));
    }

    public static Long getLastPage(List<Payment> documents, Page page) {
        if (page == null) {
            page = new Page().offset(DEFAULT_OFFSET).count(DEFAULT_COUNT);
        }
        if (documents == null) {
            return 0L;
        }
        return (long) Math.ceil((double) documents.size() / page.getCount());
    }

    public static boolean isFilters(Payment document, DocumentCriteria criteria) {
        String contragentName = null;
        String contragentInn = null;
        String contragentBank = null;
        if (PaymentUtils.isDebitForType(document.getType())) {
            contragentName = Optional.ofNullable(document).map(Payment::getPayee).map(Requisite::getName).orElse(null);
            contragentInn = Optional.ofNullable(document).map(Payment::getPayee).map(Requisite::getInn).orElse(null);
            contragentBank = Optional.ofNullable(document).map(Payment::getPayee).map(Requisite::getBank)
                    .map(BankInfo::getBic).orElse(null);

        } else {
            contragentName = Optional.ofNullable(document).map(Payment::getPayer).map(Requisite::getName).orElse(null);
            contragentInn = Optional.ofNullable(document).map(Payment::getPayer).map(Requisite::getInn).orElse(null);
            contragentBank = Optional.ofNullable(document).map(Payment::getPayer).map(Requisite::getBank)
                    .map(BankInfo::getBic).orElse(null);
        }
        BigDecimal amount = Optional.ofNullable(document).map(Payment::getAmount).map(Amount::getSum).orElse(null);
        return TextFilter.containsText(contragentName, criteria.getContragentName())
                && TextFilter.containsText(contragentInn, criteria.getContragentInn())
                && TextFilter.containsText(contragentBank, criteria.getBank())
                && TextFilter.containsText(document.getNumber(), criteria.getDocNumber())
                && (criteria.getSumFrom() == null || amount == null
                || criteria.getSumFrom().abs().compareTo(amount.abs()) <= 0)
                && (criteria.getSumTo() == null || amount == null
                || criteria.getSumTo().abs().compareTo(amount.abs()) >= 0);
    }
}
