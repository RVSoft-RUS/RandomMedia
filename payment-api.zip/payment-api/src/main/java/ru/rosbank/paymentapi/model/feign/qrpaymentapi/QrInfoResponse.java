package ru.rosbank.paymentapi.model.feign.qrpaymentapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QrInfoResponse {

    private ResultDto result;
    private QrInfoDto data;

    public boolean isSuccess() {
        if (data != null && result != null) {
            return result.isSuccess();
        }
        return false;
    }

}

