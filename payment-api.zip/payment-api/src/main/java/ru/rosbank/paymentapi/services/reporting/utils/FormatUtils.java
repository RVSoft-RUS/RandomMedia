package ru.rosbank.paymentapi.services.reporting.utils;

import static ru.rosbank.paymentapi.util.FormatUtils.checkTrue;

import com.google.common.base.CharMatcher;
import com.google.common.base.Strings;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.Assert;
import org.threeten.bp.DateTimeUtils;
import org.threeten.bp.OffsetDateTime;

/**
 * Утилиты для форматирования.
 *
 * <p>В системе жестко заданы параметры локализации. Текущая локаль сервера/клиентов не учитывается.
 * Поэтому здесь эти параметры явно определены.</p>
 *
 * @author Q-APE
 * @author Q-DSH
 */
public class FormatUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(FormatUtils.class);

    public static final String PHONE_PREFIX = "+7";

    public static final String PHONE_NUMBER_MASK = "+7 (095) 999-99-99";

    private static final byte ACCOUNT_NUMBER_LENGTH = 20;

    private static final Locale LOCALE_RU = new Locale("ru", "RU");

    private static final String AMOUNT_PATTERN_1C = "###0.00;- ###0.00";

    /**
     * Формат для денежных сумм.
     */
    public static final String CURRENCY_PATTERN = "#,##0.00;- #,##0.00";

    /**
     * Формат для курсов пересчёта валют.
     */
    public static final String CURRENCY_RATE_PATTERN = "#,##0.00####";

    /**
     * Формат для тарифов.
     */
    public static final String TARIFF_PATTERN = "#,##0.0000";

    /**
     * Формат для процентов.
     */
    public static final String PERCENT_PATTERN = "#,##0.00'%'";

    /**
     * Формат для процентов без дробной части.
     */
    public static final String PERCENT_INTEGER_PATTERN = "#,##0'%'";

    /**
     * Формат для целых чисел.
     */
    public static final String INTEGER_PATTERN = "#,##0";

    /**
     * Формат для целых чисел без использования группировки по разрядам.
     */
    public static final String INTEGER_NO_GROUPING_PATTERN = "#0";

    /**
     * Разделитель целой дробной частей.
     */
    public static final char DECIMAL_SEPARATOR = '.';

    /**
     * Разделитель групп в числах.
     *
     * <p>Внимание! Используется разделитель по умолчанию для русской локали - no-break space.</p>
     */
    public static final char GROUPING_SEPARATOR = '\u00A0';

    /**
     * Формат по умолчанию для даты и времени.
     */
    public static final String DATE_TIME_PATTERN = "dd.MM.yyyy HH:mm";

    public static final String TIME_PATTERN = "HH:mm:ss";


    /**
     * Формат по умолчанию для даты.
     */
    public static final String DATE_PATTERN = "dd.MM.yyyy";

    public static final String DATE_PATTERN_SHORT_YEAR = "dd.MM.yy";

    /**
     * Формат для даты с днями месяца без лидирующего нуля и месяцем в родительном падеже.
     */
    public static final String STRING_MONTH_DATE_PATTERN = "d MMMM yyyy";

    /**
     * Формат для даты истечения срока.
     */
    public static final String EXPIRATION_DATE_PATTERN = "MM/yy";

    /**
     * Формат для денежных сумм.
     *
     * <p><b>Внимание!</b> NumberFormat не является потоко-безопасным!
     * Методы класса должны использовать/возвращать копию данного объекта!</p>
     */
    private static final NumberFormat CURRENCY_FORMAT = createNumberFormat(CURRENCY_PATTERN);

    /**
     * Формат пересчёта курсов валют.
     *
     * <p><b>Внимание!</b> NumberFormat не является потоко-безопасным!
     * Методы класса должны использовать/возвращать копию данного объекта!</p>
     */
    private static final NumberFormat CURRENCY_RATE_FORMAT = createNumberFormat(CURRENCY_RATE_PATTERN);

    /**
     * Формат для тарифов за единицу потреблённого по счётчикам.
     *
     * <p><b>Внимание!</b> NumberFormat не является потоко-безопасным!
     * Методы класса должны использовать/возвращать копию данного объекта!</p>
     */
    private static final NumberFormat TARIFF_FORMAT = createNumberFormat(TARIFF_PATTERN);

    /**
     * Формат для процентов.
     *
     * <p><b>Внимание!</b> NumberFormat не является потоко-безопасным!
     * Методы класса должны использовать/возвращать копию данного объекта!</p>
     */
    private static final NumberFormat PERCENT_FORMAT = createNumberFormat(PERCENT_PATTERN);

    /**
     * Формат для процентов без дробной части.
     *
     * <p><b>Внимание!</b> NumberFormat не является потоко-безопасным!
     * Методы класса должны использовать/возвращать копию данного объекта!</p>
     */
    private static final NumberFormat PERCENT_INTEGER_FORMAT = createIntegralNumberFormat(PERCENT_INTEGER_PATTERN);

    /**
     * Формат для целых чисел.
     *
     * <p><b>Внимание!</b> NumberFormat не является потоко-безопасным!
     * Методы класса должны использовать/возвращать копию данного объекта!</p>
     */
    private static final NumberFormat INTEGER_FORMAT = createIntegralNumberFormat(INTEGER_PATTERN);

    /**
     * Формат для целых чисел без использования группировки по разрядам.
     *
     * <p><b>Внимание!</b> NumberFormat не является потоко-безопасным!
     * Методы класса должны использовать/возвращать копию данного объекта!</p>
     */
    private static final NumberFormat INTEGER_NO_GROUPING_FORMAT = createIntegralNumberFormat(INTEGER_NO_GROUPING_PATTERN);

    private static final String SEPARATOR_SEMICOLON = ";";

    /**
     * Возвращает {@link NumberFormat} для денежных сумм.
     *
     * @return {@link NumberFormat} для денежных сумм
     */
    public static NumberFormat getCurrencyFormat() {
        return (NumberFormat) CURRENCY_FORMAT.clone();
    }

    /**
     * Возвращает {@link NumberFormat} для курса пересчёта валют сумм.
     *
     * @return {@link NumberFormat} для пересчёта валют
     */
    public static NumberFormat getCurrencyRateFormat() {
        return (NumberFormat) CURRENCY_RATE_FORMAT.clone();
    }

    /**
     * Возвращает {@link NumberFormat} для тарифов.
     *
     * @return {@link NumberFormat} для тарифов
     */
    public static NumberFormat getTariffFormat() {
        return (NumberFormat) TARIFF_FORMAT.clone();
    }

    /**
     * Возвращает {@link NumberFormat} для процентов.
     *
     * @return {@link NumberFormat} для процентов
     */
    public static NumberFormat getPercentFormat() {
        return (NumberFormat) PERCENT_FORMAT.clone();
    }

    /**
     * Возвращает {@link NumberFormat} для процентов без дробной части.
     *
     * @return {@link NumberFormat} для процентов без дробной части
     */
    public static NumberFormat getPercentIntegerFormat() {
        return (NumberFormat) PERCENT_INTEGER_FORMAT.clone();
    }

    /**
     * Возвращает {@link NumberFormat} для целых чисел.
     *
     * @return {@link NumberFormat} для целых чисел
     */
    public static NumberFormat getIntegerFormat() {
        return (NumberFormat) INTEGER_FORMAT.clone();
    }

    /**
     * Возвращает {@link NumberFormat} для целых чисел без использования группировки по рязрядам.
     *
     * @return {@link NumberFormat} для целых чисел без использования группировки по рязрядам
     */
    public static NumberFormat getIntegerNoGroupingFormat() {
        return (NumberFormat) INTEGER_NO_GROUPING_FORMAT.clone();
    }

    /**
     * Форматирует проценты.
     *
     * @param number BigDecimal денежная сумма (nullable)
     * @return String форматированная строка. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatPercent(Number number) {
        if (number == null) {
            return "";
        }
        boolean hasFraction = number.floatValue() - number.intValue() > 0;
        NumberFormat format = hasFraction ? getPercentFormat() : getPercentIntegerFormat();
        return format.format(number);
    }

    /**
     * Форматирует денежную сумму.
     *
     * @param number BigDecimal денежная сумма (nullable)
     * @return String форматированная строка. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatCurrency(BigDecimal number) {
        if (number == null) {
            return "";
        }
        NumberFormat format = getCurrencyFormat();
        return format.format(number);
    }

    /**
     * Форматирует курс пересчёта валют.
     *
     * @param number BigDecimal денежная сумма (nullable)
     * @return String форматированная строка. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatCurrencyRate(BigDecimal number) {
        if (number == null) {
            return "";
        }
        NumberFormat format = getCurrencyRateFormat();
        return format.format(number);
    }

    /**
     * Форматирует денежную сумму в строку, представляющую сумму прописью в российских рублях.
     *
     * @param number BigDecimal денежная сумма (nullable)
     * @return String форматированная строка. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatCurrencyToRubleString(BigDecimal number) {
        return number == null ? "" : StringUtils.capitalize(Numerals.spellAmount(number.abs(), "RUR"));
    }

    /**
     * Парсит форматированную строку с денежной суммой.
     *
     * @param string String форматированная строка.
     * @return BigDecimal денежная сумма
     */
    public static BigDecimal parseCurrency(String string) {
        try {
            return (BigDecimal) getCurrencyFormat().parse(string);
        } catch (ParseException e) {
            throw new IllegalArgumentException(String.format("Can't convert string '%s' to number.", string));
        }
    }

    public static BigDecimal parseAmount(String string) {
        return NumberUtils.toScaledBigDecimal(string, 2, RoundingMode.HALF_UP);
    }

    public static String formatInstant(Instant instant) {
        return formatDate(Date.from(instant), DATE_PATTERN);
    }

    /**
     * Форматирует дату/время с использованием стандартного шаблона ({@link #DATE_TIME_PATTERN}).
     *
     * @param date Date дата/время
     * @return String форматированная дата/время. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDateTime(Date date) {
        return formatDate(date, DATE_TIME_PATTERN);
    }

    /**
     * Форматирует дату/время с использованием стандартного шаблона ({@link #DATE_TIME_PATTERN}).
     *
     * @param date Instant дата/время
     * @return String форматированная дата/время. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDateTime(Instant date) {
        ZonedDateTime zonedDateTime = date.atZone(ZoneId.systemDefault());
        return DateTimeFormatter.ofPattern(DATE_TIME_PATTERN).format(zonedDateTime);
    }

    /**
     * Форматирует дату с использованием стандартного шаблона ({@link #DATE_PATTERN}).
     *
     * @param offsetDateTime OffsetDateTime дата
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDateTime(java.time.OffsetDateTime offsetDateTime) {
        Date date = Date.from(offsetDateTime.toInstant());
        return formatDate(date, DATE_TIME_PATTERN);
    }

    /**
     * Форматирует время с использованием стандартного шаблона ({@link #TIME_PATTERN}).
     *
     * @param date Date дата/время
     * @return String форматированная время. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatTime(Date date) {
        return formatDate(date, TIME_PATTERN);
    }

    /**
     * Форматирует дату с использованием стандартного шаблона ({@link #DATE_PATTERN}).
     *
     * @param date Date дата
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(Date date) {
        return formatDate(date, DATE_PATTERN);
    }

    /**
     * Форматирует дату.
     *
     * @param date    Date дата
     * @param pattern String шаблон формата даты. К примеру "yyyy/mm/dd"
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(Date date, String pattern) {
        return formatDate(date, pattern, LOCALE_RU.getLanguage());
    }

    /**
     * Форматирует дату.
     *
     * @param date     Date дата
     * @param pattern  String шаблон формата даты. К примеру "yyyy/mm/dd"
     * @param language String двухсимвольный код языка локали (ru, en, ...)
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(Date date, String pattern, String language) {
        if (date == null) {
            return "";
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern, new Locale(language));
        return toLocalDateTime(date).format(formatter);
    }

    /**
     * Форматирует дату с использованием стандартного шаблона ({@link #DATE_PATTERN}).
     *
     * @param localDate LocalDate дата
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(LocalDate localDate) {
        Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        return formatDate(date, DATE_PATTERN);
    }

    /**
     * Форматирует дату с использованием стандартного шаблона ({@link #DATE_PATTERN}).
     *
     * @param offsetDateTime OffsetDateTime дата
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(OffsetDateTime offsetDateTime) {
        Date date = DateTimeUtils.toDate(offsetDateTime.toInstant());
        return formatDate(date, DATE_PATTERN);
    }

    /**
     * Форматирует дату с использованием стандартного шаблона ({@link #DATE_PATTERN}).
     *
     * @param offsetDateTime OffsetDateTime дата
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDate(java.time.OffsetDateTime offsetDateTime) {
        Date date = Date.from(offsetDateTime.toInstant());
        return formatDate(date, DATE_PATTERN);
    }

    /**
     * Форматирует дату с использованием шаблона ({@link #STRING_MONTH_DATE_PATTERN}).
     *
     * @param localDate LocalDate дата
     * @return String форматированная дата. Если параметр {@code null} возвращается пустая строка.
     */
    public static String formatDateToStringMonth(LocalDate localDate) {
        Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        return formatDate(date, STRING_MONTH_DATE_PATTERN);
    }

    /**
     * Конвертирует дату из типа {@link Date} в тип {@link LocalDateTime}.
     *
     * @param date Date дата
     * @return LocalDateTime дата
     */
    public static LocalDateTime toLocalDateTime(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static Date toDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    private static NumberFormat createNumberFormat(String pattern) {
        DecimalFormatSymbols formatSymbols = DecimalFormatSymbols.getInstance(getLocale());

        formatSymbols.setDecimalSeparator(DECIMAL_SEPARATOR);
        formatSymbols.setGroupingSeparator(GROUPING_SEPARATOR);

        return new DecimalFormat(pattern, formatSymbols);
    }

    private static NumberFormat createIntegralNumberFormat(String pattern) {
        NumberFormat numberFormat = createNumberFormat(pattern);
        numberFormat.setParseIntegerOnly(true);
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(0);
        return numberFormat;
    }

    /**
     * Возвращает локаль приложения.
     *
     * @return Locale экземпляр локали.
     */
    public static Locale getLocale() {
        return LOCALE_RU;
    }

    /**
     * Очищает номер телефона от символов форматирования (пробелы, тире, скобки), оставляет цифры и ведущий знак '+'.
     *
     * @param phone String номер телефона (nullable)
     * @return String номер телефона без символов форматирования. Если phone null or empty, возвращается как есть.
     */
    public static String cleanupPhone(String phone) {
        if (Strings.isNullOrEmpty(phone)) {
            return phone;
        }

        String result = CharMatcher.anyOf("0123456789").retainFrom(phone);

        if (phone.startsWith("+")) {
            result = "+" + result;
        }

        return result;
    }

    /**
     * Возвращает полный номер телефона (включая префикс {@link #PHONE_PREFIX}).
     *
     * <pre>
     *     +38 (012) 345-67-89
     *     +380 - префикс (не вводится пользователем)
     *     123456789 - краткий номер телефона (вводится пользователем, остальные символы добавляет маска)
     *     +380123456789 - полный номер телефона. Фигурирует в базе, используется для отправки СМС и пр.
     * </pre>
     *
     * @param phone String полный либо краткий номер телефона (nullable)
     * @return String полный номер телефона. Если phone null or empty, возвращается как есть.
     */
    public static String fullPhone(String phone) {
        return Strings.isNullOrEmpty(phone) || phone.startsWith(PHONE_PREFIX) ? phone : PHONE_PREFIX + phone;
    }

    /**
     * Удаляет префикс из телефона.
     *
     * @param phone телефон с префиксом или без (nullable)
     * @return телефон без префикса {@link #PHONE_PREFIX}. Если phone null or empty, возвращается как есть.
     */
    public static String removePhonePrefix(String phone) {
        return !Strings.isNullOrEmpty(phone) && phone.startsWith(PHONE_PREFIX) ? phone.substring(PHONE_PREFIX.length()) : phone;
    }

    /**
     * Маскирует номер телефона, возвращая его в виде +38 (0**) ***-99-99, где 9 - любая цифра, * - символ "*".
     * <p>
     * Пример: +70111111111 -> +7 (0**) ***-11-11
     * </p>
     *
     * @param phoneNumber String полный или краткий номер телефона
     * @return String замаскированный номер телефона. null если параметр null. Как есть если длина номера < 8
     */
    public static String maskPhoneNumber(String phoneNumber) {
        if (Strings.isNullOrEmpty(phoneNumber) || phoneNumber.length() < 8) {
            return phoneNumber;
        }

        String fullPhone = fullPhone(phoneNumber);

        return String.format("%s (0**) ***-%s-%s",
            fullPhone.substring(0, 3), fullPhone.substring(9, 11), fullPhone.substring(11));
    }

    public static String formatPhone(String input) {
        throw new UnsupportedOperationException("not implemented");
    }

    public static DateFormat getDateFormat() {
        throw new UnsupportedOperationException("not implemented");
    }

    public static NumberFormat getDecimalFormat() {
        throw new UnsupportedOperationException("not implemented");
    }

    /**
     * Преобразует 20-ти значный номер счета, возвращая его в виде XXXXX ХХХ X XXXX XXXXXXX.
     *
     * @param accountNumber неотформатированный номер счета, представляющий собой строку длиной 20 символов
     * @return отформатированный номер счета
     */
    public static String formatAccountNumber(String accountNumber) {
        if (StringUtils.isBlank(accountNumber) || accountNumber.length() != ACCOUNT_NUMBER_LENGTH) {
            return "";
        }
        return String.format("%s %s %s %s %s",
            accountNumber.substring(0, 5),
            accountNumber.substring(5, 8),
            accountNumber.substring(8, 9),
            accountNumber.substring(9, 13),
            accountNumber.substring(13, 20));
    }

    public static String maskCardNumber(String cardNumber) {
        Assert.notNull(cardNumber, "Argument 'cardNumber' must not be null");
        checkTrue(StringUtils.isNumeric(cardNumber), "Argument 'cardNumber' must be numeric");
        checkTrue(cardNumber.length() >= 16 && cardNumber.length() <= 18,
            "Argument's 'cardNumber' length must be between 16 and 18");

        return String.format("%s %s** **** %s",
            cardNumber.substring(0, 4),
            cardNumber.substring(4, 6),
            cardNumber.substring(12));
    }

    public static String toUrlString(String path) {
        try {
            ClassPathResource classPathResource = new ClassPathResource(path);
            URL baseUrl = classPathResource.getURL();
            Assert.notNull(baseUrl, String.format("template resource [%s] not found", path));
            return baseUrl.toExternalForm();
        } catch (IOException e) {
            throw new IllegalStateException(String.format("Can not resolve resources path '%s'", path), e);
        }
    }

    public static String formatAmount(String amount) {
        return formatAmount(new BigDecimal(amount));
    }

    public static String formatAmount(BigDecimal amount) {
        if (amount == null) {
            return "";
        }

        String stringNumber = amount.abs().toPlainString();
        int pointIndex = stringNumber.indexOf('.');

        String integralPart = pointIndex > 0 ? stringNumber.substring(0, pointIndex) : stringNumber;

        int countOfParts = integralPart.length() / 3;
        StringBuilder res = new StringBuilder();

        res.append(integralPart, 0, integralPart.length() - countOfParts * 3);

        int offset = integralPart.length() - countOfParts * 3;
        for (int i = 0; i < countOfParts; i++) {
            if (i != 0 || (offset > 0)) {
                res.append(" ");
            }
            res.append(integralPart, i * 3 + offset, i * 3 + 3 + offset);
        }

        String fraction = String.valueOf(roundFraction(amount));

        return res.toString() + "-" + ("00" + fraction).substring(fraction.length());
    }

    // TODO refactor
    public static String formatAmountIntegral(BigDecimal amount) {
        if (amount == null) {
            return "";
        }
        return formatAmount(amount).split("-")[0] + ".";
    }

    public static String formatAmountFraction(BigDecimal amount) {
        if (amount == null) {
            return "";
        }
        return formatAmount(amount).split("-")[1];
    }

    private static int roundFraction(BigDecimal number) {
        number = number.abs();
        return number
            .multiply(BigDecimal.valueOf(100))
            .remainder(BigDecimal.valueOf(100))
            .setScale(0, RoundingMode.HALF_UP)
            .intValue();
    }

    public static String formatAmountWithDot(BigDecimal amount) {
        if (amount == null) {
            return "";
        }
        DecimalFormatSymbols formatSymbols = DecimalFormatSymbols.getInstance(getLocale());
        formatSymbols.setDecimalSeparator(DECIMAL_SEPARATOR);
        NumberFormat numberFormat = new DecimalFormat(AMOUNT_PATTERN_1C, formatSymbols);
        return numberFormat.format(amount);
    }

    public static String formatKbk(String kbk) {
        if (kbk == null || kbk.length() != 20) {
            return kbk;
        }

        return String.format("%s %s %s %s %s %s %s",
            kbk.substring(0, 3),
            kbk.substring(3, 4),
            kbk.substring(4, 6),
            kbk.substring(6, 11),
            kbk.substring(11, 13),
            kbk.substring(13, 17),
            kbk.substring(17, 20));
    }

    public static String formatOktmo(String oktmo) {
        if (oktmo == null || (oktmo.length() != 11 && oktmo.length() != 8)) {
            return oktmo;
        }

        if (oktmo.length() == 8) {
            return String.format("%s %s %s",
                oktmo.substring(0, 2),
                oktmo.substring(2, 5),
                oktmo.substring(5, 8));
        } else {
            return String.format("%s %s %s %s",
                oktmo.substring(0, 2),
                oktmo.substring(2, 5),
                oktmo.substring(5, 8),
                oktmo.substring(8, 11));
        }
    }

    public static String formatCmsOperatingTime(String operatingTime) {
        StringBuilder formattedTime = new StringBuilder();
        if (StringUtils.isBlank(operatingTime)) {
            return "";
        }
        String[] parts = operatingTime.split("\n");

        List<String> list = Arrays.stream(parts).map(p -> StringUtils.replaceOnce(p, "]-[", " ")
            .replaceAll("[\\[\\]]", "")
            .trim())
            .collect(Collectors.toList());

        formattedTime.append(String.join(SEPARATOR_SEMICOLON, list));

        if (!operatingTime.contains("вс")) {
            formattedTime.append(SEPARATOR_SEMICOLON);
            if (operatingTime.contains("сб")) {
                formattedTime.append("вс выходной");
            } else {
                formattedTime.append("сб, вс выходной");
            }
        }

        return formattedTime.toString();
    }

    public static String formatBooleanString(String booleanValue) {
        boolean value = false;
        if ("1".equals(booleanValue)) {
            return booleanValue;
        } else if ("0".equals(booleanValue)) {
            return "";
        }
        try {
            value = Boolean.parseBoolean(booleanValue);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
        }
        return value ? "1" : "";
    }

    public static String formatBoolean(Boolean value) {
        return value == null || !value ? "" : "1";
    }

    public static String formatShort(Short value) {
        return value == null || value == 0 ? "" : value.toString();
    }
}
