package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoDto;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundData;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoRequest;

@Mapper(componentModel = "spring")
public interface RefundDataMapper {

    @Mapping(target = "qrcIdr", source = "qrInfoDto.payment.qrId")
    @Mapping(target = "trxId", source = "qrInfoDto.payment.id")
    @Mapping(target = "amount", source = "amountRubKopeck")
    @Mapping(target = "currencyAmount", constant = "RUB")
    @Mapping(target = "accountLegal", source = "sbpRefundInfo.account")
    @Mapping(target = "merchantId", source = "qrInfoDto.payee.merchantId")
    @Mapping(target = "tin", source = "qrInfoDto.payee.inn")
    @Mapping(target = "reasonText", source = "sbpRefundInfo.reasonText")
    RefundData convert(QrInfoDto qrInfoDto, SbpRefundInfoRequest sbpRefundInfo, String amountRubKopeck);

}
