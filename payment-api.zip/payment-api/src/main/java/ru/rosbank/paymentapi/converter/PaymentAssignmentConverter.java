package ru.rosbank.paymentapi.converter;

import ru.rosbank.paymentapi.mapper.PaymentOutputModeMapper;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class PaymentAssignmentConverter {
    public static Payment convert(PaymentDTO input) {
        var payment = new Payment();
        payment.setSubtype(Payment.SubtypeEnum.PAYMENT_ASSIGNMENT);
        BaseConverter.convert(payment, input);



        // Очерёдность платежа
        payment.setPaymentPriority(input.getPaymentPriority());
        // Дата поступления в банк плательщика
        payment.setIncomingDate(input.getIncomingDate());

        payment.setUin(input.getUin());
        payment.setKbk(input.getKbk());
        payment.setOktmo(input.getOktmo());
        payment.setPaymentBasis(input.getPaymentBasis());
        payment.setTaxPeriod(input.getTaxPeriod());
        payment.setBasisDocumentNumber(input.getBasisDocumentNumber());
        payment.setBasisDocumentCreated(input.getBasisDocumentCreated());

        // Статус плательщика
        payment.setPayerStatus(input.getPayerStatus());

        //Операция по карте
        payment.setCardPan(input.getCardPan());
        payment.setCardHolder(input.getCardHolder());
        payment.setApproveCode(input.getApproveCode());
        payment.setMcc(input.getMcc());
        payment.setCompleted(input.getCompleted());

        payment.setCodeTypeIncome(input.getCodeTypeIncome());
        return payment;
    }

}
