package ru.rosbank.paymentapi.services.validator;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.validator.field.DocumentAmountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentNumberValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankBicValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankCorrAccountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentTypeTaxPaymentValidator;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentBasisDocumentNumberValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentCodeTypeIncomeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentKbkValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentOktmoValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayPriorityValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeInnValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeNameValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerAccountValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerNameValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerStatusValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisCreatedValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPurposeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentTaxPeriodValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentUinCode22Validator;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Slf4j
@Service
@RequiredArgsConstructor
public class DefaultPaymentValidators {

    private final List<IDocumentValidator> payrollValidators;

    @Autowired
    DefaultPaymentValidators(
            DocumentPayerNameValidator documentPayerNameValidator,
            DocumentPayeeBankBicValidator documentPayeeBankBicValidator,
            DocumentPayerAccountValidator documentPayerAccountValidator,
            DocumentPaymentBasisValidator documentPaymentBasisValidator,
            DocumentPayeeBankCorrAccountValidator documentPayeeBankCorrAccountValidator,
            DocumentPayPriorityValidator documentPayPriorityValidator,
            DocumentNumberValidator documentNumberValidator,
            DocumentUinCode22Validator documentUinCode22Validator,
            DocumentPayeeInnValidator documentPayeeInnValidator,
            DocumentPayeeKppValidator documentPayeeKppValidator,
            DocumentPayerKppValidator documentPayerKppValidator,
            DocumentPayeeNameValidator documentPayeeNameValidator,
            DocumentAmountValidator documentAmountValidator,
            DocumentKbkValidator documentKbkValidator,
            DocumentOktmoValidator documentOktmoValidator,
            DocumentPurposeValidator documentPurposeValidator,
            DocumentBasisDocumentNumberValidator documentBasisDocumentNumberValidator,
            DocumentPayerStatusValidator documentPayerStatusValidator,
            DocumentTaxPeriodValidator documentTaxPeriodValidator,
            DocumentPaymentBasisCreatedValidator documentPaymentBasisCreatedValidator,
            DocumentCodeTypeIncomeValidator documentCodeTypeIncomeValidator,
            DocumentTypeTaxPaymentValidator documentTypeTaxPaymentValidator
    ) {
        payrollValidators = List.of(
                documentPayeeBankBicValidator,
                documentPayeeBankCorrAccountValidator,
                documentPayerAccountValidator,
                documentPaymentBasisValidator,
                documentBasisDocumentNumberValidator,
                documentPaymentBasisCreatedValidator,
                documentPayerStatusValidator,
                documentTaxPeriodValidator,
                documentPayerNameValidator,
                documentPayPriorityValidator,
                documentNumberValidator,
                documentUinCode22Validator,
                documentKbkValidator,
                documentOktmoValidator,
                documentPayeeInnValidator,
                documentPayeeKppValidator,
                documentPayerKppValidator,
                documentPayeeNameValidator,
                documentAmountValidator,
                documentPurposeValidator,
                documentCodeTypeIncomeValidator,
                documentTypeTaxPaymentValidator
        );
    }

    public void validate(DocumentDTO documentDTO) throws ValidationPaymentException {

        for (IDocumentValidator validator : payrollValidators) {

            validator.validate(documentDTO);

        }

    }
}
