package ru.rosbank.paymentapi.converter;

import ru.rosbank.paymentapi.mapper.PaymentOutputModeMapper;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class PaymentBillConverter {
    public static Payment convert(PaymentDTO input) {
        Payment document = new Payment();
        document.setSubtype(Payment.SubtypeEnum.PAYMENT_BILL);
        BaseConverter.convert(document, input);

        // Очерёдность платежа
        document.setPaymentPriority(input.getPaymentPriority());

        // Условия оплаты
        document.setPaymentCondition(input.getPaymentCondition());

        // Срок акцепта
        document.setExpirationAcceptance(input.getExpirationAcceptance());

        // Окончание срока акцепта
        document.setEndExpirationAcceptance(input.getEndExpirationAcceptance());

        // Дата отсылки (вручения) плательщику предусмотренных договором документов
        document.setOrderDate(input.getOrderDate());
        // Дата поступления в банк плательщика
        document.setIncomingDate(input.getIncomingDate());

        // Уникальный идентификатор начисления
        document.setUin(input.getUin());

        return document;
    }

}
