package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.rosbank.platform.client.paymentapp.model.DocumentSendRequestAppDTO;
import ru.rosbank.platform.server.paymentapi.model.DocumentSendRequestApi;

@Mapper(componentModel = "spring")
public interface DocumentSendRequestMapper {

    @Mapping(target = "dboProId", source = "dboProId")
    @Mapping(target = "documentId", source = "request.documentId")
    @Mapping(target = "email", source = "request.email")
    @Mapping(target = "phone", source = "request.phone")
    DocumentSendRequestAppDTO apiToAppDocumentSendRequest(DocumentSendRequestApi request, String dboProId);
}
