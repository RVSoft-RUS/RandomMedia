package ru.rosbank.paymentapi.services.email;

import freemarker.template.Configuration;
import freemarker.template.TemplateException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import ru.rosbank.paymentapi.services.reporting.template.TemplateMerger;
import ru.rosbank.paymentapi.services.reporting.template.impl.FreeMarkerTemplateEngine;
import ru.rosbank.paymentapi.services.reporting.utils.FormatUtils;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;


/**
 * Summary.
 * @author rb068869
 */
@Component
public class DocumentRectificationLetter {

    private FreeMarkerTemplateEngine freeMarkerTemplateEngine;
    private static final String TEMPLATES_PATH = "templates/";

    static final Map<String, Object> COMMON_TEMPLATE_PARAMETERS = new HashMap<String, Object>() {{
            put("formatter", new FormatUtils());
        }};


    private TemplateMerger newFreeMarkerTemplateMerger() {
        return new TemplateMerger(freeMarkerTemplateEngine);
    }

    String getTemplateResourcePath(String templateName) {
        return TEMPLATES_PATH + templateName;
    }


    public DocumentRectificationLetter() throws IOException, TemplateException {
        FreeMarkerConfigurationFactoryBean configurationFactoryBean = new FreeMarkerConfigurationFactoryBean();
        configurationFactoryBean.setPreferFileSystemAccess(false);
        configurationFactoryBean.setDefaultEncoding("UTF-8");

        Configuration freeMarkerConfiguration = configurationFactoryBean.createConfiguration();
        freeMarkerConfiguration.setClassForTemplateLoading(this.getClass(), "/templates/");

        this.freeMarkerTemplateEngine = new FreeMarkerTemplateEngine(freeMarkerConfiguration);
    }


    public String buildPlainTextMessage(Rectification rectification, Payment payment) {
        TemplateMerger merger = newFreeMarkerTemplateMerger()
            .template(getTemplateResourcePath("document_rectification.txt.ftl"))
            .parameters(COMMON_TEMPLATE_PARAMETERS)
            .parameter("msg", rectification)
            .parameter("dto", payment);
        return merger.merge();
    }


    public String buildHtmlMessage(Rectification rectification, Payment payment) {
        TemplateMerger merger = newFreeMarkerTemplateMerger()
            .template(getTemplateResourcePath("document_rectification.html.ftl"))
            .parameters(COMMON_TEMPLATE_PARAMETERS)
            .parameter("msg", rectification)
            .parameter("dto", payment);
        return merger.merge();
    }

}
