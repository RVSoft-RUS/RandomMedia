package ru.rosbank.paymentapi.services.rectification.validators;

import static ru.rosbank.paymentapi.commons.Constants.NOT_ENOUGH_RIGHTS_ERROR;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;

/**
 * Summary.
 *
 * @author rb066284
 */
@Service
@RequiredArgsConstructor
public class UserRoleValidator {
    public static final String RECT_DOCUMENT_MISS_GRANT_ERROR_MSG =
            "Уточнение доступно только пользователю с полными правами.";
    private final OrganizationService organizationService;
    private final AccountService accountService;

    public void validate(String dboProId, AccountDTO accountDTO, OrganizationDTO organizationDTO) {
        if (accountDTO == null) {
            throw new ValidationException(NOT_ENOUGH_RIGHTS_ERROR);
        }
        if (organizationDTO == null) {
            throw new ValidationException(NOT_ENOUGH_RIGHTS_ERROR);
        }
        IndividualDTO.AccessGroupEnum accessGroup = organizationService.applyRole(dboProId, organizationDTO);
        if (!IndividualDTO.AccessGroupEnum.ALL_RIGHTS.equals(accessGroup)) {
            throw new ValidationException(RECT_DOCUMENT_MISS_GRANT_ERROR_MSG);
        }
    }
}
