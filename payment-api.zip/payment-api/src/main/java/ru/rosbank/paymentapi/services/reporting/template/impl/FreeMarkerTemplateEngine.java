package ru.rosbank.paymentapi.services.reporting.template.impl;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import org.springframework.util.Assert;
import ru.rosbank.paymentapi.services.reporting.template.TemplateContext;
import ru.rosbank.paymentapi.services.reporting.template.TemplateEngine;
import ru.rosbank.paymentapi.services.reporting.template.TemplateEngineException;

/**
 * Шаблонизатор <a href="https://freemarker.apache.org/">Apache FreeMarker</a>.
 *
 * <p>Принимает на вход текстовые файлы различных форматов (plain, xml, html и др.),
 * включающие специальную разметку, подставляет данные из контекста и формирует итоговой файл.</p>
 *
 * @author Q-DSH
 * @author Q-APE
 */
public class FreeMarkerTemplateEngine implements TemplateEngine {

    private final Configuration configuration;

    public FreeMarkerTemplateEngine(Configuration configuration) {
        Assert.notNull(configuration, "Argument 'configuration' must not be null!");

        this.configuration = configuration;
    }

    @Override
    public void evaluate(InputStream inputStream, OutputStream outputStream, TemplateContext context) {
        Assert.notNull(inputStream, "Argument 'inputStream' must not be null!");
        Assert.notNull(outputStream, "Argument 'outputStream' must not be null!");
        Assert.notNull(context, "Argument 'context' must not be null!");

        Writer writer = new OutputStreamWriter(outputStream, getEncoding());
        Reader reader = new InputStreamReader(inputStream, getEncoding());

        try (writer; reader) {
            Template template = new Template("template", reader, configuration);

            template.process(context.getData(), writer);
        } catch (TemplateException | IOException e) {
            throw new TemplateEngineException("An error occurred while evaluating template", e);
        }
    }

    private Charset getEncoding() {
        return Charset.forName(configuration.getDefaultEncoding());
    }
}
