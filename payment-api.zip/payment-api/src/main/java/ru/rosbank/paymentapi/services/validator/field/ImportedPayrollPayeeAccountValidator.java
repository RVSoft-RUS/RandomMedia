package ru.rosbank.paymentapi.services.validator.field;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.Optional;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;


@Service
public class ImportedPayrollPayeeAccountValidator  implements IDocumentValidator {

    public static final String PAYROLL_PAYEE_ACCOUNT_20 = "00000000000000000000";

    public void validate(DocumentDTO document) {
        String payeeAccount = Optional.ofNullable(document)
                .map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getAccount).orElse("");

        if (isNotBlank(payeeAccount)) {
            if (PAYROLL_PAYEE_ACCOUNT_20.equals(payeeAccount)) {
                document.getPayee().setAccount("");
            }
        }
    }
}
