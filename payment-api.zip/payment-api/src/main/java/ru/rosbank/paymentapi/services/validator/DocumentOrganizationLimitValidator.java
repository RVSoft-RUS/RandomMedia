package ru.rosbank.paymentapi.services.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.AccessForbiddenException;
import ru.rosbank.paymentapi.exception.ValidationDocumentOrgLimitException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.ErrorDTO;
import ru.rosbank.platform.client.paymentapp.model.LimitRequestDTO;
import ru.rosbank.platform.client.paymentapp.model.LimitResponseDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.server.paymentapi.model.Error;

@Slf4j
@RequiredArgsConstructor
@Service
public class DocumentOrganizationLimitValidator {

    private final PaymentAppApi paymentAppApi;

    public void validate(OrganizationDTO org, List<DocumentDTO> documents) throws ValidationException {
        LimitRequestDTO limitRequestDTO = new LimitRequestDTO();
        limitRequestDTO.documentIds(documents.stream().map(d -> d.getId().toString()).collect(Collectors.toList()));
        try {
            paymentAppApi.limitOrganizationIdPost(org.getCrmId(), limitRequestDTO)
                    .getBody();
        } catch (FeignException e) {
            if (e.responseBody().isPresent()) {
                ErrorDTO errorDTO;
                try {
                    String error = new String(e.responseBody().get().array(), StandardCharsets.UTF_8);
                    errorDTO = new ObjectMapper().readValue(error, ErrorDTO.class);
                } catch (Exception exception) {
                    log.error(e.getMessage(), e);
                    throw e;
                }
                if (ErrorDTO.TypeEnum.VALIDATION_ERROR.equals(errorDTO.getType())) {
                    log.error(e.getMessage(), e);
                    throw new ValidationDocumentOrgLimitException(errorDTO.getMessage());
                }
            }
            log.error(e.getMessage(), e);
            throw e;
        }
    }


}
