package ru.rosbank.paymentapi.api;

import static ru.rosbank.paymentapi.commons.Constants.ATTRIBUTE_CLIENT_ID;

import io.micrometer.core.annotation.Timed;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import ru.rosbank.paymentapi.exception.ConfirmationRequiredException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.mapper.EventMapper;
import ru.rosbank.paymentapi.services.AccountTurnoverService;
import ru.rosbank.paymentapi.services.AuditService;
import ru.rosbank.paymentapi.services.ClarificationService;
import ru.rosbank.paymentapi.services.CommissionService;
import ru.rosbank.paymentapi.services.CreatePaymentService;
import ru.rosbank.paymentapi.services.DocumentImportService;
import ru.rosbank.paymentapi.services.DocumentListService;
import ru.rosbank.paymentapi.services.RecallService;
import ru.rosbank.paymentapi.services.RefundSbpService;
import ru.rosbank.paymentapi.services.TemplateService;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.PaymentService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.paymentapi.services.rectification.DocumentRectificationService;
import ru.rosbank.paymentapi.services.reporting.DocumentFormService;
import ru.rosbank.paymentapi.services.signature.SignatureService;
import ru.rosbank.paymentapi.util.ReferenceType;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.interceptor.security.AuthorizedOnlyAccess;
import ru.rosbank.platform.server.paymentapi.api.PaymentApiApi;
import ru.rosbank.platform.server.paymentapi.model.CreateTemplateRequest;
import ru.rosbank.platform.server.paymentapi.model.DocumentListPdfRequest;
import ru.rosbank.platform.server.paymentapi.model.DocumentResponse;
import ru.rosbank.platform.server.paymentapi.model.DocumentSendRequestApi;
import ru.rosbank.platform.server.paymentapi.model.DocumentsRequest;
import ru.rosbank.platform.server.paymentapi.model.DocumentsResponse;
import ru.rosbank.platform.server.paymentapi.model.FileResource;
import ru.rosbank.platform.server.paymentapi.model.ImportedBatchResult;
import ru.rosbank.platform.server.paymentapi.model.ImportedDocument;
import ru.rosbank.platform.server.paymentapi.model.NextDocumentInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.PaymentCommission;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoRequest;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoResponse;
import ru.rosbank.platform.server.paymentapi.model.SignDocumentRequest;
import ru.rosbank.platform.server.paymentapi.model.SignDocumentResponse;
import ru.rosbank.platform.server.paymentapi.model.Template;
import ru.rosbank.platform.server.paymentapi.model.TemplatesRequest;
import ru.rosbank.platform.server.paymentapi.model.TemplatesResponse;

@Slf4j
@Controller
@RequiredArgsConstructor
public class PaymentApiApiController implements PaymentApiApi {

    private final HttpSession session;
    private final TemplateService templateService;
    private final CreatePaymentService createPaymentService;
    private final DocumentListService documentListService;
    private final PaymentService paymentService;
    private final RecallService recallService;
    private final DocumentFormService documentFormService;
    private final OrganizationService organizationService;
    private final DocumentImportService documentImportService;
    private final CommissionService commissionService;
    private final DocumentRectificationService documentRectificationService;
    private final AccountTurnoverService accountTurnoverService;
    private final AuditService auditService;
    private final EventMapper eventMapper;
    private final OtpService otpService;
    private final SignatureService signatureService;
    private final RefundSbpService refundSbpService;
    private final ClarificationService clarificationService;
    private final ReferenceService referenceService;
    private final AccountService accountService;

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<TemplatesResponse> apiTemplateSearchPost(@Valid TemplatesRequest templatesRequest) {
        String dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        List<Template> result = templateService.search(templatesRequest.getQuery(), dboProId);
        return ResponseEntity.ok(new TemplatesResponse()
                .templates(templateService.getPage(result, templatesRequest.getPage()))
                .lastPage(templateService.getLastPage(result, templatesRequest.getPage())));
    }

    /**
     * Get document details.
     * @deprecated forRemoval.
     */
    @Deprecated
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<DocumentResponse> apiDocumentDetailsIdGet(String id) {
        return PaymentApiApi.super.apiDocumentDetailsIdGet(id);
    }

    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<FileResource> apiDocumentIdFormatGet(String id, String format, String type) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        if ("AE".equals(type)) {
            return  new ResponseEntity<>(documentFormService.getDocumentFormPDSN(id, format, clientId), HttpStatus.OK);
        }
        return new ResponseEntity<>(documentFormService.getDocumentForm(id, format, clientId), HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Payment> apiDocumentIdUpdatePost(String id, @Valid Payment document) {

        document.setId(id);
        Payment payment = createPaymentService.updatePayment(document, session.getAttribute(ATTRIBUTE_CLIENT_ID).toString());
        if (payment == null) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return new ResponseEntity<>(payment, HttpStatus.OK);
        }
    }

    /**
     * Сервис обращается к card-app методом GET /app/, получая в ответ список карт организаций пользователя,
     * определяет наличие карты в статусе status "АА" к номеру счёта, переданному в запросе.
     * Если в запросе передан статус COMPLETED, то:
     * a. Осуществляется вызов метода bs-api POST /api/document/list, передавая атрибуты, полученные в запросе +
     * номера карт (полученные в п.5.)
     * Если в запросе передан статус CREATED/PROCESSING/REJECTED, то:
     * b. Сервис обращается к payment-app методом GET /document/ получая в ответ список документов из БД в статусе,
     * полученном в запросе.
     * Если в запросе передан список статусов и тип документа "CP"
     * (вкладка с платежными поручениями в разделе "Зарплатный проект"),
     * то:
     * a. Сервис обращается к payment-app методом GET /document/ получая в ответ весь список документов из БД для счетов,
     * переданных в запросе.
     * Если в запросе передан номер карты, то:
     * a. Осуществляется вызов метода bs-api POST /api/document/list, передавая атрибуты, полученные в запросе
     * Сервис агрегирует список документов на основании атрибутов, переданных в запросе,
     * сортирует по дате операции (по текущей реализации)
     * Сервис возвращает успешный ответ и список операций
     */
    @SneakyThrows
    @Override
    @Timed(value = "pro_dbo_document_list_loading_time")
    @AuthorizedOnlyAccess
    public ResponseEntity<DocumentsResponse> apiDocumentListPost(DocumentsRequest documentsRequest) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();

        var orgDTOList = organizationService.getActiveOrganizations(clientId);
        CompletableFuture<DocumentsResponse> documentsResponseFuture =
                documentListService.getDocumentList(documentsRequest.getCriteria(), clientId, orgDTOList);
        CompletableFuture<List<Payment>> cardPaymentList =
                documentListService.getCardList(documentsRequest.getCriteria(), clientId, orgDTOList)
                    .exceptionally(ex -> {
                        log.error("Error getting card list : ", ex);
                        return Collections.emptyList();
                    });
        CompletableFuture.allOf(documentsResponseFuture, cardPaymentList).join();
        List<Payment> accountPaymentList = documentsResponseFuture.get().getPayments();
        var result = Stream.of(accountPaymentList, cardPaymentList.get())
                .flatMap(Collection::stream)
                .sorted((d1, d2) -> {
                    OffsetDateTime dateToCompare1 = calcSortingDate(d1);
                    OffsetDateTime dateToCompare2 = calcSortingDate(d2);
                    return (d2.getCompleted() != null ? d2.getCompleted() : dateToCompare2)
                            .compareTo(d1.getCompleted() != null
                                    ? d1.getCompleted() : dateToCompare1);
                }).collect(Collectors.toList());
        //Отправка эвента в лог
        String message = String.format(DocumentListService.GET_DOCUMENT_LIST_MESSAGE,
                documentsRequest.getCriteria().getStartDate(),
                documentsRequest.getCriteria().getEndDate(), result.size());
        EventDTO eventDTO = new EventDTO();
        eventDTO.setDboProId(clientId);
        eventDTO.setInitiator(DocumentListService.USER_INITIATOR);
        eventDTO.setStage(DocumentListService.USER_GET_DOCUMENT_LIST);
        eventDTO.setMessage(message);
        auditService.sendEvent(eventDTO);
        DocumentsResponse documentsResponse = documentsResponseFuture.get()
                .payments(DocumentListService.getPage(result, documentsRequest.getPage()))
                .lastPage(DocumentListService.getLastPage(result, documentsRequest.getPage()))
                .turnovers(accountTurnoverService.getAccountTurnoversForDocumentList(result)).totalCount(result.size());
        return new ResponseEntity<>(documentsResponse, HttpStatus.OK);
    }

    private OffsetDateTime calcSortingDate(Payment payment) {
        if (Payment.TypeEnum.DT.equals(payment.getType())) {
            return payment.getTransactionDate();
        } else {
            return payment.getExecutionDate() != null ? payment.getExecutionDate() : payment.getCreated();
        }
    }

    /**
     * TODO
     * 7.2. Если AbstractDocument.type не заполнен, то:
     * -Осуществляются кросс-проверки по существующей логике создания платежа
     */
    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Payment> apiDocumentPost(Payment document) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();

        Payment payment = createPaymentService.createPayment(document, clientId);
        if (payment == null) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return new ResponseEntity<>(payment, HttpStatus.OK);
        }

    }

    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Long> apiDocumentRectificationPost(@Valid Rectification rectification) {
        String dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(documentRectificationService.register(rectification, dboProId), HttpStatus.OK);
    }

    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> apiDocumentRectificationIdSignPost(Long id) {
        String dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        Rectification rectification = documentRectificationService.getRegistryRequest(id);
        if (!documentRectificationService.isRectificationRequestAccessible(rectification)) {
            throw new ValidationException("Уточнение для документа id="
                    + rectification.getDocumentId() + " уже создано.");
        }
        if (documentRectificationService.isRectificationRequestSigned(rectification.getId())) {
            documentRectificationService.processDocument(rectification, dboProId);
            return new ResponseEntity<>(HttpStatus.OK);

        } else {
            throw new ConfirmationRequiredException(documentRectificationService.signCertificateRequest(rectification,
                    dboProId));
        }
    }

    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<FileResource> apiDocumentListPdfPost(@Valid DocumentListPdfRequest documentListPdfRequest) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(documentFormService
                .getDocumentListPdf(documentListPdfRequest.getIds(), clientId), HttpStatus.OK);
    }

    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<List<Payment>> apiDocumentDuplicatesPost(List<String> requestBody) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        List<Payment> duplicates = new ArrayList<>();
        return new ResponseEntity<>(duplicates
                /*duplicatesService.getDuplicatesList(requestBody, clientId)*/, HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<SignDocumentResponse> apiDocumentBatchSignPost(@Valid SignDocumentRequest request) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(
                paymentService.batchSign(request, clientId), HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<List<ImportedDocument>> apiImportedBatchIdGet(String id, String status) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(documentImportService.getImportedDocuments(id, clientId, status), HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<ImportedBatchResult> apiImportedBatchIdProcessPost(String id) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(documentImportService.processBatch(id, clientId), HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> apiImportedDocumentIdDelete(String id) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        documentImportService.deleteImportedDocument(id, clientId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<ImportedDocument> apiImportedDocumentPost(ImportedDocument importedDocument) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(documentImportService.updateImportedDocument(importedDocument, clientId), HttpStatus.OK);
    }

    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<ImportedBatchResult> apiImportedPost(FileResource file) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        log.debug(file.toString());
        return new ResponseEntity<>(documentImportService.createBatch(Base64.getDecoder().decode(file.getContent()), clientId),
                HttpStatus.OK);
    }

    @SneakyThrows
    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<PaymentCommission> apiDocumentCommissionCalculationPost(@Valid Payment payment) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(commissionService.getPaymentCommission(payment, clientId), HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> apiDocumentIdRecallPost(String id) {
        String clientId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        recallService.recallPayment(id, clientId);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<NextDocumentInfo> apiDocumentNextGet(@Valid String organizationId) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return ResponseEntity.ok(paymentService.getNextDocumentInfo(dboProId, organizationId));
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Template> apiTemplateCreatePost(@Valid CreateTemplateRequest createTemplateRequest) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();

        var eventDTO = eventMapper.toDTO(dboProId, TemplateService.USER_INITIATOR,
                TemplateService.USER_REQUEST_CREATE_TEMPLATE);
        auditService.sendEvent(eventDTO);

        var template = templateService
                .createTemplateFromDocument(createTemplateRequest.getPayment(), createTemplateRequest.getName(), dboProId);
        return new ResponseEntity<>(template, HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> apiTemplateIdDelete(String id) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();

        var eventDTO = eventMapper.toDTO(dboProId, TemplateService.USER_INITIATOR,
                TemplateService.USER_REQUEST_DELETE_TEMPLATE);
        auditService.sendEvent(eventDTO);

        templateService.deleteTemplate(id, dboProId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Template> apiTemplateSavePost(@Valid Template template) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();

        var eventDTO = eventMapper.toDTO(dboProId, TemplateService.USER_INITIATOR,
                TemplateService.USER_REQUEST_SAVE_TEMPLATE);
        auditService.sendEvent(eventDTO);

        var saveTemplate = templateService.saveTemplate(template, dboProId);
        return new ResponseEntity<>(saveTemplate, HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Template> apiTemplateENPGet() {
        return ResponseEntity.ok(templateService.getTemplateENP());
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Template> apiTemplateFTSGet() {
        return ResponseEntity.ok(templateService.getTemplateFTS());
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> apiTemplateIdIncrementPost(String id) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        templateService.apiTemplateIdIncrementPost(id, dboProId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> apiDocumentIdDelete(String id) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        createPaymentService.deleteDocument(id, dboProId);
        var eventDTO = eventMapper.toDTO(dboProId, TemplateService.USER_INITIATOR,
                CreatePaymentService.USER_REQUEST_DELETE_DOCUMENT, id, ReferenceType.DOCUMENT.name());
        auditService.sendEvent(eventDTO);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<FileResource> apiDeliveringResourceIdGet(String id) {
        return ResponseEntity.ok(paymentService.getDeliveringResource(id));
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> apiDocumentSendPost(@Valid DocumentSendRequestApi request) {
        if (StringUtils.isBlank(request.getEmail()) && StringUtils.isBlank(request.getPhone())) {
            throw new ValidationException("Должно быть заполнено хотя бы одно поле из телефона или почты.");
        }
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        paymentService.sendDocument(request, dboProId);
        return ResponseEntity.ok().build();
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Integer> apiDocumentSignedCountCorrelationIdGet(String correlationId) {
        var otp = otpService.getOtpByUUID(correlationId);
        var signatureIds = signatureService.getSignaturesByOtp(otp).stream()
                .filter(SignatureDTO::getConfirmed)
                .map(signature -> Long.parseLong(signature.getReference().getId()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(paymentService.getSignedDocumentCount(signatureIds));
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<SbpRefundInfoResponse> apiV1RefundsbpPost(SbpRefundInfoRequest sbpRefundInfo) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return new ResponseEntity<>(refundSbpService.createRefund(sbpRefundInfo, dboProId), HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<SbpRefundInfoResponse> apiV1RefundsbpIdExecutePatch(UUID id) {
        return new ResponseEntity<>(refundSbpService.executeRefund(id), HttpStatus.OK);
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<BigDecimal> documentRectificationCommissionGet(String organizationId, String operationUid,
                                                                         String payerAccount20) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        return ResponseEntity.ok(clarificationService.commissionGet(organizationId, operationUid, payerAccount20, dboProId));

    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Boolean> accountCdtBlockGet(String acc20, String bic) {
        String branch = referenceService.getBranchForBic(bic);
        log.info("accountCdtBlockGet: For bic {} was found branch {}", bic, branch);
        return ResponseEntity.ok(accountService.restrictionCdtGet(branch, acc20));
    }

    @Override
    @AuthorizedOnlyAccess
    public ResponseEntity<Void> documentBatchSignPackagesignatureIdExecute(String otpUUID) {
        var dboProId = session.getAttribute(ATTRIBUTE_CLIENT_ID).toString();
        paymentService.batchSignPackageSignatureIdExecute(otpUUID, dboProId);
        return ResponseEntity.ok().build();
    }
}
