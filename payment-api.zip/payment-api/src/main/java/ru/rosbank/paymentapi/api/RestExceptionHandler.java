package ru.rosbank.paymentapi.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import ru.rosbank.paymentapi.exception.AccessForbiddenException;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.exception.ClarificationValidationException;
import ru.rosbank.paymentapi.exception.ConfirmationRequiredException;
import ru.rosbank.paymentapi.exception.DuplicateTemplateNameException;
import ru.rosbank.paymentapi.exception.ImportDocumentException;
import ru.rosbank.paymentapi.exception.InvalidOrganizationException;
import ru.rosbank.paymentapi.exception.NoRightsException;
import ru.rosbank.paymentapi.exception.PaymentNotRevertibleException;
import ru.rosbank.paymentapi.exception.ValidationDocumentOrgLimitException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.platform.client.paymentapp.model.ErrorDTO;
import ru.rosbank.platform.interceptor.security.AuthorizationLevelException;
import ru.rosbank.platform.server.paymentapi.model.Error;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

/**
 * Exception resolver.
 *
 * @author rb067368
 */
@Slf4j
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(Exception.class)
    protected ResponseEntity<Object> handleException(Exception ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(Error.TypeEnum.UNEXPECTED, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(AuthorizationLevelException.class)
    protected ResponseEntity<Object> handleException(AuthorizationLevelException ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

    // Отображаем текст ошибки пользователям
    @ExceptionHandler(ValidationException.class)
    protected ResponseEntity<Object> handleException(ValidationException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().message(ex.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(BackendException.class)
    protected ResponseEntity<Object> handleException(BackendException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().message(ex.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(PaymentNotRevertibleException.class)
    protected ResponseEntity<Object> handleException(PaymentNotRevertibleException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().message(ex.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(DuplicateTemplateNameException.class)
    protected ResponseEntity<Object> handleException(DuplicateTemplateNameException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().message(ex.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // Отображаем текст ошибки пользователям
    @ExceptionHandler(ValidationPaymentException.class)
    protected ResponseEntity<Object> handleException(ValidationPaymentException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error()
                    .message(ex.getMessage())
                    .type(Error.TypeEnum.VALIDATION_ERROR)
                    .field(ex.getErrorField())
                    .fieldId(ex.getErrorCode()),
                HttpStatus.BAD_REQUEST);
    }

    // Отображаем текст ошибки пользователям
    @ExceptionHandler(AccessForbiddenException.class)
    protected ResponseEntity<Object> handleException(AccessForbiddenException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().message(ex.getMessage()).type(Error.TypeEnum.FORBIDDEN),
                HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(ImportDocumentException.class)
    protected ResponseEntity<Object> handleException(ImportDocumentException ex) {
        log.info(ex.getMessage(), ex);
        return new ResponseEntity<>(new Error().message(ex.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ConfirmationRequiredException.class)
    protected ResponseEntity<Object> handleException(ConfirmationRequiredException ex) {
        return new ResponseEntity<>(ex.getConfirmation(), HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(BankInfoException.class)
    protected ResponseEntity<Object> handleException(BankInfoException ex) {
        log.error(ex.getMessage(), ex);
        return new ResponseEntity<>(Error.TypeEnum.UNEXPECTED, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(FeignException.class)
    protected ResponseEntity<Object> handleException(FeignException e) {
        if (e.responseBody().isPresent()) {
            String error = new String(e.responseBody().get().array(), StandardCharsets.UTF_8);
            ErrorDTO errorDTO;
            try {
                errorDTO = new ObjectMapper().readValue(error, ErrorDTO.class);
            } catch (JsonProcessingException jsonProcessingException) {
                log.error(e.getMessage(), e);
                return new ResponseEntity<>(Error.TypeEnum.UNEXPECTED, HttpStatus.INTERNAL_SERVER_ERROR);
            }
            if (ErrorDTO.TypeEnum.VALIDATION_ERROR.equals(errorDTO.getType())) {
                log.error(e.getMessage(), e);
                return new ResponseEntity<>(new Error().message(e.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                        HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        log.error(e.getMessage(), e);
        return new ResponseEntity<>(Error.TypeEnum.UNEXPECTED, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(ValidationDocumentOrgLimitException.class)
    protected ResponseEntity<Object> handleException(ValidationDocumentOrgLimitException e) {
        log.error(e.getMessage(), e);
        return new ResponseEntity<>(new Error().message(e.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.FORBIDDEN);

    }

    @ExceptionHandler(InvalidOrganizationException.class)
    protected ResponseEntity<Object> handleException(InvalidOrganizationException e) {
        log.error(e.getMessage(), e);
        return new ResponseEntity<>(new Error().message(e.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(NoRightsException.class)
    protected ResponseEntity<Object> handleException(NoRightsException e) {
        log.error(e.getMessage(), e);
        return new ResponseEntity<>(new Error().message(e.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR),
                HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(ClarificationValidationException.class)
    protected ResponseEntity<Object> handleException(ClarificationValidationException ex) {
        log.info(ex.getMessage(), ex);
        return ResponseEntity.internalServerError()
                .body(new Error().message(ex.getMessage()).type(Error.TypeEnum.VALIDATION_ERROR));
    }
}
