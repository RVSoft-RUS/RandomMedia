package ru.rosbank.paymentapi.services.validator.field;

import com.google.common.base.Objects;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import ru.rosbank.paymentapi.services.integration.NotificationService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

/**
 * Summary.
 *
 * @author rb064742
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DfmBlockValidator {
    private static final String DFM_BLOCK_MESSAGE = "Этот платеж нельзя подписать онлайн из-за ограничений. "
            + "Вы можете отправить только платёж в бюджет или перевести средства себе в любой банк. "
            + "Подробности в сообщениях от Банка.";
    private static final int FIELD_ID = 9;
    private static final String FIELD_NAME = "payer.account";

    private final NotificationService notificationService;



    public void validate(DocumentDTO documentDTO, Map<String, AccountDTO> clientAccounts) {

        boolean blocked = notificationService.isBlocked(documentDTO.getBisId().getId(), documentDTO.getBisId().getBranch());
        validate(documentDTO, clientAccounts, blocked);
    }

    public void validate(DocumentDTO documentDTO, Map<String, AccountDTO> clientAccounts, Boolean blocked) {
        Assert.notNull(blocked, "blocked is Empty");
        RequisiteDTO payee = documentDTO.getPayee();
        RequisiteDTO payer = documentDTO.getPayer();
        var payerAccountDTO = clientAccounts.get(payer.getAccount());
        if (blocked && (Objects.equal(documentDTO.getType(), DocumentDTO.TypeEnum.DE)
                || (Objects.equal(payee.getInn(), payer.getInn())
                && Objects.equal(payee.getAccount().substring(0, 5), payer.getAccount().substring(0, 5))
                && (List.of("CA", "C5", "C6", "C1").contains(payerAccountDTO.getAccountType()))))) {
            blocked = false;
        }

        if (blocked) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, DFM_BLOCK_MESSAGE);
        }
    }

    public void validate(List<DocumentDTO> documentDTO, Map<String, AccountDTO> clientAccounts) {
        List<BisIdDTO> bisIdDTOS = getBisIds(documentDTO);
        Assert.notEmpty(bisIdDTOS, "bisIdDTOS is Empty");
        Map<String, Boolean> bisIdIsBlockedMap = getIsBlockedMap(bisIdDTOS);
        Assert.notEmpty(bisIdIsBlockedMap, "bisIdIsBlockedMap is Empty");
        documentDTO.forEach(d -> validate(d, clientAccounts, bisIdIsBlockedMap.get(d.getBisId().getId())));
    }

    Map<String, Boolean> getIsBlockedMap(List<BisIdDTO> bisIdDTOS) {
        Map<String, Boolean> bisIdIsBlockedMap = new HashMap<>();
        bisIdDTOS.forEach(b -> bisIdIsBlockedMap.put(b.getId(),
                notificationService.isBlocked(b.getId(), b.getBranch())));
        return bisIdIsBlockedMap;
    }

    List<BisIdDTO> getBisIds(List<DocumentDTO> documentDTO) {
        Map<String, BisIdDTO> bisIdDTOSMap = new HashMap<>();
        documentDTO.forEach(d -> bisIdDTOSMap.put(d.getBisId().getId(), d.getBisId()));
        List<BisIdDTO> bisIdDTOS = new ArrayList<>();
        bisIdDTOS.addAll(bisIdDTOSMap.values());
        return bisIdDTOS;
    }
}
