package ru.rosbank.paymentapi.services.rectification.validators;

import com.google.common.collect.ImmutableMap;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.Optional;
import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.utils.payment.validators.DocumentBasisDocumentNumberValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentKbkValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentOktmoValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeInnValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeNameValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisCreatedValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPurposeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentTaxPeriodValidator;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;


/**
 * Summary.
 * @author rb066284
 */
@Service
public class RectificationFieldsValidator {
    public static final String RECT_DOCUMENT_FIELDS_EQUALS_ERROR_MSG =
            "Уточнённые данные не должны совпадать с исходным платежом. Измените хотя бы одно поле.";
    private static final Logger LOGGER = LoggerFactory.getLogger(RectificationFieldsValidator.class);

    @Autowired
    private DocumentPayeeNameValidator documentPayeeNameValidator;
    @Autowired
    private DocumentPayeeAccountValidator documentPayeeAccountValidator;
    @Autowired
    private DocumentPayeeInnValidator documentPayeeInnValidator;
    @Autowired
    private DocumentPayeeKppValidator documentPayeeKppValidator;
    @Autowired
    private DocumentPurposeValidator documentPurposeValidator;
    @Autowired
    private DocumentKbkValidator documentKbkValidator;
    @Autowired
    private DocumentOktmoValidator documentOktmoValidator;
    @Autowired
    private DocumentPaymentBasisValidator documentPaymentBasisValidator;
    @Autowired
    private DocumentTaxPeriodValidator documentTaxPeriodValidator;
    @Autowired
    private DocumentBasisDocumentNumberValidator documentBasisDocumentNumberValidator;
    @Autowired
    private DocumentPaymentBasisCreatedValidator documentBasisDocumentCreatedValidator;
    @Autowired
    private DocumentToPaymentConverter documentToPaymentConverter;
    @Autowired
    private UinValidator uinValidator;

    private ImmutableMap<String, IDocumentValidator> fieldValidationMap;

    @PostConstruct
    public void init() {
        fieldValidationMap = new ImmutableMap.Builder<String, IDocumentValidator>()
            .put("payeeName", documentPayeeNameValidator)
            .put("payeeAccount", documentPayeeAccountValidator)
            .put("payeeInn", documentPayeeInnValidator)
            .put("payeeKpp", documentPayeeKppValidator)
            .put("purpose", documentPurposeValidator)
            .put("kbk", documentKbkValidator)
            .put("oktmo", documentOktmoValidator)
            .put("paymentBasis", documentPaymentBasisValidator)
            .put("taxPeriod", documentTaxPeriodValidator)
            .put("basisDocumentNumber", documentBasisDocumentNumberValidator)
            .put("basisDocumentCreated", documentBasisDocumentCreatedValidator)
            .put("uin", uinValidator)
            .build();
    }

    public void validate(Rectification documentRectification,
                         Payment payment, AccountDTO account) {
        DocumentDTO document = documentToPaymentConverter.convertBackWithoutId(payment, account);
        Rectification rectificationFieldFromDocument = getRectificationFieldFromDocument(document);
        boolean allMatch = true;
        for (String field : fieldValidationMap.keySet()) {
            try {
                if (getField(field, documentRectification) == null) {
                    continue;
                }
                if (compareFields(field, documentRectification, rectificationFieldFromDocument)) {
                    clearField(field, documentRectification);
                } else {
                    allMatch = false;
                    updateDocumentField(field, document, getField(field, documentRectification));
                    fieldValidationMap.get(field).validate(document);
                }
            } catch (Exception e) {
                LOGGER.info(e.getMessage());
            }
        }
        if (allMatch) {
            throw new ValidationException(RECT_DOCUMENT_FIELDS_EQUALS_ERROR_MSG);
        }

    }

    /**
     * compareFields - сравнение значений одноименных полей объектов src и trg.
     *
     */
    public static boolean compareFields(String fieldName, Object src, Object trg) throws Exception {

        Object srcVal = (new PropertyDescriptor(fieldName, src.getClass())).getReadMethod().invoke(src);
        Object trgVal = (new PropertyDescriptor(fieldName, trg.getClass())).getReadMethod().invoke(trg);

        if (srcVal != null && srcVal.equals(trgVal)) {
            return true;
        }

        return false;
    }

    public static Object getField(String fieldName, Object src) throws IntrospectionException,
            InvocationTargetException, IllegalAccessException {
        return (new PropertyDescriptor(fieldName, src.getClass())).getReadMethod().invoke(src);
    }

    public static void clearField(String fieldName, Object obj) throws Exception {
        updateField(fieldName, obj, null);
    }

    /**
     * updateField - присваивает значение value полю fieldName объекта obj.
     *
     * @param fieldName f
     * @param obj o
     * @param value val
     * @throws Exception ex
     */
    public static void updateField(String fieldName, Object obj, Object value) throws Exception {

        PropertyDescriptor pd = new PropertyDescriptor(fieldName, obj.getClass());
        pd.getWriteMethod().invoke(obj, value);

    }

    public static void updateDocumentField(String fieldName, DocumentDTO document, Object value) throws Exception {

        switch (fieldName) {
            case "payeeName":
                Optional.ofNullable(document.getPayee()).orElse(new RequisiteDTO()).setName((String)value);
                break;
            case "payeeAccount":
                Optional.ofNullable(document.getPayee()).orElse(new RequisiteDTO()).setAccount((String)value);
                break;
            case "payeeInn":
                Optional.ofNullable(document.getPayee()).orElse(new RequisiteDTO()).setInn((String)value);
                break;
            case "payeeKpp":
                Optional.ofNullable(document.getPayee()).orElse(new RequisiteDTO()).setKpp((String)value);
                break;

            default:
                PropertyDescriptor pd = new PropertyDescriptor(fieldName, document.getClass());
                pd.getWriteMethod().invoke(document, value);
        }


    }

    public static Rectification getRectificationFieldFromDocument(DocumentDTO document) {
        Rectification rectification = new Rectification();
        RequisiteDTO payee = Optional.ofNullable(document.getPayee()).orElse(new RequisiteDTO());
        rectification.setPayeeName(payee.getName());
        rectification.setPayeeAccount(payee.getAccount());
        rectification.setPayeeInn(payee.getInn());
        rectification.setPayeeKpp(payee.getKpp());
        rectification.setPurpose(document.getPurpose());
        rectification.setKbk(document.getKbk());
        rectification.setOktmo(document.getOktmo());
        rectification.setPaymentBasis(document.getPaymentBasis());
        rectification.setTaxPeriod(document.getTaxPeriod());
        rectification.setBasisDocumentNumber(document.getBasisDocumentNumber());
        rectification.setBasisDocumentCreated(document.getBasisDocumentCreated());
        return rectification;
    }
}
