package ru.rosbank.paymentapi.model.feign.qrpaymentapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QrInfoDto {

    private PaymentQrDto payment;
    private PaymentPayerDto payer;
    private PaymentPayeeDto payee;

}

