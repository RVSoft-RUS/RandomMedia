package ru.rosbank.paymentapi.services.onec;


import java.util.Optional;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

/**
 * Summary.
 * @author rb068869
 */
public class PayeeAccountParser1C extends AbstractDocumentFieldParser1C {
    private static final String PAYEE_ACCOUNT_KEY = "ПолучательСчет";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            RequisiteDTO payee = Optional.of(document).map(DocumentDTO::getPayee).orElse(new RequisiteDTO());
            document.setPayee(payee);
            payee.setAccount(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, PAYEE_ACCOUNT_KEY);
    }

}
