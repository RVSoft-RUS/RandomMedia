package ru.rosbank.paymentapi.services.validator.field;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

/**
 * Summary.
 * @author rb068774
 *      Поле 110
 */
@Service
public class DocumentTypeTaxPaymentValidator implements IDocumentValidator {

    private static final List<String> D_PERSONAL_MASK = Arrays.asList("30232", "40817", "40820", "42301", "42302", "42303",
            "42304", "42305", "42306", "42307", "42601", "42602", "42603", "42604", "42605", "42606", "42607");

    private static final Set<String> ACC_NUMBER = new HashSet<>(D_PERSONAL_MASK);

    public void validate(DocumentDTO document) throws ValidationPaymentException {
        if (StringUtils.isNotBlank(document.getTypeTaxPayment()) && Boolean.parseBoolean(document.getTypeTaxPayment())
                && DocumentDTO.TypeEnum.DE.equals(document.getType())) {

            throw new ValidationPaymentException(110, "type_tax_payment", "Некорректное значение поля тип налогового платежа");
        }
    }
}
