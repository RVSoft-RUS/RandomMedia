package ru.rosbank.paymentapi.services.validator.field;

import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * Validate fields payer_status, payment_basis, basis_document_number,
 * basis_document_created, tax_period, kbk, oktmo
 * Если это не 'Расчёты с бюджетом', то указанные поля должны быть пустыми
 */
@Service
public class DocumentBudgetFieldsValidator {

    public void validate(DocumentDTO document) {
        document.setPayerStatus(null);
        document.setPaymentBasis(null);
        document.setBasisDocumentNumber(null);
        document.setBasisDocumentCreated(null);
        document.setTaxPeriod(null);
        document.setKbk(null);
        document.setOktmo(null);
    }

}
