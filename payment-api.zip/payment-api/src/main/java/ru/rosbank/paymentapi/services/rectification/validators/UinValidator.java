package ru.rosbank.paymentapi.services.rectification.validators;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentUinCode22Validator;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

/**
 * Summary.
 *
 * @author rb067368
 */
@Service
public class UinValidator implements IDocumentValidator {

    @Autowired
    private DocumentUinCode22Validator documentUinCode22Validator;

    @Override
    public void validate(DocumentDTO document) throws ValidationPaymentException {
        String uin = document.getUin();
        if (StringUtils.isBlank(uin)) {
            return;
        }
        documentUinCode22Validator.basicValidation(uin);
    }
}
