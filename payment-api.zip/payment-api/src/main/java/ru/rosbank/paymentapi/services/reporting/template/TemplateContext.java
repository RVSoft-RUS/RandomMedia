package ru.rosbank.paymentapi.services.reporting.template;

import java.util.HashMap;
import java.util.Map;
import org.springframework.util.Assert;

/**
 * Контекст данных, используемый при формировании результатов {@link TemplateEngine шаблонизаторами}.
 *
 * @author Q-DSH
 */
public class TemplateContext {

    /**
     * Данные для шаблонизатора в виде множества пар (ключ, значение).
     */
    private final Map<String, Object> data = new HashMap<>();

    /**
     * Конструктор.
     */
    public TemplateContext() {
    }

    /**
     * Конструктор.
     *
     * @param data данные для шаблонизатора в виде множества пар (ключ, значение)
     */
    public TemplateContext(Map<String, ?> data) {
        Assert.notNull(data, "Argument 'data' must not be null!");

        put(data);
    }

    /**
     * Возвращает данные для шаблонизатора в виде множества пар (ключ, значение).
     *
     * @return данные для шаблонизатора в виде множества пар (ключ, значение)
     */
    public Map<String, Object> getData() {
        return data;
    }

    /**
     * Возвращает значение, соответствующее ключу.
     *
     * @param key ключ
     * @return значение, соответствующее ключу; либо {@code null} - если не задано
     */
    public Object get(String key) {
        Assert.notNull(key, "Argument 'key' must not be null!");
        return data.get(key);
    }

    /**
     * Добавляет пару (ключ, значение) в данные для шаблонизатора.
     *
     * @param key   ключ
     * @param value значение
     * @return {@code this}
     */
    public TemplateContext put(String key, Object value) {
        Assert.notNull(key, "Argument 'key' must not be null!");
        data.put(key, value);
        return this;
    }

    /**
     * Добавляет множество пар (ключ, значение) в данные для шаблонизатора.
     *
     * @param map множество пар (ключ, значение)
     * @return {@code this}
     */
    public TemplateContext put(Map<String, ?> map) {
        Assert.notNull(map, "Argument 'map' must not be null!");
        data.putAll(map);
        return this;
    }
}
