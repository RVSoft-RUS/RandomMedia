package ru.rosbank.paymentapi.mapper;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

@Mapper(componentModel = "spring")
public interface OffsetDateTimeMapper {
    DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

    @Named("toDate")
    public default OffsetDateTime toDate(OffsetDateTime value) {
        if (value == null) {
            return null;
        }
        return OffsetDateTime.parse(DATE_TIME_FORMATTER.format(value), DATE_TIME_FORMATTER);
    }
}
