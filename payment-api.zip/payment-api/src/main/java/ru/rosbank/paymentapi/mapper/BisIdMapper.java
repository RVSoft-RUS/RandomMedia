package ru.rosbank.paymentapi.mapper;

import java.util.List;
import org.mapstruct.Mapper;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;

@Mapper(componentModel = "spring")
public interface BisIdMapper {
    BisIdDTO organizationToAccount(
            ru.rosbank.platform.client.organizationapp.model.BisIdDTO orgBisId);

    List<BisIdDTO> organizationListToAccountList(
            List<ru.rosbank.platform.client.organizationapp.model.BisIdDTO> orgBisId);
}
