package ru.rosbank.paymentapi.services.reporting.utils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

/**
 * Класс преобразующий числа и денежные суммы в русскоязычный текст.
 *
 * @author Q-YAA
 */
public class RussianNumeral extends AbstractNumeral {

    private static final String[] UNITS = {
        "ноль", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять"
    };

    private static final String[] TEENS = {
        "десять", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать", "пятнадцать", "шестнадцать",
        "семнадцать", "восемнадцать", "девятнадцать"
    };

    private static final String[] TENS = {
        "", "десять", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто"
    };

    private static final String[] HUNDREDS = {
        "", "сто", "двести", "триста", "четыреста", "пятьсот", "шестьсот", "семьсот", "восемьсот", "девятьсот"
    };

    private static final String[] LIONS = {
        "", "тысяча", "миллион", "миллиард", "триллион", "квадриллион", "квинтиллион", "секстиллион", "септиллион",
        "октиллион", "нониллион", "дециллион"
    };

    private static final Map<String, String[]> INTEGRAL_CURRENCY_MAP =
            Map.of("RUR", new String[] {"рубль", "рубля", "рублей"},
                    "RUB", new String[] {"рубль", "рубля", "рублей"},
                    "USD", new String[] {"доллар", "доллара", "долларов"},
                    "EUR", new String[] {"евро", "евро", "евро"});

    private static final Map<String, String[]> FRACTION_CURRENCY_MAP =
            Map.of("RUR", new String[] {"копейка", "копейки", "копеек"},
                    "RUB", new String[] {"копейка", "копейки", "копеек"},
                    "USD", new String[] {"цент", "цента", "центов"},
                    "EUR", new String[] {"цент", "цента", "центов"});

    @Override
    public String spellNumber(BigInteger number) {
        checkNumberSupported(number);
        return spellNumberImpl(number.toString());
    }

    @Override
    public String spellAmount(BigDecimal number, String currency) {
        checkCurrencySupported(currency);
        return spellAmountImpl(number, currency);
    }

    private String spellNumberImpl(String number) {
        if ("0".equals(number)) {
            return UNITS[0];
        }

        StringBuilder stringBuilder = new StringBuilder();

        if (number.startsWith("-")) {
            stringBuilder.append("минус ");
            number = number.substring(1);
        }

        String[] blocks = NumeralUtils.numberToBlocks(number);

        for (int i = 0; i < blocks.length; ++i) {
            // 1 = 1000, 2 = 1 000 000
            int exponent = blocks.length - i - 1;

            // Сотни
            int hundreds = Character.getNumericValue(blocks[i].charAt(0));
            // Десятки
            int tens = Character.getNumericValue(blocks[i].charAt(1));
            // Единицы
            int units = Character.getNumericValue(blocks[i].charAt(2));

            // Присутствуют сотни
            if (hundreds > 0) {
                String textHundreds = HUNDREDS[hundreds];
                stringBuilder.append(textHundreds);
                stringBuilder.append(" ");
            }
            // Десятки отсутствуют
            if (tens == 0) {
                String textUnits = units(units, exponent);
                stringBuilder.append(textUnits);
                stringBuilder.append(!"".equals(textUnits) ? " " : "");
            } else if (tens == 1) { // от 11 до 21
                stringBuilder.append(TEENS[units]);
                stringBuilder.append(" ");
            } else if (tens > 1) { // Двадцать один и больше
                stringBuilder.append(TENS[tens]);
                stringBuilder.append(" ");

                String textUnits = units(units, exponent);
                stringBuilder.append(units(units, exponent));
                stringBuilder.append(!"".equals(textUnits) ? " " : "");
            }

            // одна две три четыре пять шесть семь восемь девять десять
            if (exponent > 0 && (hundreds + tens + units > 0)) {
                if (exponent == 1) {
                    stringBuilder.append(thousands(tens, units));
                } else {
                    stringBuilder.append(lions(tens, units, exponent));
                }
                stringBuilder.append(" ");
            }
        }

        return stringBuilder.toString().trim();
    }

    private String units(int units, int exponent) {
        String textUnits = "";
        if (units > 0) {
            textUnits = UNITS[units];
            if (exponent == 1) {
                switch (units) {
                    case 1:
                        textUnits = "одна";
                        break;
                    case 2:
                        textUnits = "две";
                        break;
                    default:
                }
            }
        }
        return textUnits;
    }

    private String lions(int tens, int units, int exponent) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(LIONS[exponent]);

        if (tens == 0 || tens > 1) {
            switch (units) {
                case 1:
                    break;
                case 2:
                case 3:
                case 4:
                    stringBuilder.append("а");
                    break;
                default:
                    stringBuilder.append("ов");
                    break;
            }
        } else {
            stringBuilder.append("ов");
        }
        return stringBuilder.toString();
    }

    private String thousands(int tens, int units) {
        String result = "тысяч";
        // от 0 до 9 или h*100
        if (tens == 0 || tens > 1) {
            switch (units) {
                case 1:
                    result = "тысяча";
                    break;
                case 2:
                case 3:
                case 4:
                    result = "тысячи";
                    break;
                default:
                    break;
            }
        }
        return result;
    }

    private void checkCurrencySupported(String currency) {
        if (!INTEGRAL_CURRENCY_MAP.containsKey(currency)) {
            throw new IllegalArgumentException(String.format("Currency '%s' not supported", currency));
        }
    }

    private String spellAmountImpl(BigDecimal number, String currency) {
        String stringNumber = number.stripTrailingZeros().toPlainString();

        int pointIndex = stringNumber.indexOf('.');

        String integralPart = pointIndex > 0 ? stringNumber.substring(0, pointIndex) : stringNumber;
        String textIntegralPart = spellNumberImpl(integralPart);

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(textIntegralPart);
        stringBuilder.append(" ");
        stringBuilder.append(integralCurrency(number, currency));
        stringBuilder.append(" ");

        int fraction = roundFraction(number);

        if (fraction != 0) {
            stringBuilder.append(fraction);
            stringBuilder.append(" ");
            stringBuilder.append(fractionCurrency(fraction, currency));
        }

        return stringBuilder.toString().trim();
    }

    private static int roundFraction(BigDecimal number) {
        number = number.abs();
        return number
            .multiply(BigDecimal.valueOf(100))
            .remainder(BigDecimal.valueOf(100))
            .setScale(0, RoundingMode.HALF_UP)
            .intValue();
    }

    private static String fractionCurrency(int fraction, String currency) {
        String[] fractionCurrencyNames = FRACTION_CURRENCY_MAP.get(currency);

        String fractionCurrencyName;
        if (fraction > 10 && fraction < 20) {
            fractionCurrencyName = fractionCurrencyNames[2];
        } else {
            int lastDigit = fraction % 10;
            switch (lastDigit) {
                case 1:
                    fractionCurrencyName = fractionCurrencyNames[0];
                    break;
                case 2:
                case 3:
                case 4:
                    fractionCurrencyName = fractionCurrencyNames[1];
                    break;
                default:
                    fractionCurrencyName = fractionCurrencyNames[2];
            }
        }

        return fractionCurrencyName;
    }

    private static String integralCurrency(BigDecimal sum, String currency) {
        BigInteger integralPart = sum.setScale(0, RoundingMode.DOWN).toBigInteger();
        int remainder = integralPart.remainder(BigInteger.valueOf(100)).intValue();

        String[] integralCurrencyNames = INTEGRAL_CURRENCY_MAP.get(currency);

        String currencyName;
        if (remainder > 10 && remainder <= 20) {
            currencyName = integralCurrencyNames[2];
        } else {
            int lastDigit = remainder % 10;
            switch (lastDigit) {
                case 1:
                    currencyName = integralCurrencyNames[0];
                    break;
                case 2:
                case 3:
                case 4:
                    currencyName = integralCurrencyNames[1];
                    break;
                default:
                    currencyName = integralCurrencyNames[2];
            }
        }
        return currencyName;
    }
}
