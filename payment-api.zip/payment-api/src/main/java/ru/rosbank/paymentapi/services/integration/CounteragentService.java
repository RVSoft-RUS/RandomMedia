package ru.rosbank.paymentapi.services.integration;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.contragentapp.api.ContragentAppAutomaticApi;
import ru.rosbank.platform.client.contragentapp.model.ContragentDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class CounteragentService {

    private final ContragentAppAutomaticApi contragentAppAutomaticApi;

    @Async("audit_executor")
    public void saveOrUpdateCounteragent(List<DocumentDTO> documents) {

        documents.stream()
                .sorted(Comparator.comparing(DocumentDTO::getDate).reversed())
                .filter(distinctByKey(doc -> Optional.ofNullable(doc).map(DocumentDTO::getPayee)
                        .map(RequisiteDTO::getInn).orElse("")))
                .forEach(this::save);
    }

    private void save(DocumentDTO document) {
        try {
            contragentAppAutomaticApi.createContragentAutoPost(
                    document.getCrmId(), getContragentDTO(document));
        } catch (Exception e) {
            log.error("Error processing counteragent document with id {}", document.getId(), e);
        }
    }

    private ContragentDTO getContragentDTO(DocumentDTO document) {
        ContragentDTO contragentDTO = new ContragentDTO();
        contragentDTO.setAccount(Optional.ofNullable(document).map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getAccount).orElse(null));
        contragentDTO.setBic(Optional.ofNullable(document).map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getBank).map(BankInfoDTO::getBic).orElse(null));
        contragentDTO.setInn(Optional.ofNullable(document).map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getInn).orElse(null));
        contragentDTO.setKpp(Optional.ofNullable(document).map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getKpp).orElse(null));
        contragentDTO.setName(Optional.ofNullable(document).map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getName).orElse(null));
        return contragentDTO;
    }

    private static <T> Predicate<T> distinctByKey(
            Function<? super T, ?> keyExtractor) {

        Map<Object, Boolean> docsWithUniquePayeeInn = new HashMap<>();
        return t -> docsWithUniquePayeeInn.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
}
