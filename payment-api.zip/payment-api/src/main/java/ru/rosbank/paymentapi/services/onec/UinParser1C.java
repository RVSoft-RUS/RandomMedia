package ru.rosbank.paymentapi.services.onec;


import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class UinParser1C extends AbstractDocumentFieldParser1C {
    private static final String UIN_KEY = "Код";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.setUin(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, UIN_KEY);
    }
}
