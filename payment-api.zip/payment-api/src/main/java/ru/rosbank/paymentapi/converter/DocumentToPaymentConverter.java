package ru.rosbank.paymentapi.converter;

import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static ru.rosbank.paymentapi.commons.PaymentUtils.formatPaymentPriority;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.fileapp.api.FileAppApi;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.CurrencyControlDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.FileInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.CurrencyControl;
import ru.rosbank.platform.server.paymentapi.model.FileInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentToPaymentConverter {

    private final DocumentTypeCalculatorImpl documentTypeCalculatorImpl;
    private final ReferenceService referenceService;
    private final FileAppApi fileAppApi;
    private final AccountService accountService;
    private static final String BANK_INFO_ERROR = "Произошла техническая ошибка. Не удалось создать платёж. Попробуйте позже.";


    private BankInfo fillBankInfo(BankInfoDTO inputDTO) {
        var bankInfo = new BankInfo();
        bankInfo.setBic(inputDTO.getBic());
        bankInfo.setCorrespondentAccount(inputDTO.getCorrespondentAccount());
        bankInfo.setName(inputDTO.getName());
        return bankInfo;
    }

    private BankInfoDTO fillBankInfo(BankInfo input) {
        var bankInfo = new BankInfoDTO();
        bankInfo.setBic(input.getBic());
        bankInfo.setCorrespondentAccount(input.getCorrespondentAccount());
        bankInfo.setName(input.getName());
        return bankInfo;
    }

    public Payment convert(DocumentDTO documentDTO) {
        var payment = new Payment();
        Optional.ofNullable(documentDTO.getId()).map(String::valueOf).ifPresent(payment::setId);
        payment.setSubtype(Payment.SubtypeEnum.PAYMENT_ASSIGNMENT);
        payment.setNumber(documentDTO.getNumber());
        payment.setExecutionDate(documentDTO.getExecutionDate());

        payment.setPaymentPriority(documentDTO.getPaymentPriority());
        payment.setPayerStatus(documentDTO.getPayerStatus());
        payment.setPaymentBasis(documentDTO.getPaymentBasis());
        payment.setBasisDocumentNumber(documentDTO.getBasisDocumentNumber());
        payment.setBasisDocumentCreated(documentDTO.getBasisDocumentCreated());
        payment.setTaxPeriod(documentDTO.getTaxPeriod());
        payment.setUin(documentDTO.getUin());
        payment.setKbk(documentDTO.getKbk());
        payment.setOktmo(documentDTO.getOktmo());

        if (documentDTO.getShowError() != null && documentDTO.getShowError()) {
            payment.setStatusMessage(documentDTO.getStatusMessage());
        }
        payment.setPurpose(documentDTO.getPurpose());

        // TODO rectification

        payment.setAmount(new Amount().currency("RUB")
                .sum(Optional.ofNullable(documentDTO.getAmount()).map(BigDecimal::new).orElse(null)));

        payment.setCreated(documentDTO.getDate());

        if (documentDTO.getStatus() != null) {
            payment.setStatus(Payment.StatusEnum.fromValue(
                    DocumentStatusConverter.getDocumentStatusDto(documentDTO).name()));
        }

        if (documentDTO.getType() != null) {
            payment.setType(Payment.TypeEnum.fromValue(documentDTO.getType().name()));
        }

        payment.setCodeTypeIncome(documentDTO.getCodeTypeIncome());

        Optional.ofNullable(documentDTO.getTypeTaxPayment()).map(Boolean::parseBoolean).ifPresent(payment::setTaxPaymentType);

        var payer = new Requisite();
        if (documentDTO.getPayer() != null) {
            payer.setAccount(documentDTO.getPayer().getAccount());
            payer.setName(documentDTO.getPayer().getName());
            payer.setInn(documentDTO.getPayer().getInn());
            payer.setKpp(documentDTO.getPayer().getKpp());
            if (documentDTO.getPayer().getBank() != null) {
                payer.setBank(fillBankInfo(documentDTO.getPayer().getBank()));
            }
        }
        payment.setPayer(payer);

        var payee = new Requisite();
        if (documentDTO.getPayee() != null) {
            payee.setAccount(documentDTO.getPayee().getAccount());
            payee.setName(documentDTO.getPayee().getName());
            payee.setInn(documentDTO.getPayee().getInn());
            payee.setKpp(documentDTO.getPayee().getKpp());
            if (documentDTO.getPayee().getBank() != null) {
                payee.setBank(fillBankInfo(documentDTO.getPayee().getBank()));
            }
        }
        payment.setPayee(payee);

        if (documentDTO.getCurrencyControl() != null) {
            CurrencyControl currencyControl = new CurrencyControl();
            currencyControl.setComment(documentDTO.getCurrencyControl().getComment());
            currencyControl.setFullName(documentDTO.getCurrencyControl().getFullName());
            currencyControl.setIsSumContractLess200(documentDTO.getCurrencyControl().getIsSumContractLess200());
            currencyControl.setPhone(documentDTO.getCurrencyControl().getPhone());
            List<FileInfo> fileInfoList = documentDTO.getCurrencyControl().getFileInfo()
                    .stream()
                    .map(fileInfoDTO -> {
                        FileInfo fileInfo = new FileInfo();
                        fileInfo.setId(fileInfoDTO.getId());
                        ru.rosbank.platform.client.fileapp.model.FileInfoDTO fileDTO =
                                fileAppApi.fileIdGet(fileInfoDTO.getId()).getBody();
                        if (fileDTO != null) {
                            fileInfo.setName(fileDTO.getName());
                            fileInfo.setSize(fileDTO.getSize());
                        }
                        return fileInfo;
                    })
                    .collect(Collectors.toList());
            currencyControl.setFileInfo(fileInfoList);
            payment.setCurrencyControl(currencyControl);
        }
        payment.setOrganizationId(documentDTO.getCrmId());
        payment.setEnrollmentDate(documentDTO.getEnrollmentDate());

        return payment;
    }

    public DocumentDTO convertBack(Payment payment, AccountDTO accountDto) {
        var documentDTO = convertBackWithoutId(payment, accountDto);
        if (isNotBlank(payment.getId())) {
            documentDTO.setId(Integer.parseInt(payment.getId()));
        }
        return documentDTO;
    }

    public DocumentDTO convertBackWithoutId(Payment payment, AccountDTO accountDto) {
        var documentDTO = new DocumentDTO();

        documentDTO.setType(documentTypeCalculatorImpl.calculate(payment));
        documentDTO.setPaymentPriority(formatPaymentPriority(payment.getPaymentPriority()));
        documentDTO.setStatus(DocumentStatusDTO.CREATED);
        documentDTO.setNumber(payment.getNumber());
        documentDTO.setBasisDocumentNumber(payment.getBasisDocumentNumber());
        documentDTO.setBasisDocumentCreated(payment.getBasisDocumentCreated());
        documentDTO.setTaxPeriod(payment.getTaxPeriod());
        documentDTO.setUin(payment.getUin());
        documentDTO.setKbk(payment.getKbk());
        documentDTO.setOktmo(payment.getOktmo());
        documentDTO.setPurpose(payment.getPurpose());
        documentDTO.setCodeTypeIncome(payment.getCodeTypeIncome());
        Optional.ofNullable(payment.getTaxPaymentType()).map(String::valueOf).ifPresent(documentDTO::setTypeTaxPayment);
        documentDTO.setPaymentBasis(payment.getPaymentBasis());
        documentDTO.setPayerStatus(payment.getPayerStatus());
        documentDTO.setExecutionDate(payment.getExecutionDate());
        Optional.ofNullable(payment.getAmount()).map(Amount::getSum)
                .map(BigDecimal::toString).ifPresent(documentDTO::setAmount);

        documentDTO.setDate(payment.getCreated());
        documentDTO.setCrmId(payment.getOrganizationId());

        // TODO
        //        document.setUrgent(PaymentOutputModeDto.URGENT.equals((documentDto.getPaymentOutputMode())));
        var payer = new RequisiteDTO();
        if (payment.getPayer() != null) {
            payer.setAccount(payment.getPayer().getAccount());
            payer.setInn(payment.getPayer().getInn());
            payer.setKpp(payment.getPayer().getKpp());
            payer.setName(payment.getPayer().getName());

            if (payment.getPayer().getBank() != null) {
                BankInfoUtil.setBankInfo(payer, payment.getPayer().getAccount(), accountService, referenceService,
                        accountDto);
            }
        }
        documentDTO.setPayer(payer);

        var payee = new RequisiteDTO();
        if (payment.getPayee() != null) {
            payee.setAccount(payment.getPayee().getAccount());
            payee.setInn(payment.getPayee().getInn());
            payee.setKpp(payment.getPayee().getKpp());
            payee.setName(payment.getPayee().getName());

            if (payment.getPayee().getBank() != null) {
                payee.setBank(fillBankInfo(payment.getPayee().getBank()));

                // Заполняем данные банка на основании БИК из справочника
                referenceService.getBankInfo(payee.getBank().getBic()).stream()
                        .filter(bb -> StringUtils.isBlank(payee.getBank().getCorrespondentAccount())
                                || payee.getBank().getCorrespondentAccount().equals(bb.getCorrespondentAccount()))
                        .findFirst()
                        .ifPresent(bankDTO -> {
                            payee.getBank().setCorrespondentAccount(bankDTO.getCorrespondentAccount());
                            payee.getBank().setName(bankDTO.getName());
                        });
            }
        }

        if (payment.getCurrencyControl() != null) {
            CurrencyControlDTO currencyControlDTO = new CurrencyControlDTO();
            currencyControlDTO.setComment(payment.getCurrencyControl().getComment());
            currencyControlDTO.setFullName(payment.getCurrencyControl().getFullName());
            currencyControlDTO.setIsSumContractLess200(payment.getCurrencyControl().getIsSumContractLess200());
            currencyControlDTO.setPhone(payment.getCurrencyControl().getPhone());
            List<FileInfoDTO> fileInfoDTOList = payment.getCurrencyControl().getFileInfo()
                    .stream()
                    .map(fileInfo -> {
                        FileInfoDTO fileInfoDTO = new FileInfoDTO();
                        fileInfoDTO.setId(fileInfo.getId());
                        return fileInfoDTO;
                    })
                    .collect(Collectors.toList());
            currencyControlDTO.setFileInfo(fileInfoDTOList);
            documentDTO.setCurrencyControl(currencyControlDTO);
        }
        documentDTO.setPayee(payee);
        documentDTO.setEnrollmentDate(payment.getEnrollmentDate());

        return documentDTO;
    }

}
