package ru.rosbank.paymentapi.model.feign.refundapi;


/**
 * Валюта возврата.
 */
public enum CurrencyAmountEnum {

    RUB("RUB");

    private String value;

    CurrencyAmountEnum(String value) {
        this.value = value;
    }

}

