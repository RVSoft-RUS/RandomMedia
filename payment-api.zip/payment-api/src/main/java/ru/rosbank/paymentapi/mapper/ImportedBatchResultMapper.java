package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.paymentapp.model.ImportedBatchResultDTO;
import ru.rosbank.platform.server.paymentapi.model.ImportedBatchResult;


@Mapper
public abstract class ImportedBatchResultMapper {

    public static final ImportedBatchResultMapper INSTANCE = Mappers.getMapper(ImportedBatchResultMapper.class);

    public abstract ImportedBatchResult fromDTO(ImportedBatchResultDTO batchDTO);

}
