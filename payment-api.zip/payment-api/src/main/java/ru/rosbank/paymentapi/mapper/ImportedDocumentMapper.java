package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.server.paymentapi.model.ImportedDocument;

@Mapper
public abstract class ImportedDocumentMapper {

    public static final ImportedDocumentMapper INSTANCE = Mappers.getMapper(ImportedDocumentMapper.class);

    public abstract ImportedDocument fromDTO(ImportedDocumentDTO cardDTO);

    public abstract ImportedDocumentDTO toDTO(ImportedDocument cardDTO);
}
