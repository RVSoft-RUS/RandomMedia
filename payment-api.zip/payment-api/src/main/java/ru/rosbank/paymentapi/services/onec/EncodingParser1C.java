package ru.rosbank.paymentapi.services.onec;


import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class EncodingParser1C extends AbstractDocumentFieldParser1C {

    private static final String ENCODING_KEY = "Кодировка";
    private static final String WINDOWS_ENCODING =  "Windows";
    boolean isWindowsEncoding = false;

    public void parseAndSetValue(String line) {
        if (isMatch(line)) {
            isWindowsEncoding = WINDOWS_ENCODING.equals(getValueFromLine(line));
        }
    }

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        // nothing to do
        throw new RuntimeException("Not supported exception");
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, ENCODING_KEY);
    }

    public boolean isWindowsEncoding() {
        return isWindowsEncoding;
    }

}
