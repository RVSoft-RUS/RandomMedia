package ru.rosbank.paymentapi.services.validator;

import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.validator.field.DocumentDateValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentValidator {

    private final DefaultPaymentValidators defaultPaymentValidators;
    private final PayrollPaymentValidators payrollPaymentValidators;
    private final DocumentPayerAccountChecker documentPayerAccountChecker;
    private final ImportedPaymentValidators importedPaymentValidators;
    private final ImportedPayrollPaymentValidators importedPayrollPaymentValidators;
    private final DocumentOrganizationLimitValidator documentOrganizationLimitValidator;
    private final DocumentPayeeAccountValidator documentPayeeAccountValidator;
    private final DocumentDateValidator documentDateValidator;

    public void validate(DocumentDTO documentDTO, Map<String, AccountDTO> clientAccounts) {

        if (DocumentDTO.TypeEnum.DP == documentDTO.getType()) {
            payrollPaymentValidators.validate(documentDTO);
        } else {
            defaultPaymentValidators.validate(documentDTO);
            documentPayeeAccountValidator.validate(documentDTO, clientAccounts);
        }

    }

    public void validatePayerAccountAndOrgLimit(String clientId, List<DocumentDTO> documents, OrganizationDTO org) {

        documentPayerAccountChecker.validate(clientId, org);
        documentOrganizationLimitValidator.validate(org, documents);
    }

    public void validateImportedDoc(DocumentDTO documentDTO, String dboProId, Map<String, AccountDTO> clientAccounts)
            throws ValidationPaymentException {

        documentDateValidator.validate(documentDTO);
        if (DocumentDTO.TypeEnum.DP == documentDTO.getType()) {
            importedPayrollPaymentValidators.validate(documentDTO);
        } else {
            importedPaymentValidators.validate(documentDTO, dboProId);
            documentPayeeAccountValidator.validate(documentDTO, clientAccounts);
        }

    }
}
