package ru.rosbank.paymentapi.services.validator.field;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

import com.fasterxml.jackson.annotation.OptBoolean;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Service
public class DocumentPayerBankValidator {

    @Autowired
    ReferenceService referenceService;

    public void validate(DocumentDTO document, String branch) throws ValidationPaymentException {

        if (Optional.ofNullable(document).map(DocumentDTO::getPayer).map(RequisiteDTO::getBank)
                .filter(b -> isNotBlank(b.getBic()) && isNotBlank(b.getCorrespondentAccount())
                        && isNotBlank(b.getName())).orElse(null) != null) {
            return;
        }
        BranchDTO branchList = referenceService.getBranch(Optional.ofNullable(document).map(DocumentDTO::getBisId)
                .map(BisIdDTO::getBranch).orElse(branch)).stream().findFirst().orElse(null);
        if (branchList == null) {
            return;
        }
        document.setPayer(Optional.ofNullable(document).map(p -> Optional.ofNullable(p.getPayer())
                .orElse(new RequisiteDTO())).get());
        BankInfoDTO payerBank = Optional.ofNullable(document.getPayer()).map(b -> Optional.ofNullable(b.getBank())
                .orElse(new BankInfoDTO())).get();
        if (isBlank(payerBank.getBic())) {
            payerBank.setBic(branchList.getBik());
        }
        if (isBlank(payerBank.getName())) {
            payerBank.setName(branchList.getName());
        }
        if (isBlank(payerBank.getCorrespondentAccount())) {
            payerBank.setCorrespondentAccount(branchList.getCorrespondentAccount());
        }
        document.getPayer().setBank(payerBank);
    }

}
