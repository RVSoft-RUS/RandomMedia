package ru.rosbank.paymentapi.exception;

/**
 * Summary.
 *
 * @author rb066284
 * @since 24.10.2018
 */
public class AccessForbiddenException extends RuntimeException {
    public AccessForbiddenException(String msg) {
        super(msg);
    }
}
