package ru.rosbank.paymentapi.services.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.AvaliableBalanceExcessException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.validator.field.AntifraudBlockValidator;
import ru.rosbank.paymentapi.services.validator.field.DfmBlockValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentDateOnSignValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;


@RequiredArgsConstructor
@Service
@Slf4j
public class DocumentPackageValidator {

    private final DocumentValidator documentValidator;
    private final AntifraudBlockValidator antifraudBlockValidator;
    private final DfmBlockValidator dfmBlockValidator;
    private final DocumentDateOnSignValidator documentDateOnSignValidator;


    public void validate(List<DocumentDTO> documents, ClientDTO user, OrganizationDTO org,
                         Map<String, AccountDTO> accountsMap)
            throws ValidationException, AvaliableBalanceExcessException {

        validateOneAccount(documents);

        documentValidator.validatePayerAccountAndOrgLimit(user.getId(),  documents, org);

        dfmBlockValidator.validate(documents, accountsMap);

        antifraudBlockValidator.validate(user.getDbId());

    }

    public List<DocumentDTO> filterValidDocuments(List<DocumentDTO> documents, Map<String, AccountDTO> clientAccounts) {
        List<DocumentDTO> validDocuments = new ArrayList<>();
        for (DocumentDTO document : documents) {
            try {
                documentValidator.validate(document, clientAccounts);
                documentDateOnSignValidator.validate(document);
                //TODO fixUinOnlyBeforeSendToBis
            } catch (Exception e) {
                if (documents.size() == 1) {
                    throw e;
                }
                log.debug("Invalid document #{}, error = {}", document.getId(), e.getMessage());
                continue;
            }
            if (DocumentStatusDTO.CREATED.equals(document.getStatus())) {
                validDocuments.add(document);
            }
        }
        return validDocuments;
    }

    public static String getPayerAccountFromDocumentPackage(List<DocumentDTO> documents) {
        return documents.stream().findFirst().map(d -> d.getPayer().getAccount()).orElse(null);
    }

    private void validateOneAccount(List<DocumentDTO> documents) throws ValidationException {
        if (documents.stream().map(d -> d.getPayer().getAccount()).collect(Collectors.toSet()).size() != 1) {
            throw new ValidationException("Выберите один счёт, чтобы подписать документы пачкой");
        }
    }
}
