package ru.rosbank.paymentapi.exception;


public class DocumentSignException extends RuntimeException {

    public DocumentSignException(String msg) {
        super(msg);
    }

}
