package ru.rosbank.paymentapi.services.validator;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import ru.rosbank.platform.utils.payment.validators.DocumentProperty;

@ConfigurationProperties("document")
@Component
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DocumentPropertyImpl implements DocumentProperty {
    boolean enable107N6V = false;

    public boolean isEnable107N6V() {
        return enable107N6V;
    }
}
