package ru.rosbank.paymentapi.services.rectification;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static ru.rosbank.paymentapi.commons.Constants.NOT_ENOUGH_RIGHTS_ERROR;
import static ru.rosbank.paymentapi.util.FormatUtils.masqueradePhoneNumber;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.converter.PaymentToPaymentConverter;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.mapper.ClarificationMapper;
import ru.rosbank.paymentapi.mapper.RectificationMapper;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.paymentapi.services.AuditService;
import ru.rosbank.paymentapi.services.ClarificationService;
import ru.rosbank.paymentapi.services.email.DocumentRectificationLetter;
import ru.rosbank.paymentapi.services.email.LocalEmailSender;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.paymentapi.services.integration.StatementService;
import ru.rosbank.paymentapi.services.integration.UserService;
import ru.rosbank.paymentapi.services.rectification.validators.DocumentTypeValidator;
import ru.rosbank.paymentapi.services.rectification.validators.RectificationFieldsValidator;
import ru.rosbank.paymentapi.services.rectification.validators.StatusValidator;
import ru.rosbank.paymentapi.services.rectification.validators.UserRoleValidator;
import ru.rosbank.paymentapi.services.signature.RectificationSigner;
import ru.rosbank.paymentapi.util.DocumentUtils;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Confirmation;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentRectificationService {
    private static final String USER_DOCUMENT_RECTIFICATION = "Запрос на уточнение реквизитов платежа";
    private static final String SYSTEM_SIGN_DOCUMENT_RECTIFICATION_REQUEST =
            "Запрос на подпись документа уточнения реквизитов платежа";
    private final PaymentAppApi paymentAppApi;
    private final StatementService statementService;
    private final StatusValidator statusValidator;
    private final UserRoleValidator userRoleValidator;
    private final DocumentTypeValidator documentTypeValidator;
    private final RectificationFieldsValidator fieldsValidator;
    private final PaymentToPaymentConverter paymentToPaymentConverter;
    private final DocumentToPaymentConverter documentToPaymentConverter;
    private final RectificationSigner rectificationSigner;
    private final UserService userService;
    private final OtpService otpService;
    private final LocalEmailSender localEmailSender;
    private final DocumentRectificationLetter documentRectificationLetter;
    private final AuditService auditService;
    @Qualifier("rectificationExecutorService")
    private final ExecutorService rectificationExecutorService;
    private final ClarificationService clarificationService;
    private final ProductService productService;
    private final AccountService accountService;
    private final ClarificationMapper clarificationMapper;
    @Value("${document.rectification.email}")
    private String[] emailList;
    @Value("${batch.size.rectification: 100}")
    private int batchSize;

    @Value("${batch.size.clarification: 200}")
    private int batchSizeClarification;
    @Value("${rbsp.clarification.enabled}")
    boolean rbspEnabled;

    private static final List<String> NON_VALIDATED_TYPES = List.of("Return", "Confirm");
    private static final HashSet<String> statusesEnabledSet = new HashSet<>();

    static {
        statusesEnabledSet.add("SIGNED");
        statusesEnabledSet.add("PROCESSING");
        statusesEnabledSet.add("SENT_TO_CB");
        statusesEnabledSet.add("ACCEPTED");
        statusesEnabledSet.add("DELIVERED");
        statusesEnabledSet.add("REJECTED");
        statusesEnabledSet.add("REJECTED_CB");
    }

    public Long register(Rectification rectification, String dboProId) {
        auditService.sendEvent(new EventDTO().stage(USER_DOCUMENT_RECTIFICATION).dboProId(dboProId).initiator("USER"));
        var payment = getPayment(rectification.getDocumentId(), dboProId);
        var account = getAccount(payment);
        var organization = getOrganization(dboProId, account);
        var validated = validate(rectification, dboProId, account, organization, payment);
        if (rbspEnabled) {
            return clarificationService.clarificationPost(validated, payment, organization.getCrmId(),
                    account.getBisId(), organization.getInn());
        }
        return Optional.ofNullable(paymentAppApi.documentRectificationPost(
                        RectificationMapper.INSTANCE.toDTO(validated).dboProId(dboProId)).getBody())
                .map(RectificationDTO::getId).orElse(null);
    }

    public boolean isRectificationRequestSigned(Long id) {
        return rectificationSigner.isRectificationRequestSigned(id.toString());
    }

    public void processDocument(Rectification rectification, String dboProId) {

        Payment payment = getPayment(rectification.getDocumentId(), dboProId);

        if (rbspEnabled) {
            clarificationService.clarificationExecute(rectification);
        } else {
            sendRectificationLetter(rectification, payment, emailList);
            paymentAppApi.documentRectificationIdExecutePost(rectification.getId());
        }
    }

    public Rectification getRegistryRequest(Long id) {
        if (rbspEnabled) {
            return clarificationService.rectificationGet(id);
        }
        return RectificationMapper.INSTANCE.fromDTO(paymentAppApi.documentRectificationGet(id, null).getBody());
    }

    public boolean isRectificationRequestAccessible(Rectification rectification) {
        if (rbspEnabled) {
            return true;
        }
        RectificationDTO rectificationTemp = Optional.ofNullable(paymentAppApi.documentRectificationGet(null,
                        DocumentUtils.toPaymentBisId(rectification.getDocumentId()))).map(ResponseEntity::getBody)
                .orElse(null);
        return rectificationTemp == null;
    }


    Payment getPayment(String bisDocumentId, String dboProId) throws ValidationException {

        Payment payment = null;
        try {
            PaymentDTO documentDto = statementService.getPayment(dboProId, bisDocumentId);
            if (documentDto != null) {
                validatePaymentAssignmentOnly(documentDto);
                payment = paymentToPaymentConverter.convert(documentDto);
            }
        } catch (Exception e) {
            log.info(e.getMessage(), e);
        }

        if (payment == null) {
            // Get document from statement.
            payment = Optional.ofNullable(paymentAppApi.refferenceIdGet(DocumentUtils.toPaymentBisId(bisDocumentId)))
                    .map(ResponseEntity::getBody).map(documentToPaymentConverter::convert)
                    .orElseThrow(() -> new ValidationException("Платеж не найден"));
        }

        return payment;
    }

    private void validatePaymentAssignmentOnly(PaymentDTO documentDto) throws ValidationException {
        if (!PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT.equals(documentDto.getSubtype())) {
            throw new ValidationException("Уточнение доступно только для документа с типом платёжное поручение");
        }
    }

    private Rectification validate(Rectification rectification, String dboProId, AccountDTO account,
                                   OrganizationDTO organization, Payment payment) {

        // Validate document status.
        statusValidator.validate(payment);
        // Validate user role.
        userRoleValidator.validate(dboProId, account, organization);
        // Validate document type.
        documentTypeValidator.validate(payment);
        // Validate fields value difference
        if (rectification.getType() == null || !NON_VALIDATED_TYPES.contains(rectification.getType())) {
            fieldsValidator.validate(rectification, payment, account);
        }


        return rectification;
    }

    private void sendRectificationLetter(Rectification rectification,
                                         Payment payment,
                                         String[] emailList) {

        localEmailSender.sendMimeEmail(emailList,
                documentRectificationLetter.buildHtmlMessage(rectification, payment),
                documentRectificationLetter.buildPlainTextMessage(rectification, payment),
                "Уточнение по платежу " + payment.getPayer().getName() + " сч. " + payment.getPayer().getAccount(),
                Collections.emptyList(), Collections.emptyList());


    }


    public Confirmation signCertificateRequest(Rectification rectification, String dboProId) throws Exception {
        auditService.sendEvent(new EventDTO().stage(SYSTEM_SIGN_DOCUMENT_RECTIFICATION_REQUEST).dboProId(dboProId)
                .initiator("USER"));
        var user = userService.getUser(dboProId);
        Payment payment = getPayment(rectification.getDocumentId(), dboProId);
        OtpDTO otp = rectificationSigner.sign(user, rectification, payment);
        if (otp == null) {
            throw new Exception("Не удалось подписать документ");
        }
        return new Confirmation().id(otp.getId()).attempts(otp.getAttempts()).type(Confirmation.TypeEnum.SMS)
                .message(masqueradePhoneNumber(user.getPhone())).expiresIn(otpService.getExpireMilliSeconds(otp)
                        .intValue());
    }

    public Map<String, List<Rectification>> getActiveDocumentRectificationsByDocumentsId(List<String> ids) {

        List<Rectification> fromPayments = getActiveDocumentRectificationsByDocumentsIdFromPayment(ids);

        List<Rectification> fromClarifications = getActiveDocumentRectificationsByDocumentsIdsFromClarification(ids);
        Map<String, Rectification> fromClarificationsMap = new HashMap<>();
        fromClarifications.forEach(r -> fromClarificationsMap.put(r.getDocumentId(), r));
        List<Rectification> rectifications = new ArrayList<>();
        rectifications.addAll(fromClarifications);
        rectifications.addAll(fromPayments.stream().filter(r -> !fromClarificationsMap.containsKey(r.getDocumentId()))
                .collect(Collectors.toList()));
        Map<String, List<Rectification>> result = new HashMap<>();
        rectifications.forEach(r -> {
            var docRec = result.get(r.getDocumentId());
            if (docRec == null) {
                docRec = new ArrayList<>();
                result.put(r.getDocumentId(), docRec);
            }
            docRec.add(r);
        });

        return result;
    }

    public List<Rectification> getActiveDocumentRectificationsByDocumentsIdFromPayment(List<String> ids) {
        if (CollectionUtils.isNotEmpty(ids)) {
            try {
                List<CompletableFuture<List<RectificationDTO>>> futures = new ArrayList<>();

                // Разбиваем список идентификаторов на батчи
                List<List<String>> batches = ListUtils.partition(ids, batchSize);

                // Для каждого батча создаем CompletableFuture для выполнения запроса
                for (List<String> batch : batches) {
                    CompletableFuture<List<RectificationDTO>> future = CompletableFuture.supplyAsync(() -> {
                        try {
                            return paymentAppApi.documentRectificationBatchGet(batch).getBody();
                        } catch (RuntimeException e) {
                            log.error("Error executing batch request: {}", e.getMessage(), e);
                            return Collections.emptyList();
                        }
                    }, rectificationExecutorService);
                    futures.add(future);
                }

                // Дожидаемся завершения всех CompletableFuture и объединяем результаты
                List<RectificationDTO> rectificationDTOS = futures.stream()
                        .flatMap(future -> future.join().stream())
                        .collect(Collectors.toList());

                if (CollectionUtils.isNotEmpty(rectificationDTOS)) {
                    return rectificationDTOS
                            .stream().filter(r -> RectificationDTO.StatusEnum.ACTIVE.equals(r.getStatus()))
                            .map(RectificationMapper.INSTANCE::fromDTO).peek(r -> r.setStatus("SENT_TO_CB"))
                            .collect(Collectors.toList());
                }
            } catch (Exception e) {
                log.error("Error getActiveDocumentRectificationsByDocumentsId message: " + e.getMessage(), e);
            }
        }
        return Collections.emptyList();
    }

    public List<Rectification> getActiveDocumentRectificationsByDocumentsIdsFromClarification(List<String> ids) {
        if (CollectionUtils.isNotEmpty(ids)) {
            try {
                List<CompletableFuture<List<Clarification>>> futures = new ArrayList<>();

                // Разбиваем список идентификаторов на батчи
                List<List<String>> batches = ListUtils.partition(ids, batchSizeClarification);

                // Загрузка уточнений из clarification-api
                // Для каждого батча создаем CompletableFuture для выполнения запроса
                for (List<String> batch : batches) {
                    CompletableFuture<List<Clarification>> future = CompletableFuture.supplyAsync(() -> {
                        try {
                            return clarificationService.clarificationFiltered(batch);
                        } catch (Exception e) {
                            log.error("Error executing batch request: {}", e.getMessage(), e);
                            return Collections.emptyList();
                        }
                    }, rectificationExecutorService);
                    futures.add(future);
                }

                // Дожидаемся завершения всех CompletableFuture и объединяем результаты
                List<Clarification> rectificationDTOS = futures.stream()
                        .flatMap(future -> future.join().stream())
                        .collect(Collectors.toList());

                if (CollectionUtils.isNotEmpty(rectificationDTOS)) {
                    return rectificationDTOS
                            .stream()
                            .map(clarificationMapper::toRectification)
                            .collect(Collectors.toList());
                }
            } catch (Exception e) {
                log.error("Error getActiveDocumentRectificationsByDocumentsId message: " + e.getMessage(), e);
            }
        }
        return Collections.emptyList();
    }

    private AccountDTO getAccount(Payment payment) {
        String accountNumber20 = Optional.ofNullable(payment).map(Payment::getPayer).map(Requisite::getAccount)
                .orElse(null);
        if (isBlank(accountNumber20)) {
            throw new ValidationPaymentException(NOT_ENOUGH_RIGHTS_ERROR);
        }
        return accountService.getAccount(accountNumber20);
    }

    private OrganizationDTO getOrganization(String dboProId, AccountDTO accountNumber) {
        return productService.getOrganizationByAccAndDboProId(dboProId, accountNumber)
                .orElseThrow(() -> new ValidationException(NOT_ENOUGH_RIGHTS_ERROR));
    }

    public List<Rectification> getRectificationsByPaymentId(Map<String, List<Rectification>> rectificationMap, Payment payment) {
        String paymentId = payment.getId();
        if (StringUtils.isBlank(paymentId) || rectificationMap == null) {
            return null;
        }

        List<Rectification> rectificationList = rectificationMap.get(paymentId);
        if (CollectionUtils.isEmpty(rectificationList)) {
            String replaceBisId = DocumentUtils.replaceBisId(paymentId);
            rectificationList = rectificationMap.get(replaceBisId);
        }
        if (CollectionUtils.isEmpty(rectificationList)) {
            return null;
        }
        rectificationList.sort(Comparator.comparing(Rectification::getCreated).reversed());
        return rectificationList;
    }

    public Rectification getRectificationByRectifications(List<Rectification> rectifications) {
        if (CollectionUtils.isEmpty(rectifications)) {
            return null;
        }
        return rectifications.stream().filter(r ->
                statusesEnabledSet.contains(r.getStatus()))
                .max(Comparator.comparing(Rectification::getCreated)).orElse(null);
    }
}
