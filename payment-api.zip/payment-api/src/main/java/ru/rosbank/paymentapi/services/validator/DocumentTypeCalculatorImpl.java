package ru.rosbank.paymentapi.services.validator;

import static ru.rosbank.paymentapi.commons.PaymentUtils.BIC_TUPE_UTRA_ACC;
import static ru.rosbank.paymentapi.commons.PaymentUtils.getPayeeAccount;
import static ru.rosbank.paymentapi.commons.PaymentUtils.getPayeeBankBic;
import static ru.rosbank.paymentapi.commons.PaymentUtils.getPayeeBankCorrespondentAccount;
import static ru.rosbank.paymentapi.commons.PaymentUtils.isBudgetBic;
import static ru.rosbank.paymentapi.services.validator.field.ImportedPayrollPayeeAccountValidator.PAYROLL_PAYEE_ACCOUNT_20;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.commons.PaymentUtils;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.utils.payment.validators.AccountMasksForTransactionTypes;
import ru.rosbank.platform.utils.payment.validators.DocumentTypeCalculator;

@Service
public class DocumentTypeCalculatorImpl implements AccountMasksForTransactionTypes, DocumentTypeCalculator {

    @Autowired
    private ReferenceService referenceService;

    @Override
    public DocumentDTO.TypeEnum calculate(DocumentDTO documentDto) {
        if (DocumentDTO.TypeEnum.DP.equals(documentDto.getType())) {
            return DocumentDTO.TypeEnum.DP;
        }
        String payerInn = Optional.ofNullable(documentDto).map(DocumentDTO::getPayer).map(RequisiteDTO::getInn).orElse(null);
        String payeeInn = Optional.ofNullable(documentDto).map(DocumentDTO::getPayee).map(RequisiteDTO::getInn).orElse(null);

        return calculate(payerInn, payeeInn, getPayeeAccount(documentDto), getPayeeBankBic(documentDto),
                getPayeeBankCorrespondentAccount(documentDto));
    }

    public DocumentDTO.TypeEnum calculate(Payment payment) {
        if (Payment.TypeEnum.DP.equals(payment.getType())) {
            return DocumentDTO.TypeEnum.DP;
        }
        String payerInn = Optional.ofNullable(payment).map(Payment::getPayer).map(Requisite::getInn).orElse(null);
        String payeeInn = Optional.ofNullable(payment).map(Payment::getPayee).map(Requisite::getInn).orElse(null);
        return calculate(payerInn, payeeInn, Optional.ofNullable(payment.getPayee()).map(Requisite::getAccount).orElse(""),
                Optional.ofNullable(payment.getPayee()).map(Requisite::getBank).map(BankInfo::getBic).orElse(null),
                Optional.ofNullable(payment.getPayee()).map(Requisite::getBank).map(BankInfo::getCorrespondentAccount)
                        .orElse(null));
    }

    public DocumentDTO.TypeEnum calculate(String payerInn, String payeeInn, String payeeAccount, String bic,
                                          String correspondentAccount) {
        boolean toMyself = payerInn != null && payerInn.equals(payeeInn);
        if (toMyself && !matchPatternList(payeeAccount, DEPOSIT_MASK)) {
            return DocumentDTO.TypeEnum.DG;
        }
        if (isBudgetBic(bic, payeeAccount) || isBudgetSecondCondition(bic, payeeAccount, correspondentAccount)) {
            return DocumentDTO.TypeEnum.DE;
        }
        if (matchPatternList(payeeAccount, D_COUNTERPARTY_MASK)) {
            return DocumentDTO.TypeEnum.DA;
        }
        if (matchPatternList(payeeAccount, D_PERSONAL_MASK)) {
            return DocumentDTO.TypeEnum.DB;
        }
        if (toMyself && matchPatternList(payeeAccount, DEPOSIT_MASK)) {
            return DocumentDTO.TypeEnum.DC;
        }
        if (matchPatternList(payeeAccount, D_BANKSERVICE_MASK)) {
            return DocumentDTO.TypeEnum.DD;
        }
        return DocumentDTO.TypeEnum.DF;
    }

    public boolean isBudgetSecondCondition(String bic, String account, String correspondentAccount) {
        if (StringUtils.isBlank(bic) || StringUtils.isBlank(correspondentAccount) || StringUtils.isBlank(account)) {
            return false;
        }
        return isBicTypeUtra(bic) && account.startsWith("0") && account.length() == 20
                && correspondentAccount.startsWith(PaymentUtils.PREFIX_COR_ACCOUNT_UTRA);
    }

    public boolean matchPatternList(String account, List<String> patternList) {
        for (String pattern : patternList) {
            if (account.startsWith(pattern)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isBudget(DocumentDTO documentDTO) {
        return DocumentDTO.TypeEnum.DE.name().equals(calculate(documentDTO).name());
    }

    @Override
    public boolean isCounterparty(DocumentDTO documentDTO) {
        return DocumentDTO.TypeEnum.DA.name().equals(calculate(documentDTO).name());
    }

    @Override
    public String getAccountType(DocumentDTO documentDTO) {
        return null;
    }

    public boolean isBicTypeUtra(String bic) {
        return referenceService.getBankInfo(bic).stream().findFirst()
                .map(bank -> BIC_TUPE_UTRA_ACC.contains(bank.getBikType()))
                .orElse(false);
    }

    public DocumentDTO.TypeEnum calculateForImportedDoc(DocumentDTO documentDto) {
        String payeeAccount = Optional.ofNullable(documentDto)
                .map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getAccount).orElse("");
        String payeeInn = Optional.ofNullable(documentDto)
                .map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getInn).orElse("");


        if (("".equals(payeeAccount) || PAYROLL_PAYEE_ACCOUNT_20.equals(payeeAccount))
                && referenceService.isRosbankInn(payeeInn)) {
            return DocumentDTO.TypeEnum.DP;
        }

        return calculate(documentDto);
    }

}
