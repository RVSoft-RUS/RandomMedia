package ru.rosbank.paymentapi.services;

public class DocumentUpdateStatusService {


}
