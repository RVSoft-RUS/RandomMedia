package ru.rosbank.paymentapi.commons;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

/**
 * Summary.
 *
 * @author rb068869
 */
public class PaymentUtils {
    private static final int PAYMENT_PRIORITY_MAX_LENGTH = 1;
    private static final List<String> BUDGET_ACCOUNT_PREFIX_WITHOUT_DIGIT_CHECK = List.of("40204");
    private static final List<Map.Entry<String, String>> BUDGET_ACCOUNT_DIGIT_MAP =
            List.of(new AbstractMap.SimpleEntry<>("40503", "4"),
                    new AbstractMap.SimpleEntry<>("40603", "4"),
                    new AbstractMap.SimpleEntry<>("40703", "4"));

    public static final Collection<String> ESB_ERROR_CODES_SHOW_IN_DOCUMENT = Collections.unmodifiableCollection(
            Arrays.asList("0108", "0001")
    );

    public static final Collection<String> STATUSES_AFTER_SIGNING = Collections.unmodifiableCollection(
            Arrays.asList("SIGNED", "PROCESSING", "COMPLETED", "PLANNED")
    );

    public static final Collection<String> BIC_ENDING_TRSA_ACC = Collections.unmodifiableCollection(
            Arrays.asList("000", "001", "002")
    );

    public static final String PREFIX_COR_ACCOUNT_UTRA = "40102";

    public static final Collection<String> BIC_TUPE_UTRA_ACC = Collections.unmodifiableCollection(
            Arrays.asList("51", "52")
    );


    public static String getPayeeAccount(DocumentDTO documentDto) {
        return Optional.ofNullable(documentDto)
                .map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getAccount)
                .orElse("");
    }

    public static String getPayeeAccount(Payment payment) {
        return Optional.ofNullable(payment)
                .map(Payment::getPayee)
                .map(Requisite::getAccount)
                .orElse("");
    }

    public static String getPayeeBankBic(DocumentDTO documentDto) {
        return Optional.ofNullable(documentDto)
                .map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getBank)
                .map(BankInfoDTO::getBic)
                .orElse("");
    }

    public static String getPayeeBankBic(Payment payment) {
        return Optional.ofNullable(payment)
                .map(Payment::getPayee)
                .map(Requisite::getBank)
                .map(BankInfo::getBic)
                .orElse("");
    }

    public static String getPayeeBankCorrespondentAccount(DocumentDTO documentDto) {
        return Optional.ofNullable(documentDto)
                .map(DocumentDTO::getPayee)
                .map(RequisiteDTO::getBank)
                .map(BankInfoDTO::getCorrespondentAccount)
                .orElse("");
    }

    public static boolean isRejectedOrRecalled(DocumentDTO documentDTO) {
        return DocumentStatusDTO.RECALLED.equals(documentDTO.getStatus())
                || DocumentStatusDTO.REJECTED.equals(documentDTO.getStatus());
    }

    public static boolean isSentToBank(DocumentDTO documentDTO) {
        return DocumentStatusDTO.SIGNED.equals(documentDTO.getStatus())
                || DocumentStatusDTO.DFM_PROCESSING.equals(documentDTO.getStatus())
                || DocumentStatusDTO.PLANNED.equals(documentDTO.getStatus());
    }

    public static boolean isReceivedByBank(DocumentDTO documentDTO) {
        return DocumentStatusDTO.SENT_TO_BIS.equals(documentDTO.getStatus());
    }

    public static boolean isPartialAccept(PaymentDTO documentDto) {
        return documentDto.getContent() != null && documentDto.getContent().equals("ЧА");
    }

    //
    //    public static boolean isPartialAccept(AbstractDocumentDto documentDto) {
    //        if (documentDto instanceof PaymentOrderDocumentDto) {
    //            return !(((PaymentOrderDocumentDto) documentDto).getDocumentContent() != null
    //                && ((PaymentOrderDocumentDto) documentDto).getDocumentContent().equals("ЧА"));
    //        } else {
    //            return false;
    //        }
    //    }
    //
    //    public static String getPaymentType(PaymentOutputModeDto paymentOutputModeDto) {
    //        switch (paymentOutputModeDto) {
    //            case URGENT:
    //                return "Срочно";
    //            default:
    //                return "";
    //        }
    //    }
    //

    /**
     * Списание.
     *
     * @param documentDto dto
     * @return
     */
    public static boolean isDebit(PaymentDTO documentDto) {
        return documentDto.getType() != null && documentDto.getType().name() != null
                && isDebit(documentDto.getType().name());
    }

    public static boolean isDebit(String type) {

        return type != null && type.startsWith("D");
    }

    public static boolean isDebitForType(Payment.TypeEnum type) {
        return type != null && type.name() != null
                && isDebit(type.name());
    }

    public static boolean isCredit(PaymentDTO paymentDTO) {
        return paymentDTO.getType() != null && paymentDTO.getType().name().startsWith("C");
    }

    //
    //    public static String getDocOwnerAccount(AbstractDocumentDto document) {
    //
    //        String ret = "";
    //        if (Constants.OUTCOME_PAYMENT_DTO.contains(document.getType())) {
    //            ret = document.getPayer().getAccount();
    //        } else if (Constants.INCOME.contains(document.getType())) {
    //            ret = document.getPayee().getAccount();
    //        }
    //
    //        return ret;
    //    }
    //
    //    public static boolean isBudgetAccount(Document document) {
    //        return isBudgetAccount(document.getPayeeAccount());
    //    }
    //
    //    public static boolean isBudgetAccount(AbstractDocumentDto documentDto) {
    //        return isBudgetAccount(getPayeeAccount(documentDto));
    //    }
    //
    public static boolean isBudgetAccount(String accountNumber) {

        var accountPrefix = accountNumber.substring(0, 5);

        if (BUDGET_ACCOUNT_PREFIX_WITHOUT_DIGIT_CHECK.contains(accountPrefix)) {
            return true;
        }

        List<Map.Entry<String, String>> accountDigitPairs = BUDGET_ACCOUNT_DIGIT_MAP
                .stream()
                .filter(accountDigitPair -> accountDigitPair.getKey().equals(accountPrefix))
                .collect(Collectors.toList());

        return accountDigitPairs.stream()
                .anyMatch(accountDigitPair -> accountDigitPair.getValue().equals(accountNumber.substring(13, 14)));
    }

    public static boolean isBudgetBic(String bic, String accountNumber) {
        if (isBlank(bic) || isBlank(accountNumber) || accountNumber.length() < 20) {
            return false;
        }

        return BIC_ENDING_TRSA_ACC.stream().filter(bic::endsWith)
                .count() == 1 && isBudgetAccount(accountNumber);
    }

    //    public static boolean isBudget(Document document) {
    //        DocumentTypeCalculator documentTypeCalculator = new DocumentTypeCalculator();
    //        String documentType = documentTypeCalculator.calculate(document).name();
    //        return DocumentTypeDto.DE.name().equals(documentType);
    //    }
    //
    //    public static boolean isCounterparty(Document document) {
    //        DocumentTypeCalculator documentTypeCalculator = new DocumentTypeCalculator();
    //        String documentType = documentTypeCalculator.calculate(document).name();
    //        return DocumentTypeDto.DA.name().equals(documentType);
    //    }


    //    public static String getDocumentTypeText(String paymentType) {
    //        if (StringUtils.isBlank(paymentType)) {
    //            return DocumentTypes.PAYMENT_ASSIGNMENT.getText();
    //        }
    //        switch (paymentType) {
    //            case OPERATION_TYPE_PAYMENT_ORDER:
    //                return DocumentTypes.PAYMENT_ORDER.getText();
    //            case OPERATION_TYPE_BANK_ORDER:
    //                return DocumentTypes.BANK_ORDER.getText();
    //            case OPERATION_TYPE_PAYMENT_ASSIGNMENT:
    //                return DocumentTypes.PAYMENT_ASSIGNMENT.getText();
    //            case OPERATION_TYPE_COLLECTION_ASSIGNMENT:
    //                return DocumentTypes.COLLECTION_ASSIGNMENT.getText();
    //            case OPERATION_TYPE_MEMORIAL_ORDER:
    //                return DocumentTypes.MEMORIAL_ORDER.getText();
    //            case OPERATION_TYPE_PAYMENT_BILL:
    //                return DocumentTypes.PAYMENT_BILL.getText();
    //            case OPERATION_TYPE_ACCOUNT_CASH_WARRANT:
    //                return DocumentTypes.ACCOUNT_CASH_WARRANT.getText();
    //            case OPERATION_TYPE_CASH_RECEIPT_ORDER:
    //                return DocumentTypes.CASH_RECEIPT_ORDER.getText();
    //            default:
    //                return DocumentTypes.PAYMENT_ASSIGNMENT.getText();
    //        }
    //    }

    public static Boolean isCompleted(PaymentDTO paymentDTO) {
        return paymentDTO.getCompleted() != null;
    }

    public static String getPaymentType(PaymentDTO paymentDTO) {
        if (paymentDTO.getPaymentOutputMode() == PaymentDTO.PaymentOutputModeEnum.URGENT) {
            return "Срочно";
        }
        return "";
    }

    public static String formatPaymentPriority(String paymentPriority) {
        String truncatedPaymentPriority = Optional
                .ofNullable(StringUtils
                        .right(paymentPriority, PAYMENT_PRIORITY_MAX_LENGTH))
                .orElse("");
        if (Constants.getPaymentPriorityDirectory()
                .containsKey(truncatedPaymentPriority)) {
            return truncatedPaymentPriority;
        } else {
            return ((TreeMap<String, String>) Constants.getPaymentPriorityDirectory()).lastKey();
        }
    }
    //
    //    public static String getPayerAccountFromDocumentPackage(List<Document> documents) {
    //        return documents.stream().findFirst().map(Document::getPayerAccount).orElse(null);
    //    }
    //
    //    public static AbstractDocumentDto stringToDocument(String base64) {
    //        try {
    //            JAXBContext context = JAXBContext.newInstance(AbstractDocumentDto.class);
    //            StringReader reader = new StringReader(new String(Base64.getDecoder().decode(base64)));
    //            return (AbstractDocumentDto) context.createUnmarshaller().unmarshal(reader);
    //        } catch (Exception e) {
    //            return null;
    //        }
    //    }

}
