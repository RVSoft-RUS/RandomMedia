package ru.rosbank.paymentapi.util;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocumentUtils {

    public static String toPaymentBisId(String bisId) {
        if (bisId.startsWith("Y01")) {
            String changedBisId = bisId.replace("Y01", "PP");
            changedBisId = changedBisId.substring(0, 8) + "-" + changedBisId.substring(8);
            return changedBisId;
        }
        return bisId;
    }

    public static String replaceBisId(String bisId) {
        String changedBisId;
        if (bisId.startsWith("Y01")) {
            changedBisId = bisId.replace("Y01", "PP");
            changedBisId = changedBisId.substring(0, 8) + "-" + changedBisId.substring(8);
            return changedBisId;
        }
        if (bisId.startsWith("PP")) {
            changedBisId = bisId.replace("PP", "Y01");
            changedBisId = changedBisId.replace("-", "");
            return changedBisId;
        }
        return bisId;
    }
}
