package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.rosbank.platform.client.auditapp.model.PaymentEventDTO;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

@Mapper(componentModel = "spring")
public interface PaymentEventMapper {

    @Mapping(target = "date", source = "signDate")
    @Mapping(target = "bisData", source = "bisId")
    PaymentEventDTO toPaymentEvent(DocumentDTO document);

    ru.rosbank.platform.client.auditapp.model.RequisiteDTO toEventRequisite(RequisiteDTO requisite);

    ru.rosbank.platform.client.auditapp.model.BankInfoDTO toBankInfo(BankInfoDTO bankInfo);

    ru.rosbank.platform.client.auditapp.model.BisDataDTO toBisData(BisIdDTO bisId);

}
