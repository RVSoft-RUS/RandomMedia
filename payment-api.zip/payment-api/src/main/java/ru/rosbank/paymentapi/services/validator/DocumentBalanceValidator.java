package ru.rosbank.paymentapi.services.validator;

import java.math.BigDecimal;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;


/**
 * Summary.
 * @author rb068774
 */

@Slf4j
public class DocumentBalanceValidator {


    public static boolean validateBalance(List<DocumentDTO> documents, AccountDTO account)  {
        BigDecimal documentsAmount = BigDecimal.ZERO;

        for (DocumentDTO document : documents) {
            documentsAmount = documentsAmount.add(new BigDecimal(document.getAmount()));
        }
        BigDecimal accountBalance = (account == null || account.getRestAmount() == null ? null
                : new BigDecimal(account.getRestAmount()));
        return accountBalance != null && accountBalance.compareTo(documentsAmount) >= 0;
    }

}