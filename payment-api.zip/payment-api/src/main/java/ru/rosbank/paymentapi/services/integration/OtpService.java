package ru.rosbank.paymentapi.services.integration;

import feign.FeignException;
import java.time.OffsetDateTime;
import javax.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.platform.client.otpapp.api.OtpAppApi;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.otpapp.model.OtpTemplateDTO;

@Slf4j
@RequiredArgsConstructor
@Service
public class OtpService {

    private static final String OPERATION_TYPE_PACKAGE_SIGNATURE = "PACKAGE_SIGNATURE";

    private final HttpSession session;
    private final OtpAppApi otpAppApi;

    @Value("${auth.otp.code.duration}")
    private long codeDuration;

    public OtpDTO generatePackageSignatureOtp(String ref, String phoneNumber) {
        return createOtp(ref, phoneNumber);
    }

    private OtpDTO createOtp(String reference, String phone) {

        OtpDTO otp = new OtpDTO()
            .phone(phone)
            .reference(reference)
            .type(OPERATION_TYPE_PACKAGE_SIGNATURE)
            .sessionId(session.getId())
            .template(new OtpTemplateDTO().type(OtpService.OPERATION_TYPE_PACKAGE_SIGNATURE));
        try {
            otp = otpAppApi.rootPost(otp).getBody();
        } catch (FeignException e) {
            log.error("Ошибка создания otp {} ", reference, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        return otp;
    }

    public Long getExpireMilliSeconds(OtpDTO otp) {
        return (codeDuration - (OffsetDateTime.now().toEpochSecond() - otp.getCreated().toEpochSecond()));
    }

    public OtpDTO getOtpByUUID(String uuid) {
        try {
            return otpAppApi.idGet(uuid).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения otp {} ", uuid, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
    }

}
