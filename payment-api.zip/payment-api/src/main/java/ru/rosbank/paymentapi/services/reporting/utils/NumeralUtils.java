package ru.rosbank.paymentapi.services.reporting.utils;

/**
 * Класс содержаший вспомогательные методы.
 *
 * @author Q-YAA
 */
public class NumeralUtils {

    /**
     * Создаёт из переданного числа блоки строк по 3 символа.
     *
     * @param number число
     * @return String[] группы блоков по 3 символа
     */
    public static String[] numberToBlocks(String number) {
        // Дополняем число слева нулями если это необходимо
        // 1 234 567 -> 001 234 567
        while (number.length() % 3 != 0) {
            number = "0" + number;
        }

        return number.split("(?<=\\G.{3})");
    }
}
