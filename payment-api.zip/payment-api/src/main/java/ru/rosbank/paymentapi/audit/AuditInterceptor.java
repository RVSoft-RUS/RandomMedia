package ru.rosbank.paymentapi.audit;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.stereotype.Component;

@Component
public class AuditInterceptor implements RequestInterceptor {

    public static final String IP = "ip";
    public static final String DEVICE_ID = "device-id";
    public static final String PLATFORM = "platform";
    public static final String MACADDRESS = "macaddress";
    public static final String SESSION_ID = "session-id";
    public static final String USER_AGENT = "User-Agent";
    public static final String APP_VERSION = "app-version";
    public static final String COMPANY_INN = "company-inn";
    public static final String BIS_COMPANY_ID = "bis-company-id";
    public static final String CRM_COMPANY_ID = "crm-company-id";

    @Override
    public void apply(RequestTemplate template) {
        AuditContext context = ThreadLocalAuditContext.get();
        template.header(IP, context.getIp());
        template.header(DEVICE_ID, context.getDeviceId());
        template.header(PLATFORM, context.getPlatform());
        template.header(MACADDRESS, context.getMacAddress());
        template.header(SESSION_ID, context.getSessionId());
        template.header(USER_AGENT, context.getUserAgent());
        template.header(APP_VERSION, context.getApplicationVersion());
        template.header(COMPANY_INN, context.getCompanyInn());
        template.header(BIS_COMPANY_ID, context.getBisCompanyId());
        template.header(CRM_COMPANY_ID, context.getCrmCompanyId());
    }
}
