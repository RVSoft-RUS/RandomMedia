package ru.rosbank.paymentapi.exception;

public class ValidationDocumentOrgLimitException extends RuntimeException {

    public ValidationDocumentOrgLimitException(String msg) {
        super(msg);
    }

    public ValidationDocumentOrgLimitException(String msg, Throwable t) {
        super(msg, t);
    }

}
