package ru.rosbank.paymentapi.services.reporting;

import freemarker.template.TemplateException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Optional;
import java.util.StringJoiner;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import ru.rosbank.paymentapi.commons.PaymentUtils;
import ru.rosbank.paymentapi.exception.UnknownDocumentException;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.FileResource;

@Slf4j
@Service
@RequiredArgsConstructor
public class StatementFormService {
    private static DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public FileResource generate(PaymentDTO paymentDTO, String format) throws TemplateException, IOException {
        var fileResource = new FileResource();
        String template = getTemplate(paymentDTO);
        if ("html".equals(format)) {
            fileResource.setContent(new String(Base64.getEncoder().encode(
                    generateHtmlForm(paymentDTO, template))));
            fileResource.setContentType(FileResource.ContentTypeEnum.HTML);
            fileResource.setName(getPaymentName(paymentDTO) + ".html");
        } else if ("pdf".equals(format)) {
            fileResource.setContent(new String(Base64.getEncoder().encode(
                    generatePdfForm(paymentDTO, template).toByteArray())));
            fileResource.setContentType(FileResource.ContentTypeEnum.PDF);
            fileResource.setName(getPaymentName(paymentDTO) + ".pdf");
        } else {
            throw new UnknownDocumentException("Wrong format = " + format);
        }
        fileResource.setId(paymentDTO.getId());

        return fileResource;
    }

    static String getPaymentName(PaymentDTO paymentDTO) {
        StringJoiner stringJoiner = new StringJoiner(" ");
        return stringJoiner
                .add(StringUtils.defaultString(paymentDTO.getNumber()))
                .add(Optional.ofNullable(paymentDTO.getCompleted()).map(c -> c.format(DATE_TIME_FORMATTER)).orElse(""))
                .add(Optional.ofNullable(paymentDTO.getAmount())
                        .map(AmountDTO::getSum)
                        .map(BigDecimal::toString)
                        .map(a -> a.replace(".", ",")).orElse(""))
                .toString();


    }

    public byte[] generateHtmlForm(PaymentDTO paymentDTO, String template) throws TemplateException, IOException {
        var configurationFactoryBean = new FreeMarkerConfigurationFactoryBean();
        configurationFactoryBean.setPreferFileSystemAccess(false);
        configurationFactoryBean.setDefaultEncoding("UTF-8");

        StatementFormGenerator reportService = new StatementFormGenerator(configurationFactoryBean.createConfiguration());
        return reportService.generateHtml(paymentDTO, template).getBytes(StandardCharsets.UTF_8);
    }

    public ByteArrayOutputStream generatePdfForm(PaymentDTO paymentDTO, String template) throws TemplateException, IOException {
        var configurationFactoryBean = new FreeMarkerConfigurationFactoryBean();
        configurationFactoryBean.setPreferFileSystemAccess(false);
        configurationFactoryBean.setDefaultEncoding("UTF-8");

        StatementFormGenerator reportService = new StatementFormGenerator(configurationFactoryBean.createConfiguration());
        return (ByteArrayOutputStream) reportService.generatePdf(paymentDTO, template);
    }

    public String getTemplate(PaymentDTO paymentDTO) {
        if (PaymentDTO.SubtypeEnum.PAYMENT_ORDER.equals(paymentDTO.getSubtype())) {
            return "paymentOrder.html.ftl";
        } else if (PaymentDTO.SubtypeEnum.PAYMENT_ASSIGNMENT.equals(paymentDTO.getSubtype())) {
            if (StringUtils.isNotBlank(paymentDTO.getCardPan())) {
                return "cardOperation.html.ftl";
            } else {
                return "paymentAssignment.html.ftl";
            }
        } else if (PaymentDTO.SubtypeEnum.BANK_ORDER.equals(paymentDTO.getSubtype())) {
            return "bankingOrder.html.ftl";
        } else if (PaymentDTO.SubtypeEnum.MEMORIAL_ORDER.equals(paymentDTO.getSubtype())) {
            return "memorialOrder.html.ftl";
        } else if (PaymentDTO.SubtypeEnum.PAYMENT_BILL.equals(paymentDTO.getSubtype())) {
            if (PaymentUtils.isCredit(paymentDTO)) {
                return "paymentRequestCredit.html.ftl";
            } else {
                return "paymentRequestDebit.html.ftl";
            }
        } else if (PaymentDTO.SubtypeEnum.COLLECTION_ASSIGNMENT.equals(paymentDTO.getSubtype())) {
            if (PaymentUtils.isCredit(paymentDTO)) {
                return "collectionOrderCredit.html.ftl";
            } else {
                return "collectionOrderDebit.html.ftl";
            }
        } else {
            throw new UnknownDocumentException("Для документа с типом "
                    + paymentDTO.getSubtype().name() + " не предусмотрена печатная форма.");
        }
    }


}
