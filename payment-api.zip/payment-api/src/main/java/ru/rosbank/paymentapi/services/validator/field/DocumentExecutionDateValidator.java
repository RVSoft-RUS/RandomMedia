package ru.rosbank.paymentapi.services.validator.field;

import java.time.OffsetDateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.reporting.utils.FormatUtils;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;


/**
 * Summary.
 * @author rb067368
 *      16.09.2020
 */

@Service
public class DocumentExecutionDateValidator {

    @Value("${document.execution_date.futurePeriod:31}")
    private Integer futureDocumentListPeriod;

    private static final String DATE_IS_NOT_AFTER = "Дата исполнения платежа не должна быть позднее ";
    private static final String DATE_IS_NOT_BEFORE = "Дата исполнения платежа не может быть раньше текущей даты";

    public void validate(DocumentDTO document) throws ValidationException {
        OffsetDateTime dateIn31Days = OffsetDateTime.now().plusDays(futureDocumentListPeriod);
        if (document.getExecutionDate().isAfter(dateIn31Days)) {
            throw new ValidationException(DATE_IS_NOT_AFTER + FormatUtils.formatDate(dateIn31Days));
        }
        if (document.getExecutionDate().toLocalDateTime().isBefore(document.getDate().toLocalDate().atStartOfDay())) {
            throw new ValidationException(DATE_IS_NOT_BEFORE);
        }
    }
}
