package ru.rosbank.paymentapi.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.ImportDocumentException;
import ru.rosbank.paymentapi.services.onec.AbstractDocumentFieldParser1C;
import ru.rosbank.paymentapi.services.onec.AmountParser1C;
import ru.rosbank.paymentapi.services.onec.CodeTypeIncomeParser1C;
import ru.rosbank.paymentapi.services.onec.DocumentDateParser1C;
import ru.rosbank.paymentapi.services.onec.DocumentEndParser1C;
import ru.rosbank.paymentapi.services.onec.DocumentNumberParser1C;
import ru.rosbank.paymentapi.services.onec.DocumentStartParser1C;
import ru.rosbank.paymentapi.services.onec.DocumentTypeCodeParser1C;
import ru.rosbank.paymentapi.services.onec.EncodingParser1C;
import ru.rosbank.paymentapi.services.onec.EndOfFileParser1C;
import ru.rosbank.paymentapi.services.onec.PayeeAccountParser1C;
import ru.rosbank.paymentapi.services.onec.PayeeBankBicParser1C;
import ru.rosbank.paymentapi.services.onec.PayeeBankNameParser1C;
import ru.rosbank.paymentapi.services.onec.PayeeCorrAccountParser1C;
import ru.rosbank.paymentapi.services.onec.PayeeInnParser1C;
import ru.rosbank.paymentapi.services.onec.PayeeKppParser1C;
import ru.rosbank.paymentapi.services.onec.PayeeNameParser1C;
import ru.rosbank.paymentapi.services.onec.PayerAccountParser1C;
import ru.rosbank.paymentapi.services.onec.PayerBankBicParser1C;
import ru.rosbank.paymentapi.services.onec.PayerBankNameParser1C;
import ru.rosbank.paymentapi.services.onec.PayerCorrAccountParser1C;
import ru.rosbank.paymentapi.services.onec.PayerInnParser1C;
import ru.rosbank.paymentapi.services.onec.PayerKppParser1C;
import ru.rosbank.paymentapi.services.onec.PayerNameParser1C;
import ru.rosbank.paymentapi.services.onec.PaymentPriorityParser1C;
import ru.rosbank.paymentapi.services.onec.PurposeParser1C;
import ru.rosbank.paymentapi.services.onec.TypeTaxPaymentParser1C;
import ru.rosbank.paymentapi.services.onec.UinParser1C;
import ru.rosbank.paymentapi.services.onec.budget.BasisDocDateParser1C;
import ru.rosbank.paymentapi.services.onec.budget.BasisDocNumberParser1C;
import ru.rosbank.paymentapi.services.onec.budget.KbkParser1C;
import ru.rosbank.paymentapi.services.onec.budget.OktmoParser1C;
import ru.rosbank.paymentapi.services.onec.budget.PayerStatusParser1C;
import ru.rosbank.paymentapi.services.onec.budget.PaymentBasisParser1C;
import ru.rosbank.paymentapi.services.onec.budget.TaxPeriodParser1C;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;


/**
 * Summary.
 * @author rb068869
 */
@Service
@Slf4j
public class DocumentParserService {

    public static final String ENCODING_WINDOWS_1251 = "Cp1251";
    public static final List<String> SPACE_CHARACTERS = Collections.unmodifiableList(
            Arrays.asList("\n", "\r")
    );
    public static final String IMPORT_DOCUMENT_ERROR_MESSAGE = "Ошибка при обработке документа";
    public static final String IMPORT_DOCUMENT_ENCODING_ERROR_MESSAGE =
            "Неверная кодировка файла! Пожалуйста, для загрузки платежей используйте файлы в кодировке Windows1251.";

    private static final List<AbstractDocumentFieldParser1C> FIELD_PARSERS = Collections.unmodifiableList(
        Arrays.asList(
            new DocumentStartParser1C(),

            new DocumentNumberParser1C(),
            new DocumentDateParser1C(),
            new PayerAccountParser1C(),
            new PayerNameParser1C(),
            new PayerInnParser1C(),
            new PayerKppParser1C(),
            new PayerCorrAccountParser1C(),
            new PayerBankNameParser1C(),
            new PayerBankBicParser1C(),

            new PayeeAccountParser1C(),
            new PayeeBankBicParser1C(),
            new PayeeBankNameParser1C(),
            new PayeeCorrAccountParser1C(),
            new PayeeInnParser1C(),
            new PayeeKppParser1C(),
            new PayeeNameParser1C(),

            new AmountParser1C(),
            new DocumentTypeCodeParser1C(),
            new PaymentPriorityParser1C(),
            new PurposeParser1C(),
            new UinParser1C(),

            new KbkParser1C(),
            new OktmoParser1C(),
            new TaxPeriodParser1C(),
            new PaymentBasisParser1C(),
            new BasisDocDateParser1C(),
            new BasisDocNumberParser1C(),
            new PayerStatusParser1C(),

            new DocumentEndParser1C(),
            new EndOfFileParser1C(),
            new TypeTaxPaymentParser1C(),
            new CodeTypeIncomeParser1C()
        ));


    public List<DocumentDTO> parseDocumentsTxt(byte[] content) throws ImportDocumentException {
        try {
            String fileContent = new String(content, ENCODING_WINDOWS_1251);

            List<String> lines = Arrays.stream(fileContent.split(String.join("|", SPACE_CHARACTERS)))
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.toList());

            List<DocumentDTO> parsedDocs = new ArrayList<>();
            DocumentDTO document = new DocumentDTO();

            EncodingParser1C encodingParser1C = new EncodingParser1C();
            for (String currentLine : lines) {
                for (AbstractDocumentFieldParser1C parser1C : FIELD_PARSERS) {
                    parser1C.parseAndSetValue(currentLine, document);
                }
                if (currentLine.startsWith(DocumentEndParser1C.getDocumentEndKey())) {
                    parsedDocs.add(document);
                    document = new DocumentDTO();
                }
                encodingParser1C.parseAndSetValue(currentLine);
            }
            if (parsedDocs.isEmpty()) {
                if (!encodingParser1C.isWindowsEncoding() && lines.size() > 3) {
                    throw new ImportDocumentException(IMPORT_DOCUMENT_ENCODING_ERROR_MESSAGE);
                } else {
                    throw new ImportDocumentException(IMPORT_DOCUMENT_ERROR_MESSAGE);
                }
            }
            return parsedDocs;

        } catch (IOException | NullPointerException e) {
            log.info("Parsing 1C document failed successfully {}", e.getMessage());
            throw new ImportDocumentException(IMPORT_DOCUMENT_ERROR_MESSAGE);
        }

    }
}
