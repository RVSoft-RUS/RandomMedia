package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.statementapp.model.AmountDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;

@Mapper
public abstract class AmountMapper {

    public static final AmountMapper INSTANCE = Mappers.getMapper(AmountMapper.class);

    public abstract Amount fromDTO(AmountDTO amount);

}
