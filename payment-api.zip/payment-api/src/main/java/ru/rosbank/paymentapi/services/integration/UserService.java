package ru.rosbank.paymentapi.services.integration;

import feign.FeignException;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.userapp.api.UserAppApi;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserAppApi userAppApi;

    public ClientDTO getUser(String id) {

        try {
            return Optional.ofNullable(userAppApi.userGet(id, null, null, null, null))
                    .map(ResponseEntity::getBody)
                    .orElse(null);
        } catch (FeignException e) {
            log.error("Ошибка получения списка пользователя user-app {}", id, e);
            return null;
        }

    }

}
