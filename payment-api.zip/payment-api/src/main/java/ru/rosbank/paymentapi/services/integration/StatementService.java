package ru.rosbank.paymentapi.services.integration;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import feign.FeignException;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.statementapp.api.StatementAppApi;
import ru.rosbank.platform.client.statementapp.model.AccountStatementDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class StatementService {

    private static final int PAYMENT_NOT_FOUND_STATUS = 404;
    private final StatementAppApi statementAppApi;

    @HystrixCommand(commandKey = "getStatementList")
    public List<PaymentDTO> getStatementList(String accountNumber, String branch, OffsetDateTime from, OffsetDateTime to,
                                             String clientId) {
        return Optional.ofNullable(statementAppApi
                        .accountStatementOnlineGet(accountNumber, branch, from, to, clientId, null))
                .map(ResponseEntity::getBody)
                .map(AccountStatementDTO::getOperations)
                .orElse(Collections.emptyList());
    }

    public List<PaymentDTO> getCardStatementList(String cardNumber, OffsetDateTime from, OffsetDateTime to,
                                             String clientId) {
        try {
            return Optional.ofNullable(statementAppApi.cardStatementOnlineGet(cardNumber, from, to, clientId))
                    .map(ResponseEntity::getBody)
                    .orElse(Collections.emptyList());
        } catch (FeignException e) {
            log.error("Ошибка получения списка карточных транзакций {}", cardNumber, e);
            return Collections.emptyList();
        }

    }

    public PaymentDTO getPayment(String clientId, String paymentId) {
        try {
            return Optional.ofNullable(statementAppApi.documentDboProIdIdGet(clientId, paymentId))
                    .map(ResponseEntity::getBody)
                    .orElse(null);
        } catch (FeignException e) {
            if (e.status() == PAYMENT_NOT_FOUND_STATUS) {
                log.info("Платеж не найден в кэше выписки statement-app {}", paymentId, e);
            } else {
                log.info("Ошибка получения платежа statement-app {}", paymentId, e);
            }
        }
        return null;
    }

    public PaymentDTO getCardTransaction(String clientId, String transactionId) {
        try {
            return Optional.ofNullable(statementAppApi.cardTransactionsDboProIdIdGet(transactionId, clientId))
                    .map(ResponseEntity::getBody)
                    .orElse(null);
        } catch (FeignException e) {
            if (e.status() == PAYMENT_NOT_FOUND_STATUS) {
                log.info("Платеж не найден в кэше выписки statement-app {}", transactionId, e);
            } else {
                log.error("Ошибка получения платежа statement-app {}", transactionId, e);
            }
            return null;
        }
    }
}
