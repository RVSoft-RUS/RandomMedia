package ru.rosbank.paymentapi.services.validator.field;

import static org.apache.commons.lang3.BooleanUtils.isFalse;
import static org.apache.commons.lang3.StringUtils.isNumeric;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

/**
 * Summary.
 * Field 3
 */
@Service
public class DocumentNumberValidator implements IDocumentValidator {
    private static final int FIELD_ID = 3;
    private static final String FIELD_NAME = "number";
    private static final String ERROR_MESSAGE_COUNT_OF_CHARS = "Максимум 6 символов. Для ввода доступны только цифры";
    private static final String ERROR_MESSAGE_ZEROS = "Все цифры не могут быть нулями";
    private static final String ERROR_MESSAGE_ONE_ZERO = "Номер не может быть \"0\"";
    private static final String ERROR_MESSAGE_EMPTY = "Заполните поле";

    public void validate(DocumentDTO document) {
        String number = document.getNumber();

        if (StringUtils.isBlank(number)) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, ERROR_MESSAGE_EMPTY);
        }

        if (number.equals("0")) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, ERROR_MESSAGE_ONE_ZERO);
        }

        if (StringUtils.containsOnly(number, "0")) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, ERROR_MESSAGE_ZEROS);
        }

        if (isFalse(isNumeric(number)) || number.length() > 6) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, ERROR_MESSAGE_COUNT_OF_CHARS);
        }
    }

}
