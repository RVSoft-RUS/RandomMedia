package ru.rosbank.paymentapi.services.onec;


import java.util.Optional;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

/**
 * Summary.
 * @author rb068869
 */
public class PayerKppParser1C extends AbstractDocumentFieldParser1C {
    private static final String PAYER_KPP_KEY = "ПлательщикКПП";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.payer(Optional.ofNullable(document).map(DocumentDTO::getPayer).orElse(new RequisiteDTO())).getPayer()
                    .setKpp(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, PAYER_KPP_KEY);
    }
}
