package ru.rosbank.paymentapi.exception;


public class PaymentNotRevertibleException extends RuntimeException {

    public PaymentNotRevertibleException(String msg) {
        super(msg);
    }

}
