package ru.rosbank.paymentapi.model.feign.qrpaymentapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Информация о получателе по покупке СБП (ЮЛ).
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentPayeeDto {

    private String name;
    private String accountNumber;
    private String inn;
    private String merchantId;
    private String legalId;

}

