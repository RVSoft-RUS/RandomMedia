package ru.rosbank.paymentapi.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.paymentapi.exception.DuplicateTemplateNameException;
import ru.rosbank.paymentapi.mapper.TemplateMapper;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApi;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.ErrorDTO;
import ru.rosbank.platform.client.paymentapp.model.TemplateDTO;
import ru.rosbank.platform.server.paymentapi.model.Page;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Template;

@Slf4j
@Service
@RequiredArgsConstructor
public class TemplateService {
    private final PaymentAppApi paymentAppApi;
    private final TemplateMapper templateMapper;
    public static final String USER_REQUEST_CREATE_TEMPLATE = "Запрос на создание шаблона";
    public static final String USER_REQUEST_SAVE_TEMPLATE = "Запрос на сохранение шаблона";
    public static final String USER_REQUEST_DELETE_TEMPLATE = "Запрос на удаление шаблона";
    public static final String USER_INITIATOR = "USER";
    public static final String ENP_TEMPLATE_ID = "ENP";
    public static final String FTS_TEMPLATE_ID = "FTS";
    private static final Integer DEFAULT_OFFSET = 0;
    private static final Integer DEFAULT_COUNT = 10;

    public List<Template> search(String query, String dboProId) {

        ResponseEntity<List<TemplateDTO>> responseEntity = paymentAppApi.templateSearchGet(dboProId, query, null);
        if (responseEntity != null && responseEntity.getBody() != null) {
            return responseEntity.getBody()
                    .stream()
                    .map(templateMapper::fromDTO)
                    .map(t -> t.dateCreated(null).dboProId(null).status(null)).collect(Collectors.toList());
        } else {
            log.error("Empty templateSearchGet");
            return new ArrayList<>();
        }
    }

    public Template createTemplateFromDocument(Payment payment, String name, String dboProId) {
        var templateDTO = templateMapper.paymentToTemplateDTO(payment);
        templateDTO.setId(null);
        templateDTO.setDboProId(dboProId);
        templateDTO.setName(name);
        try {
            ResponseEntity<TemplateDTO> responseEntity = paymentAppApi.templatePost(templateDTO);

            return Optional.ofNullable(responseEntity).map(ResponseEntity::getBody).map(body -> {
                if (responseEntity.getStatusCode().is2xxSuccessful()) {
                    return templateMapper.fromDTO(responseEntity.getBody());
                } else {
                    log.error("Status code: {}, body: {}", responseEntity.getStatusCodeValue(), responseEntity.getBody());
                    throw new BackendException("Template error");
                }
            }).orElseThrow(() -> {
                log.error("Empty paymentAppApi.templatePost");
                return new BackendException("Empty paymentAppApi.templatePost");
            });
        } catch (FeignException e) {
            throwDuplicateTemplateNameException(e);
        }
        return null;
    }

    public Template saveTemplate(Template template, String dboProId) {
        var templateDto = templateMapper.toDTO(template);
        templateDto.setDboProId(dboProId);
        try {
            ResponseEntity<TemplateDTO> responseEntity = paymentAppApi.templateIdPost(template.getId(), templateDto);

            return Optional.ofNullable(responseEntity).map(ResponseEntity::getBody).map(body -> {
                if (responseEntity.getStatusCode().is2xxSuccessful()) {
                    return templateMapper.fromDTO(responseEntity.getBody());
                } else {
                    log.error("Status code: {}, body: {}", responseEntity.getStatusCodeValue(), responseEntity.getBody());
                    throw new BackendException("Template error");
                }
            }).orElseThrow(() -> {
                log.error("Empty paymentAppApi.saveTemplate");
                throw new BackendException("Empty paymentAppApi.saveTemplate");
            });
        } catch (FeignException e) {
            throwDuplicateTemplateNameException(e);
        }
        return null;
    }

    public void deleteTemplate(String templateId, String dboProId) {
        paymentAppApi.templateIdDelete(templateId, dboProId);
    }

    private void throwDuplicateTemplateNameException(FeignException e) {
        log.error(e.getMessage());
        ErrorDTO errorDTO;
        try {
            errorDTO = new ObjectMapper().readValue(e.contentUTF8(), ErrorDTO.class);
        } catch (JsonProcessingException jsonProcessingException) {
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        if (ErrorDTO.TypeEnum.VALIDATION_ERROR.equals(errorDTO.getType())) {
            throw new DuplicateTemplateNameException(errorDTO.getMessage());
        }
        if (ErrorDTO.TypeEnum.UNEXPECTED.equals(errorDTO.getType())) {
            throw new BackendException(errorDTO.getMessage());
        }
    }

    public List<Template> getPage(List<Template> templates, Page page) {
        if (page == null) {
            page = new Page().offset(DEFAULT_OFFSET).count(DEFAULT_COUNT);
        }
        if (templates.size() <= page.getOffset()) {
            return new LinkedList<>();
        }
        return templates.subList(page.getOffset(), Math.min(page.getOffset() + page.getCount(), templates.size()));
    }

    public Long getLastPage(List<Template> templates, Page page) {
        if (page == null) {
            page = new Page().offset(DEFAULT_OFFSET).count(DEFAULT_COUNT);
        }
        if (templates == null) {
            return 0L;
        }
        return (long)Math.ceil((double) templates.size() / page.getCount());
    }

    public Template getTemplateENP() {
        return paymentAppApi.templateGet(ENP_TEMPLATE_ID, "1", DEFAULT_OFFSET.toString(), null).getBody()
                .stream()
                .findFirst()
                .map(templateMapper::fromDTO)
                .orElseThrow(() -> new RuntimeException("Unable to find any ENP template"));
    }

    public Template getTemplateFTS() {
        return paymentAppApi.templateGet(FTS_TEMPLATE_ID, "1", DEFAULT_OFFSET.toString(), null).getBody()
                .stream()
                .findFirst()
                .map(templateMapper::fromDTO)
                .orElseThrow(() -> new RuntimeException("Unable to find any FTS template"));
    }

    public void apiTemplateIdIncrementPost(String id, String dboProId) {
        boolean isPresent = Optional.ofNullable(paymentAppApi.templateIdGet(id, dboProId)).map(ResponseEntity::getBody)
                .isPresent();
        if (isPresent) {
            paymentAppApi.templateIdIncrementPost(id);
        }
    }
}
