package ru.rosbank.paymentapi.converter;

import ru.rosbank.paymentapi.mapper.PaymentOutputModeMapper;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class CollectionAssignmentConverter {
    public static Payment convert(PaymentDTO input) {
        Payment document = new Payment();
        document.setSubtype(Payment.SubtypeEnum.COLLECTION_ASSIGNMENT);
        BaseConverter.convert(document, input);

        // Очерёдность платежа
        document.setPaymentPriority(input.getPaymentPriority());
        // Дата поступления в банк плательщика
        document.setIncomingDate(input.getIncomingDate());

        document.setUin(input.getUin());
        document.setKbk(input.getKbk());
        document.setOktmo(input.getOktmo());
        document.setPaymentBasis(input.getPaymentBasis());
        document.setTaxPeriod(input.getTaxPeriod());
        document.setBasisDocumentNumber(input.getBasisDocumentNumber());
        document.setBasisDocumentCreated(input.getBasisDocumentCreated());

        // Статус плательщика
        document.setPayerStatus(input.getPayerStatus());

        // Дата помещения в картотеку
        document.setPlaceInFileDate(input.getPlaceInFileDate());

        return document;
    }

}
