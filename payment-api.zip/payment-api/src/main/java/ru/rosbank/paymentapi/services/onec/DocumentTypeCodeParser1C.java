package ru.rosbank.paymentapi.services.onec;




import static ru.rosbank.platform.utils.payment.validators.DocumentUtils.OPERATION_TYPE_PAYMENT_ASSIGNMENT;

import ru.rosbank.paymentapi.exception.ImportDocumentException;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class DocumentTypeCodeParser1C extends AbstractDocumentFieldParser1C {
    private static final String DOCUMENT_TYPE_CODE_KEY = "ВидОплаты";
    private static final String PAYMENT_ASSIGNMENT_ONLY_ERROR = "Загрузка документов возможна только с типом Платежное поручение";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) throws ImportDocumentException {
        if (isMatch(line)) {
            validate(getValueFromLine(line));
        }
    }

    public boolean validate(String value) throws ImportDocumentException {
        if (OPERATION_TYPE_PAYMENT_ASSIGNMENT.equals(value)) {
            return true;
        } else {
            throw new ImportDocumentException(PAYMENT_ASSIGNMENT_ONLY_ERROR);
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, DOCUMENT_TYPE_CODE_KEY);
    }
}
