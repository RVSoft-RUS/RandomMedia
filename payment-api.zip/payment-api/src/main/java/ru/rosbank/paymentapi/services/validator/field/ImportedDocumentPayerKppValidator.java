package ru.rosbank.paymentapi.services.validator.field;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.validator.DocumentPropertyImpl;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentProperty;


/*
 * Field 102
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ImportedDocumentPayerKppValidator {
    private static final String ERROR_MESSAGE = "102: Введите 9 символов";
    private final OrganizationService organizationService;
    private final DocumentPayerKppValidator documentPayerKppValidator;



    public void validate(DocumentDTO document, String dboProId) {

        String payerKpp = Optional.ofNullable(document).map(DocumentDTO::getPayer).map(RequisiteDTO::getKpp).orElse("");
        String payerInn = Optional.ofNullable(document)
                .map(DocumentDTO::getPayer).map(RequisiteDTO::getInn).orElse("");
        if (StringUtils.isBlank(payerKpp)
                && payerInn.length() == 10) {
            Optional.ofNullable(document).map(DocumentDTO::getPayer).orElse(new RequisiteDTO())
                    .setKpp(getKpp(payerInn, dboProId));
            return;
        }

        documentPayerKppValidator.validate(document);
    }

    String getKpp(String inn, String dboProId) {
        try {
            List<OrganizationDTO> organizationList = organizationService.getOrganizations(dboProId);
            Optional<OrganizationDTO> oorganization = organizationList.stream()
                    .filter(organization -> organization.getInn().equals(inn))
                    .findFirst();
            return oorganization.map(OrganizationDTO::getKpp).orElseThrow(() -> new ValidationException(ERROR_MESSAGE));
        } catch (Exception e) {
            throw new ValidationException(ERROR_MESSAGE);
        }
    }

}
