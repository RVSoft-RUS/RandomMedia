package ru.rosbank.paymentapi.services.integration;

import static java.util.Objects.requireNonNull;

import feign.FeignException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.mapper.BisIdMapper;
import ru.rosbank.platform.client.accountapp.api.AccountAppApiClient;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.accountapp.model.AccountsCachedResponseDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.utils.async.mdc.MdcAwareExecutors;

@Slf4j
@Service
public class AccountService {

    // TODO: дублируется в account-api
    @Value("${esb.bis.account.typesToShow}")
    private String[] esbBisAccountTypesToShow;

    @Value("${getAccounts.timeout:15}")
    private int accountsTimeOut;

    private final AccountAppApiClient accountAppApi;
    private final BisIdMapper bisIdMapper;
    private final ExecutorService executorService;

    @Autowired
    public AccountService(AccountAppApiClient accountAppApi,  BisIdMapper bisIdMapper,
                          @Value("${getAccounts.pool.size:10}") int accountPoolSize) {
        this.accountAppApi = accountAppApi;
        this.bisIdMapper = bisIdMapper;
        this.executorService = MdcAwareExecutors.newMdcAwareFixedThreadPool(accountPoolSize);
    }

    public AccountDTO getAccount(String accountNumber20) {
        try {
            return accountAppApi.idGet(accountNumber20).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения счета = {}", accountNumber20, e);
            return null;
        }
    }

    public List<AccountDTO> getAccountList(String bisId, String branchId) {
        try {
            return accountAppApi.rootGet(bisId, branchId).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения списка счетов по BisID/BranchId {}/{}", bisId, branchId, e);
            return Collections.emptyList();
        }
    }

    public List<AccountDTO> getAccountList(String crmId, List<BisIdDTO> bisIdDTO) {
        try {
            return Objects.requireNonNull(accountAppApi.organizationAccountsGet(crmId,
                            bisIdMapper.organizationListToAccountList(bisIdDTO), false)
                    .getBody()).getAccounts();
        } catch (Exception e) {
            log.error("Ошибка получения списка счетов {}:{}", crmId, bisIdDTO, e);
            return Collections.emptyList();
        }
    }

    // TODO: похожая фильтрация есть в account-api
    public List<AccountDTO> getCustomerAccountListEsb(OrganizationDTO organization) {
        return getAccountList(organization.getCrmId(), organization.getBisIds())
                .stream()
                .filter(acc -> Arrays.asList(esbBisAccountTypesToShow).contains(acc.getAccountType()))
                .collect(Collectors.toList());
    }

    public List<AccountDTO> getAccountsAsync(List<OrganizationDTO> orgList) {

        List<CompletableFuture<List<AccountDTO>>> accountsLoadTasks = new ArrayList<>(orgList.size());
        for (OrganizationDTO organizationDTO : orgList) {
            try {
                CompletableFuture<List<AccountDTO>> accountsLoadFuture = getOrgAccountsAsync(organizationDTO, true);
                accountsLoadTasks.add(accountsLoadFuture);
            } catch (Exception e) {
                log.error("Ошибка получения списка счетов {}", organizationDTO.getCrmId(), e);
            }
        }
        return accountsLoadTasks.stream().map(CompletableFuture::join).flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    public Map<String, List<AccountDTO>> getMapCrmIdAndAccountsAsync(List<OrganizationDTO> orgList) {

        List<CompletableFuture<Pair<String, List<AccountDTO>>>> accountsLoadTasks = new ArrayList<>(orgList.size());
        for (OrganizationDTO organizationDTO : orgList) {
            CompletableFuture<Pair<String, List<AccountDTO>>> accountsLoadFuture
                    = getOrgCrmAndAccountsAsync(organizationDTO, true);
            accountsLoadTasks.add(accountsLoadFuture);
        }
        Map<String, List<AccountDTO>> accountsMapCrmId = new HashMap<>();
        accountsLoadTasks.stream().map(CompletableFuture::join).forEach(p -> accountsMapCrmId.put(p.getLeft(), p.getRight()));
        return accountsMapCrmId;
    }

    public CompletableFuture<List<AccountDTO>> getOrgAccountsAsync(
                OrganizationDTO organization,
                Boolean requiredActualData) {
        return CompletableFuture.supplyAsync(() -> getOrgAccounts(organization, requiredActualData).getAccounts(),
                executorService)
                .orTimeout(accountsTimeOut, TimeUnit.SECONDS)
                .exceptionally(e -> {
                    log.error("Failed to load account cached response, organizationId:{}", organization.getCrmId(), e);
                    throw new CompletionException(e);
                });
    }

    public CompletableFuture<Pair<String,List<AccountDTO>>> getOrgCrmAndAccountsAsync(
            OrganizationDTO organization,
            Boolean requiredActualData) {
        return CompletableFuture.supplyAsync(() -> Pair.of(organization.getCrmId(),
                getOrgAccounts(organization, requiredActualData).getAccounts()), executorService)
                .orTimeout(accountsTimeOut, TimeUnit.SECONDS)
                .exceptionally(e -> {
                    log.error("Failed to load account cached response, organizationId:{}", organization.getCrmId(), e);
                    throw new CompletionException(e);
                });
    }

    public Boolean restrictionCdtGet(String branch, String account20) {
        return accountAppApi.restrictionCdtGet(branch, account20).getBody();
    }

    private AccountsCachedResponseDTO getOrgAccounts(OrganizationDTO organizationDTO, Boolean requiredActualData) {
        AccountsCachedResponseDTO accountsCachedResponse;
        log.debug("Start getOrgAccounts for: {}, requiredActualData: {}",
                organizationDTO.getCrmId(), requiredActualData);

        accountsCachedResponse = requireNonNull(accountAppApi.organizationAccountsGet(organizationDTO.getCrmId(),
                organizationDTO.getBisIds().stream().map(bisIdMapper::organizationToAccount)
                        .collect(Collectors.toList()), requiredActualData)
                .getBody());

        log.debug("Stop getOrgAccounts for: {}, requiredActualData: {}",
                organizationDTO.getCrmId(), requiredActualData);
        return accountsCachedResponse;
    }
}
