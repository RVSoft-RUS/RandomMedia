package ru.rosbank.paymentapi.converter;

import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class CashReceiptOrderConverter {
    public static Payment convert(PaymentDTO input) {
        Payment document = new Payment();
        document.setSubtype(Payment.SubtypeEnum.CASH_RECEIPT_ORDER);
        BaseConverter.convert(document, input);

        // Дата валютирования
        document.setValueDate(input.getValueDate());
        // Составитель (не заполняется ?)
        /*
        if (po.getOrderStamp() != null && po.getOrderStamp().getSignerList() != null &&
                po.getOrderStamp().getSignerList().getSigner() != null) {
            document
                    .setOrderStampSinger(po.getOrderStamp().getSignerList().getSigner().getPosition());
        }
        */

        // Содержание
        document.setContent(input.getContent());

        document.setOrderStampSinger(input.getOrderStampSinger());

        document.setItmTransId(input.getItmTransId());
        return document;
    }
}
