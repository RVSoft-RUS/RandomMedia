package ru.rosbank.paymentapi.services.validator;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.validator.field.DocumentAmountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentNumberValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankBicValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayeeBankCorrAccountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentTypeTaxPaymentValidator;
import ru.rosbank.paymentapi.services.validator.field.ImportedDocumentPayerKppValidator;
import ru.rosbank.paymentapi.services.validator.field.ImportedDocumentPayerNameValidator;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentBasisDocumentNumberValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentCodeTypeIncomeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentKbkValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentOktmoValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayPriorityValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeInnValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeNameValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerAccountValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerStatusValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisCreatedValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPurposeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentTaxPeriodValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentUinCode22Validator;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Slf4j
@Service
@RequiredArgsConstructor
public class ImportedPaymentValidators {

    private final List<IDocumentValidator> importedValidators;
    ImportedDocumentPayerKppValidator importedDocumentPayerKppValidator;

    @Autowired
    ImportedPaymentValidators(
            ImportedDocumentPayerNameValidator documentPayerNameValidator,
            DocumentPayeeBankBicValidator documentPayeeBankBicValidator,
            DocumentPayerAccountValidator documentPayerAccountValidator,
            DocumentPaymentBasisValidator documentPaymentBasisValidator,
            DocumentPayeeBankCorrAccountValidator documentPayeeBankCorrAccountValidator,
            DocumentPayPriorityValidator documentPayPriorityValidator,
            DocumentNumberValidator documentNumberValidator,
            DocumentUinCode22Validator documentUinCode22Validator,
            DocumentPayeeInnValidator documentPayeeInnValidator,
            DocumentPayeeKppValidator documentPayeeKppValidator,
            ImportedDocumentPayerKppValidator documentPayerKppValidator,
            DocumentPayeeNameValidator documentPayeeNameValidator,
            DocumentAmountValidator documentAmountValidator,
            DocumentKbkValidator documentKbkValidator,
            DocumentOktmoValidator documentOktmoValidator,
            DocumentPurposeValidator documentPurposeValidator,
            DocumentBasisDocumentNumberValidator documentBasisDocumentNumberValidator,
            DocumentPayerStatusValidator documentPayerStatusValidator,
            DocumentTaxPeriodValidator documentTaxPeriodValidator,
            DocumentPaymentBasisCreatedValidator documentPaymentBasisCreatedValidator,
            DocumentCodeTypeIncomeValidator documentCodeTypeIncomeValidator,
            DocumentTypeTaxPaymentValidator documentTypeTaxPaymentValidator
    ) {
        importedValidators = List.of(
                documentPayerNameValidator,//
                documentPurposeValidator,
                documentPayeeNameValidator,
                documentUinCode22Validator,//

                documentNumberValidator,//

                documentPayerAccountValidator,
                documentPayeeBankBicValidator,
                documentBasisDocumentNumberValidator,
                documentPaymentBasisValidator,
                documentPaymentBasisCreatedValidator,
                documentPayPriorityValidator,
                documentTaxPeriodValidator,
                documentKbkValidator,
                documentOktmoValidator,
                documentPayeeInnValidator,
                documentPayeeKppValidator,
                documentPayerStatusValidator,
                documentPayeeBankCorrAccountValidator,
                documentCodeTypeIncomeValidator,
                documentTypeTaxPaymentValidator,
                documentAmountValidator
        );
        importedDocumentPayerKppValidator = documentPayerKppValidator;
    }

    public void validate(DocumentDTO documentDTO, String dboProId)
            throws ValidationPaymentException {
        // Желательно должен находиться в верху списка
        importedDocumentPayerKppValidator.validate(documentDTO, dboProId);
        for (IDocumentValidator validator : importedValidators) {

            validator.validate(documentDTO);

        }
    }
}
