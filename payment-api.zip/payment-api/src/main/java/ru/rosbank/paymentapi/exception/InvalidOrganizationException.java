package ru.rosbank.paymentapi.exception;

public class InvalidOrganizationException extends RuntimeException {
    public InvalidOrganizationException(String message) {
        super(message);
    }

}
