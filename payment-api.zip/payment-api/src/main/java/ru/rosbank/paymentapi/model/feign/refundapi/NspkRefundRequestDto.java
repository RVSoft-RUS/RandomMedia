package ru.rosbank.paymentapi.model.feign.refundapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NspkRefundRequestDto {

    private String agentId;
    private String memberId;
    private String merchantId;
    private String originalTrxId;
    private String originalQrcId;
    private String amount;
    private String currency;
    private String agentRefundRequestId;
    private String opkcRefundRequestId;

}

