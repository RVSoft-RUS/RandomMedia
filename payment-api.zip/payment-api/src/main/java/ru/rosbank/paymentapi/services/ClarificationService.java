package ru.rosbank.paymentapi.services;

import java.math.BigDecimal;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.exception.ClarificationValidationException;
import ru.rosbank.paymentapi.mapper.ClarificationMapper;
import ru.rosbank.paymentapi.rbsp.client.ClarificationRBSPFeign;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.paymentapi.rbsp.dto.Commission;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.accountapp.model.BisIdDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClarificationService {

    private final ClarificationRBSPFeign rbspClient;
    private final ClarificationMapper mapper;
    private final ProductService productService;

    public Long clarificationPost(Rectification rectification, Payment payment, String orgId, BisIdDTO bisIdDTO,
                                  String payerInn) {
        try {
            var clarification = mapper.toClarification(rectification, payment, orgId, bisIdDTO.getId(),
                    bisIdDTO.getBranch(), payerInn);
            var receivedId = rbspClient.clarificationPost(clarification).getData().getClarificationId();
            return receivedId;
        } catch (Exception e) {
            log.error("Error while sending rectification to clarification-api, {}", e.getMessage(), e);
            return null;
        }
    }

    public void clarificationExecute(Rectification rectification) {
        try {
            rbspClient.clarificationExecutePatch(rectification.getId(), new Commission())
                    .getData().getClarificationId();
        } catch (Exception e) {
            log.error("Error clarificationExecute to clarification-api, {}", e.getMessage(), e);
        }
    }

    public Clarification clarificationGet(Long id) {
        try {
            var clarification = rbspClient.clarificationGet(id).getData();
            return clarification;
        } catch (Exception e) {
            log.error("Error clarificationGet clarification-api, {}", e.getMessage(), e);
            return null;
        }
    }

    public Rectification rectificationGet(Long id) {
        try {
            var rectification = mapper.toRectification(clarificationGet(id));
            return rectification;
        } catch (Exception e) {
            log.error("Error rectificationGet, {}", e.getMessage(), e);
            return null;
        }
    }

    public List<Clarification> clarificationFiltered(List<String> operationIdList) {
        try {
            var clarification = rbspClient.clarificationFilteredPost(operationIdList).getData();
            return clarification;
        } catch (Exception e) {
            log.error("Error clarificationFiltered to clarification-api, {}", e.getMessage(), e);
            return null;
        }
    }

    public BigDecimal commissionGet(String organizationId, String operationUid, String payerAccount20, String dboProId) {
        try {
            var response = rbspClient.commissionGet(organizationId, operationUid);
            var metaData = response.getResult();
            if (metaData.getStatus() != 200) {
                throw new BankInfoException("rbspClient.commissionGet:" + metaData);
            }
            if (StringUtils.isNotBlank(metaData.getMessage())) {
                switch (metaData.getMessage()) {
                    case "STATUS_PROCESSING":
                        throw new ClarificationValidationException("Дождитесь обработки предыдущего уточнения.");
                    case "STATUS_COMMISSION_PROCESSING":
                        throw new ClarificationValidationException("Не удалось списать комиссию по предыдущему уточнению. "
                                + "Пополните счёт и сообщите менеджеру для урегулирования задолженности.");
                    case "MAX_COUNT":
                        throw new ClarificationValidationException("Превышено количество уточнений по одному платежу — 5 штук.");
                    default:
                }
            }
            var summ = response.getData();
            if (summ.compareTo(BigDecimal.ZERO) > 0 && !isEnoughMoneyForCommission(summ, payerAccount20, dboProId)) {
                throw new ClarificationValidationException("Не хватает денег для оплаты комиссии за уточнение платежа. "
                        + "Стоимость услуги — " + summ + " рублей.");
            }
            return summ;
        } catch (ClarificationValidationException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error commissionGet clarification-api, {}", e.getMessage(), e);
            throw e;
        }
    }

    private boolean isEnoughMoneyForCommission(BigDecimal summ, String payerAccount20, String dboProId) {
        BigDecimal accountBalance = productService.getAccountBalance(payerAccount20, dboProId);
        if (accountBalance != null && accountBalance.compareTo(summ) >= 0) {
            return true;
        }
        return false;
    }
}
