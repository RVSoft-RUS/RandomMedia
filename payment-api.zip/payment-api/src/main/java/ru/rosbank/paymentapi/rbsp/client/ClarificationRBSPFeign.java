package ru.rosbank.paymentapi.rbsp.client;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import java.math.BigDecimal;
import java.util.List;
import javax.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.rosbank.paymentapi.config.FeignConfig;
import ru.rosbank.paymentapi.rbsp.dto.Clarification;
import ru.rosbank.paymentapi.rbsp.dto.Commission;
import ru.rosbank.paymentapi.rbsp.dto.common.Response;




@FeignClient(value = "clarificationClient", url = "${rbsp.uri}/${rbsp.clarification.name}/${rbsp.clarification.version}",
    configuration = FeignConfig.class)
public interface ClarificationRBSPFeign {
    /**
     * POST /clarification/v0/ : Создание уточнения для платежа.
     *
     *
     * @param clarification Тело запроса (required)
     * @return Запрос обработан (status code 200)
     */
    @Operation(summary = "Создание уточнения для платежа")
    @PostMapping(consumes = "application/json")
    Response<Clarification> clarificationPost(
            @Parameter(description = "Тело запроса", required = true) @Valid @RequestBody Clarification clarification);

    /**
     * POST /clarification/v0/filtered : Получение информации уточнения по массиву operation_uid.
     *
     * @param operationIdList Тело запроса (required)
     * @return Запрос обработан (status code 200)
     */
    @Operation(summary = "Получение информации уточнения по массиву operation_uid")
    @PostMapping(value = "/filtered", consumes = "application/json")
    Response<List<Clarification>> clarificationFilteredPost(
            @Parameter(description = "Тело запроса", required = true) @Valid @RequestBody List<String> operationIdList);

    /**
     * PATCH /clarification/v0/{clarificationId}/execute : Запрос на выполнение уточнения.
     *
     * @param clarificationId Идентификатор уточнения (required)
     * @param commission Тело запроса (required)
     * @return Запрос принят в обработку (status code 200)
     */
    @Operation(summary = "Запрос на выполнение уточнения.")
    @PatchMapping(value = "/{clarificationId}/execute", consumes = "application/json")
    Response<Clarification> clarificationExecutePatch(
            @Parameter(description = "Идентификатор уточнения", required = true) @PathVariable("clarificationId")
                    Long clarificationId,
            @Parameter(description = "Тело запроса", required = false) @RequestBody Commission commission);

    /**
     * GET /clarification/v0/issue/{clarificationId} : Запрос уточнения.
     *
     * @param clarificationId Идентификатор уточнения (required)
     * @return Уточнение найдено (status code 200)
     *         or Произошла функциональная ошибка (status code 400)
     *         or Unauthorized (status code 401)
     *         or Forbidden (status code 403)
     *         or Произошла системная ошибка (status code 500)
     */
    @Operation(summary = "Запрос уточнения.")
    @GetMapping(value = "/{clarificationId}", consumes = "application/json")
    Response<Clarification> clarificationGet(
            @Parameter(description = "Идентификатор уточнения", required = true) @PathVariable("clarificationId")
                    Long clarificationId);

    /**
     * GET /clarification/v0/operation/{organizationId}/{operationUid}/commission :
     * Запрос комиссии за уточнение.
     *
     * @param organizationId Идентификатор организации (required)
     * @param operationUid Идентификатор организации (required)
     * @return Уточнение найдено (status code 200)
     *         or Произошла функциональная ошибка (status code 400)
     *         or Unauthorized (status code 401)
     *         or Forbidden (status code 403)
     *         or Произошла системная ошибка (status code 500)
     */
    @GetMapping(value = "/operation/{organizationId}/{operationUid}/commission")
    Response<BigDecimal> commissionGet(@PathVariable("organizationId") String organizationId,
            @PathVariable("operationUid") String operationUid);
}
