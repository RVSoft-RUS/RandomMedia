package ru.rosbank.paymentapi.util;

public class FormatUtils {

    public static String masqueradePhoneNumber(String phoneNumber) {
        String phoneNo = phoneNumber.replace("+", "");

        String result = phoneNo.charAt(0) + " " + phoneNo.substring(1, 4)
                + " *** ** " + phoneNo.substring(phoneNo.length() - 2);
        if (!phoneNo.startsWith("8")) {
            result = "+" + result;
        }

        return result;
    }

    public static void checkTrue(boolean expression, String messageFormat, Object... arguments) {
        if (!expression) {
            throw new IllegalArgumentException(String.format(messageFormat, arguments));
        }
    }

}
