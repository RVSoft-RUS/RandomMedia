package ru.rosbank.paymentapi.config;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import ru.rosbank.platform.utils.async.mdc.MdcAwareExecutors;

@Configuration
@EnableAsync
public class AsyncConfig {

    @Value("${async.pool.document.max:100}")
    private int documentPoolSize;
    @Value("${async.pool.document.min:10}")
    private int documentCorePoolSize;
    @Value("${async.pool.audit.max:50}")
    private int auditPoolSize;
    @Value("${async.pool.audit.max:5}")
    private int auditCorePoolSize;
    @Value("${async.count.rectification:50}")
    private int rectificationThreadCount;
    @Value("${async.count.signed-document:50}")
    private int signedDocumentThreadCount;

    @Bean(name = "document_executor")

    public Executor getDocumentExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(documentCorePoolSize);
        executor.setMaxPoolSize(documentPoolSize);
        executor.setQueueCapacity(documentPoolSize * 100);
        executor.setThreadNamePrefix("document-");
        executor.setRejectedExecutionHandler(new PaymentRejectedExecutionHandlerImpl());
        executor.initialize();
        return executor;
    }

    @Bean(name = "audit_executor")
    public Executor getAuditExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(auditCorePoolSize);
        executor.setMaxPoolSize(auditPoolSize);
        executor.setQueueCapacity(auditPoolSize * 100);
        executor.setThreadNamePrefix("ru.rosbank.paymentapi.audit-");
        executor.initialize();
        return executor;
    }

    @Bean(name = "rectificationExecutorService")
    public ExecutorService rectificationExecutorService() {
        return MdcAwareExecutors.newMdcAwareFixedThreadPool(rectificationThreadCount);
    }

    @Bean(name = "signedDocumentExecutorService")
    public ExecutorService signedDocumentExecutorService() {
        return MdcAwareExecutors.newMdcAwareFixedThreadPool(signedDocumentThreadCount);
    }
}
