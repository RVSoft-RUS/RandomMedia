package ru.rosbank.paymentapi.services.integration;

import feign.FeignException;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.notificationapp.api.NotificationAppApi;
import ru.rosbank.platform.client.notificationapp.api.NotificationAppApiClient;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationAppApiClient notificationAppApi;

    public boolean isBlocked(String bisId, String bisBranch) {

        try {
            return Optional.ofNullable(notificationAppApi.dfmblockGet(bisId, bisBranch))
                    .map(ResponseEntity::getBody)
                    .orElse(true);
        } catch (FeignException e) {
            log.error("Ошибка сервиса notification-app {} ", e.status());
            return true;
        }

    }

}



