package ru.rosbank.paymentapi.services.onec.budget;


import ru.rosbank.paymentapi.services.onec.AbstractDocumentFieldParser1C;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class KbkParser1C extends AbstractDocumentFieldParser1C {
    private static final String KBK_KEY = "ПоказательКБК";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.setKbk(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, KBK_KEY);
    }
}
