package ru.rosbank.paymentapi.services.documents;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

/**
 * Summary.
 * @author rb064742
 */
public class TextFilter {

    public static boolean documentContainsText(Payment document, String textFilter) {
        if (textFilter == null) {
            return true;
        }
        String[] words = textFilter.replaceAll("[^a-zA-Zа-яА-я0-9\\s]", " ").toLowerCase().split("\\s+");

        if (words.length == 0) {
            return true;
        }

        List<String> searchStrings = Arrays.asList(
            document.getPurpose().toLowerCase(),
            document.getAmount().getSum().toString().replace(".", " "),
            getRequisiteName(document.getPayer()),
            getRequisiteName(document.getPayee())
        );

        return searchStrings.stream()
            .anyMatch(searchString -> Arrays.stream(words).allMatch(searchString::contains));
    }

    private static String getRequisiteName(Requisite requisiteDto) {
        return Optional.ofNullable(requisiteDto)
            .map(Requisite::getName)
            .orElse("")
            .toLowerCase();
    }

    public static boolean containsText(String sours, String textFilter) {
        if (StringUtils.isBlank(textFilter) || StringUtils.isBlank(sours)) {
            return true;
        }
        String textFilterLowerCase = textFilter.toLowerCase();
        String soursLowerCase = sours.toLowerCase();

        return soursLowerCase.contains(textFilterLowerCase);
    }

}
