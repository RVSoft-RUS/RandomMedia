package ru.rosbank.paymentapi.services;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.mapper.PaymentEventMapper;
import ru.rosbank.platform.client.auditapp.api.AuditAppApi;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.client.auditapp.model.PaymentEventDTO;
import ru.rosbank.platform.client.cryptoproapp.model.MetaDataDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.userapp.api.UserAppApi;
import ru.rosbank.platform.client.userapp.model.ClientDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService {

    private static final String HEADER_NAME_IP = "ip";
    private static final String HEADER_NAME_SESSION_ID = "session-id";
    private static final String HEADER_NAME_DEVICE_ID = "device-id";
    private static final String HEADER_NAME_USER_AGENT = "User-Agent";
    private static final String HEADER_NAME_APP_VERSION = "app-version";
    private static final String HEADER_NAME_MAC_ADDRESS = "macaddress";

    private final AuditAppApi auditAppApi;
    private final PaymentEventMapper paymentEventMapper;
    private final UserAppApi userAppApi;

    @Async("audit_executor")
    public void sendEvent(EventDTO event) {
        try {
            fillTraceInfo(event);
            auditAppApi.rootPost(event);
        } catch (Exception e) {
            log.error("Failed to invoke audit-app", e);
        }
    }

    @Async("audit_executor")
    public void logPaymentEvent(DocumentDTO documentDTO, String dboProId, PaymentEventDTO.EventEnum event) {
        var eventDto = paymentEventMapper.toPaymentEvent(documentDTO);
        Optional.ofNullable(userAppApi.userGetByDboProId(dboProId).getBody())
                .map(ClientDTO::getFio)
                .ifPresent(eventDto::setFio);
        eventDto.setDboProId(dboProId);
        eventDto.setEvent(event);
        sendPaymentEvent(eventDto);
    }

    private void sendPaymentEvent(PaymentEventDTO event) {
        try {
            event.setIpAddress(MDC.get(HEADER_NAME_IP));
            event.setMacAddress(MDC.get(HEADER_NAME_MAC_ADDRESS));
            auditAppApi.paymentEventPost(event);
        } catch (Exception e) {
            log.error("Failed to invoke audit-app.paymentEventPost", e);
        }
    }

    private void fillTraceInfo(EventDTO event) {
        event.setDeviceId(MDC.get(HEADER_NAME_DEVICE_ID));
        event.setIpAddress(MDC.get(HEADER_NAME_IP));
        event.setUserAgent(MDC.get(HEADER_NAME_USER_AGENT));
        event.setSessionId(MDC.get(HEADER_NAME_SESSION_ID));
    }

    public MetaDataDTO getMetaDataDTO() {
        return new MetaDataDTO()
                .ip(MDC.get(HEADER_NAME_IP))
                .appVersion(MDC.get(HEADER_NAME_APP_VERSION))
                .deviceId(MDC.get(HEADER_NAME_DEVICE_ID))
                .platform(MDC.get(HEADER_NAME_USER_AGENT));
    }

}
