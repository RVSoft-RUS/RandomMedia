package ru.rosbank.paymentapi.services.onec;


import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class PaymentPriorityParser1C extends AbstractDocumentFieldParser1C {
    private static final String PAYMENT_PRIORITY_KEY = "Очередность";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.setPaymentPriority(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, PAYMENT_PRIORITY_KEY);
    }
}
