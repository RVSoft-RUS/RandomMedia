package ru.rosbank.paymentapi.model.feign.qrpaymentapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResultDto {

    private String timestamp;
    private String code;
    private String message;
    private Integer status;

    public boolean isSuccess() {
        if (status != null) {
            return status >= 200 && status < 300;
        }
        return false;
    }

}

