package ru.rosbank.paymentapi.converter;

import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

// TODO bean
public class PaymentOrderConverter {

    public static Payment convert(PaymentDTO input) {
        var payment = new Payment();
        payment.setSubtype(Payment.SubtypeEnum.PAYMENT_ORDER);
        BaseConverter.convert(payment, input);

        // Очерёдность платежа
        payment.setPaymentPriority(input.getPaymentPriority());
        // № ч. плат.
        payment.setPaymentPartialNumber(input.getPaymentPartialNumber());
        // Шифр плат.док.
        payment.setTypeCodeOrder(input.getTypeCodeOrder());
        // № плат.док.
        payment.setPaymentOrderNumber(input.getPaymentOrderNumber());
        // Дата плат.док.
        payment.setPaymentOrderDate(input.getPaymentOrderDate());
        // Сумма ост. плат.
        payment.setPaymentBalanceAmount(input.getPaymentBalanceAmount());
        // Дата поступления в банк плательщика
        payment.setIncomingDate(input.getIncomingDate());
        // Содержание операции
        payment.setContent(input.getContent());

        payment.setUin(input.getUin());
        payment.setKbk(input.getKbk());
        payment.setOktmo(input.getOktmo());
        payment.setPaymentBasis(input.getPaymentBasis());
        payment.setTaxPeriod(input.getTaxPeriod());
        payment.setBasisDocumentNumber(input.getBasisDocumentNumber());
        payment.setBasisDocumentCreated(input.getBasisDocumentCreated());

        // Статус плательщика
        payment.setPayerStatus(input.getPayerStatus());

        return payment;
    }

    private PaymentOrderConverter() {

    }

}
