package ru.rosbank.paymentapi.exception;

/**
 * Summary.
 *
 * @author dpetrov
 */
public class UnknownDocumentException extends RuntimeException {

    public UnknownDocumentException(String msg) {
        super(msg);
    }

    public UnknownDocumentException(String msg, Throwable t) {
        super(msg, t);
    }
}


