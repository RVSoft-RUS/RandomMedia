package ru.rosbank.paymentapi.exception;

public class ClarificationValidationException extends ValidationException {

    public ClarificationValidationException(String msg) {
        super(msg);
    }

}
