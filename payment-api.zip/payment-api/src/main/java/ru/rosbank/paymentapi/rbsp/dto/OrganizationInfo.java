package ru.rosbank.paymentapi.rbsp.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Информация об организации.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OrganizationInfo {
    @NotNull
    private String organizationId;
    @NotNull
    private String bisId;
    @NotNull
    private String bisBranch;
}
