package ru.rosbank.paymentapi.exception;

public class NoRightsException extends RuntimeException {
    public NoRightsException(String message) {
        super(message);
    }

}
