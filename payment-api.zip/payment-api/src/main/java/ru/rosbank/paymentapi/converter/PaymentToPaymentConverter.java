package ru.rosbank.paymentapi.converter;

import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

@Service
public class PaymentToPaymentConverter {

    public Payment convert(PaymentDTO input) {
        Payment payment;
        switch (input.getSubtype()) {
            case PAYMENT_ORDER:
                payment = PaymentOrderConverter.convert(input);
                break;
            case PAYMENT_ASSIGNMENT:
                payment = PaymentAssignmentConverter.convert(input);
                break;
            case BANK_ORDER:
                payment = BankOrderConverter.convert(input);
                break;
            case COLLECTION_ASSIGNMENT:
                payment = CollectionAssignmentConverter.convert(input);
                break;
            case MEMORIAL_ORDER:
                payment = MemorialOrderConverter.convert(input);
                break;
            case PAYMENT_BILL:
                payment = PaymentBillConverter.convert(input);
                break;
            case ACCOUNT_CASH_WARRANT:
                payment = AccountCashWarrantConverter.convert(input);
                break;
            case CASH_RECEIPT_ORDER:
                payment = CashReceiptOrderConverter.convert(input);
                break;
            case CURRENCY_TRANSACTION:
            case CURRENCY_OTHER:
            case CURRENCY_MEMORIAL_ORDER:
                payment = CurrencyConverter.convert(input);
                break;
            default:
                payment = PaymentAssignmentConverter.convert(input);
        }
        return payment;
    }

}
