package ru.rosbank.paymentapi.services.validator;

import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.validator.field.DocumentAmountValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentNumberValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPurposePayrollValidator;
import ru.rosbank.paymentapi.services.validator.field.ImportedDocumentPayerNameValidator;
import ru.rosbank.paymentapi.services.validator.field.ImportedPayrollPayeeAccountValidator;
import ru.rosbank.paymentapi.services.validator.field.PurposePayrollValidator;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.DocumentPayPriorityValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeInnValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeNameValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentUinCode22Validator;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Slf4j
@Service
public class ImportedPayrollPaymentValidators {

    private final List<IDocumentValidator> payrollValidators;

    @Autowired
    ImportedPayrollPaymentValidators(PurposePayrollValidator purposePayrollValidator,
                                     ImportedDocumentPayerNameValidator documentPayerNameValidator,
                                     DocumentPayPriorityValidator documentPayPriorityValidator,
                                     DocumentNumberValidator documentNumberValidator,
                                     DocumentUinCode22Validator documentUinCode22Validator,
                                     DocumentPayeeInnValidator documentPayeeInnValidator,
                                     DocumentPayeeKppValidator documentPayeeKppValidator,
                                     DocumentPayerKppValidator documentPayerKppValidator,
                                     DocumentPayeeNameValidator documentPayeeNameValidator,
                                     DocumentAmountValidator documentAmountValidator,
                                     DocumentPurposePayrollValidator documentPurposePayrollValidator,
                                     ImportedPayrollPayeeAccountValidator importedPayrollPayeeAccountValidator
    ) {
        payrollValidators = List.of(
                documentPayerNameValidator,
                documentPayPriorityValidator,
                purposePayrollValidator,
                documentNumberValidator,
                documentUinCode22Validator,
                documentPayeeInnValidator,
                documentPayeeKppValidator,
                documentPayerKppValidator,
                documentPayeeNameValidator,
                documentAmountValidator,
                documentPurposePayrollValidator,
                importedPayrollPayeeAccountValidator
        );
    }

    public void validate(DocumentDTO documentDTO) throws ValidationPaymentException {

        for (IDocumentValidator validator : payrollValidators) {

            validator.validate(documentDTO);

        }

    }

}
