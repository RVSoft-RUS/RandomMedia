package ru.rosbank.paymentapi.services.onec;


import java.util.Optional;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;

/**
 * Summary.
 * @author rb068869
 */
public class PayerInnParser1C extends AbstractDocumentFieldParser1C {
    private static final String PAYER_INN_KEY = "ПлательщикИНН";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.payer(Optional.ofNullable(document).map(DocumentDTO::getPayer).orElse(new RequisiteDTO())).getPayer()
                    .setInn(getValueFromLine(line));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, PAYER_INN_KEY);
    }
}
