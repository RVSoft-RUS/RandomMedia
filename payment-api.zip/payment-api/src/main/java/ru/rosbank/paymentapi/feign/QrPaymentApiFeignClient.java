package ru.rosbank.paymentapi.feign;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoResponse;

@FeignClient(name = "QrPaymentApi", url = "${fastpayle.url}")
public interface QrPaymentApiFeignClient {

    @GetMapping(value = "/qrpayment/v0/payment/bisreference/{bisReference}", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<QrInfoResponse> qrPaymentPaymentBisReferenceGet(@PathVariable("bisReference") String bisReference,
        @RequestParam("paymentDate") String paymentDate);

}
