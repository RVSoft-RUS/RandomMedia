package ru.rosbank.paymentapi.services;



import static ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator.DEFAULT_ERROR_MESSAGE;
import static ru.rosbank.paymentapi.services.validator.field.DocumentPayeeAccountValidator.PAYEE_ACCOUNT_FIELD;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DA;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DB;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DC;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DD;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DE;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DF;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DG;
import static ru.rosbank.platform.client.paymentapp.model.DocumentDTO.TypeEnum.DP;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import ru.rosbank.paymentapi.converter.DocumentToImportedDocumentConverter;
import ru.rosbank.paymentapi.exception.ImportDocumentException;
import ru.rosbank.paymentapi.mapper.ImportedBatchResultMapper;
import ru.rosbank.paymentapi.mapper.ImportedDocumentMapper;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.paymentapi.services.validator.DocumentValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentBudgetFieldsValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.ImportedDocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.server.paymentapi.model.ImportedBatchResult;
import ru.rosbank.platform.server.paymentapi.model.ImportedDocument;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

/**
 * DocumentImportService.
 * @author rb068869
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentImportService {
    private static final String ERROR_MESSAGE_PAYEE_BANK_BIC_EMPTY = "Заполните поле БИК получателя";
    private static final List<DocumentDTO.TypeEnum> DOC_TYPE_LIST_1C = Collections.unmodifiableList(Arrays.asList(
        DA,
        DB,
        DC,
        DD,
        DF,
        DG,
        DE,
        DP 
    ));
    private static final String INVALID_DOCUMENT_TYPE_ERROR = "Создание документа невозможно. "
        + "Для загрузки доступны исходящие платежи контрагенту и в бюджет.";
    private static final int MAX_LENGTH_BANK_NAME = 45;

    private final DocumentParserService documentParserService;
    private final DocumentValidator documentValidator;
    private final DocumentBudgetFieldsValidator documentBudgetFieldsValidator;
    private final DocumentToImportedDocumentConverter documentToImportedDocumentConverter;
    private final PaymentAppApi paymentAppApi;
    private final DocumentTypeCalculatorImpl documentTypeCalculator;
    private final ReferenceService referenceService;
    private final ProductService productService;

    //@LogAuditEvent
    public ImportedBatchResult createBatch(byte[] content, String dboProId) throws ImportDocumentException {

        List<DocumentDTO> parsedDocs = documentParserService.parseDocumentsTxt(content);
        Map<String, List<AccountDTO>> crmIdAccountMap = productService.getAccounts(dboProId);

        ImportedBatchResult batch = new ImportedBatchResult();
        batch.invalidPaymentsCount(0).paymentsCount(0).payrollPaymentsCount(0);
        batch.setId(UUID.randomUUID().toString());
        List<ImportedDocumentDTO> documentList = new ArrayList<>();
        for (DocumentDTO doc : parsedDocs) {
            ImportedDocumentDTO.StatusEnum status;
            String errorMessage;
            Map<String, AccountDTO> accountsMap = new HashMap<>();
            try {
                fillRemainingFields(doc);
                int payPriority = Integer.parseInt(doc.getPaymentPriority());
                doc.setPaymentPriority(String.valueOf(payPriority));
                List<AccountDTO> accounts = new ArrayList<>();
                for (String crmId : crmIdAccountMap.keySet()) {
                    if (crmIdAccountMap.get(crmId).stream().anyMatch(accountDTO -> accountDTO.getNumber().equals(
                            Optional.ofNullable(doc).map(DocumentDTO::getPayer).map(RequisiteDTO::getAccount)
                                    .orElseThrow(() -> new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD,
                                            DEFAULT_ERROR_MESSAGE))))) {
                        accounts = crmIdAccountMap.get(crmId);
                    }
                }
                Assert.notEmpty(accounts, "createBatch: accounts is Empty; dboProId = " + dboProId);

                accounts.forEach(a -> accountsMap.put(a.getNumber(), a));
                documentValidator.validateImportedDoc(doc, dboProId, accountsMap);
                status = ImportedDocumentDTO.StatusEnum.VALID;
                if (DocumentDTO.TypeEnum.DP.equals(doc.getType())) {
                    batch.setPayrollPaymentsCount(batch.getPayrollPaymentsCount() + 1);
                } else {
                    batch.setPaymentsCount(batch.getPaymentsCount() + 1);
                }
                errorMessage = null;
            } catch (ImportDocumentException ie) {
                throw ie;
            } catch (Exception e) {
                status = ImportedDocumentDTO.StatusEnum.INVALID;
                batch.setInvalidPaymentsCount(batch.getInvalidPaymentsCount() + 1);
                log.info(e.getMessage(), e);
                errorMessage = e.getMessage();
            }
            var payerAccount = Optional.ofNullable(doc).map(DocumentDTO::getPayer).map(RequisiteDTO::getAccount)
                    .orElseThrow(() -> new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен"));
            ImportedDocumentDTO importedDocument = documentToImportedDocumentConverter.convert(doc,
                    accountsMap.get(payerAccount));
            importedDocument.setErrorMessage(errorMessage);
            importedDocument.setDboProId(dboProId);
            importedDocument.setStatus(status);
            importedDocument.setDateCreated(OffsetDateTime.now());

            validateIfBudgetPayment(doc);

            documentList.add(importedDocument);
        }
        batch.setId(paymentAppApi.importedPost(dboProId, documentList).getBody());

        return batch;
    }

    private void fillRemainingFields(DocumentDTO document) throws ImportDocumentException {

        String payeeBankBic = Optional.ofNullable(Optional.of(Optional.of(document).map(DocumentDTO::getPayee)
                .orElse(new RequisiteDTO())).map(RequisiteDTO::getBank).orElse(new BankInfoDTO()).getBic())
                .orElseThrow(() -> new ValidationPaymentException(14, "payee.bank.bic", ERROR_MESSAGE_PAYEE_BANK_BIC_EMPTY));
        String payeeCorAccount = Optional.of(Optional.of(Optional.of(document).map(DocumentDTO::getPayee)
                .orElse(new RequisiteDTO())).map(RequisiteDTO::getBank).orElse(new BankInfoDTO())).get()
                .getCorrespondentAccount();
        Optional<BankDTO> bicReferenceDto
            = referenceService.getBankInfo(payeeBankBic).stream().filter(bb ->
                StringUtils.isBlank(payeeCorAccount) || payeeCorAccount.equals(bb.getCorrespondentAccount()))
            .findFirst();

        document.getPayee().getBank().setName(bicReferenceDto.map(BankDTO::getName).orElse(
            Optional.ofNullable(document.getPayee().getBank().getName()).map(
                n -> n.length() > MAX_LENGTH_BANK_NAME ? n.substring(0, MAX_LENGTH_BANK_NAME) : n).orElse("")));

        document.getPayee().getBank().setCorrespondentAccount(bicReferenceDto.map(BankDTO::getCorrespondentAccount)
            .orElse(Optional.ofNullable(document.getPayee().getBank().getCorrespondentAccount())
                .orElse("")));

        document.setUin(Optional.ofNullable(document.getUin()).orElse("0"));

        DocumentDTO.TypeEnum documentTypeDto = documentTypeCalculator.calculateForImportedDoc(document);

        document.setType(documentTypeDto);

        if (!DOC_TYPE_LIST_1C.contains(documentTypeDto)) {
            throw new ImportDocumentException(INVALID_DOCUMENT_TYPE_ERROR);
        }
    }

    //@LogAuditEvent
    public void deleteImportedDocument(String id, String dboProId) {
        paymentAppApi.importedDocumentIdDelete(id, dboProId);
    }

    //@LogAuditEvent
    public List<ImportedDocument> getImportedDocuments(String batch, String dboProId, String status) {
        return paymentAppApi.importedBatchIdGet(batch, dboProId, status).getBody().stream()
                .map(ImportedDocumentMapper.INSTANCE::fromDTO).collect(Collectors.toList());

    }

    //@LogAuditEvent
    public ImportedBatchResult processBatch(String batch, String dboProId) {
        return ImportedBatchResultMapper.INSTANCE.fromDTO(paymentAppApi.importedBatchIdProcessPost(batch, dboProId).getBody());
    }



    //@LogAuditEvent
    public ImportedDocument updateImportedDocument(ImportedDocument importedDocument, String dboProId) {
        var organizationAcc = productService.getOrganizationAccByAccNumberAndDboProId(
                Optional.ofNullable(importedDocument).map(ImportedDocument::getPayer).map(Requisite::getAccount)
                        .orElseThrow(() -> new ValidationPaymentException(17, PAYEE_ACCOUNT_FIELD, DEFAULT_ERROR_MESSAGE)),
                dboProId);
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        organizationAcc.getAccounts().forEach(a -> accountsMap.put(a.getNumber(), a));
        documentValidator.validateImportedDoc(documentToImportedDocumentConverter.convertBack(importedDocument), dboProId,
                accountsMap);
        return ImportedDocumentMapper.INSTANCE.fromDTO(
                paymentAppApi.importedDocumentPost(dboProId, ImportedDocumentMapper.INSTANCE.toDTO(importedDocument)).getBody());
    }

    private void validateIfBudgetPayment(DocumentDTO documentDTO) {
        if (documentDTO != null && DocumentDTO.TypeEnum.DE != documentDTO.getType()) {
            documentBudgetFieldsValidator.validate(documentDTO);
        }
    }
}
