package ru.rosbank.paymentapi.services.integration;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.client.referenceapp.model.BranchDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReferenceService {

    private final ReferenceAppService referenceAppService;
    private Set<String> rosbankInnSet = null;

    public List<BankDTO> getBankInfo(String query) {
        if (isBlank(query)) {
            return Collections.emptyList();
        }

        try {
            return referenceAppService.getBankInfo(query);
        } catch (RuntimeException e) {
            log.error("Ошибка при вызове referenceAppApi.bankGet: {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    public List<BranchDTO> getBranch(String code) {
        try {
            return referenceAppService.getBranch(code);
        } catch (RuntimeException e) {
            log.error("Ошибка при вызове referenceAppApi.branchGet: {}", e.getMessage());
        }
        return Collections.emptyList();
    }

    public boolean isRosbankInn(String inn) {
        if (rosbankInnSet == null) {
            List<BranchDTO> bankDTOS = getBranch(null);
            rosbankInnSet = new HashSet<>();
            rosbankInnSet.addAll(bankDTOS.stream().map(BranchDTO::getInn).collect(Collectors.toList()));
        }
        return rosbankInnSet.contains(inn);
    }

    public String getBranchForBic(String bic) {
        List<BranchDTO> bankDTOS = getBranch(null);
        return bankDTOS
                .stream()
                .filter(branchDTO -> branchDTO.getBik().equals(bic))
                .map(BranchDTO::getCode)
                .findFirst()
                .orElse(null);
    }
}
