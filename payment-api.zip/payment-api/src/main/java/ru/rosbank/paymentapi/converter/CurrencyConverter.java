package ru.rosbank.paymentapi.converter;

import lombok.extern.slf4j.Slf4j;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

@Slf4j
public class CurrencyConverter {

    public static Payment convert(PaymentDTO po) {
        Payment document = getPaymentTemp();
        document.setId(po.getId());
        setSubtype(po, document);
        document.setNumber(po.getNumber());
        setType(po, document);
        document.setCreated(po.getCreated());
        document.setCompleted(po.getCompleted());
        if (po.getAmount() != null && po.getAmount().getCurrency() != null) {
            document.getAmount().setCurrency(po.getAmount().getCurrency());
        }
        if (po.getAmount() != null && po.getAmount().getSum() != null) {
            document.getAmount().setSum(po.getAmount().getSum());
        }
        if (po.getAmount() != null && po.getAmount().getSumRur() != null) {
            document.getAmount().setSumRur(po.getAmount().getSumRur());
        }
        if (po.getPayee() != null && po.getPayee().getBank().getSwift() != null) {
            document.getPayee().getBank().setSwift(po.getPayee().getBank().getSwift());
        }
        if (po.getPayer() != null && po.getPayer().getBank() != null) {
            document.getPayer().getBank().setSwift(po.getPayer().getBank().getSwift());
        }
        if (po.getPayee() != null) {
            document.getPayee().setName(po.getPayee().getName());
        }
        if (po.getPayer() != null) {
            document.getPayer().setName(po.getPayer().getName());
        }
        document.setPurpose(po.getPurpose());
        if (po.getPayee() != null && po.getPayee().getAccount() != null) {
            document.getPayee().setAccount(po.getPayee().getAccount());
        }
        if (po.getPayer() != null && po.getPayer().getAccount() != null) {
            document.getPayer().setAccount(po.getPayer().getAccount());
        }
        if (po.getPayee() != null && po.getPayee().getBank() != null) {
            document.getPayee().getBank().setName(po.getPayee().getBank().getName());
        }
        if (po.getPayer() != null && po.getPayer().getBank() != null) {
            document.getPayer().getBank().setName(po.getPayer().getBank().getName());
        }
        document.setPaymentOrderNumber(po.getPaymentOrderNumber());
        if (po.getPaymentOrderDate() != null) {
            document.setPaymentOrderDate(po.getPaymentOrderDate());
        }

        return document;
    }

    private static void setSubtype(PaymentDTO po, Payment document) {
        switch (po.getSubtype().getValue()) {
            case "CURRENCY_MEMORIAL_ORDER":
                document.setSubtype(Payment.SubtypeEnum.CURRENCY_MEMORIAL_ORDER);
                break;
            case "CURRENCY_TRANSACTION":
                document.setSubtype(Payment.SubtypeEnum.CURRENCY_TRANSACTION);
                break;
            case "CURRENCY_OTHER":
                document.setSubtype(Payment.SubtypeEnum.CURRENCY_OTHER);
                break;
            default:
                log.error("Subtype is not defined for {} ",po.getId());
        }
    }

    private static void setType(PaymentDTO po, Payment document) {
        switch (po.getType().getValue()) {
            case "CK":
                document.setType(Payment.TypeEnum.CK);
                break;
            case "DK":
                document.setType(Payment.TypeEnum.DK);
                break;
            case "DN":
                document.setType(Payment.TypeEnum.DN);
                break;
            case "CN":
                document.setType(Payment.TypeEnum.CN);
                break;
            case "DO":
                document.setType(Payment.TypeEnum.DO);
                break;
            case "CO":
                document.setType(Payment.TypeEnum.CO);
                break;
            case "DL":
                document.setType(Payment.TypeEnum.DL);
                break;
            case "CL":
                document.setType(Payment.TypeEnum.CL);
                break;
            case "CM":
                document.setType(Payment.TypeEnum.CM);
                break;
            case "DM":
                document.setType(Payment.TypeEnum.DM);
                break;
            case "DR":
                document.setType(Payment.TypeEnum.DR);
                break;
            case "CR":
                document.setType(Payment.TypeEnum.CR);
                break;
            default:
                log.error("type is not defined for {} ", po.getId());

        }
    }

    private static Payment getPaymentTemp() {
        var document = new Payment();
        document.setPayer(new Requisite());
        document.setPayee(new Requisite());
        document.getPayer().setBank(new BankInfo());
        document.getPayee().setBank(new BankInfo());
        document.setAmount(new Amount());
        return document;
    }
}
