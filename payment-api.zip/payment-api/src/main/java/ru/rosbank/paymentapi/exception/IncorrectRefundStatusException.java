package ru.rosbank.paymentapi.exception;

public class IncorrectRefundStatusException extends RuntimeException {

    public IncorrectRefundStatusException(String message) {
        super(message);
    }

}
