package ru.rosbank.paymentapi.converter;

import ru.rosbank.paymentapi.mapper.BankInfoMapper;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class BankOrderConverter {
    public static Payment convert(PaymentDTO input) {
        Payment document = new Payment();
        document.setSubtype(Payment.SubtypeEnum.BANK_ORDER);
        BaseConverter.convert(document, input);

        document.setNumber(input.getNumber());
        // Дата создания документа
        document.setCreated(input.getCreated());
        // Дата исполнения
        document.setCompleted(input.getCompleted());

        // Назначение платежа
        document.setPurpose(input.getPurpose());

        // Вид операции
        // ???????????????????
        // Очерёдность платежа
        document.setPaymentPriority(input.getPaymentPriority());

        // Отметка об исполнении
        document.setProcessedBy(BankInfoMapper.INSTANCE.fromDTO(input.getProcessedBy()));

        return document;
    }
}
