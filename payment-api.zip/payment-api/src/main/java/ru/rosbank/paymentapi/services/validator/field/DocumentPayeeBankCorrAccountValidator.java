package ru.rosbank.paymentapi.services.validator.field;

import static ru.rosbank.paymentapi.commons.PaymentUtils.BIC_TUPE_UTRA_ACC;

import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.paymentapp.model.BankInfoDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.referenceapp.model.BankDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Service
public class DocumentPayeeBankCorrAccountValidator implements IDocumentValidator {

    @Autowired
    private ReferenceService referenceService;

    private static final String ERROR_MESSAGE_BIC = "Неверный корр.счёт получателя";
    private static final String ERROR_MESSAGE_CORR_ACCOUNT = "Неверный корр.счёт получателя";

    public void validate(DocumentDTO document) throws ValidationPaymentException {

        String payeeBankBic = Optional.ofNullable(document.getPayee())
                .map(RequisiteDTO::getBank)
                .map(BankInfoDTO::getBic).orElseThrow(() ->
                        new ValidationPaymentException(14, "payee.bank.bic", ERROR_MESSAGE_BIC));
        String payeeBankCorrespondentAccount = Optional.ofNullable(document.getPayee())
                .map(RequisiteDTO::getBank)
                .map(BankInfoDTO::getCorrespondentAccount).orElseThrow(() ->
                        new ValidationPaymentException(15, "payee.bank.correspondent_account", ERROR_MESSAGE_CORR_ACCOUNT));

        if (isBicTypeUtra(payeeBankBic)) {
            return;
        }

        var banksCorAccounts = referenceService.getBankInfo(payeeBankBic)
                .stream()
                .map(BankDTO::getCorrespondentAccount)
                .collect(Collectors.toList());

        if (!banksCorAccounts.isEmpty()
                && banksCorAccounts.stream().noneMatch(it -> it.equals(payeeBankCorrespondentAccount))) {
            throw new ValidationPaymentException(15, "payee.bank.correspondent_account", ERROR_MESSAGE_CORR_ACCOUNT);
        }

        if ((banksCorAccounts.isEmpty()) && !StringUtils.isEmpty(payeeBankCorrespondentAccount)) {
            throw new ValidationPaymentException(15, "payee.bank.correspondent_account", ERROR_MESSAGE_CORR_ACCOUNT);
        }

    }

    public boolean isBicTypeUtra(String bic) {
        return referenceService.getBankInfo(bic).stream().findFirst().map(bank -> BIC_TUPE_UTRA_ACC.contains(bank.getBikType()))
                .orElse(false);
    }
}
