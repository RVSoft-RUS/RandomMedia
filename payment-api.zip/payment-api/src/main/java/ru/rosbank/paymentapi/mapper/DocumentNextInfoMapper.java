package ru.rosbank.paymentapi.mapper;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import org.mapstruct.Mapper;
import ru.rosbank.platform.client.paymentapp.model.NextDocumentInfoDTO;
import ru.rosbank.platform.server.paymentapi.model.NextDocumentInfo;

@Mapper(componentModel = "spring")
public interface DocumentNextInfoMapper {

    DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

    NextDocumentInfo fromDto(NextDocumentInfoDTO nextDocumentInfoDTO);

    default String map(OffsetDateTime value) {
        if (value == null) {
            return null;
        }
        return DATE_TIME_FORMATTER.format(value);
    }
}
