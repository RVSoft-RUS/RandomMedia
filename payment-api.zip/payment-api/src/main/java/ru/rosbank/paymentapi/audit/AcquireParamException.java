package ru.rosbank.paymentapi.audit;

public class AcquireParamException extends RuntimeException {

    public AcquireParamException(String message, Throwable cause) {
        super(message, cause);
    }

}
