package ru.rosbank.paymentapi.commons;

import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DA;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DB;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DC;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DD;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DE;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DF;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DG;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DH;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DI;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DJ;
import static ru.rosbank.platform.client.paymentapi.model.PaymentDTO.TypeEnum.DT;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import org.apache.commons.lang3.StringUtils;
import ru.rosbank.paymentapi.audit.AuditContext;
import ru.rosbank.platform.client.paymentapi.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class Constants {

    public static final String ATTRIBUTE_CLIENT_ID = "CLIENT_ID";

    public static final String NOT_ENOUGH_RIGHTS_ERROR = "Счёт плательщика запрещён.";

    public static Map<String, String> getPaymentPriorityDirectory() {
        return PAYMENT_PRIORITY_DIRECTORY;
    }

    private static final Map<String, String> PAYMENT_PRIORITY_DIRECTORY;

    public static final Collection<PaymentDTO.TypeEnum> OUTCOME_PAYMENT_DTO = Collections.unmodifiableCollection(
            Arrays.asList(DA, DB, DD, DC, DE, DF, DG, DH, DI, DT, DJ)
    );

    public static final Collection<Payment.TypeEnum> OUTCOME_PAYMENT = Collections.unmodifiableCollection(
            Arrays.asList(Payment.TypeEnum.DA, Payment.TypeEnum.DB, Payment.TypeEnum.DD, Payment.TypeEnum.DC,
                    Payment.TypeEnum.DE, Payment.TypeEnum.DF, Payment.TypeEnum.DG, Payment.TypeEnum.DH,
                    Payment.TypeEnum.DI, Payment.TypeEnum.DT, Payment.TypeEnum.DJ, Payment.TypeEnum.DK,
                    Payment.TypeEnum.DN, Payment.TypeEnum.DO, Payment.TypeEnum.DL, Payment.TypeEnum.DM, Payment.TypeEnum.DR)
    );

    public static final Collection<String> USER_AGENT_IOS = Collections.unmodifiableCollection(
            Arrays.asList("CFNetwork", "iphone", "iPhone")
    );
    public static final Collection<String> USER_AGENT_ANDROID = Collections.singletonList("Dalvik");
    public static final Collection<String> USER_AGENT_WEB = Collections.singletonList("Mozilla");
    public static final String OS_TYPE_ANDROID = "ANDROID";
    public static final String OS_TYPE_IOS = "IOS";
    public static final String OS_TYPE_WEB = "WEB";

    static {
        PAYMENT_PRIORITY_DIRECTORY = new TreeMap<>();
        PAYMENT_PRIORITY_DIRECTORY.put("1", "Выплаты по исполнительным док-там на возмещение"
                + " нанесенного здоровью/жизни ущерба и уплату алиментов");
        PAYMENT_PRIORITY_DIRECTORY.put("2", "Выплаты выходных пособий/задолженностей по зарплате; гонораров авторам.");
        PAYMENT_PRIORITY_DIRECTORY.put("3", "Выплаты заработной платы; оплата задолженности по налогам, "
                + "сборам/взносам по поручениям налог.органов/органов контроля за уплатой взносов");
        PAYMENT_PRIORITY_DIRECTORY.put("4", "Выплаты по исполнительным документам, "
                + "предусматривающим удовлетворение других денежных требований");
        PAYMENT_PRIORITY_DIRECTORY.put("5", "Перечисления в бюджет РФ (налоги, сборы, пошлины); "
                + "иные текущие платежи (оплата товаров/услуг)");
    }

    public static String getPlatform(AuditContext auditContext) {
        String userAgent = auditContext.getUserAgent();
        if (StringUtils.isBlank(userAgent) || USER_AGENT_WEB.stream().anyMatch(userAgent::contains)) {
            return OS_TYPE_WEB;
        }

        if (USER_AGENT_ANDROID.stream().anyMatch(userAgent::contains)) {
            return OS_TYPE_ANDROID;
        }

        if (USER_AGENT_IOS.stream().anyMatch(userAgent::contains)) {
            return OS_TYPE_IOS;
        }

        return OS_TYPE_WEB;
    }

    private Constants() {

    }

}
