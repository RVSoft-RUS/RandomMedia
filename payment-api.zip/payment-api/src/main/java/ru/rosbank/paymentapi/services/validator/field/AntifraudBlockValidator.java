package ru.rosbank.paymentapi.services.validator.field;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.userapp.api.UserAppApi;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

@Slf4j
@Service
@RequiredArgsConstructor
public class AntifraudBlockValidator {
    private static final String ANTIFRAUD_BLOCK_MESSAGE = "Для подписания платежа подтвердите операцию в центре "
            + "поддержки бизнеса по телефону: 8-800-770-75-00";
    private static final int FIELD_ID = 9;
    private static final String FIELD_NAME = "payer.account";

    private final UserAppApi userAppApi;

    public void validate(String clientId) {

        boolean blocked = Boolean.TRUE.equals(userAppApi.antifraudBlockGet(clientId).getBody());

        if (blocked) {
            throw new ValidationPaymentException(FIELD_ID, FIELD_NAME, ANTIFRAUD_BLOCK_MESSAGE);
        }

    }
}
