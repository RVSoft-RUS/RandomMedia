package ru.rosbank.paymentapi.services.reporting;

import freemarker.template.TemplateException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import ru.rosbank.paymentapi.exception.AccessForbiddenException;
import ru.rosbank.paymentapi.exception.UnknownDocumentException;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.PaymentService;
import ru.rosbank.paymentapi.services.integration.StatementService;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.FileResource;

@Slf4j
@Controller
@RequiredArgsConstructor
public class DocumentFormService {

    private final PaymentFormService paymentFormService;
    private final PaymentService paymentService;

    private final StatementFormService statementFormService;
    private final StatementService statementService;

    private final AccountService accountService;
    private final OrganizationService organizationService;

    public FileResource getDocumentFormPDSN(String documentId, String format, String clientId)
            throws TemplateException, IOException {
        log.info("Запрос documentId {} format {} clientId {}", documentId, format, clientId);
        DocumentDTO documentDTO = paymentService.getDocumentByBisId(documentId);
        log.info("Найдено в paymentService.getDocumentByBisId {}", documentDTO);
        if (documentDTO != null) {
            List<OrganizationDTO> organizations = organizationService.getOrganizations(clientId);
            for (OrganizationDTO organization : organizations) {
                var matchForDocumentPayer = accountService.getAccountList(organization.getCrmId(), organization.getBisIds())
                        .stream()
                        .anyMatch(it -> it.getNumber().equals(documentDTO.getPayer().getAccount()));
                if (matchForDocumentPayer) {
                    log.info("Все норм {}", documentDTO);
                    return paymentFormService.generate(documentDTO, format, true);
                }
            }
            throw new AccessForbiddenException("Document doesn't belong");
        } else {
            throw new UnknownDocumentException("Document not found = " + documentId);
        }
    }

    public FileResource getDocumentForm(String documentId, String format, String clientId) throws TemplateException, IOException {

        PaymentDTO paymentDTO = statementService.getPayment(clientId, documentId);

        if (paymentDTO != null) {
            return statementFormService.generate(paymentDTO, format);
        } else {
            DocumentDTO documentDTO = paymentService.getDocument(documentId);
            if (documentDTO != null) {
                List<OrganizationDTO> organizations = organizationService.getOrganizations(clientId);
                for (OrganizationDTO organization : organizations) {
                    var matchForDocumentPayer = accountService.getAccountList(organization.getCrmId(), organization.getBisIds())
                            .stream()
                            .anyMatch(it -> it.getNumber().equals(documentDTO.getPayer().getAccount()));
                    if (matchForDocumentPayer) {
                        return paymentFormService.generate(documentDTO, format, false);
                    }
                }
                throw new AccessForbiddenException("Document doesn't belong");
            } else {
                throw new UnknownDocumentException("Document not found = " + documentId);
            }
        }
    }

    public FileResource getDocumentListPdf(List<String> ids, String clientId) throws IOException, TemplateException {

        StatementPdfMerger statementPdfMerger = new StatementPdfMerger();
        List<String> pdfList = new ArrayList<>();
        for (String id : ids) {
            String pdf = getDocumentForm(id, "pdf", clientId).getContent();
            pdfList.add(pdf);
        }
        String fullPdf;
        if (ids.size() == 1) {
            fullPdf = pdfList.get(0);
        } else {
            for (String pdfBase64 : pdfList) {
                ByteArrayOutputStream baos = null;
                try {
                    byte[] pdf = Base64.getDecoder().decode(pdfBase64);
                    baos = new ByteArrayOutputStream(pdf.length);
                    baos.write(pdf, 0, pdf.length);
                    statementPdfMerger.add(baos);
                } finally {
                    Optional.ofNullable(baos).ifPresent(s -> {
                        try {
                            s.close();
                        } catch (IOException e) {
                            log.error(e.getMessage(), e);
                        }
                    });
                }
            }

            fullPdf = new String(Base64.getEncoder().encode(statementPdfMerger.process().toByteArray()));
        }

        FileResource fileResource = new FileResource();
        fileResource.setContent(fullPdf);
        fileResource.setContentType(FileResource.ContentTypeEnum.PDF);
        fileResource.setName("documents");
        return fileResource;
    }

}
