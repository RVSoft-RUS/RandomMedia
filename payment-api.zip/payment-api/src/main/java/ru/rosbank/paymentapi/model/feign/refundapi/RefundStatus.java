package ru.rosbank.paymentapi.model.feign.refundapi;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Статус операции возврата.
 */

public enum RefundStatus {

    CREATED("CREATED"),

    CONFIRMED("CONFIRMED"),

    PROCESSING("PROCESSING"),

    COMPLETED("COMPLETED"),

    FAILED("FAILED"),

    SUSPEND("SUSPEND");

    private String value;

    RefundStatus(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    @JsonCreator
    public static RefundStatus fromValue(String value) {
        for (RefundStatus b : RefundStatus.values()) {
            if (b.value.equals(value)) {
                return b;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
}

