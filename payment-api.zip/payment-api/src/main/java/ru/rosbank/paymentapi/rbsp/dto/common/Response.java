package ru.rosbank.paymentapi.rbsp.dto.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.Strings;
import lombok.Data;


/**
 * DTO успешной или ожидаемо неуспешной обработки запроса.
 *
 * @param <D> класс, являющийся полезной нагрузкой ответа.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response<D> {
    /**
     * Расширенная информация по статусу обработки запроса.
     */
    protected ResponseMetaData result;

    /**
     * Полезная нагрузка ответа.
     */
    protected D data;

    public Response(ResponseMetaData result, D data) {
        this.result = result;
        this.data = data;
    }

}