package ru.rosbank.paymentapi.services.integration;

import static ru.rosbank.platform.client.rolesapp.model.IndividualDTO.AccessGroupEnum.BLOCK;
import static ru.rosbank.platform.client.rolesapp.model.IndividualDTO.AccessGroupEnum.NO_RIGHTS;

import feign.FeignException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApi;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;

@Slf4j
@Service
@RequiredArgsConstructor
public class RolesService {

    public static final String REPRESENTATIVE_TYPE = "Representative";
    public static final String ACCOUNT_MANAGER_TYPE = "Account Management";

    private final RolesAppApi rolesAppApi;

    public IndividualDTO getIndividual(String organizationId, String clientId) {

        try {

            return Optional.ofNullable(rolesAppApi.idGet(organizationId, clientId)).map(ResponseEntity::getBody)
                    .orElse(new ArrayList<>()).stream()
                    .filter(individual -> individual.getDboProId().equals(clientId))
                    .findFirst()
                    .orElse(null);

        } catch (FeignException e) {
            log.error("Ошибка получения списка ролей roles-app, dbo_pro_id = {}", clientId, e);
            return null;
        }

    }

    public static boolean checkAccessGroup(IndividualDTO individual) {
        IndividualDTO.AccessGroupEnum group = individual.getAccessGroup();
        return !(group == null || Arrays.asList(NO_RIGHTS, BLOCK).contains(group));
    }

    public static boolean isActive(IndividualDTO individual) {
        LocalDate now = LocalDate.now();
        return (now.isAfter(individual.getAccessDate()) || now.equals(individual.getAccessDate()))
                && (individual.getAccessValidPeriod() == null
                || (now.isBefore(individual.getAccessValidPeriod()) || now.equals(individual.getAccessValidPeriod())));
    }

    public List<IndividualDTO> getIndividuals(String organizationId, String clientId) {

        try {
            return Optional.ofNullable(rolesAppApi.idGet(organizationId, clientId)).map(ResponseEntity::getBody)
                    .orElse(new ArrayList<>());
        } catch (Exception e) {
            log.error("Ошибка получения списка ролей roles-app, dbo_pro_id = {}", clientId, e);
            return new ArrayList<>();
        }

    }

    public List<IndividualDTO> getActiveIndividuals(String organizationId, String clientId) {
        return getIndividuals(organizationId, clientId).stream().filter(RolesService::isActive)
                .filter(RolesService::checkAccessGroup).collect(Collectors.toList());
    }

    public boolean isActiveIndividual(String organizationId, String clientId) {
        return getActiveIndividuals(organizationId, clientId).size() > 0;
    }

    public boolean isAccountManagerOrRepresentative(IndividualDTO individual) {
        return (REPRESENTATIVE_TYPE.equals(individual.getRelationType())
                || ACCOUNT_MANAGER_TYPE.equals(individual.getRelationType()));
    }
}
