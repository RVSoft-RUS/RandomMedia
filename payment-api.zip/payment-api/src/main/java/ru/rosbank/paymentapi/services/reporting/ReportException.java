package ru.rosbank.paymentapi.services.reporting;

/**
 * Исключение, выбрасываемое при ошибках генерации отчетов.
 *
 * @author rb066284
 */
public class ReportException extends RuntimeException {

    public ReportException() {
    }

    public ReportException(String message) {
        super(message);
    }

    public ReportException(String message, Throwable cause) {
        super(message, cause);
    }

    public ReportException(Throwable cause) {
        super(cause);
    }
}
