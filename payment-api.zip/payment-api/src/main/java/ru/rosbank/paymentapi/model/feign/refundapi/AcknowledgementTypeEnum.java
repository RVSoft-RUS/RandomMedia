package ru.rosbank.paymentapi.model.feign.refundapi;

public enum AcknowledgementTypeEnum {

    CONFIRM("CONFIRM"),

    CANCEL("CANCEL");

    private String value;

    AcknowledgementTypeEnum(String value) {
        this.value = value;
    }

}