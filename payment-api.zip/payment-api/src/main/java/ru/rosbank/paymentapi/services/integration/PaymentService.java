package ru.rosbank.paymentapi.services.integration;

import static org.apache.commons.lang3.ObjectUtils.isEmpty;
import static org.apache.commons.lang3.ObjectUtils.isNotEmpty;
import static ru.rosbank.paymentapi.util.FormatUtils.masqueradePhoneNumber;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.exception.DocumentSignException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.mapper.DocumentNextInfoMapper;
import ru.rosbank.paymentapi.mapper.DocumentSendRequestMapper;
import ru.rosbank.paymentapi.mapper.FileResourceMapper;
import ru.rosbank.paymentapi.services.AuditService;
import ru.rosbank.paymentapi.services.signature.DocumentSigner;
import ru.rosbank.paymentapi.services.validator.DocumentBalanceValidator;
import ru.rosbank.paymentapi.services.validator.DocumentPackageValidator;
import ru.rosbank.paymentapi.util.OrganizationAcc;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.auditapp.model.EventDTO;
import ru.rosbank.platform.client.auditapp.model.PaymentEventDTO;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.otpapp.api.OtpAppApi;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;
import ru.rosbank.platform.client.paymentapp.model.ErrorDTO;
import ru.rosbank.platform.client.paymentapp.model.MetaDataDTO;
import ru.rosbank.platform.server.paymentapi.model.Confirmation;
import ru.rosbank.platform.server.paymentapi.model.DocumentSendRequestApi;
import ru.rosbank.platform.server.paymentapi.model.FileResource;
import ru.rosbank.platform.server.paymentapi.model.NextDocumentInfo;
import ru.rosbank.platform.server.paymentapi.model.SignDocumentRequest;
import ru.rosbank.platform.server.paymentapi.model.SignDocumentResponse;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {
    private static final String DEFAULT_LIMIT = "9999";
    private static final String DEFAULT_OFFSET = "0";
    private static final String PACKAGE_SIGNATURE_REF_TYPE = "PACKAGE_SIGNATURE";
    private static final String DBOPRO_INITIATOR = "DBOPRO";
    @Value("${batch.size.signed-document: 50}")
    private int batchSize;
    @Qualifier("signedDocumentExecutorService")
    private final ExecutorService signedDocumentExecutorService;

    private final PaymentAppApi paymentAppApi;
    private final DocumentPackageValidator documentPackageValidator;
    private final DocumentSigner documentSigner;
    private final UserService userService;
    private final OtpService otpService;
    private final OrganizationService organizationService;
    private final AccountService accountService;
    private final DocumentNextInfoMapper documentNextInfoMapper;
    private final FileResourceMapper fileResourceMapper;
    private final ProductService productService;
    private final DocumentSendRequestMapper documentSendRequestMapper;
    private final CryptoproAppApi cryptoproAppApi;
    private final AuditService auditService;
    private final CounteragentService counteragentService;
    private final OtpAppApi otpAppApi;

    public List<DocumentDTO> getPaymentList(List<String> accList, OffsetDateTime from, OffsetDateTime to,
                                            List<DocumentStatusDTO> statuses) {
        try {
            return paymentAppApi.documentGet(accList, parseDate(from), parseDate(to),
                    DEFAULT_LIMIT, DEFAULT_OFFSET, null, statuses).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения списка платежей payment-app ", e);
            return Collections.emptyList();
        }
    }

    public DocumentDTO createPayment(DocumentDTO documentDTO) {
        try {
            return Optional.ofNullable(paymentAppApi.documentPost(documentDTO)).map(ResponseEntity::getBody).orElse(null);
        } catch (FeignException e) {
            throwValidationException(e);
            log.error("Ошибка создания платежа payment-app {}", documentDTO.toString(), e);
            return null;
        }
    }

    public DocumentDTO updatePayment(String documentId, DocumentDTO documentDTO) {
        try {
            return Optional.ofNullable(paymentAppApi.documentIdPost(documentId, documentDTO)).map(ResponseEntity::getBody)
                    .orElse(null);
        } catch (FeignException e) {
            throwValidationException(e);
            log.error("Ошибка изменения платежа payment-app {}", documentDTO.toString(), e);
            return null;
        }
    }

    public DocumentDTO getDocument(String documentId) {
        try {
            return Optional.ofNullable(paymentAppApi.documentIdGet(documentId)).map(ResponseEntity::getBody).orElse(null);
        } catch (FeignException e) {
            log.error("Ошибка получения платежа payment-app {}", documentId, e);
            return null;
        }
    }

    public DocumentDTO getDocumentByBisId(String documentId) {
        try {
            return Optional.ofNullable(paymentAppApi.refferenceIdGet(documentId)).map(ResponseEntity::getBody).orElse(null);
        } catch (FeignException e) {
            log.error("Ошибка получения платежа payment-app {}", documentId, e);
            return null;
        }
    }

    public SignDocumentResponse batchSign(SignDocumentRequest request, String dboProId) {

        if (isEmpty(request.getDocumentIds()) && StringUtils.isBlank(request.getImportedBatchId())) {
            throw new IllegalArgumentException("Требуется список документов или идентификатор пачки импортированных документов");
        }

        List<DocumentDTO> documents = getDocumentsForSignature(request.getDocumentIds(), request.getImportedBatchId(), dboProId);
        var user = userService.getUser(dboProId);
        var accountNumber20 = DocumentPackageValidator.getPayerAccountFromDocumentPackage(documents);
        var organizationAcc = productService.getOrganizationAccByAccNumberAndDboProId(accountNumber20, dboProId);

        if (organizationAcc.getOrg() == null || organizationAcc.getAccounts() == null) {
            throw new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен");
        }
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        organizationAcc.getAccounts().forEach(a -> accountsMap.put(a.getNumber(), a));
        documentPackageValidator.validate(documents, user, organizationAcc.getOrg(), accountsMap);

        List<DocumentDTO> validDocuments = documentPackageValidator.filterValidDocuments(documents, accountsMap);
        if (validDocuments.isEmpty()) {
            throw new ValidationException("Не удалось подписать документы");
        }
        OtpDTO otp = documentSigner.sign(user, validDocuments);
        if (otp == null) {
            throw new DocumentSignException("Не удалось подписать документ");
        }

        var response = new SignDocumentResponse();
        response.setConfirmation(new Confirmation()
                .id(otp.getId())
                .type(Confirmation.TypeEnum.SMS)
                .attempts(otp.getAttempts())
                .message(masqueradePhoneNumber(user.getPhone()))
                .expiresIn(otpService.getExpireMilliSeconds(otp).intValue()));
        if (documents.size() > validDocuments.size()) {
            response.setRejectedIds(documents.stream()
                    .map(DocumentDTO::getId)
                    .filter(id -> validDocuments.stream().noneMatch(v -> v.getId().equals(id)))
                    .map(String::valueOf)
                    .collect(Collectors.toList()));
        }
        return response;
    }

    private List<DocumentDTO> getDocumentsForSignature(List<String> documentIds, String importedBatchId, String clientId) {
        if (isNotEmpty(documentIds)) {
            return documentIds.stream()
                    .map(paymentAppApi::documentIdGet)
                    .map(ResponseEntity::getBody)
                    .collect(Collectors.toList());
        } else {
            return paymentAppApi.importedDocumentsGet(importedBatchId, clientId).getBody();
        }

    }

    private String parseDate(OffsetDateTime date) {
        return date.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime().toString();
    }

    void throwValidationException(FeignException e) {
        e.responseBody().ifPresent(byteBuffer -> {
            String error = new String(byteBuffer.array(), StandardCharsets.UTF_8);
            ErrorDTO errorDTO;
            try {
                errorDTO = new ObjectMapper().readValue(error, ErrorDTO.class);
            } catch (JsonProcessingException jsonProcessingException) {
                log.error(e.getMessage(), e);
                return;
            }
            if (ErrorDTO.TypeEnum.VALIDATION_ERROR.equals(errorDTO.getType())) {
                throw new ValidationPaymentException(errorDTO.getMessage());
            }
        });
    }

    public OffsetDateTime getDocumentTestOperDateGet() {
        try {
            return paymentAppApi.documentTestOperDateGet().getBody();
        } catch (Exception e) {
            return OffsetDateTime.now();
        }
    }

    public void markDocumentsAsCompleted(List<String> bisDocumentIds) {
        paymentAppApi.documentsComplete(bisDocumentIds);
    }

    public NextDocumentInfo getNextDocumentInfo(String dboProId, String organizationId) {
        var user = userService.getUser(dboProId);
        var availableOrganizations = organizationService.getAvailableOrganizationListByClient(user);
        var noOrganizationIdMatch = availableOrganizations.stream().noneMatch(org -> org.getCrmId().equals(organizationId));
        var accountNumbers = availableOrganizations.stream()
                .filter(org -> noOrganizationIdMatch || org.getCrmId().equals(organizationId))
                .flatMap(org -> accountService.getCustomerAccountListEsb(org).stream())
                .map(AccountDTO::getNumber)
                .collect(Collectors.toList());
        try {
            return documentNextInfoMapper.fromDto(paymentAppApi.documentNextInfoGet(accountNumbers).getBody());
        } catch (FeignException e) {
            log.error("Ошибка получения информации о создаваемом документе payment-app {}", accountNumbers, e);
            return null;
        }
    }

    public void deleteDocument(String documentId) {
        paymentAppApi.documentIdDelete(documentId);
    }

    public FileResource getDeliveringResource(String id) {
        return fileResourceMapper.appToApiFileResource(paymentAppApi.deliveringResourceIdGet(id).getBody());
    }

    public void sendDocument(DocumentSendRequestApi request, String dboProId) {
        paymentAppApi.documentSendPost(documentSendRequestMapper.apiToAppDocumentSendRequest(request, dboProId));
    }

    public Integer getSignedDocumentCount(List<Long> documentIds) {
        if (CollectionUtils.isNotEmpty(documentIds)) {
            try {
                List<CompletableFuture<Integer>> futures = new ArrayList<>();
                List<List<Long>> batches = ListUtils.partition(documentIds, batchSize);
                for (List<Long> batch : batches) {
                    CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {
                        try {
                            return paymentAppApi.documentSignedCountGet(batch).getBody();
                        } catch (Exception e) {
                            log.error("Error executing batch getSignedDocumentCount request {}", batch, e);
                            return 0;
                        }
                    }, signedDocumentExecutorService);
                    futures.add(future);
                }
                return futures.stream()
                        .map(CompletableFuture::join)
                        .mapToInt(i -> i)
                        .sum();
            } catch (Exception e) {
                log.error("Error getSignedDocumentCount for {}", documentIds, e);
            }
        }
        return 0;
    }

    public void batchSignPackageSignatureIdExecute(String otpUUID, String dboProId) {
        OtpDTO otp;
        try {
            otp = otpAppApi.idGet(otpUUID).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения otp {} ", otpUUID, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        String packageSignatureId = otp.getReference();
        List<SignatureDTO> signatures;
        try {
            signatures = cryptoproAppApi.packagesignatureIdsignatureGet(packageSignatureId).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения подписей по идентификатору пакета {} ", packageSignatureId, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        signatures = signatures.stream().filter(SignatureDTO::getConfirmed).collect(Collectors.toList());
        List<Long> documentIds = signatures.stream()
                .map(signature -> Long.parseLong(signature.getReference().getId()))
                .collect(Collectors.toList());
        var documents = new ArrayList<DocumentDTO>();
        AtomicReference<OrganizationAcc> orgAcc = new AtomicReference<>();
        AtomicReference<AccountDTO> account = new AtomicReference<>();
        if (documentIds.size() > 0) {
            for (Long documentId: documentIds) {
                DocumentDTO documentDTO = null;
                try {
                    documentDTO = paymentAppApi.documentIdGet(String.valueOf(documentId)).getBody();
                    String acc = documentDTO.getPayer().getAccount();
                    if (orgAcc.get() == null) {
                        orgAcc.set(productService.getOrganizationAccByAccNumberAndDboProId(acc,
                                dboProId));
                    }
                    if (account.get() == null) {
                        account.set(orgAcc.get().getAccounts().stream().filter(a -> acc.equals(a.getNumber()))
                                .findFirst().orElseThrow(() ->
                                        new BankInfoException("Ошибка получения счета = " + acc)));
                    }

                    paymentAppApi.documentIdSignPost(documentDTO.getId().toString(),
                            new MetaDataDTO().dateSignature(OffsetDateTime.now()).dboProId(dboProId)
                                    .crmId(orgAcc.get().getOrg().getCrmId())
                                    .bisId(new BisIdDTO().id(account.get().getBisId().getId())
                                            .branch(account.get().getBisId().getBranch()))
                                    .shortNameOrg(orgAcc.get().getOrg().getShortName()));

                    auditService.logPaymentEvent(documentDTO, dboProId, PaymentEventDTO.EventEnum.SIGN);
                    documents.add(documentDTO);
                } catch (Exception e) {
                    log.error("Error processing documentDTO with id {}",
                            documentDTO != null ? documentDTO.getId() : "null", e);
                }
            }
            auditService.sendEvent(new EventDTO().dboProId(dboProId).initiator(DBOPRO_INITIATOR)
                    .stage("Пакет документов подписан"));
            if (!DocumentBalanceValidator.validateBalance(documents, account.get())) {
                auditService.sendEvent(new EventDTO().referenceType(PACKAGE_SIGNATURE_REF_TYPE).reference(packageSignatureId)
                        .message(Integer.toString(documents.size())).stage("Подписание платежей с превышением остатка 1")
                        .dboProId(dboProId).initiator("USER"));
            }
            counteragentService.saveOrUpdateCounteragent(documents);
        }



    }
}
