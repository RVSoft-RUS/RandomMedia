package ru.rosbank.paymentapi.services.onec;


import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Parser of document_date in 1C.
 * @author rb197115
 */
public class DocumentDateParser1C extends AbstractDocumentFieldParser1C {
    private static final String DOCUMENT_DATE_KEY = "Дата";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final int MOSCOW_OFFSET = 3;

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            document.setDate(OffsetDateTime.of(
                    LocalDate.parse(
                            getValueFromLine(line), DATE_FORMATTER
                    ).atStartOfDay(), ZoneOffset.ofHours(MOSCOW_OFFSET)
            ));
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, DOCUMENT_DATE_KEY);
    }
}
