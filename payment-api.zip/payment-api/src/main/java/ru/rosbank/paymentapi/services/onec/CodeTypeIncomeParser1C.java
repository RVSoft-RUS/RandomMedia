package ru.rosbank.paymentapi.services.onec;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class CodeTypeIncomeParser1C extends AbstractDocumentFieldParser1C {
    private static final String CODE_TYPE_INCOME_KEY = "КодНазПлатежа";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        if (isMatch(line)) {
            String codeTypeIncomeString = getValueFromLine(line);
            if (isNotBlank(codeTypeIncomeString)) {
                document.setCodeTypeIncome(codeTypeIncomeString);
            }
        }
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, CODE_TYPE_INCOME_KEY);
    }
}
