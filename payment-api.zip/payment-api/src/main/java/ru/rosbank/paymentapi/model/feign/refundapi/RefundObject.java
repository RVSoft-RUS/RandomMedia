package ru.rosbank.paymentapi.model.feign.refundapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Результат обработки запроса на возврат оплаты.
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefundObject {

    private RefundStatus status;

}

