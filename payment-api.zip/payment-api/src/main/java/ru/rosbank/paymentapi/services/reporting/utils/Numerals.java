package ru.rosbank.paymentapi.services.reporting.utils;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Класс содержащий вспомогательные методы для работы с переводом чисел в текстовое представление.
 *
 * @author Q-YAA
 * @author Q-ONA
 */
public class Numerals {

    private static final RussianNumeral NUMERAL = new RussianNumeral();

    /**
     * Переводит переданное целое число в текстовое представление.
     *
     * @param number целое число
     * @return String целое число в текстовом представлении
     */
    public static String spellNumber(BigInteger number) {
        return NUMERAL.spellNumber(number);
    }

    /**
     * Переводит переданную денежную сумму в текстовое представление.
     *
     * @param sum      значение денежной суммы суммы
     * @param currency трёхсимвольный код валюты (RUR, USD и т.п.)
     * @return String денежная сумма в текстовом представлении
     */
    public static String spellAmount(BigDecimal sum, String currency) {
        return NUMERAL.spellAmount(sum, currency);
    }

}
