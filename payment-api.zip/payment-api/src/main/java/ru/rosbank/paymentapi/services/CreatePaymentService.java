package ru.rosbank.paymentapi.services;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static ru.rosbank.paymentapi.commons.Constants.NOT_ENOUGH_RIGHTS_ERROR;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.audit.AuditContext;
import ru.rosbank.paymentapi.audit.ThreadLocalAuditContext;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.paymentapi.services.integration.PaymentService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.paymentapi.services.integration.RolesService;
import ru.rosbank.paymentapi.services.integration.UserService;
import ru.rosbank.paymentapi.services.validator.DocumentValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentBudgetFieldsValidator;
import ru.rosbank.paymentapi.services.validator.field.DocumentPayerBankValidator;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.model.BisIdDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.RequisiteDTO;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;

@Slf4j
@Service
@RequiredArgsConstructor
public class CreatePaymentService {
    public static final String USER_REQUEST_DELETE_DOCUMENT = "Удаление платёжного документа";

    private static final List<String> PAYER_STATUS_FOR_NATURAL_PERSONS = Arrays.asList("19");

    private final PaymentService paymentService;
    private final UserService userService;
    private final RolesService rolesService;
    private final DocumentToPaymentConverter converter;
    private final PermissionService permissionService;
    private final OrganizationService organizationService;
    private final DocumentValidator documentValidator;
    private final DocumentPayerBankValidator payerBankValidator;
    private final DocumentBudgetFieldsValidator documentBudgetFieldsValidator;
    private final ProductService productService;


    public DocumentDTO upsert(Payment payment, String clientId) {
        String accountNumber20 = Optional.ofNullable(payment).map(Payment::getPayer).map(Requisite::getAccount).orElse(null);

        if (isBlank(accountNumber20) || payment == null) {
            throw new ValidationPaymentException(NOT_ENOUGH_RIGHTS_ERROR);
        }

        var organizationAcc = productService.getOrganizationAccByAccNumberAndDboProId(accountNumber20, clientId);
        AuditContext auditContext = ThreadLocalAuditContext.get();
        auditContext.setCrmCompanyId(organizationAcc.getOrg().getCrmId());
        auditContext.setCompanyInn(organizationAcc.getOrg().getInn());
        auditContext.setCompanyName(organizationAcc.getOrg().getShortName());
        organizationAcc.getOrg().getBisIds().stream().findFirst()
                .ifPresent(id -> auditContext.setBisCompanyId(id.getBranch() + id.getId()));
        ThreadLocalAuditContext.set(auditContext);

        IndividualDTO individualDTO = rolesService.getIndividual(organizationAcc.getOrg().getCrmId(), clientId);

        permissionService.checkCreatePaymentPermissions(individualDTO);

        List<AccountDTO> accounts = organizationAcc.getAccounts();
        Map<String, AccountDTO> accountsMap = new HashMap<>();
        accounts.forEach(a -> accountsMap.put(a.getNumber(), a));
        var accountOpt = accounts.stream().filter(a -> accountNumber20.equals(a.getNumber())).findFirst();
        if (organizationAcc.getOrg() == null || accounts == null || accountOpt.isEmpty()) {
            throw new ValidationPaymentException(17, "payer_account", "Сервис платежей недоступен");
        }
        var accountDTO = accountOpt.get();

        DocumentDTO documentDTO = converter.convertBack(payment, accountDTO);

        if (StringUtils.isBlank(documentDTO.getPayer().getKpp()) || "0".equals(documentDTO.getPayer().getKpp())) {
            setPayerKppFromOrganization(documentDTO, organizationAcc.getOrg());
        }

        documentDTO.setBisId(new BisIdDTO().id(accountDTO.getBisId().getId()).branch(accountDTO.getBisId().getBranch()));
        documentDTO.setCrmId(organizationAcc.getOrg().getCrmId());

        payerBankValidator.validate(documentDTO, accountDTO.getBisId().getBranch());
        // TODO validation
        documentValidator.validate(documentDTO, accountsMap);
        validateIfBudgetPayment(documentDTO);

        ClientDTO clientDTO = userService.getUser(clientId);
        if (clientDTO == null) {
            log.error("client with dbo_pro_id = {} not found!", clientId);
            return null;
        }
        documentDTO.setClientId(clientDTO.getLegacyId());
        return documentDTO;
    }

    public Payment updatePayment(Payment payment, String clientId) {
        DocumentDTO documentDTO = upsert(payment, clientId);

        return Optional.ofNullable(paymentService.updatePayment(String.valueOf(documentDTO.getId()), documentDTO))
                .map(converter::convert)
                .orElse(null);

    }

    public Payment createPayment(Payment payment, String clientId) throws ValidationPaymentException {

        DocumentDTO documentDTO = upsert(payment, clientId);

        return Optional.ofNullable(paymentService.createPayment(documentDTO)).map(converter::convert)
                .orElse(null);

    }

    private void validateIfBudgetPayment(DocumentDTO documentDTO) {
        if (documentDTO != null && DocumentDTO.TypeEnum.DE != documentDTO.getType()) {
            documentBudgetFieldsValidator.validate(documentDTO);
        }
    }

    void setPayerKppFromOrganization(DocumentDTO documentDTO, OrganizationDTO organizationDTO) {
        int innLength = Optional.ofNullable(documentDTO).map(DocumentDTO::getPayer).map(RequisiteDTO::getInn)
                .map(String::length).orElse(0);
        if ((innLength == 10 || innLength == 5)
                && !PAYER_STATUS_FOR_NATURAL_PERSONS.contains(
                        Optional.ofNullable(documentDTO).map(DocumentDTO::getPayerStatus).orElse(""))) {
            Optional.ofNullable(documentDTO).map(DocumentDTO::getPayer).orElse(new RequisiteDTO())
                    .setKpp(organizationDTO.getKpp());
        } else {
            Optional.ofNullable(documentDTO).map(DocumentDTO::getPayer).orElse(new RequisiteDTO()).setKpp("0");
        }
    }

    public void deleteDocument(String documentId, String clientId) {
        DocumentDTO documentDTO = paymentService.getDocument(documentId);
        OrganizationDTO organizationDTO = organizationService.getOrganizations(clientId).stream()
                .filter(o -> o.getCrmId().equals(documentDTO.getCrmId())).findAny()
                .orElseThrow(() -> new ValidationPaymentException(NOT_ENOUGH_RIGHTS_ERROR));
        IndividualDTO individualDTO = rolesService.getIndividual(organizationDTO.getCrmId(), clientId);

        permissionService.checkCreatePaymentPermissions(individualDTO);

        paymentService.deleteDocument(documentId);
    }

}
