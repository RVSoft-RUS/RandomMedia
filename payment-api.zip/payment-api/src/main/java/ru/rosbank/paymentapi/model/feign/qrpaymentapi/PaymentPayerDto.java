package ru.rosbank.paymentapi.model.feign.qrpaymentapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Информация о плательщике по покупке СБП (физ. лице).
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentPayerDto {

    private String bankBic;
    private String bankId;
    private String id;
    private String idType;
    private String accountNumber;

}

