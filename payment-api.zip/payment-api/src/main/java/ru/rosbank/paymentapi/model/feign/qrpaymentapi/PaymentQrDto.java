package ru.rosbank.paymentapi.model.feign.qrpaymentapi;

import java.time.OffsetDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * Информация о покупке по СБП.
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentQrDto {

    private String qrId;
    private String id;
    private String bisReference;
    private String amount;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private OffsetDateTime date;

}

