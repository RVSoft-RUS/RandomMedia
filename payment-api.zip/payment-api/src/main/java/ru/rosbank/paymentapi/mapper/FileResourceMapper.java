package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;
import ru.rosbank.platform.client.paymentapp.model.FileResourceDTO;
import ru.rosbank.platform.server.paymentapi.model.FileResource;

@Mapper(componentModel = "spring")
public interface FileResourceMapper {
    @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.NULL)
    FileResource appToApiFileResource(FileResourceDTO appDTO);
}
