package ru.rosbank.paymentapi.services.integration;

import static ru.rosbank.paymentapi.commons.Constants.NOT_ENOUGH_RIGHTS_ERROR;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.BankInfoException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.util.OrganizationAcc;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.model.BisIdDTO;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;

@Slf4j
@RequiredArgsConstructor
@Service
public class ProductService {
    private final AccountService accountService;
    private final OrganizationService organizationService;

    public BigDecimal getAccountBalance(String accountNumber, String dboProId) {
        try {
            AccountDTO account = getAccount(accountNumber, dboProId);

            return account == null ? null : new BigDecimal(account.getRestAmount());
        } catch (Exception ex) {
            log.error("Ошибка получения баланса", ex);
            return null;
        }
    }

    public AccountDTO getAccount(String accountNumber, String dboProId) {
        if (StringUtils.isBlank(accountNumber)) {
            throw new BankInfoException("Ошибка получения счета = " + accountNumber);
        }
        try {
            List<OrganizationDTO> organizationList = organizationService.getOrganizations(dboProId);
            List<AccountDTO> accounts = accountService.getAccountsAsync(organizationList);

            return accounts.stream().filter(a -> accountNumber.equals(a.getNumber())).findFirst().orElseThrow(() ->
                    new BankInfoException("Ошибка получения счета = " + accountNumber));
        } catch (Exception ex) {
            log.error("Ошибка получения счета = " + accountNumber, ex);
            throw ex;
        }
    }

    public Optional<OrganizationDTO> getOrganizationByAccNumberAndDboProId(String payerAccount, String dboProId) {
        return Optional.of(getOrganizationAccByAccNumberAndDboProId(payerAccount, dboProId).getOrg());
    }

    public OrganizationAcc getOrganizationAccByAccNumberAndDboProId(String payerAccount, String dboProId) {
        List<OrganizationDTO> organizationList = organizationService.getOrganizations(dboProId);
        Map<String, List<AccountDTO>> crmIdAccountMap = getAccounts(organizationList);

        for (String crmId : crmIdAccountMap.keySet()) {
            List<AccountDTO> accounts = crmIdAccountMap.get(crmId);
            if (accounts.stream().anyMatch(accountDTO -> accountDTO.getNumber().equals(payerAccount))) {
                Optional<OrganizationDTO> optOrg = organizationList.stream()
                        .filter(organizationDTO -> organizationDTO.getCrmId().equals(crmId))
                        .findFirst();
                if (optOrg.isPresent()) {
                    OrganizationAcc orgAcc = new OrganizationAcc();
                    orgAcc.setOrg(optOrg.get());
                    orgAcc.setAccounts(accounts);
                    return orgAcc;
                }
            }
        }
        throw new ValidationException(NOT_ENOUGH_RIGHTS_ERROR);
    }

    public Map<String, List<AccountDTO>> getAccounts(List<OrganizationDTO> organizationList) {
        return accountService.getMapCrmIdAndAccountsAsync(organizationList);
    }

    public Map<String, List<AccountDTO>> getAccounts(String dboProId) {
        List<OrganizationDTO> organizationList = organizationService.getOrganizations(dboProId);
        return getAccounts(organizationList);
    }

    public Optional<OrganizationDTO> getOrganizationByAccAndDboProId(String dboProId, AccountDTO accountNumber) {
        List<OrganizationDTO> organizations = organizationService.getOrganizations(dboProId);
        assert organizations != null;

        for (OrganizationDTO organizationDTO : organizations) {
            for (BisIdDTO bisId : organizationDTO.getBisIds()) {
                if (bisId.getId().equals(accountNumber.getBisId().getId())) {
                    return Optional.of(organizationDTO);
                }
            }
        }
        return Optional.empty();
    }
}
