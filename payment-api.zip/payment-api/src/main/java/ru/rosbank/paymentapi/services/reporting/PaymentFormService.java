package ru.rosbank.paymentapi.services.reporting;

import freemarker.template.TemplateException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import ru.rosbank.paymentapi.commons.PaymentUtils;
import ru.rosbank.paymentapi.exception.UnknownDocumentException;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.server.paymentapi.model.FileResource;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentFormService {

    public FileResource generate(DocumentDTO documentDTO, String format, boolean isPDSN) throws TemplateException, IOException {
        String template = getTemplate(documentDTO, isPDSN);
        log.info("format: {}", format);
        log.info("generated template: {}", new String(generateHtmlForm(documentDTO, template)));
        var fileResource = new FileResource();
        if ("html".equals(format)) {
            fileResource.setContent(new String(Base64.getEncoder().encode(
                    generateHtmlForm(documentDTO, template))));
            fileResource.setContentType(FileResource.ContentTypeEnum.HTML);
            fileResource.setName(documentDTO.getNumber() + ".html");
        } else if ("pdf".equals(format)) {
            fileResource.setContent(new String(Base64.getEncoder().encode(
                    generatePdfForm(documentDTO, template).toByteArray())));
            fileResource.setContentType(FileResource.ContentTypeEnum.PDF);
            fileResource.setName(documentDTO.getNumber() + ".pdf");
        } else {
            throw new UnknownDocumentException("Wrong format = " + format);
        }

        return fileResource;

    }

    public byte[] generateHtmlForm(DocumentDTO documentDTO, String template) throws TemplateException, IOException {
        var configurationFactoryBean = new FreeMarkerConfigurationFactoryBean();
        configurationFactoryBean.setPreferFileSystemAccess(false);
        configurationFactoryBean.setDefaultEncoding("UTF-8");

        PaymentFormGenerator reportService = new PaymentFormGenerator(configurationFactoryBean.createConfiguration());
        return reportService.generateHtml(documentDTO, template).getBytes(StandardCharsets.UTF_8);

    }

    public ByteArrayOutputStream generatePdfForm(DocumentDTO documentDTO, String template) throws TemplateException, IOException {
        var configurationFactoryBean = new FreeMarkerConfigurationFactoryBean();
        configurationFactoryBean.setPreferFileSystemAccess(false);
        configurationFactoryBean.setDefaultEncoding("UTF-8");

        PaymentFormGenerator reportService = new PaymentFormGenerator(configurationFactoryBean.createConfiguration());
        return (ByteArrayOutputStream) reportService.generatePdf(documentDTO, template);
    }

    public String getTemplate(DocumentDTO documentDTO, boolean isPDSN) {
        if (isPDSN) {
            return "paymentAssignmentPDSN.html.ftl";
        }
        if (PaymentUtils.isRejectedOrRecalled(documentDTO)) {
            return "paymentAssignmentWithComment.html.ftl";
        } else {
            return "paymentAssignment.html.ftl";
        }
    }

}
