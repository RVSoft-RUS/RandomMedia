package ru.rosbank.paymentapi.audit;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class RequestAuditFilter implements Filter {

    public static final String IP = "ip";
    public static final String DEVICE_ID = "device-id";
    public static final String OS = "os";
    public static final String MACADDRESS = "macaddress";
    public static final String SESSION_ID = "session-id";
    public static final String USER_AGENT = "User-Agent";
    public static final String APP_VERSION = "app-version";
    public static final String DEVICE = "device";
    public static final String MODEL = "model";
    public static final String MAN = "man";

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response, FilterChain chain) throws IOException, ServletException {
        AuditContext context = createAuditContext((HttpServletRequest) request);
        ThreadLocalAuditContext.set(context);
        chain.doFilter(request, response);
    }

    private AuditContext createAuditContext(HttpServletRequest request) {

        AuditContext auditContext = new AuditContext();
        auditContext.setSessionId(request.getHeader(SESSION_ID));
        auditContext.setDeviceId(request.getHeader(DEVICE_ID));
        auditContext.setIp(request.getHeader(IP));
        auditContext.setUserAgent(request.getHeader(USER_AGENT));
        auditContext.setPlatform(request.getHeader(OS));
        auditContext.setApplicationVersion(request.getHeader(APP_VERSION));
        auditContext.setServerId(request.getServerName());
        auditContext.setMacAddress(request.getHeader(MACADDRESS));
        fillFromDevice(request.getHeader(DEVICE), auditContext);
        return auditContext;
    }

    void fillFromDevice(String device, AuditContext auditContext) {
        if (StringUtils.isBlank(device) || auditContext == null) {
            return;
        }
        try {
            JSONObject jsonObject = new JSONObject(device);
            auditContext.setOs(jsonObject.getString(OS));
            auditContext.setModel(jsonObject.getString(MODEL));
            auditContext.setMan(jsonObject.getString(MAN));
        } catch (Exception e) {
            log.error(e.getMessage() + "; device = " + device, e);
        }


    }
}
