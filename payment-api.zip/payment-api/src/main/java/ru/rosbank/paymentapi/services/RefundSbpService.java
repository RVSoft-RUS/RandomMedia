package ru.rosbank.paymentapi.services;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.params.SetParams;
import ru.rosbank.paymentapi.exception.IncorrectRefundStatusException;
import ru.rosbank.paymentapi.exception.IncorrectResponseException;
import ru.rosbank.paymentapi.exception.InvalidOrganizationException;
import ru.rosbank.paymentapi.exception.NoRightsException;
import ru.rosbank.paymentapi.feign.QrPaymentApiFeignClient;
import ru.rosbank.paymentapi.feign.RefundApiFeignClient;
import ru.rosbank.paymentapi.mapper.RefundDataMapper;
import ru.rosbank.paymentapi.model.IdempotenceData;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoDto;
import ru.rosbank.paymentapi.model.feign.qrpaymentapi.QrInfoResponse;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundData;
import ru.rosbank.paymentapi.model.feign.refundapi.RefundStatus;
import ru.rosbank.paymentapi.model.feign.refundapi.WebResponseCreateRefundResponse;
import ru.rosbank.paymentapi.model.feign.refundapi.WebResponseGetRefundResponse;
import ru.rosbank.paymentapi.services.integration.OrganizationService;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApi;
import ru.rosbank.platform.client.rolesapp.model.RightsDTO;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoRequest;
import ru.rosbank.platform.server.paymentapi.model.SbpRefundInfoResponse;


@Slf4j
@Service
@RequiredArgsConstructor
public class RefundSbpService {

    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final OrganizationService organizationService;
    private final RetryableService retryableService;
    private final QrPaymentApiFeignClient qrPaymentApiFeignClient;
    private final RefundApiFeignClient refundApiFeignClient;
    private final RolesAppApi rolesAppApi;
    private final JedisPool pool;
    private final RefundDataMapper refundDataMapper;
    @Value("${cache.sbpRefundPaymentKey.ttl}")
    private Long ttl;
    @Value("${sbpRefund.status.sleep}")
    private Long sleep;

    public SbpRefundInfoResponse createRefund(SbpRefundInfoRequest sbpRefundInfo, String dboProId) {
        BigDecimal amountRubKopeck = sbpRefundInfo.getAmount().movePointRight(2);
        String paymentId = sbpRefundInfo.getPaymentId().substring(0, sbpRefundInfo.getPaymentId().length() - 2);
        QrInfoDto qrInfoResponse = getQrInfo(sbpRefundInfo, paymentId);
        validateUserRights(dboProId, qrInfoResponse);
        IdempotenceData idempotenceData = getIdempotenceData(amountRubKopeck, paymentId);
        RefundData refundData = refundDataMapper.convert(qrInfoResponse, sbpRefundInfo,
                amountRubKopeck.toPlainString());
        UUID docId = createRefundRequest(idempotenceData, refundData);
        delay(sleep);
        refundStatusPoll(docId, RefundStatus.CONFIRMED);
        SbpRefundInfoResponse response = new SbpRefundInfoResponse();
        response.setId(docId);
        response.setStatus(SbpRefundInfoResponse.StatusEnum.CONFIRMED);
        return response;
    }

    public SbpRefundInfoResponse executeRefund(UUID id) {
        executeRefundRequest(id);
        refundStatusPoll(id, RefundStatus.COMPLETED);
        SbpRefundInfoResponse response = new SbpRefundInfoResponse();
        response.setId(id);
        response.setStatus(SbpRefundInfoResponse.StatusEnum.COMPLETED);
        return response;
    }

    private void executeRefundRequest(UUID id) {
        WebResponseCreateRefundResponse webResponseCreateRefundResponse =
                refundApiFeignClient.refundDocumentIdExecutePatch(id).getBody();
        if (webResponseCreateRefundResponse == null || !webResponseCreateRefundResponse.isSuccess()) {
            throw new IncorrectResponseException("Response from refund PATCH is empty or not successful");
        }
    }

    private UUID createRefundRequest(IdempotenceData idempotenceData, RefundData refundData) {
        WebResponseCreateRefundResponse webResponseCreateRefundResponse =
                refundApiFeignClient.refundPost(idempotenceData.getKey(), refundData).getBody();
        if (webResponseCreateRefundResponse == null || !webResponseCreateRefundResponse.isSuccess()) {
            throw new IncorrectResponseException("Response from refund POST is empty or not successful");
        }
        return webResponseCreateRefundResponse.getResult().getId();
    }

    private void validateUserRights(String dboProId, QrInfoDto qrInfoResponse) {
        OrganizationDTO organization = getOrganizationByInn(dboProId, qrInfoResponse.getPayee().getInn());
        String crmId = organization.getCrmId();
        List<RightsDTO> individualList = rolesAppApi.rightsGet(crmId, dboProId).getBody();
        if (!isAllRights(individualList)) {
            throw new NoRightsException(String.format("User %s doesn't have full rights", crmId));
        }
    }

    private QrInfoDto getQrInfo(SbpRefundInfoRequest sbpRefundInfo, String paymentId) {
        QrInfoResponse infoResponse = qrPaymentApiFeignClient
                .qrPaymentPaymentBisReferenceGet(paymentId, DATE_FORMATTER.format(sbpRefundInfo.getDate()))
                .getBody();
        if (infoResponse == null || !infoResponse.isSuccess()) {
            throw new IncorrectResponseException("Response from qrPayment GET is empty or not successful");
        }
        return infoResponse.getData();
    }

    private void refundStatusPoll(UUID documentId, RefundStatus expectedStatus) {
        WebResponseGetRefundResponse webResponseGetRefundResponse =
                refundApiFeignClient.refundDocumentIdGet(documentId).getBody();
        if (webResponseGetRefundResponse == null || !webResponseGetRefundResponse.isSuccess()) {
            throw new IncorrectResponseException("Response from refund GET is empty or not successful");
        }
        RefundStatus status = webResponseGetRefundResponse.getData().getStatus();
        if (!expectedStatus.equals(status) && !RefundStatus.FAILED.equals(status)) {
            status = retryableService.attemptToGetRefundExpectedStatus(documentId, expectedStatus);
        }
        if (!expectedStatus.equals(status)) {
            throw new IncorrectRefundStatusException(
                    String.format("After all retries actual refund status is '%s', expected: '%s'. "
                            + "Document id: '%s'", status, expectedStatus, documentId));
        }
    }

    private boolean isAllRights(List<RightsDTO> rights) {
        return Optional.ofNullable(rights)
                .orElse(new ArrayList<>()).stream()
                .anyMatch(r -> RightsDTO.AccessRightsEnum.ALL.equals(r.getAccessRights())
                        && RightsDTO.StatusEnum.ACCESS.equals(r.getStatus()));
    }

    private void delay(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private OrganizationDTO getOrganizationByInn(String dboProId, String inn) {
        return organizationService.getOrganizations(dboProId)
                .stream()
                .filter(o -> Objects.equals(o.getInn(), inn))
                .findFirst()
                .orElseThrow(() -> new InvalidOrganizationException(
                        String.format("User %s is not related to organization with inn %s", dboProId, inn)));
    }

    private IdempotenceData getIdempotenceData(BigDecimal amountRubKopeck, String paymentId) {
        String uniquePaymentKey = "sbp_refund:" + paymentId + "_" + amountRubKopeck.toPlainString();
        //REDIS uniquePaymentKey <--> idempotenceKey
        IdempotenceData idempotenceData = IdempotenceData.builder()
                .key(UUID.randomUUID())
                .isRefundAlreadyInProgress(true)
                .build();
        if (StringUtils.hasText(paymentId)) {
            try (Jedis jedis = pool.getResource()) {
                if (Boolean.TRUE.equals(jedis.exists(uniquePaymentKey))) {
                    UUID existsIdempotenceKey = UUID.fromString(jedis.get(uniquePaymentKey));
                    log.info("Refund already in progress. paymentKey: {}, idempotenceKey: {}",
                            uniquePaymentKey,  existsIdempotenceKey);
                    idempotenceData.setKey(existsIdempotenceKey);
                    idempotenceData.setRefundAlreadyInProgress(true);
                } else {
                    String idempotenceKey = String.valueOf(idempotenceData.getKey());
                    jedis.set(uniquePaymentKey, idempotenceKey, SetParams.setParams().ex(ttl));
                    log.info("New refund. paymentKey: {}, idempotenceKey: {}", uniquePaymentKey,  idempotenceKey);
                    idempotenceData.setRefundAlreadyInProgress(false);
                }
            }
        }
        return idempotenceData;
    }
}
