package ru.rosbank.paymentapi.services.onec;


import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class EndOfFileParser1C extends AbstractDocumentFieldParser1C {
    private static final String END_OF_FILE_KEY = "КонецФайла";

    @Override
    public void parseAndSetValue(String line, DocumentDTO document) {
        // nothing to do
    }

    @Override
    public boolean isMatch(String line) {
        return containsWithSeparator(line, END_OF_FILE_KEY);
    }
}
