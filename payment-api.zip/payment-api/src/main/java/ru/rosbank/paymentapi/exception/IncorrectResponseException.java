package ru.rosbank.paymentapi.exception;

public class IncorrectResponseException extends RuntimeException {
    public IncorrectResponseException(String message) {
        super(message);
    }

}
