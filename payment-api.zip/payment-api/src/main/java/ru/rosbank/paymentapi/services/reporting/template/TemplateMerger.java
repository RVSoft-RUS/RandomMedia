package ru.rosbank.paymentapi.services.reporting.template;

import com.google.common.base.Strings;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

/**
 * Helper class for easy template merging.
 *
 * <p>Apache Velocity template engine is used under the cover.</p>
 *
 * <pre>
 *   String mergedTemplate = new TemplateMerger(velocityEngine, "com/madjaxx/email/templates/AdminInvitedEmail.html")
 *       .parameter("invitedBy", invitedBy)
 *       .parameter("invitedEmail", invitedEmail)
 *       .parameter("ref_code", ref_code)
 *       .merge();
 * </pre>
 *
 * @author Q-APE
 */
public class TemplateMerger {

    private static final String MUST_NOT_NULL = "Template resource must not be null!";
    private final TemplateEngine templateEngine;

    private Resource template;

    private final Map<String, Object> parameters = new HashMap<>();

    /**
     * Creates template merger.
     *
     * @param templateEngine FreeMarker configuration
     */
    public TemplateMerger(TemplateEngine templateEngine) {
        Assert.notNull(templateEngine, "Argument 'templateEngine' must not be null!");

        this.templateEngine = templateEngine;
    }

    /**
     * Set template.
     *
     * @param resource Spring resource
     * @return this object
     */
    public TemplateMerger template(Resource resource) {
        Assert.notNull(resource, MUST_NOT_NULL);

        this.template = resource;

        return this;
    }

    /**
     * Set template.
     *
     * @param resource Spring resource specification (classpath:, file:, etc.)
     * @return this object
     */
    public TemplateMerger template(String resource) {
        Assert.notNull(resource, MUST_NOT_NULL);

        template(new DefaultResourceLoader().getResource(resource));

        return this;
    }

    /**
     * Set parameter to be merged.
     *
     * <p>Multiple parameters supported. Each call to this method adds new parameter.</p>
     *
     * <p>Template engine supports dot syntax (${user.address.street}).</p>
     *
     * @param name  String parameter name
     * @param value Object parameter value
     * @return this object
     */
    public TemplateMerger parameter(String name, Object value) {
        Assert.notNull(name, "Parameter name for velocity template must not be null!");
        Assert.notNull(value, "Parameter value for velocity template must not be null!");

        parameters.put(name, value);

        return this;
    }

    /**
     * Set string parameter to be merged.
     *
     * <p>Multiple parameters supported. Each call to this method adds new parameter.</p>
     *
     * @param name  String parameter name
     * @param value String parameter value
     * @return this object
     */
    public TemplateMerger parameter(String name, String value) {
        Assert.notNull(name, "Parameter name for velocity template must not be null!");
        Assert.notNull(value, "Parameter value for velocity template must not be null!");

        parameters.put(name, Strings.nullToEmpty(value));

        return this;
    }

    /**
     * Set parameters map to be merged.
     *
     * <p>Adds all provided parameters to existing</p>
     *
     * @param parameters Map parameters map
     * @return this object
     */
    public TemplateMerger parameters(Map<String, Object> parameters) {
        Assert.notNull(parameters, "templateParameters for velocity template must not be null!");

        this.parameters.putAll(parameters);

        return this;
    }

    /**
     * Perform merging and return resulting text as string.
     *
     */
    public void merge(OutputStream outputStream) {
        Assert.notNull(template, MUST_NOT_NULL);

        try (InputStream inputStream = template.getInputStream()) {

            templateEngine.evaluate(inputStream, outputStream, new TemplateContext(parameters));
        } catch (IOException e) {
            throw new IllegalStateException(String.format("Can't load template resource '%s'.", template), e);
        }
    }

    public String merge() {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        merge(outputStream);

        return new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
    }
}
