package ru.rosbank.paymentapi.converter;

import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.client.paymentapp.model.DocumentStatusDTO;


/**
 * Summary.
 * @author rb0678774
 */

public class DocumentStatusConverter {

    public static DocumentStatusDTO getDocumentStatusDto(DocumentDTO document) {
        if (isRevertEnableDocStatus(document.getStatus())) {
            return DocumentStatusDTO.SIGNED;
        } else if (isProcessingForDto(document.getStatus())) {
            return DocumentStatusDTO.PROCESSING;
        } else {
            return document.getStatus();
        }
    }

    static boolean isProcessingForDto(DocumentStatusDTO status) {
        return DocumentStatusDTO.DFM_PROCESSING.equals(status) || DocumentStatusDTO.SENT_TO_BIS.equals(status)
                || DocumentStatusDTO.ERROR.equals(status) || DocumentStatusDTO.PROCESSING.equals(status)
                || DocumentStatusDTO.REVIEW.equals(status);
    }

    static boolean isRevertEnableDocStatus(DocumentStatusDTO status) {
        return DocumentStatusDTO.SIGNED.equals(status) || DocumentStatusDTO.PLANNED.equals(status)
                || DocumentStatusDTO.SENT_TO_BIS.equals(status);
    }
}
