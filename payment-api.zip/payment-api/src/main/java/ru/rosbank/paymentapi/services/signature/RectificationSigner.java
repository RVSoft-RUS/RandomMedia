package ru.rosbank.paymentapi.services.signature;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import feign.FeignException;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.exception.BackendException;
import ru.rosbank.paymentapi.exception.DocumentSignException;
import ru.rosbank.paymentapi.exception.ValidationException;
import ru.rosbank.paymentapi.services.AuditService;
import ru.rosbank.paymentapi.services.integration.OtpService;
import ru.rosbank.paymentapi.services.integration.ProductService;
import ru.rosbank.platform.client.cryptoproapp.api.CryptoproAppApi;
import ru.rosbank.platform.client.cryptoproapp.model.CertificateDTO;
import ru.rosbank.platform.client.cryptoproapp.model.FileResourceDTO;
import ru.rosbank.platform.client.cryptoproapp.model.ReferenceDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SignatureDTO;
import ru.rosbank.platform.client.cryptoproapp.model.SubjectDTO;
import ru.rosbank.platform.client.otpapp.model.OtpDTO;
import ru.rosbank.platform.client.userapp.model.ClientDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

/**
 * Summary.
 * @author rb064742
 */

@Service
@Slf4j
@RequiredArgsConstructor
public class RectificationSigner {
    protected static final String UNCONFIRMED_CERTIFICATE_ERROR = "Ваш сертификат на подписи у руководителя.";
    public static final String DOCUMENT_RECTIFICATION = "DOCUMENT_RECTIFICATION";
    public static final String DOCUMENT_CLARIFICATION = "DOCUMENT_CLARIFICATION";
    @Value("${rbsp.clarification.enabled}")
    boolean rbspEnabled;

    private final ProductService productService;
    private final OtpService otpService;
    private final CryptoproAppApi cryptoproAppApi;
    private final AuditService auditService;

    private String getType() {
        if (rbspEnabled) {
            return DOCUMENT_CLARIFICATION;
        } else {
            return DOCUMENT_RECTIFICATION;
        }
    }

    public OtpDTO sign(ClientDTO user, Rectification dr, Payment payment) {

        var certificate = getSignerCertificate(user.getId(), payment);
        List<SubjectDTO> subjects = Collections.singletonList(buildSubject(dr));
        String packageSignatureId;
        try {
            packageSignatureId = cryptoproAppApi.certificateIdSignPost(certificate.getId(), subjects).getBody();
        } catch (FeignException e) {
            log.error("Ошибка создания транзакции подписи {} ", user.getId(), e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        if (packageSignatureId != null) {
            return otpService.generatePackageSignatureOtp(packageSignatureId, user.getPhone());
        }
        return null;
    }

    CertificateDTO getSignerCertificate(String dboProId, Payment payment) {
        var organizationDTO = productService.getOrganizationByAccNumberAndDboProId(payment.getPayer().getAccount(), dboProId)
                .orElseThrow(() -> new DocumentSignException("Организация не найдена"));
        List<CertificateDTO> certificates;
        try {
            certificates = cryptoproAppApi.userIdCertificateGet(dboProId).getBody();
        } catch (FeignException e) {
            log.error("Ошибка получения сертификатов пользователя {} ", dboProId, e);
            throw new BackendException(e.getMessage(), String.valueOf(e.status()), true);
        }
        Optional<CertificateDTO> ocertificate = certificates.stream()
                .filter(cert -> organizationDTO.getCrmId().equals(cert.getCrmId()))
                .filter(cert -> CertificateDTO.StatusEnum.ACTIVE.equals(cert.getStatus()))
                .findFirst();
        if (ocertificate.isPresent()) {
            return ocertificate.get();
        }

        throw new ValidationException(UNCONFIRMED_CERTIFICATE_ERROR);
    }

    SubjectDTO buildSubject(Rectification dr) {
        var subject = new SubjectDTO();

        subject.setReference(
            new ReferenceDTO()
                .id(dr.getId().toString())
                .type(getType())
        );
        try {
            subject.setResource(
                    new FileResourceDTO().id(UUID.randomUUID().toString())
                            .content(documentToString(dr))
                            .contentType(FileResourceDTO.ContentTypeEnum.TXT)
                            .name("documentRectification.xml")
            );
            subject.setMetaData(
                    auditService.getMetaDataDTO()
            );
        } catch (JsonProcessingException e) {
            log.error(e.getMessage());
        }
        return subject;
    }

    String documentToString(Rectification doc) throws JsonProcessingException {
        var mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        String json = mapper.writeValueAsString(doc);
        return new String(Base64.getEncoder().encode(json.getBytes()));
    }

    public boolean isRectificationRequestSigned(String id) {
        return Objects.requireNonNull(cryptoproAppApi
                .signatureGet(id, getType())
                .getBody())
                .stream()
                .anyMatch(SignatureDTO::getConfirmed);
    }
}
