package ru.rosbank.paymentapi.services.reporting.template;

/**
 * Исключение, герерируемое в случае возникновения ошибок в процессе работы шаблонизатора.
 *
 * @author Q-DSH
 * @see TemplateEngine
 */
public class TemplateEngineException extends RuntimeException {

    /**
     * Конструктор.
     *
     * @param message сообщение об ошибке
     */
    public TemplateEngineException(String message) {
        super(message);
    }

    /**
     * Конструктор.
     *
     * @param message сообщение об ошибке
     * @param cause   первопричина ошибки
     */
    public TemplateEngineException(String message, Throwable cause) {
        super(message, cause);
    }
}
