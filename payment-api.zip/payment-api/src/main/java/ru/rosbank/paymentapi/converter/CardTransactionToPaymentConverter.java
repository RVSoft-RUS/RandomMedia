package ru.rosbank.paymentapi.converter;

import org.springframework.stereotype.Service;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Amount;
import ru.rosbank.platform.server.paymentapi.model.Payment;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

@Service
public class CardTransactionToPaymentConverter {

    public Payment convert(PaymentDTO dto) {
        var payment = new Payment();
        payment.setId(dto.getItmTransId());
        payment.setSubtype(Payment.SubtypeEnum.valueOf(dto.getSubtype().getValue()));
        payment.setType(Payment.TypeEnum.valueOf(dto.getType().getValue()));
        payment.setCardPan(dto.getCardPan());
        payment.setTransactionDate(dto.getTransDateTime());
        payment.setPayer(new Requisite().account(dto.getAccountNumber13()));
        payment.setAmount(new Amount()
                .sum(dto.getAmount().getSum())
                .currency(dto.getAmount().getCurrency()));
        payment.setComissionAmount(String.valueOf(dto.getAmount().getComissionAmount()));
        payment.setStatus(Payment.StatusEnum.valueOf(dto.getStatus()));
        payment.setMcc(dto.getMcc());
        payment.setApproveCode(dto.getApproveCode());
        payment.setPurpose(dto.getPurpose());
        payment.setMerchant(dto.getMerchantName());
        payment.setItmTransId(dto.getItmTransId());

        return payment;
    }

}
