package ru.rosbank.paymentapi.rbsp.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Информация о получателе платежа.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PayeeInfo {
    private String payeeName;
    private String payeeAccNumber;
    private String payeeInn;
    private String payeeKpp;
}
