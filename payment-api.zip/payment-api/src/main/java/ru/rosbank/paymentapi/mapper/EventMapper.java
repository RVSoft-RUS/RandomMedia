package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import ru.rosbank.platform.client.auditapp.model.EventDTO;

@Mapper(componentModel = "spring")
public interface EventMapper {

    EventDTO toDTO(String dboProId, String initiator, String stage);

    EventDTO toDTO(String dboProId, String initiator, String stage, String reference, String referenceType);
}
