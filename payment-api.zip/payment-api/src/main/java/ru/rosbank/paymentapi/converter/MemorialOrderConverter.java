package ru.rosbank.paymentapi.converter;

import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

public class MemorialOrderConverter {
    public static Payment convert(PaymentDTO input) {
        Payment document = new Payment();
        document.setSubtype(Payment.SubtypeEnum.MEMORIAL_ORDER);
        BaseConverter.convert(document, input);

        // Дата валютирования
        document.setValueDate(input.getValueDate());

        // Содержание
        document.setContent(input.getContent());

        document.setOrderStampSinger(input.getOrderStampSinger());

        document.setItmTransId(input.getItmTransId());

        return document;
    }
}
