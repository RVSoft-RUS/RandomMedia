package ru.rosbank.paymentapi.model.feign.refundapi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WebResponseCreateRefundResponse {

    private ResponseMetadata result;
    private RefundObject data;

    public boolean isSuccess() {
        if (data != null && result != null) {
            return result.isSuccess();
        }
        return false;
    }

}

