package ru.rosbank.paymentapi.services.validator.field;

import static org.apache.commons.lang3.StringUtils.isBlank;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.services.integration.ReferenceService;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;
import ru.rosbank.platform.utils.payment.exceptions.ValidationPaymentException;
import ru.rosbank.platform.utils.payment.validators.IDocumentValidator;

@Service
@Order(-100)
public class DocumentPayeeBankBicValidator implements IDocumentValidator {
    private static final String ERROR_MESSAGE_EMPTY = "Заполните поле БИК получателя";
    private static final String ERROR_MESSAGE_INVALID = "Введите 9 цифр, БИК получателя";

    @Autowired
    ReferenceService referenceService;

    public void validate(DocumentDTO document) throws ValidationPaymentException {

        String bic = document.getPayee().getBank().getBic();


        if (isBlank(bic)) {
            throw new ValidationPaymentException(14, "payee.bank.bic", ERROR_MESSAGE_EMPTY);
        }

        if (bic.length() != 9 || !StringUtils.isNumeric(bic)) {
            throw new ValidationPaymentException(14, "payee.bank.bic", ERROR_MESSAGE_INVALID);
        }
    }

}
