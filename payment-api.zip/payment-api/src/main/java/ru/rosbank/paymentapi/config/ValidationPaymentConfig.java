package ru.rosbank.paymentapi.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import ru.rosbank.paymentapi.services.validator.DocumentPropertyImpl;
import ru.rosbank.paymentapi.services.validator.DocumentTypeCalculatorImpl;
import ru.rosbank.platform.utils.payment.validators.DocumentBasisDocumentNumberValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentCodeTypeIncomeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentKbkValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentOktmoValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayPriorityValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeInnValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayeeNameValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerAccountValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerKppValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerNameValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPayerStatusValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisCreatedValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPaymentBasisValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentPurposeValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentTaxPeriodValidator;
import ru.rosbank.platform.utils.payment.validators.DocumentUinCode22Validator;

@Configuration
public class ValidationPaymentConfig {

    @Autowired
    DocumentTypeCalculatorImpl documentTypeCalculatorImpl;
    @Autowired
    DocumentPropertyImpl documentProperty;

    @Bean
    public DocumentBasisDocumentNumberValidator documentBasisDocumentNumberValidator() {
        return new DocumentBasisDocumentNumberValidator(documentTypeCalculatorImpl, documentProperty);
    }

    @Bean
    public DocumentCodeTypeIncomeValidator documentCodeTypeIncomeValidator() {
        return new DocumentCodeTypeIncomeValidator();
    }

    @Bean
    @Order(-99)
    public DocumentKbkValidator documentKbkValidator() {
        return new DocumentKbkValidator(documentTypeCalculatorImpl);
    }

    @Bean
    public DocumentOktmoValidator documentOktmoValidator() {
        return new DocumentOktmoValidator(documentTypeCalculatorImpl);
    }

    @Bean
    @Order(-100)
    public DocumentPayeeInnValidator documentPayeeInnValidator() {
        return new DocumentPayeeInnValidator();
    }

    @Bean
    @Order(-100)
    public DocumentPayeeKppValidator documentPayeeKppValidator() {
        return new DocumentPayeeKppValidator(documentTypeCalculatorImpl);
    }

    @Bean
    @Order(-100)
    public DocumentPayeeNameValidator documentPayeeNameValidator() {
        return new DocumentPayeeNameValidator();
    }

    @Bean
    @Order(-100)
    public DocumentPayerAccountValidator documentPayerAccountValidator() {
        return new DocumentPayerAccountValidator();
    }

    @Bean
    @Order(-100)
    public DocumentPayerNameValidator documentPayerNameValidator() {
        return new DocumentPayerNameValidator();
    }

    @Bean
    @Order(-99)
    public DocumentPayerStatusValidator documentPayerStatusValidator() {
        return new DocumentPayerStatusValidator(documentTypeCalculatorImpl, documentProperty);
    }

    @Bean
    public DocumentPaymentBasisCreatedValidator documentPaymentBasisCreatedValidator() {
        return new DocumentPaymentBasisCreatedValidator(documentTypeCalculatorImpl);
    }

    @Bean
    public DocumentPaymentBasisValidator documentPaymentBasisValidator() {
        return new DocumentPaymentBasisValidator(documentTypeCalculatorImpl, documentProperty);
    }

    @Bean
    public DocumentPayPriorityValidator documentPayPriorityValidator() {
        return new DocumentPayPriorityValidator(documentTypeCalculatorImpl);
    }

    @Bean
    public DocumentPurposeValidator documentPurposeValidator() {
        return new DocumentPurposeValidator(documentTypeCalculatorImpl);
    }

    @Bean
    public DocumentTaxPeriodValidator documentTaxPeriodValidator() {
        return new DocumentTaxPeriodValidator(documentTypeCalculatorImpl);
    }

    @Bean
    public DocumentPayerKppValidator documentPayerKppValidator() {
        return new DocumentPayerKppValidator(documentProperty);
    }

    @Bean
    public DocumentUinCode22Validator documentUinCode22Validator() {
        return new DocumentUinCode22Validator(documentTypeCalculatorImpl);
    }

}
