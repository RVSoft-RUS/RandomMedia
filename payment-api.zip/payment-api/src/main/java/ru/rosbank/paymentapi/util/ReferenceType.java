package ru.rosbank.paymentapi.util;

/**
 * Summary.
 * @author rb068869
 */
public enum ReferenceType {
    DOCUMENT,
    CLIENT,
    REMOTE_REGISTRATION
}
