package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.paymentapp.model.RectificationDTO;
import ru.rosbank.platform.server.paymentapi.model.Rectification;

@Mapper
public abstract class RectificationMapper implements OffsetDateTimeMapper {

    public static final RectificationMapper INSTANCE = Mappers.getMapper(RectificationMapper.class);

    @Mapping(target = "status", expression = "java(getStatus(doc))")
    public abstract RectificationDTO toDTO(Rectification doc);

    @Mapping(target = "created", source = "created", qualifiedByName = "toDate")
    @Mapping(target = "type", ignore = true)
    public abstract Rectification fromDTO(RectificationDTO doc);

    RectificationDTO.StatusEnum getStatus(Rectification doc) {
        if (doc == null) {
            return RectificationDTO.StatusEnum.CREATED;
        }
        switch (doc.getStatus()) {
            case "CREATED":
                return RectificationDTO.StatusEnum.CREATED;
            case "ACTIVE":
                return RectificationDTO.StatusEnum.ACTIVE;
            default:
                return RectificationDTO.StatusEnum.CREATED;
        }
    }
}
