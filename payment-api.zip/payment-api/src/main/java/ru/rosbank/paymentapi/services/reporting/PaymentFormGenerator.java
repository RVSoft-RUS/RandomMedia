package ru.rosbank.paymentapi.services.reporting;

import static ru.rosbank.paymentapi.services.reporting.utils.FormatUtils.toUrlString;

import freemarker.template.Configuration;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Map;
import ru.rosbank.paymentapi.commons.PaymentUtils;
import ru.rosbank.paymentapi.services.reporting.pdfrenderer.PdfRenderer;
import ru.rosbank.paymentapi.services.reporting.template.TemplateMerger;
import ru.rosbank.paymentapi.services.reporting.template.impl.FreeMarkerTemplateEngine;
import ru.rosbank.paymentapi.services.reporting.utils.FormatUtils;
import ru.rosbank.platform.client.paymentapp.model.DocumentDTO;

/**
 * Summary.
 * @author rb068869
 */
public class PaymentFormGenerator {

    private static final String TEMPLATES_PATH = "templates/payment/";
    private static final Map<String, Object> COMMON_TEMPLATE_PARAMETERS = Collections
            .singletonMap("formatter", new FormatUtils());

    private final FreeMarkerTemplateEngine freeMarkerTemplateEngine;

    private TemplateMerger newFreeMarkerTemplateMerger() {
        return new TemplateMerger(freeMarkerTemplateEngine);
    }

    public PaymentFormGenerator(Configuration freeMarkerConfiguration) {
        this.freeMarkerTemplateEngine = new FreeMarkerTemplateEngine(freeMarkerConfiguration);
        freeMarkerConfiguration.setClassForTemplateLoading(this.getClass(), "/templates/");
    }

    public String generateHtml(DocumentDTO documentDTO, String templateName) {
        TemplateMerger merger = newFreeMarkerTemplateMerger()
                .template(TEMPLATES_PATH + templateName)
                .parameters(COMMON_TEMPLATE_PARAMETERS)
                .parameter("documentDTO", documentDTO)
                .parameter("paymentUtils", new PaymentUtils());

        return merger.merge();

    }

    public OutputStream generatePdf(DocumentDTO documentDTO, String templateName) {

        OutputStream outputStream = new ByteArrayOutputStream();
        String html = generateHtml(documentDTO, templateName);
        PdfRenderer.xhtmlToPdf(html, toUrlString(TEMPLATES_PATH), outputStream);
        return outputStream;

    }

}
