package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.statementapp.model.PaymentDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

@Mapper
public abstract class PaymentOutputModeMapper {

    public static final PaymentOutputModeMapper INSTANCE = Mappers.getMapper(PaymentOutputModeMapper.class);

    public abstract Payment.PaymentOutputModeEnum fromDTO(PaymentDTO.PaymentOutputModeEnum paymentOutputModeEnum);

}
