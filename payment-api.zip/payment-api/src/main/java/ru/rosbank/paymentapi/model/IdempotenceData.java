package ru.rosbank.paymentapi.model;

import java.util.UUID;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class IdempotenceData {

    private UUID key;
    private boolean isRefundAlreadyInProgress;

}
