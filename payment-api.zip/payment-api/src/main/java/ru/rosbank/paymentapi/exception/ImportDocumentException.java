package ru.rosbank.paymentapi.exception;

/**
 * Summary.
 * @author rb068869
 */
public class ImportDocumentException extends Exception {

    public ImportDocumentException(String msg) {
        super(msg);
    }

    public ImportDocumentException(String msg, Throwable t) {
        super(msg, t);
    }

}
