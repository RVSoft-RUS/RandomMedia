package ru.rosbank.paymentapi.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.rosbank.paymentapi.converter.DocumentToPaymentConverter;
import ru.rosbank.paymentapi.services.integration.AccountService;
import ru.rosbank.platform.client.accountapp.model.AccountDTO;
import ru.rosbank.platform.client.organizationapp.api.OrganizationAppApi;
import ru.rosbank.platform.client.organizationapp.model.OrganizationDTO;
import ru.rosbank.platform.client.paymentapp.api.PaymentAppApi;
import ru.rosbank.platform.client.rolesapp.api.RolesAppApi;
import ru.rosbank.platform.client.rolesapp.model.IndividualDTO;
import ru.rosbank.platform.server.paymentapi.model.Payment;

@Slf4j
@Service
@RequiredArgsConstructor
public class DuplicatesService {


    private final AccountService accountService;

    private final RolesAppApi rolesAppApi;

    private final OrganizationAppApi organizationAppApi;

    private final PaymentAppApi paymentAppApi;

    private final DocumentToPaymentConverter documentToPaymentConverter;

    public static final List<Payment.StatusEnum> PROCESSING_STATUS
            = Collections.unmodifiableList(Arrays.asList(Payment.StatusEnum.SIGNED,
            Payment.StatusEnum.DFM_PROCESSING, Payment.StatusEnum.SENT_TO_BIS, Payment.StatusEnum.REVIEW));

    public List<Payment> getDuplicatesList(List<String> requestBody, String dboProId) {
        List<Payment> duplicates = new ArrayList<>();
        List<OrganizationDTO> organizationDTOs = Optional.ofNullable(organizationAppApi.rootGet(dboProId).getBody())
                .orElseThrow(() -> new NullPointerException("Организация пользователя не найдена! Id =" + dboProId));
        organizationDTOs = organizationDTOs.stream().filter(o -> rolesAppApi.idGet(o.getCrmId(), dboProId).getBody().stream()
                .anyMatch(i -> isValidRole(i))).collect(Collectors.toList());
        List<AccountDTO> accounts = organizationDTOs.stream()
                .map(orgDTO -> accountService.getAccountList(orgDTO.getCrmId(), orgDTO.getBisIds()))
                .flatMap(Collection::stream).collect(Collectors.toList());

        List<String> docIds = requestBody.stream().filter(id -> accounts.stream().anyMatch(acc -> acc.getNumber()
                .equals(paymentAppApi.documentIdGet(id).getBody().getPayer().getAccount()))).collect(Collectors.toList());

        paymentAppApi.documentDublicatesPost(docIds).getBody().stream().forEach(doc ->
                duplicates.add(documentToPaymentConverter.convert(doc)));

        duplicates.stream().forEach(payment -> {
            if (PROCESSING_STATUS.contains(payment.getStatus())) {
                payment.setStatus(Payment.StatusEnum.PROCESSING);
            }
        });
        return duplicates;
    }

    private static boolean isValidRole(IndividualDTO individualDTO) {

        return (individualDTO.getAccessValidPeriod() == null || individualDTO.getAccessValidPeriod().isAfter(LocalDate.now()))
                && (individualDTO.getAccessGroup().equals(IndividualDTO.AccessGroupEnum.VIEW)
                || individualDTO.getAccessGroup().equals(IndividualDTO.AccessGroupEnum.CREATE_DELETE)
                || individualDTO.getAccessGroup().equals(IndividualDTO.AccessGroupEnum.ALL_RIGHTS)
                || individualDTO.getAccessGroup().equals(IndividualDTO.AccessGroupEnum.ACCEPT)
                || individualDTO.getAccessGroup().equals(IndividualDTO.AccessGroupEnum.VIEW_ACCEPT));
    }

}
