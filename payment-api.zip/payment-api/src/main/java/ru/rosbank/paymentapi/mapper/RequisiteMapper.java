package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.statementapp.model.RequisiteDTO;
import ru.rosbank.platform.server.paymentapi.model.Requisite;

@Mapper
public abstract class RequisiteMapper {

    public static final RequisiteMapper INSTANCE = Mappers.getMapper(RequisiteMapper.class);

    public abstract Requisite fromDTO(RequisiteDTO requisiteDTO);

}
