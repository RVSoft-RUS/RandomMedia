package ru.rosbank.paymentapi.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import ru.rosbank.platform.client.statementapp.model.BankInfoDTO;
import ru.rosbank.platform.server.paymentapi.model.BankInfo;

@Mapper
public  abstract class BankInfoMapper {

    public static final BankInfoMapper INSTANCE = Mappers.getMapper(BankInfoMapper.class);

    public abstract BankInfo fromDTO(BankInfoDTO bankInfoDTO);

}
