gradle build;
docker build . -t test1-jdk8;
docker run -p 8080:8080 test1-jdk8:latest;