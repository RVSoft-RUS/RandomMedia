### Изменение импортируемого документа
#### POST /api/imported/document
#### метод apiImportedDocumentPost 
 
1. Проверяем авторизирован ли пользователь и достаем clientId из сессии.
2. Вызываем documentImportService.updateImportedDocument(importedDocument, clientId)
3. Валидируем importedDocument посредством вызова documentValidator.validateImportedDoc(documentToImportedDocumentConverter.convertBack(importedDocument), clientId)
4. Проверив документ importedDocument, отправляем запрос на его импорт в payment-app, вызвав метод paymentAppApi.importedDocumentPost(clientId, ImportedDocumentMapper.INSTANCE.toDTO(importedDocument))
5. Возвращаем этот проверенный и импортированный в payment-app документ в ответе метода как ResponseEntity

### Получение информации о номере и дате нового платежа
#### GET /api/document/next
#### метод apiDocumentNextGet

1. Ищем список организаций по клиенту
2. В списке организаций оставляем только то где crmId равно переданному organizationId
3. Среди них оставляем только те у которых пользователь является представителем или менеджером счета
4. В accountApp ищем счета.
5. По найденным счетам получаем платежное поручение из account-app
6. Возвращаем платежное поручение в ответе. Дата в ответе в формате yyyy-MM-dd'T'HH:mm:ss.SSSXXX


### Получение печатной формы документа
#### GET /api/document/{id}/{format}
#### метод apiDocumentIdFormatGet

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем documentFormService.getDocumentForm(id, format, clientId), где id - номер документа, format - "html" или "pdf"
3. Вызываем statementService.getPayment(clientId, documentId) и получаем paymentDTO
4. Проверяем если paymentDTO != null, то вызываем statementFormService.generate(paymentDTO, format) и возвращаем FileResource как ResponseEntity
5. Если paymentDTO == null в пункте 4, то вызываем paymentService.getDocument(documentId) и получаем documentDTO согласно documentId
6. Проверяем если documentDTO != null, то вызываем organizationService.getOrganizations(clientId) и получаем список AccountDTO для clientId
7. Если documentDTO.getPayer().getAccount() не найден в этом списке то генерим исключение AccessForbiddenException("Document doesn't belong")
8. Иначе вызываем paymentFormService.generate(documentDTO, format) и возвращаем FileResource как ResponseEntity
9. Если в пункте 4 paymentDTO == null, то генерим исключение UnknownDocumentException("Document not found = " + documentId)

### Получение печатных форм в одном файле
#### POST /api/documentListPdf
#### метод apiDocumentListPdfPost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии.
2. Вызываем метод documentFormService.getDocumentListPdf(documentListPdfRequest.getIds(), clientId), который сливает несколько pdf файлов из documentListPdfRequest.getIds() в один pdf в виде Base64 строки
3. Возвращаем общий pdf в виде FileResource, предварительно обернув в ResponseEntity, завершаем метод apiDocumentListPdfPost

### Получение печатной формы документа
#### GET /api/document/details/{id}
#### метод apiDocumentDetailsIdGet

1. метод устарел @deprecated, переведен в состояние не имплементирован

### Отправка документов по почте/смс
#### POST /api/document/{id}/send/{format}
#### метод apiDocumentIdSendFormatPost

1. метод еще не имплементирован

### Изменение документов
#### POST /api/document/{id}/update
#### метод apiDocumentIdUpdatePost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии.
2. Вызываем метод createPaymentService.updatePayment(document, clientId)
3. Вызываем метод upsert(document, clientId), который выполняет следующее:
4. Получает счет плательщика accountNumber20 из документа document
5. Запрашивает accountDTO из сервиса accountApp, вызывая метод accountAppApi.idGet(accountNumber20)
6. Запрашивает список organizationDTOS organizationService.getOrganizations(clientId) из сервиса organizationApp, вызвав метод organizationAppApi.rootGet(clientId)
7. Из списка организаций извлекает организацию имеющую счет accountNumber20
8. Получает individualDTO из вызова rolesAppApi.idGet(organizationId, clientId) сервиса rolesApp
9. Проверяет права клиента, если ALL_RIGHTS или CREATE_DELETE, тогда разрешает обновление документа
10. Конвертируем document в documentDTO
11. Если кпп плательщика пустой или 0, берет его из organizationDTO, полученного на шаге 7 и вставляет в documentDTO
12. Устанавливает bisId и branch из accountDTO и вставляет в documentDTO и затем валидирует его
13. Получает clientDTO из userService.getUser(clientId) сервиса userApp через метод userAppApi.userGet(clientId)
14. Передает clientDTO.getLegacyId() в documentDTO и возвращается с ним из метода upsert(document, clientId), шаг 3
15. Далее запрашиваем метод paymentService.updatePayment(String.valueOf(documentDTO.getId()), documentDTO) из сервиса paymentApp, вызывая его метод paymentAppApi.documentIdPost(documentId, documentDTO) для обновления и конвертируем DTO обратно в Payment
16. Возвращаем этот платеж (Payment), обернув его в ResponseEntity


### Подписание пачки документов
#### POST /api/document/batch/sign
#### метод apiDocumentBatchSignPost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Получаем список документов на подпись, вызывая getDocumentsForSignature(request.getDocumentIds(), request.getImportedBatchId(), clientId)
3. Метод getDocumentsForSignature вызывает метод paymentAppApi::documentIdGet если список request.getDocumentIds() не пустой, иначе метод paymentAppApi.importedDocumentsGet(importedBatchId, clientId) из сервиса paymentApp
4. Проверяет валидность документов через documentPackageValidator.validate(documents, clientId)
4.1. Документы проверяются на не превышение лимитов DocumentOrganizationLimitValidator.validate(OrganizationDTO org, List<DocumentDTO> documents)
5. Формирует список валидных документов validDocuments, которые проходят валидацию documentValidator.validate(document) и у которых статус CREATED
6. Если список validDocuments пустой, то генерим исключение ValidationException("Не удалось подписать документы")
7. Получает объект user типа ClientDTO вызывая метод userService.getUser(clientId), который обращается к userAppApi.userGet из сервиса userApp
8. Далее вызывает метод documentSigner.sign(user, validDocuments), который получает сертификат certificate из метода getSignerCertificate(user.getId(), items)
9. getSignerCertificate извлекает первый документ DocumentDTO osignable из списка validDocuments
10. Если такой документ есть в наличии, то получает счет AccountDTO oaccount, из метода productService.getAccountListByClient(clientId), который из списка счетов AccountDTO,полученного из списка организаций organizationAppApi.rootGet(clientId), извлекает нужный нам oaccount
11. Если такой счет oaccount есть в наличии, то получаем организацию, относящуюся к этому счету из метода organizationService.getOrganizations(dboProId), который вытаскивает ее с помощью organizationAppApi.rootGet(clientId) сервиса organizationApp
12. Далее вытаскиваем список сертификатов certificates из cryptoproAppApi.userIdCertificateGet(dboProId) сервиса cryptoproApp
13. Из этого списка находим активный сертификат клиента ocertificate
14. Возвращаем сертификат CertificateDTO и завершаем метод getSignerCertificate из пункта 9
15. Получаем packageSignatureId из метода cryptoproAppApi.certificateIdSignPost(certificate.getId(), subjects) из сервиса cryptoproApp
16. Если packageSignatureId успешно получена, то вызываем otpService.generatePackageSignatureOtp(packageSignatureId, user.getPhone()) и получаем OtpDTO из метода otpAppApi.rootPost(otp) сервиса otpApp
17. Завершаем метод documentSigner.sign из пункта 8
18. Если otp в наличии, формируем response типа SignDocumentResponse, устанавливая в него подтверждение через СМС, а также список не прошедших валидацию response.setRejectedIds
19. Возвращаем response типа SignDocumentResponse и завершаем метод apiDocumentBatchSignPost, обернув response в ResponseEntity

### Лента операций
#### POST /api/document/list
#### метод apiDocumentListPost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем organizationService.getActiveOrganizationIds(clientId) и получаем список идентификаторов организаций OrganizationId
3. Фильтруем полученный список организаций вызывая сервис rolesService.isActiveIndividual(org.getCrmId(), clientId) и отбирая активных клиентов, за исключением тех, которые не имеют прав NO_RIGHTS или заблокированы BLOCK 
4. Вызываем сервис documentListService.getDocumentList(documentsRequest.getCriteria(), clientId, orgIds), передав критерий из параметра documentsRequest, переданного в метод apiDocumentListPost
5. Если список организаций пуст, то завершаем getDocumentList, возвращая DocumentsResponse с пустым списком payments
6. Иначе идем дальше, проверяем на валидность StartDate и EndDate и корректируем их при необходимости, согласно operDate
7. Если даты не прошли проверку, то завершаем getDocumentList, возвращая DocumentsResponse с пустым списком payments
8. Составляем список доступных счетов accountDTOS, по ходу формируя мэп номер счета -> id организации
9. Если список доступных счетов пуст, то завершаем getDocumentList, возвращая DocumentsResponse с пустым списком payments
10. Если criteria.getStatuses() пуст или содержит статус COMPLETED, то формируем список платежей PaymentDTO, вызывая из statementAppApi (через Hystrix) метод accountStatementOnlineGet(accountNumber, branch, from, to, clientId, null)
11. Устанавливаем уточнение платежа для всех элементов списка платежей вызывая метод setRectification(documentRectificationService.getActiveDocumentRectificationByBisId(p.getId()), где p - платеж payment 
12. Обновляем статус COMPLETED платежей, вызывая метод paymentService.markDocumentsAsCompleted из сервиса paymentAppApi передавая список номеров этих платежей
13. Если criteria.getStatuses() пуст или статусов больше чем 1 и не один из них COMPLETED, тогда вызываем сервис paymentAppApi для формирования списка документов List<DocumentDTO>
14. Конвертируем список DocumentDTO в список Payment (для платежей типа DH устанавливаем имя получателя равным значению merchantName из ответа accountStatementOnlineGet)
15. Если criteria.getTypes() не пуст, фильтруем список Payment, оставляем тех, у которых getType() содержится в criteria.getTypes()
16. Иначе если список criteria.getCards() не пустой, фильтруем список Payment, оставляем тех, у которых getCardPan().substring совпадает с аналогичной подстрокой из списка строк criteria.getCards()
17. Иначе оставляем список Payment как есть, не меняя
18. Завершаем метод getDocumentList, начатый в пункте 4, возвращаем CompletableFuture.completedFuture в виде DocumentsResponse() с встроенным списком Payment
19. Вызываем сервис documentListService.getCardList(documentsRequest.getCriteria(), clientId, orgIds), передав критерий из параметра documentsRequest, переданного в метод apiDocumentListPost
20. Если includeCardTransactions == false, то завершаем getCardList, возвращая пустой список Payment
21. Составляем, на основе списка организаций, список счетов accountDTOS, вызывая для этого метод accountService.getAccountList(orgInfo.getBisId(), orgInfo.getBisBranch()), который вызывает метод accountAppApi.rootGet(bidId, bisBranch) сервиса AccountApp
22. Составляем, на основе списка организаций, список карт cardList, вызывая для этого метод cardService.getCardList(orgInfo.getBisId(), orgInfo.getBisBranch()), который вызывает метод cardAppApi.rootGetFromBd(bisId, branch) сервиса CardApp
23. Если criteria.getCards() не пуст, то фильтруем список карт на основе списка карт из критерия criteria.getCards()
24. Иначе фильтруем список карт на основе условия criteria.getTypes() пуст либо содержит только тип DocumentCriteria.TypesEnum.DT и затем фильтруем еще раз на основе условия список criteria.getAccounts() имеет совпадение с каким либо acc.getNumber() и затем card.getAccountNumber13() совпадает с каким либо acc.getNumber13() и затем карта имеет статус ACTIVE
25. Формируем список paymentList на основе списка cardList используя вызов метода statementService.getCardStatementList(card, criteria.getStartDate(), criteria.getEndDate(), clientId)), который вызывает метод   statementAppApi.cardStatementOnlineGet(cardNumber, from, to, clientId) из сервиса statementApp, затем фильтруем оставляя те, для которых filterCardTransactionsByStatuses(DocumentCriteria criteria, PaymentDTO payment) дает true
26. Метод filterCardTransactionsByStatuses проверяет список статусов, если criteria.getStatuses() пуст то возвращает true, иначе если criteria.getStatuses() содержит PROCESSING и/или REJECTED, тогда результат true если payment.getStatus() равен PROCESSING или REJECTED, иначе результат false
27. Завершаем метод getCardList, начатый в пункте 19, возвращаем CompletableFuture.completedFuture в виде списка paymentList
28. Продолжаем выполнение метода, начатое в пункте 1
29. Ждем завершения параллельных задач getCardList и getDocumentList
30. Объединяем списки в один список result
31. Сортируем список по дате getCompleted()
32. Формируем аудит eventDTO и отправляем его в метод auditAppApi.rootPost(event) из сервиса AuditApp
33. Формируем на основе result ответ сервиса documentsResponse, добавляя в него turnovers, полученный из метода getAccountTurnoversForDocumentList, и формируя постраничный вывод
34. Обертываем documentsResponse в ResponseEntity и возвращаем его потребителю


### Создание документов
#### POST /api/document
#### метод apiDocumentPost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод createPaymentService.updatePayment(document, clientId)
3. Вызываем метод upsert(document, clientId), который выполняет следующее:
4. Получает счет плательщика accountNumber20 из документа document
5. Запрашивает accountDTO из сервиса accountApp, вызывая метод accountAppApi.idGet(accountNumber20)
6. Запрашивает список organizationDTOS organizationService.getOrganizations(clientId) из сервиса organizationApp, вызвав метод organizationAppApi.rootGet(clientId)
7. Из списка организаций извлекает организацию имеющую счет accountNumber20
8. Получает individualDTO из вызова rolesAppApi.idGet(organizationId, clientId) сервиса rolesApp
9. Проверяет права клиента, если ALL_RIGHTS или CREATE_DELETE, тогда разрешает создание документа
10. Конвертируем document в documentDTO
11. Если кпп плательщика пустой или 0, берет его из organizationDTO, полученного на шаге 7 и вставляет в documentDTO
12. Устанавливает bisId и branch из accountDTO и вставляет в documentDTO и затем валидирует его
13. Получает clientDTO из userService.getUser(clientId) сервиса userApp через метод userAppApi.userGet(clientId)
14. Передает clientDTO.getLegacyId() в documentDTO и возвращается с ним из метода upsert(document, clientId), шаг 3
15. Далее запрашиваем метод paymentService.createPayment(documentDTO) из сервиса paymentApp, вызывая его метод paymentAppApi.documentPost(documentDTO) для создания документа и конвертируем DTO обратно в Payment
16. Возвращаем этот платеж (Payment), обернув его в ResponseEntity


### Поиск шаблона
#### GET /api/template/search
#### метод apiTemplateSearchGet

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод organizationAppApi.rootGet(clientId) из микросервиса organizationApp и получаем список организаций
3. Из списка организаций получаем список соответствующих счетов, используя метод accountAppApi.rootGet(orgId.getBisId(), orgId.getBisBranch()) из микросервиса accountApp
4. С помощью метода paymentAppApi.templateSearchGet(clientId, query, null) из микросервиса paymentApp находим список шаблонов
5. Возвращаем этот список шаблонов, обернув его в ResponseEntity


### Поиск дублей документов
#### POST /api/document/duplicates
#### метод apiDocumentDuplicatesPost

1. Выдает пустой список, так как вызов метода duplicatesService.getDuplicatesList(requestBody, clientId) закоментирован

### Создание пачки импортируемых документов(createBatch)
#### POST /api/imported/
#### метод apiImportedPost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Парсим содержимое content из формата 1C в список документов DocumentDTO
3. Формируем список документов ImportedDocumentDTO
4. Вызываем метод paymentAppApi.importedPost(dboProId, documentList) из микросервиса paymentApp, передав ему список из пункта 3
5. Возвращаем объект ImportedBatchResult, полученный из метода в пункте 4., обернув его в ResponseEntity


### Создание платежей из пачки импортируемых документов(processBatch)
#### POST /api/imported/batch/{id}/process
#### метод apiImportedBatchIdProcessPost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод paymentAppApi.importedBatchIdProcessPost(batch, clientId) из микросервиса paymentApp, передавая ему id пачки документов
3. Возвращаем объект ImportedBatchResult, полученный из метода в пункте 2., обернув его в ResponseEntity


### Запрос пачки импортируемых документов
#### GET /api/imported/batch/{id}
#### метод apiImportedBatchIdProcessPost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод paymentAppApi.importedBatchIdGet(batch, dboProId, status) из микросервиса paymentApp, передавая ему id пачки документов
3. Возвращаем полученный список ImportedDocument из пункта 2., обернув его в ResponseEntity

### Удаление (Изменение статуса) импортируемого документа
#### DELETE /api/imported/document/{id}
#### метод apiImportedDocumentIdDelete 

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод paymentAppApi.importedDocumentIdDelete(id, dboProId) из микросервиса paymentApp, передавая ему id документа для удаления
3. Возвращаем ResponseEntity со статусом OK или Ошибка, в зависимости от результатов вызова метода из пункта 2. 


### Расчет комиссии
#### POST /api/document/commission/calculation
#### метод apiDocumentCommissionCalculationPost

1. Вызываем метод paymentAppApi.documentCommissionCalculationPost(documentDTO) из микросервиса paymentApp, передавая ему документ
2. Возвращаем объект PaymentCommission, полученный из пункта 1., обернув его в ResponseEntity.

### Сохранение шаблона
#### POST /api/template/save
#### метод apiTemplateSavePost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод paymentAppApi.templateIdPost(template.getId(), templateDto) из микросервиса paymentApp, передавая ему id шаблона и сам шаблон
3. Возвращаем объект Template, полученный из пункта 2., обернув его в ResponseEntity 

### Создание шаблона из документа
#### POST /api/template/create
#### метод apiTemplateCreatePost

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод paymentAppApi.templatePost(template) из микросервиса paymentApp, передавая ему шаблон
3. Возвращаем объект Template, полученный из пункта 2., обернув его в ResponseEntity

### Удаление шаблона
#### DELETE /api/template/{id}
#### метод apiTemplateIdDelete

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод paymentAppApi.templateIdDelete(templateId, dboProId) из микросервиса paymentApp, передавая ему id шаблона и dboProId 
    
### Поиск шаблона единого налогового платежа ЕНП
#### GET api/template/ENP

1. Выполнить проверку авторизирации пользователя
2. Вызывать метод GET /template/ из микросервиса paymentApp, передавая ему id шаблона равный "ENP", count=1, offset=0.

### Поиск шаблона для федеральной таможенной службы
#### GET api/template/FTS

1. Выполнить проверку авторизирации пользователя
2. Вызывать метод GET /template/ из микросервиса paymentApp, передавая ему id шаблона равный "FTS", count=1, offset=0.

### Изменение документов
#### DELETE /api/document/{id}
#### метод apiDocumentIdDelete

1. Проверяем авторизирован ли пользователь и достаем clientId из сессии
2. Вызываем метод createPaymentService.deleteDocument(documentId, clientId), который выполняет следующее:
3. Получаем документ из paymentAppApi.documentIdGet(documentId)
4. Запрашивает список organizationDTOS organizationService.getOrganizations(clientId) из сервиса organizationApp, вызвав метод organizationAppApi.rootGet(clientId)
5. Из списка организаций находим организацию имеющую такой же как в документе crmId
6. Получает individualDTO из вызова rolesAppApi.idGet(organizationId, clientId) сервиса rolesApp
7. Проверяет права клиента, если ALL_RIGHTS или CREATE_DELETE, тогда разрешает удаление документа
8. Далее запрашиваем метод paymentService.deleteDocument(documentId) в сервисе paymentApp
9. Отправляем событие в аудит.
10. Возвращаем 200(OK)

### Запрос для получения количества успешно подписанных документов при подписании пакета
#### GET /api/document/signed/count/{correlationId}
#### метод apiDocumentSignedCountCorrelationIdGet
Экспортирован из bs-app

### Отправка документов по почте/смс
#### POST /api/document/send
#### метод apiDocumentSendPost 
Экспортирован из bs-app

### Запрос на получение отправленных деталей платежа
#### GET /api/delivering-resource/{id}
#### метод apiDeliveringResourceIdGet
Экспортирован из bs-app

### 
#### POST /api/v1/refundsbp
#### метод apiV1RefundsbpPost
Описание будет добавлено позднее

### 
#### PATCH /api/v1/refundsbp/{id}/execute
#### метод apiV1RefundsbpIdExecutePatch
Описание будет добавлено позднее

### Расчет комиссии за уточнение
#### GET /api/v1/document/rectification/crm-id/{organization_id}/document-id/{operation_uid}/account/{payer_account_20}/commission
#### метод documentRectificationCommissionGet

1. Вызываем метод rbspClient.commissionGet(organizationId, operationUid, payerAccount20) из микросервиса ClarificationApi, 
передавая ему organizationId Идентификатор организации (required),
              operationUid Идентификатор организации (required)
              payerAccount20 Двадцатизначный номер счёта плательщика (required)
2. Возвращаем сумму комиссии, полученный из пункта 1., обернув его в ResponseEntity.

### Получение блокировок CDT
#### GET /api/v1/accountCdtBlockGet
#### метод accountCdtBlockGet

1. Выполняется проверка авторизирации пользователя.
2. Вызываем метод referenceAppApi.branchGet, получаем список всех бранчей (в дальнейшем планируется закешировать).
3. Для переданного БИК находим соответствующий branch.
4. Вызываем метод accountAppApi.restrictionCdtGet(branch, account20), который возвращает true,
если для счета имеется ограничение CDT, иначе false.

### Перевод документов в статус подписанных после подписания пачки документов
#### POST /api/v1/document/batch/sign/{packagesignatureId}/execute
#### метод batchSignPackageSignatureIdExecute
Экспортирован из bs-app
1. По packageSignatureId в cryptoproAppApi.packagesignatureIdsignatureGet получаем все подписи по пачке документов
2. Загружаем все документы по которым подпись в статусе Confirmed = true из payment-app,
 и запускаем по каждому из подписанных документов paymentAppApi.documentIdSignPost переводя их в статус подписанных
3. Сохраняем контрагентов в contragentAppAutomaticApi.createContragentAutoPost